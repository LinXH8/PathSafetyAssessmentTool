# code-review-graph handover

Everything here is a **local, gitignored** file/folder from PathSafetyAssessmentTool —
none of it exists in the git repo, so it has to be copied by hand onto your
colleague's checkout. This folder mirrors the repo's directory structure exactly:
copy each item to the **same relative path** inside their clone of
`PathSafetyAssessmentTool`.

## Where each file goes (relative to the repo root)

| File in this folder | Destination in colleague's repo |
|---|---|
| `.mcp.json` | `PathSafetyAssessmentTool/.mcp.json` |
| `.claude/settings.json` | `PathSafetyAssessmentTool/.claude/settings.json` |
| `.claude/settings.local.json` | `PathSafetyAssessmentTool/.claude/settings.local.json` |
| `.code-review-graph/` (whole folder) | `PathSafetyAssessmentTool/.code-review-graph/` |
| `obsidian-vault/` (whole folder) | `PathSafetyAssessmentTool/obsidian-vault/` |
| `scripts/generate_obsidian_vault.py` | `PathSafetyAssessmentTool/scripts/generate_obsidian_vault.py` |
| `scripts/generate_symbol_descriptions.py` | `PathSafetyAssessmentTool/scripts/generate_symbol_descriptions.py` |

If `.claude/` or `.code-review-graph/` don't exist yet in their checkout, just
create the folders and drop the files in.

## One more thing git can't hand over: the CLI

Install the `code-review-graph` CLI itself (not a repo file — this copy was
made from a pip package, version 2.3.1):

```sh
pip install code-review-graph
```

Confirm it resolves on PATH with `which code-review-graph`.

## Verifying it worked

1. Open Claude Code in the repo — the `SessionStart` hook runs
   `code-review-graph status` and should print node/edge/file counts matching
   what's in `.code-review-graph/graph.db`.
2. Ask Claude to use any `mcp__code-review-graph__*` tool (e.g.
   "use query_graph to find callers of X") — it should already be permitted,
   no prompt, since `.claude/settings.json` / `settings.local.json` allow-list
   these tools.
3. Edit any file — the `PostToolUse` hook (`code-review-graph update
   --skip-flows`) should fire and keep `graph.db` current from then on.
4. (Optional) Open `obsidian-vault/` as an Obsidian vault to browse the graph
   visually. To regenerate it later: `python3 scripts/generate_obsidian_vault.py`.

## Notes

- `graph.db` was built on branch `xh_dev` at commit `285f294577f0` — it's a
  snapshot as of 2026-09-01. It'll drift from their checkout until the
  `PostToolUse` hook (or a manual `code-review-graph update`) catches it up.
- Everything here is regenerable from scratch (`build_or_update_graph_tool` /
  `code-review-graph update` rebuilds `.code-review-graph/`) if you'd rather
  not copy the 22MB `graph.db` — but handing it over saves the rebuild time.
