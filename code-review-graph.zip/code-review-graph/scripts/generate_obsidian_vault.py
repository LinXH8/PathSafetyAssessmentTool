#!/usr/bin/env python3
"""Generate an Obsidian-compatible markdown vault from the code-review-graph DB.

Reads `.code-review-graph/graph.db` (SQLite) and emits one note per source
file, one per function/class/test, and one per community under
`obsidian-vault/`. Notes are wired together with Obsidian `[[wiki-links]]`
so the graph view renders function-level interdependencies.

Usage (from repo root):
    python3 scripts/generate_obsidian_vault.py           # idempotent rewrite
    python3 scripts/generate_obsidian_vault.py --clean   # wipe first
"""
from __future__ import annotations

import argparse
import ast
import json
import re
import shutil
import sqlite3
import sys
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
DB_PATH = REPO_ROOT / ".code-review-graph" / "graph.db"
DESCRIPTIONS_PATH = REPO_ROOT / ".code-review-graph" / "descriptions.json"
OUT_DIR = REPO_ROOT / "obsidian-vault"

SLUG_RE = re.compile(r"[^a-z0-9]+")

MAX_SNIPPET_LINES = 250

# Map language label → fenced-code language tag.
_LANG_FENCE = {
    "python": "python",
    "javascript": "javascript",
    "typescript": "typescript",
    "tsx": "tsx",
    "jsx": "jsx",
}

_JS_LIKE = {"javascript", "typescript", "tsx", "jsx"}

# Lazy caches — populated on first access during vault generation.
_FILE_LINES_CACHE: dict[str, list[str] | None] = {}
_PY_SYMBOL_DOCS_CACHE: dict[str, dict[tuple[int, str], str]] = {}
_PY_MODULE_DOCS_CACHE: dict[str, str | None] = {}
_AI_DESCRIPTIONS: dict[str, dict] = {}


def load_ai_descriptions() -> None:
    """Populate _AI_DESCRIPTIONS from the sidecar JSON produced by
    `generate_symbol_descriptions.py`. Silently no-ops if absent."""
    global _AI_DESCRIPTIONS
    if not DESCRIPTIONS_PATH.exists():
        _AI_DESCRIPTIONS = {}
        return
    try:
        raw = json.loads(DESCRIPTIONS_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        _AI_DESCRIPTIONS = {}
        return
    _AI_DESCRIPTIONS = raw.get("entries", {}) if isinstance(raw, dict) else {}


def lookup_ai_description(qualified_name: str) -> str | None:
    entry = _AI_DESCRIPTIONS.get(qualified_name)
    if not entry:
        return None
    desc = entry.get("description")
    return desc.strip() if isinstance(desc, str) and desc.strip() else None


def get_file_lines(abs_path: str) -> list[str] | None:
    if abs_path in _FILE_LINES_CACHE:
        return _FILE_LINES_CACHE[abs_path]
    try:
        text = Path(abs_path).read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        _FILE_LINES_CACHE[abs_path] = None
        return None
    # splitlines() drops the trailing newline; keeping it consistent across OSes.
    lines = text.splitlines()
    _FILE_LINES_CACHE[abs_path] = lines
    return lines


def _load_python_docstrings(abs_path: str) -> dict[tuple[int, str], str]:
    if abs_path in _PY_SYMBOL_DOCS_CACHE:
        return _PY_SYMBOL_DOCS_CACHE[abs_path]
    lines = get_file_lines(abs_path)
    mapping: dict[tuple[int, str], str] = {}
    module_doc: str | None = None
    if lines is not None:
        source = "\n".join(lines)
        try:
            tree = ast.parse(source)
        except (SyntaxError, ValueError):
            tree = None
        if tree is not None:
            module_doc = ast.get_docstring(tree)
            for node in ast.walk(tree):
                if isinstance(
                    node,
                    (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef),
                ):
                    doc = ast.get_docstring(node)
                    if doc:
                        mapping[(node.lineno, node.name)] = doc
    _PY_SYMBOL_DOCS_CACHE[abs_path] = mapping
    _PY_MODULE_DOCS_CACHE[abs_path] = module_doc
    return mapping


_JSDOC_BLOCK_RE = re.compile(r"/\*\*([\s\S]*?)\*/")


def _clean_jsdoc(raw: str) -> str:
    out: list[str] = []
    for line in raw.splitlines():
        stripped = line.lstrip()
        if stripped.startswith("*"):
            stripped = stripped[1:]
            if stripped.startswith(" "):
                stripped = stripped[1:]
        out.append(stripped.rstrip())
    # Drop leading/trailing blank lines.
    while out and not out[0].strip():
        out.pop(0)
    while out and not out[-1].strip():
        out.pop()
    return "\n".join(out)


def _extract_js_preceding_jsdoc(lines: list[str], line_start: int) -> str | None:
    # line_start is 1-based; look at up to 20 lines immediately above the symbol.
    end_idx = line_start - 1  # exclusive
    start_idx = max(0, end_idx - 20)
    window = "\n".join(lines[start_idx:end_idx])
    # We want the jsdoc closest to the symbol (last match in the window).
    match = None
    for m in _JSDOC_BLOCK_RE.finditer(window):
        match = m
    if not match:
        return None
    # Confirm nothing but whitespace/decorator/comment sits between the close of
    # the jsdoc and the symbol itself.
    after = window[match.end():]
    if after.strip():
        # Allow decorators/attributes, but bail if there's real code in between.
        for tail in after.splitlines():
            t = tail.strip()
            if not t:
                continue
            if t.startswith("@") or t.startswith("//"):
                continue
            return None
    cleaned = _clean_jsdoc(match.group(1))
    return cleaned or None


def extract_symbol_docstring(node: "Node") -> str | None:
    if not node.language or not node.line_start:
        return None
    lang = node.language.lower()
    if lang == "python":
        mapping = _load_python_docstrings(node.file_path)
        # Python decorators shift the node's line vs. DB line_start; try a small window.
        for delta in range(0, 10):
            key = (node.line_start + delta, node.name)
            if key in mapping:
                return mapping[key].strip() or None
        # Last-ditch: match by name alone when line drifted further.
        for (ln, name), doc in mapping.items():
            if name == node.name and abs(ln - node.line_start) <= 25:
                return doc.strip() or None
        return None
    if lang in _JS_LIKE:
        lines = get_file_lines(node.file_path)
        if lines is None:
            return None
        return _extract_js_preceding_jsdoc(lines, node.line_start)
    return None


def extract_module_docstring(abs_path: str, language: str | None) -> str | None:
    if not language:
        return None
    lang = language.lower()
    if lang == "python":
        _load_python_docstrings(abs_path)  # populates module cache as a side effect
        doc = _PY_MODULE_DOCS_CACHE.get(abs_path)
        return doc.strip() if doc else None
    if lang in _JS_LIKE:
        lines = get_file_lines(abs_path)
        if not lines:
            return None
        # Scan the top of the file for the first jsdoc block, skipping shebangs/blank lines.
        head = "\n".join(lines[:40])
        match = _JSDOC_BLOCK_RE.search(head)
        if not match:
            return None
        # Only treat it as a module doc if nothing code-like precedes it.
        before = head[: match.start()]
        for line in before.splitlines():
            s = line.strip()
            if not s:
                continue
            if s.startswith("//") or s.startswith("#!"):
                continue
            return None
        cleaned = _clean_jsdoc(match.group(1))
        return cleaned or None
    return None


def _fence_for(snippet: str) -> str:
    longest = 0
    for run in re.findall(r"`+", snippet):
        longest = max(longest, len(run))
    return "`" * max(3, longest + 1)


def extract_source_snippet(node: "Node") -> tuple[str, str] | None:
    """Return (fence, body) for a code block, or None if unavailable."""
    if not node.line_start or not node.line_end:
        return None
    lines = get_file_lines(node.file_path)
    if not lines:
        return None
    start = max(0, node.line_start - 1)
    end = min(len(lines), node.line_end)
    if start >= end:
        return None
    slice_ = lines[start:end]
    truncated = 0
    if len(slice_) > MAX_SNIPPET_LINES:
        truncated = len(slice_) - MAX_SNIPPET_LINES
        slice_ = slice_[:MAX_SNIPPET_LINES]
    body = "\n".join(slice_)
    if truncated:
        body = f"{body}\n# … (truncated, {truncated} more line{'s' if truncated != 1 else ''} — see source file)"
    fence = _fence_for(body)
    lang_tag = _LANG_FENCE.get((node.language or "").lower(), "")
    header = f"{fence}{lang_tag}" if lang_tag else fence
    return header, body + "\n" + fence


def render_description_block(doc: str, *, ai_generated: bool = False) -> list[str]:
    """Render a docstring/JSDoc/AI summary as a blockquote under `## Description`."""
    out = ["## Description", ""]
    if ai_generated:
        out.append("> *AI-generated summary*")
        out.append(">")
    for line in doc.splitlines():
        out.append(f"> {line}" if line else ">")
    out.append("")
    return out


def render_source_block(node: "Node") -> list[str]:
    result = extract_source_snippet(node)
    if result is None:
        return []
    header, body = result
    return ["## Source", "", header, body, ""]


def slugify(raw: str, max_len: int = 120) -> str:
    s = SLUG_RE.sub("-", raw.lower()).strip("-")
    if len(s) > max_len:
        s = s[-max_len:].lstrip("-")
    return s or "unnamed"


@dataclass
class Node:
    qualified_name: str
    name: str
    kind: str           # File | Function | Class | Test
    file_path: str
    line_start: int | None
    line_end: int | None
    language: str | None
    signature: str | None
    community_id: int | None
    slug: str           # unique within vault, prefixed by kind


def load_nodes(conn: sqlite3.Connection) -> dict[str, Node]:
    cur = conn.execute(
        "SELECT qualified_name, name, kind, file_path, line_start, line_end, "
        "language, signature, community_id FROM nodes"
    )
    nodes: dict[str, Node] = {}
    used_slugs: set[str] = set()
    rows = cur.fetchall()

    file_rows = [r for r in rows if r[2] == "File"]
    other_rows = [r for r in rows if r[2] != "File"]

    def assign(qn: str, name: str, kind: str, file_path: str, ls, le, lang, sig, cid) -> Node:
        prefix = {
            "File": "file-",
            "Function": "fn-",
            "Class": "cls-",
            "Test": "test-",
        }.get(kind, "node-")
        if kind == "File":
            base = slugify(_relpath(file_path))
        else:
            rel = _relpath(file_path)
            base = f"{slugify(rel)}--{slugify(name)}"
        slug = prefix + base
        # Disambiguate collisions (e.g. nested anonymous functions on same name).
        candidate = slug
        n = 2
        while candidate in used_slugs:
            candidate = f"{slug}-{n}"
            n += 1
        used_slugs.add(candidate)
        return Node(qn, name, kind, file_path, ls, le, lang, sig, cid, candidate)

    for row in file_rows + other_rows:
        qn, name, kind, file_path, ls, le, lang, sig, cid = row
        nodes[qn] = assign(qn, name, kind, file_path, ls, le, lang, sig, cid)
    return nodes


def _relpath(abs_path: str) -> str:
    try:
        return str(Path(abs_path).resolve().relative_to(REPO_ROOT))
    except ValueError:
        return abs_path


def load_communities(conn: sqlite3.Connection) -> dict[int, dict]:
    cur = conn.execute(
        "SELECT id, name, size, cohesion, dominant_language, description FROM communities"
    )
    used: set[str] = set()
    out: dict[int, dict] = {}
    for cid, name, size, cohesion, lang, desc in cur.fetchall():
        base = slugify(name)
        slug = f"com-{base}"
        candidate = slug
        n = 2
        while candidate in used:
            candidate = f"{slug}-{n}"
            n += 1
        used.add(candidate)
        out[cid] = {
            "id": cid,
            "name": name,
            "size": size,
            "cohesion": cohesion,
            "language": lang,
            "description": desc,
            "slug": candidate,
        }
    return out


def load_edges(conn: sqlite3.Connection) -> list[tuple[str, str, str, int]]:
    cur = conn.execute(
        "SELECT kind, source_qualified, target_qualified, line FROM edges"
    )
    return cur.fetchall()


def node_link(node: Node) -> str:
    display = node.name if node.kind != "File" else Path(node.file_path).name
    return f"[[{node.slug}|{display}]]"


def community_link(com: dict) -> str:
    return f"[[{com['slug']}|{com['name']}]]"


def write_file_notes(nodes, node_by_file_path, outgoing, incoming, communities):
    files_dir = OUT_DIR / "files"
    files_dir.mkdir(parents=True, exist_ok=True)

    for qn, node in nodes.items():
        if node.kind != "File":
            continue
        rel = _relpath(node.file_path)
        contains = [
            n for n in node_by_file_path.get(node.file_path, [])
            if n.kind != "File"
        ]
        contains.sort(key=lambda n: (n.line_start or 0, n.name))

        imports = []
        for (kind, tgt, line) in outgoing.get(qn, []):
            if kind != "IMPORTS_FROM":
                continue
            tgt_node = nodes.get(tgt)
            if tgt_node and tgt_node.kind == "File":
                imports.append(tgt_node)
        imports = _dedupe(imports)

        imported_by = []
        for (kind, src, line) in incoming.get(qn, []):
            if kind != "IMPORTS_FROM":
                continue
            src_node = nodes.get(src)
            if src_node and src_node.kind == "File":
                imported_by.append(src_node)
        imported_by = _dedupe(imported_by)

        com = communities.get(node.community_id) if node.community_id else None

        lines: list[str] = []
        lines.append("---")
        aliases = [node.qualified_name, rel, Path(node.file_path).name]
        lines.append(f'aliases: {_yaml_list(aliases)}')
        lines.append(f'tags: [file, {node.language or "unknown"}]')
        lines.append(f'path: "{rel}"')
        lines.append("---")
        lines.append("")
        lines.append(f"# {Path(node.file_path).name}")
        lines.append("")
        lines.append(f"**Path:** `{rel}`")
        if com:
            lines.append(f"**Community:** {community_link(com)}")
        lines.append("")

        module_doc = extract_module_docstring(node.file_path, node.language)
        if module_doc:
            lines.extend(render_description_block(module_doc))

        if contains:
            lines.append(f"## Contains ({len(contains)})")
            for n in contains:
                lr = f"{n.line_start}-{n.line_end}" if n.line_start else ""
                lines.append(f"- {node_link(n)} — *{n.kind}* `{lr}`")
            lines.append("")

        if imports:
            lines.append(f"## Imports ({len(imports)})")
            for n in imports:
                lines.append(f"- {node_link(n)}")
            lines.append("")

        if imported_by:
            lines.append(f"## Imported by ({len(imported_by)})")
            for n in imported_by:
                lines.append(f"- {node_link(n)}")
            lines.append("")

        (files_dir / f"{node.slug}.md").write_text("\n".join(lines), encoding="utf-8")


def write_symbol_notes(nodes, outgoing, incoming, communities):
    fn_dir = OUT_DIR / "functions"
    fn_dir.mkdir(parents=True, exist_ok=True)

    for qn, node in nodes.items():
        if node.kind == "File":
            continue

        file_node = nodes.get(node.file_path)
        com = communities.get(node.community_id) if node.community_id else None
        rel = _relpath(node.file_path)

        callers_internal = []
        tested_by = []
        inherits_from_reverse = []  # children classes that inherit from me
        for (kind, src, _line) in incoming.get(qn, []):
            src_node = nodes.get(src)
            if not src_node:
                continue
            if kind == "CALLS":
                callers_internal.append(src_node)
            elif kind == "TESTED_BY":
                tested_by.append(src_node)
            elif kind == "INHERITS":
                inherits_from_reverse.append(src_node)

        callees_internal = []
        callees_external: dict[str, int] = defaultdict(int)
        inherits = []  # classes I inherit from
        refs = []
        for (kind, tgt, _line) in outgoing.get(qn, []):
            if kind == "CALLS":
                tgt_node = nodes.get(tgt)
                if tgt_node:
                    callees_internal.append(tgt_node)
                else:
                    callees_external[tgt] += 1
            elif kind == "INHERITS":
                tgt_node = nodes.get(tgt)
                if tgt_node:
                    inherits.append(tgt_node)
            elif kind == "REFERENCES":
                tgt_node = nodes.get(tgt)
                if tgt_node:
                    refs.append(tgt_node)

        callers_internal = _dedupe(callers_internal)
        callees_internal = _dedupe(callees_internal)
        tested_by = _dedupe(tested_by)
        inherits = _dedupe(inherits)
        inherits_from_reverse = _dedupe(inherits_from_reverse)
        refs = _dedupe(refs)

        lines: list[str] = []
        lines.append("---")
        aliases = [node.qualified_name, node.name]
        lines.append(f'aliases: {_yaml_list(aliases)}')
        tags = [node.kind.lower(), node.language or "unknown"]
        lines.append(f'tags: [{", ".join(tags)}]')
        lines.append(f'file: "{rel}"')
        if node.line_start:
            lines.append(f'lines: "{node.line_start}-{node.line_end}"')
        lines.append("---")
        lines.append("")
        lines.append(f"# {node.name}")
        lines.append("")
        lines.append(f"**Kind:** {node.kind}")
        if file_node:
            lines.append(f"**File:** {node_link(file_node)}  `{rel}`")
        else:
            lines.append(f"**File:** `{rel}`")
        if node.line_start:
            lines.append(f"**Lines:** {node.line_start}-{node.line_end}")
        if com:
            lines.append(f"**Community:** {community_link(com)}")
        if node.signature:
            sig = node.signature.replace("`", "'")
            lines.append(f"**Signature:** `{sig}`")
        lines.append("")

        doc = extract_symbol_docstring(node)
        if doc:
            lines.extend(render_description_block(doc))
        else:
            ai_doc = lookup_ai_description(node.qualified_name)
            if ai_doc:
                lines.extend(render_description_block(ai_doc, ai_generated=True))

        lines.extend(render_source_block(node))

        if callers_internal:
            lines.append(f"## Callers ({len(callers_internal)})")
            for n in callers_internal:
                lines.append(f"- {node_link(n)}")
            lines.append("")

        if callees_internal:
            lines.append(f"## Callees ({len(callees_internal)})")
            for n in callees_internal:
                lines.append(f"- {node_link(n)}")
            lines.append("")

        if inherits:
            lines.append(f"## Inherits from ({len(inherits)})")
            for n in inherits:
                lines.append(f"- {node_link(n)}")
            lines.append("")

        if inherits_from_reverse:
            lines.append(f"## Inherited by ({len(inherits_from_reverse)})")
            for n in inherits_from_reverse:
                lines.append(f"- {node_link(n)}")
            lines.append("")

        if refs:
            lines.append(f"## References ({len(refs)})")
            for n in refs:
                lines.append(f"- {node_link(n)}")
            lines.append("")

        if tested_by:
            lines.append(f"## Tested by ({len(tested_by)})")
            for n in tested_by:
                lines.append(f"- {node_link(n)}")
            lines.append("")

        if callees_external:
            top = sorted(callees_external.items(), key=lambda x: -x[1])[:30]
            lines.append(f"## External / unresolved calls ({len(callees_external)})")
            for name, count in top:
                extra = f" ×{count}" if count > 1 else ""
                lines.append(f"- `{name}`{extra}")
            if len(callees_external) > 30:
                lines.append(f"- *... and {len(callees_external) - 30} more.*")
            lines.append("")

        (fn_dir / f"{node.slug}.md").write_text("\n".join(lines), encoding="utf-8")


def write_community_notes(nodes, communities):
    com_dir = OUT_DIR / "communities"
    com_dir.mkdir(parents=True, exist_ok=True)

    members_by_com: dict[int, list[Node]] = defaultdict(list)
    for n in nodes.values():
        if n.community_id:
            members_by_com[n.community_id].append(n)

    for cid, com in communities.items():
        members = members_by_com.get(cid, [])
        members.sort(key=lambda n: (n.kind != "File", n.file_path, n.line_start or 0))

        lines: list[str] = []
        lines.append("---")
        lines.append(f'aliases: ["{com["name"]}"]')
        lines.append(f'tags: [community, {com["language"] or "unknown"}]')
        lines.append(f'size: {com["size"]}')
        lines.append(f'cohesion: {com["cohesion"]:.4f}')
        lines.append("---")
        lines.append("")
        lines.append(f"# Community · {com['name']}")
        lines.append("")
        lines.append(f"**Size:** {com['size']} &nbsp; **Cohesion:** {com['cohesion']:.4f} "
                     f"&nbsp; **Dominant language:** {com['language'] or 'unknown'}")
        if com["description"]:
            lines.append("")
            lines.append(com["description"])
        lines.append("")
        lines.append(f"## Members ({len(members)})")
        for n in members:
            lr = f" `{n.line_start}-{n.line_end}`" if n.line_start else ""
            lines.append(f"- {node_link(n)} — *{n.kind}*{lr}")
        lines.append("")

        (com_dir / f"{com['slug']}.md").write_text("\n".join(lines), encoding="utf-8")


def write_readme(nodes, communities):
    counts = defaultdict(int)
    for n in nodes.values():
        counts[n.kind] += 1

    lines = [
        "# Code Graph Vault",
        "",
        "Auto-generated from `.code-review-graph/graph.db`. Every function, class, and file is a note; "
        "`CALLS` / `IMPORTS_FROM` / `INHERITS` / `TESTED_BY` edges render as Obsidian `[[wiki-links]]`.",
        "",
        "## How to open",
        "",
        "1. Open Obsidian → **Open folder as vault** → select this `obsidian-vault/` directory.",
        "2. Press `⌘G` (macOS) or `Ctrl+G` to toggle the graph view.",
        "3. In graph settings, enable tags `function`, `class`, `file`, `community` to color-code nodes.",
        "",
        "## Counts",
        "",
        f"- Files: **{counts['File']}**",
        f"- Functions: **{counts['Function']}**",
        f"- Classes: **{counts['Class']}**",
        f"- Tests: **{counts['Test']}**",
        f"- Communities: **{len(communities)}**",
        "",
        "## Folders",
        "",
        "- [[#Files]] — `files/` one note per source file",
        "- [[#Functions & Classes]] — `functions/` one note per symbol",
        "- [[#Communities]] — `communities/` clusters from Leiden / file grouping",
        "",
        "## Regenerate",
        "",
        "```sh",
        "python3 scripts/generate_obsidian_vault.py          # refresh in place",
        "python3 scripts/generate_obsidian_vault.py --clean  # wipe and rebuild",
        "```",
        "",
        "The code-review-graph hooks keep `graph.db` up to date on every file change; "
        "re-run the script whenever you want the vault to catch up.",
        "",
    ]
    (OUT_DIR / "README.md").write_text("\n".join(lines), encoding="utf-8")


def _dedupe(items: list[Node]) -> list[Node]:
    seen: set[str] = set()
    out: list[Node] = []
    for n in items:
        if n.qualified_name in seen:
            continue
        seen.add(n.qualified_name)
        out.append(n)
    return out


def _yaml_list(values: list[str]) -> str:
    escaped = [v.replace('"', '\\"') for v in values]
    return "[" + ", ".join(f'"{v}"' for v in escaped) + "]"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--clean", action="store_true", help="Delete OUT_DIR before generating.")
    args = parser.parse_args()

    if not DB_PATH.exists():
        print(f"ERROR: graph DB not found at {DB_PATH}", file=sys.stderr)
        return 1

    if args.clean and OUT_DIR.exists():
        shutil.rmtree(OUT_DIR)
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    load_ai_descriptions()

    uri = f"file:{DB_PATH}?mode=ro"
    conn = sqlite3.connect(uri, uri=True)
    try:
        nodes = load_nodes(conn)
        communities = load_communities(conn)
        edges = load_edges(conn)
    finally:
        conn.close()

    outgoing: dict[str, list[tuple[str, str, int]]] = defaultdict(list)
    incoming: dict[str, list[tuple[str, str, int]]] = defaultdict(list)
    for kind, src, tgt, line in edges:
        outgoing[src].append((kind, tgt, line))
        incoming[tgt].append((kind, src, line))

    node_by_file_path: dict[str, list[Node]] = defaultdict(list)
    for n in nodes.values():
        node_by_file_path[n.file_path].append(n)

    write_file_notes(nodes, node_by_file_path, outgoing, incoming, communities)
    write_symbol_notes(nodes, outgoing, incoming, communities)
    write_community_notes(nodes, communities)
    write_readme(nodes, communities)

    file_count = sum(1 for n in nodes.values() if n.kind == "File")
    sym_count = sum(1 for n in nodes.values() if n.kind != "File")
    print(
        f"Wrote vault to {OUT_DIR.relative_to(REPO_ROOT)}: "
        f"{file_count} files, {sym_count} symbols, {len(communities)} communities."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
