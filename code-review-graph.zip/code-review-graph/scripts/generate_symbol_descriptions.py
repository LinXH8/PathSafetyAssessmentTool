#!/usr/bin/env python3
"""Generate AI summaries for symbols that lack source docstrings.

Reads the code-review-graph DB to enumerate every Function/Class node,
skips symbols whose source already contains a docstring / JSDoc block,
and shells out to the `claude` CLI (Haiku by default) to produce a 2-4
sentence description for the rest. Results are cached in
`.code-review-graph/descriptions.json`, keyed by qualified name + source
hash, so re-runs only touch new/changed symbols.

The companion `generate_obsidian_vault.py` script reads this cache and
falls back to the cached description when no real docstring exists.

Usage (from repo root):
    python3 scripts/generate_symbol_descriptions.py           # incremental
    python3 scripts/generate_symbol_descriptions.py --limit 20
    python3 scripts/generate_symbol_descriptions.py --regenerate  # ignore cache
    python3 scripts/generate_symbol_descriptions.py --concurrency 4
"""
from __future__ import annotations

import argparse
import ast
import concurrent.futures
import hashlib
import json
import re
import sqlite3
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
DB_PATH = REPO_ROOT / ".code-review-graph" / "graph.db"
CACHE_PATH = REPO_ROOT / ".code-review-graph" / "descriptions.json"

MAX_SOURCE_LINES = 200  # clamp source sent to the model
DEFAULT_MODEL = "haiku"
DEFAULT_CONCURRENCY = 8
CLI_TIMEOUT_SECONDS = 120

_JSDOC_RE = re.compile(r"/\*\*[\s\S]*?\*/")


def load_cache() -> dict:
    if CACHE_PATH.exists():
        try:
            return json.loads(CACHE_PATH.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            pass
    return {"version": 1, "entries": {}}


def save_cache(cache: dict) -> None:
    CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
    CACHE_PATH.write_text(json.dumps(cache, indent=2), encoding="utf-8")


def source_hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


def has_source_docstring(source: str, language: str | None) -> bool:
    """Mirror the extraction logic in generate_obsidian_vault.py."""
    if not source:
        return False
    lang = (language or "").lower()
    if lang == "python":
        dedented = _dedent_common(source)
        try:
            tree = ast.parse(dedented)
        except (SyntaxError, ValueError):
            return False
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                if ast.get_docstring(node):
                    return True
        return False
    if lang in {"typescript", "tsx", "javascript", "jsx"}:
        # A jsdoc within the first ~500 chars usually means the function itself
        # is documented (it's either the preceding block the graph captured, or
        # an inline block at the top of the class body).
        return bool(_JSDOC_RE.search(source[:800]))
    return False


def _dedent_common(text: str) -> str:
    lines = text.splitlines()
    non_empty = [ln for ln in lines if ln.strip()]
    if not non_empty:
        return text
    common = min(len(ln) - len(ln.lstrip(" ")) for ln in non_empty)
    if common == 0:
        return text
    return "\n".join(ln[common:] if ln.strip() else ln for ln in lines)


def read_source_slice(abs_path: str, line_start: int, line_end: int) -> str | None:
    try:
        text = Path(abs_path).read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return None
    lines = text.splitlines()
    start = max(0, line_start - 1)
    end = min(len(lines), line_end)
    if start >= end:
        return None
    return "\n".join(lines[start:end])


def build_prompt(
    *,
    name: str,
    kind: str,
    rel_path: str,
    signature: str | None,
    callers: list[str],
    callees: list[str],
    language: str | None,
    source: str,
) -> str:
    kind_lower = kind.lower()
    callers_line = (
        f"Callers: {', '.join(callers[:8])}" if callers else "Callers: (none internal)"
    )
    callees_line = (
        f"Callees: {', '.join(callees[:8])}" if callees else "Callees: (none internal)"
    )
    sig_line = f"Signature: {signature}" if signature else ""
    lines = source.splitlines()
    if len(lines) > MAX_SOURCE_LINES:
        clipped = "\n".join(lines[:MAX_SOURCE_LINES])
        source = f"{clipped}\n# ... ({len(lines) - MAX_SOURCE_LINES} more lines clipped)"
    fence_lang = (language or "").lower() if language else ""

    header_lines = [
        f"Symbol: {name} ({kind})",
        f"File: {rel_path}",
    ]
    if sig_line:
        header_lines.append(sig_line)
    header_lines.append(callers_line)
    header_lines.append(callees_line)
    header = "\n".join(header_lines)

    return (
        f"Write a 2-4 sentence description of the following {kind_lower} for an Obsidian "
        f"documentation wiki. Focus on what it does and its role in the file/module. "
        f"Avoid restating the signature. Reply ONLY with the description — no preamble, "
        f"no markdown headers, no code blocks.\n\n"
        f"{header}\n\n"
        f"Source:\n```{fence_lang}\n{source}\n```"
    )


def invoke_claude(prompt: str, model: str, timeout: int) -> str | None:
    try:
        proc = subprocess.run(
            [
                "claude",
                "-p",
                "--model",
                model,
                "--no-session-persistence",
                "--output-format",
                "text",
                prompt,
            ],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        return None
    except FileNotFoundError:
        print("ERROR: `claude` CLI not found on PATH.", file=sys.stderr)
        sys.exit(2)
    if proc.returncode != 0:
        return None
    text = proc.stdout.strip()
    return text or None


def fetch_symbols(conn: sqlite3.Connection) -> list[dict]:
    cur = conn.execute(
        "SELECT qualified_name, name, kind, file_path, line_start, line_end, "
        "language, signature FROM nodes "
        "WHERE kind IN ('Function', 'Class')"
    )
    out = []
    for qn, name, kind, fp, ls, le, lang, sig in cur.fetchall():
        out.append(
            {
                "qualified_name": qn,
                "name": name,
                "kind": kind,
                "file_path": fp,
                "line_start": ls,
                "line_end": le,
                "language": lang,
                "signature": sig,
            }
        )
    return out


def fetch_edges(conn: sqlite3.Connection) -> tuple[dict[str, list[str]], dict[str, list[str]]]:
    callers: dict[str, list[str]] = {}
    callees: dict[str, list[str]] = {}
    cur = conn.execute(
        "SELECT source_qualified, target_qualified FROM edges WHERE kind = 'CALLS'"
    )
    name_by_qn: dict[str, str] = {}
    node_cur = conn.execute("SELECT qualified_name, name FROM nodes")
    for qn, nm in node_cur.fetchall():
        name_by_qn[qn] = nm
    for src, tgt in cur.fetchall():
        callees.setdefault(src, []).append(name_by_qn.get(tgt, tgt.rsplit("::", 1)[-1]))
        callers.setdefault(tgt, []).append(name_by_qn.get(src, src.rsplit("::", 1)[-1]))
    return callers, callees


def relpath(abs_path: str) -> str:
    try:
        return str(Path(abs_path).resolve().relative_to(REPO_ROOT))
    except ValueError:
        return abs_path


def process_symbol(
    *,
    sym: dict,
    callers_map: dict[str, list[str]],
    callees_map: dict[str, list[str]],
    model: str,
    timeout: int,
) -> tuple[str, dict | None, str]:
    """Return (qualified_name, cache_entry_or_None, status_message)."""
    qn = sym["qualified_name"]
    if not sym["line_start"] or not sym["line_end"]:
        return qn, None, "skip-no-lines"
    source = read_source_slice(sym["file_path"], sym["line_start"], sym["line_end"])
    if not source:
        return qn, None, "skip-no-source"
    if has_source_docstring(source, sym["language"]):
        return qn, None, "skip-has-docstring"

    prompt = build_prompt(
        name=sym["name"],
        kind=sym["kind"],
        rel_path=relpath(sym["file_path"]),
        signature=sym["signature"],
        callers=callers_map.get(qn, []),
        callees=callees_map.get(qn, []),
        language=sym["language"],
        source=source,
    )
    description = invoke_claude(prompt, model, timeout)
    if not description:
        return qn, None, "fail-no-response"

    entry = {
        "hash": source_hash(source),
        "description": description,
        "model": f"claude-cli:{model}",
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "kind": sym["kind"],
        "file": relpath(sym["file_path"]),
        "lines": f"{sym['line_start']}-{sym['line_end']}",
    }
    return qn, entry, "ok"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", default=DEFAULT_MODEL, help="Claude model alias (default: haiku)")
    parser.add_argument(
        "--concurrency",
        type=int,
        default=DEFAULT_CONCURRENCY,
        help=f"Parallel CLI invocations (default: {DEFAULT_CONCURRENCY})",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=0,
        help="Stop after N new descriptions (0 = no limit). Useful for smoke tests.",
    )
    parser.add_argument(
        "--regenerate",
        action="store_true",
        help="Ignore cached entries and re-generate all undocumented symbols.",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=CLI_TIMEOUT_SECONDS,
        help=f"Per-call timeout seconds (default: {CLI_TIMEOUT_SECONDS})",
    )
    parser.add_argument(
        "--save-every",
        type=int,
        default=10,
        help="Flush cache to disk after this many successes (default: 10).",
    )
    args = parser.parse_args()

    if not DB_PATH.exists():
        print(f"ERROR: graph DB not found at {DB_PATH}", file=sys.stderr)
        return 1

    uri = f"file:{DB_PATH}?mode=ro"
    conn = sqlite3.connect(uri, uri=True)
    try:
        symbols = fetch_symbols(conn)
        callers_map, callees_map = fetch_edges(conn)
    finally:
        conn.close()

    cache = load_cache()
    entries = cache.setdefault("entries", {})

    # Pre-filter: decide which symbols actually need work so progress numbers
    # reflect real work, not skipped-by-docstring entries.
    todo: list[dict] = []
    skipped_docstring = 0
    skipped_cache = 0
    skipped_source = 0
    for sym in symbols:
        if not sym["line_start"] or not sym["line_end"]:
            skipped_source += 1
            continue
        source = read_source_slice(sym["file_path"], sym["line_start"], sym["line_end"])
        if not source:
            skipped_source += 1
            continue
        if has_source_docstring(source, sym["language"]):
            skipped_docstring += 1
            continue
        if not args.regenerate:
            existing = entries.get(sym["qualified_name"])
            if existing and existing.get("hash") == source_hash(source):
                skipped_cache += 1
                continue
        todo.append(sym)

    if args.limit and len(todo) > args.limit:
        todo = todo[: args.limit]

    print(
        f"Symbols total: {len(symbols)} | "
        f"skipped (has docstring): {skipped_docstring} | "
        f"skipped (cached): {skipped_cache} | "
        f"skipped (no source): {skipped_source} | "
        f"to process: {len(todo)}",
        flush=True,
    )
    if not todo:
        return 0

    t0 = time.monotonic()
    done = 0
    failures = 0
    since_save = 0
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.concurrency) as ex:
        futures = {
            ex.submit(
                process_symbol,
                sym=sym,
                callers_map=callers_map,
                callees_map=callees_map,
                model=args.model,
                timeout=args.timeout,
            ): sym
            for sym in todo
        }
        for fut in concurrent.futures.as_completed(futures):
            sym = futures[fut]
            try:
                qn, entry, status = fut.result()
            except Exception as exc:  # noqa: BLE001
                failures += 1
                print(f"  ! {sym['qualified_name']}: exception {exc}", flush=True)
                continue
            done += 1
            if entry is None:
                if status.startswith("fail"):
                    failures += 1
                print(f"  · [{done}/{len(todo)}] {sym['name']} — {status}", flush=True)
                continue
            entries[qn] = entry
            since_save += 1
            elapsed = time.monotonic() - t0
            rate = done / elapsed if elapsed else 0.0
            eta = (len(todo) - done) / rate if rate else 0.0
            print(
                f"  ✓ [{done}/{len(todo)}] {sym['name']} "
                f"(rate {rate:.2f}/s, eta {eta:.0f}s)",
                flush=True,
            )
            if since_save >= args.save_every:
                save_cache(cache)
                since_save = 0

    save_cache(cache)
    print(
        f"Done. Wrote {sum(1 for e in entries.values())} cached entries "
        f"({failures} failures this run).",
        flush=True,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
