# Code Graph Vault

Auto-generated from `.code-review-graph/graph.db`. Every function, class, and file is a note; `CALLS` / `IMPORTS_FROM` / `INHERITS` / `TESTED_BY` edges render as Obsidian `[[wiki-links]]`.

## How to open

1. Open Obsidian → **Open folder as vault** → select this `obsidian-vault/` directory.
2. Press `⌘G` (macOS) or `Ctrl+G` to toggle the graph view.
3. In graph settings, enable tags `function`, `class`, `file`, `community` to color-code nodes.

## Counts

- Files: **131**
- Functions: **740**
- Classes: **29**
- Tests: **4**
- Communities: **100**

## Folders

- [[#Files]] — `files/` one note per source file
- [[#Functions & Classes]] — `functions/` one note per symbol
- [[#Communities]] — `communities/` clusters from Leiden / file grouping

## Regenerate

```sh
python3 scripts/generate_obsidian_vault.py          # refresh in place
python3 scripts/generate_obsidian_vault.py --clean  # wipe and rebuild
```

The code-review-graph hooks keep `graph.db` up to date on every file change; re-run the script whenever you want the vault to catch up.
