---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/AttributesDropdown.tsx::AttributesDropdown", "AttributesDropdown"]
tags: [function, tsx]
file: "frontend/src/pages/PathAnalysisPage/components/AttributesDropdown.tsx"
lines: "711-1046"
---

# AttributesDropdown

**Kind:** Function
**File:** [[file-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx|AttributesDropdown.tsx]]  `frontend/src/pages/PathAnalysisPage/components/AttributesDropdown.tsx`
**Lines:** 711-1046
**Community:** [[com-components-handle|components-handle]]
**Signature:** `def AttributesDropdown(({
  selectedAttributes,
  onAttributeChange
}: AttributesDropdownProps))`

## Source

```tsx
export default function AttributesDropdown({
  selectedAttributes,
  onAttributeChange
}: AttributesDropdownProps) {
  const [inputValues, setInputValues] = useState<string[]>(() =>
    selectedAttributes.map((attr) => getLabelForValue(attr))
  );
  const [openComboboxes, setOpenComboboxes] = useState<boolean[]>(selectedAttributes.map(() => false));
  // Generate stable IDs for each filter slot to use as React keys
  const [filterIds, setFilterIds] = useState<string[]>(() => selectedAttributes.map(() => Math.random().toString(36).substr(2, 9)));

  const getFilterLabel = (index: number): string => {
    const labels = ["1st", "2nd", "3rd", "4th", "5th"];
    return labels[index] || "";
  };

  const handleAttributeChange = (index: number, value: string) => {
    const newAttributes = [...selectedAttributes];

    // If "Not Selected" is chosen, clear that filter
    if (value === "Not Selected") {
      newAttributes[index] = null;
    } else {
      // Check if this attribute is already selected in another filter
      const isDuplicate = selectedAttributes.some(
        (attr, i) => attr === value && i !== index
      );

      if (isDuplicate) {
        return; // Don't allow duplicate
      }

      newAttributes[index] = value;
    }

    onAttributeChange(newAttributes);
  };

  const handleAddFilter = () => {
    if (selectedAttributes.length < 5) {
      onAttributeChange([...selectedAttributes, null]);
      setInputValues([...inputValues, ""]);
      setOpenComboboxes([...openComboboxes, false]);
      setFilterIds([...filterIds, Math.random().toString(36).substr(2, 9)]);
    }
  };

  const handleRemoveFilter = (index: number) => {
    // If there's only one filter and we're removing it, reset it to empty/null state
    if (selectedAttributes.length === 1) {
      onAttributeChange([null]);
      setInputValues([""]);
      setOpenComboboxes([false]);
      // Keep changes minimal, no need to regen ID for the single remaining slot, 
      // but conceptually it's a reset. Let's keep the existing ID or regen? 
      // Existing logic implies clearing value.
      return;
    }

    const newAttributes = selectedAttributes.filter((_, i) => i !== index);
    const newInputValues = inputValues.filter((_, i) => i !== index);
    const newOpenComboboxes = openComboboxes.filter((_, i) => i !== index);
    const newFilterIds = filterIds.filter((_, i) => i !== index);

    onAttributeChange(newAttributes);
    setInputValues(newInputValues);
    setOpenComboboxes(newOpenComboboxes);
    setFilterIds(newFilterIds);
  };

  // Reset all filters
  const handleResetFilters = () => {
    onAttributeChange([null]);
    setInputValues([""]);
    setOpenComboboxes([false]);
    setFilterIds([Math.random().toString(36).substr(2, 9)]);
  };

  // Filter attributes based on input value for each filter
  // Also exclude already-selected attributes to prevent duplicates
  // Fuzzy matching for robust search
  const fuzzyMatch = (query: string, text: string): number => {
    query = query.toLowerCase();
    text = text.toLowerCase();

    let queryIndex = 0;
    let score = 0;

    for (let i = 0; i < text.length && queryIndex < query.length; i++) {
      if (text[i] === query[queryIndex]) {
        score += 1;
        queryIndex++;
      }
    }

    return queryIndex === query.length ? score : -1; // -1 if no match
  };

  const getFilteredAttributes = (inputValue: string, currentIndex: number) => {
    let filtered = allAttributes;

    // Get the currently selected attribute for this filter
    const currentAttribute = selectedAttributes[currentIndex];

    // Exclude attributes already selected in other filters
    const selectedAttributeNames = selectedAttributes
      .filter((_, i) => i !== currentIndex) // Exclude current filter
      .filter((attr) => attr !== null) as string[];

    filtered = filtered.filter(
      (attr) =>
        // Always include the current filter's value
        attr.value === currentAttribute ||
        // Always include "Not Selected"
        attr.value === "Not Selected" ||
        // Exclude attributes selected in other filters
        !selectedAttributeNames.includes(attr.value)
    );

    // Apply search filter with smart sorting
    if (!inputValue) return filtered;

    const lowerInput = inputValue.toLowerCase();

    // Score each attribute for relevance
    const scored = filtered
      .map((attr) => {
        const lowerLabel = attr.label.toLowerCase();

        // Exact match = highest priority
        if (lowerLabel === lowerInput) return { attr, score: 1000 };

        // Starts with input = very high priority
        if (lowerLabel.startsWith(lowerInput)) return { attr, score: 900 };

        // Contains input as a word = high priority
        if (lowerLabel.includes(` ${lowerInput}`) || lowerLabel.includes(`-${lowerInput}`)) {
          return { attr, score: 800 };
        }

        // Contains input substring = medium priority
        if (lowerLabel.includes(lowerInput)) return { attr, score: 700 };

        // Fuzzy match = low priority
        const fuzzyScore = fuzzyMatch(lowerInput, lowerLabel);
        if (fuzzyScore >= 0) return { attr, score: 100 + fuzzyScore };

        // No match
        return { attr, score: -1 };
      })
      .filter((item) => item.score >= 0)
      .sort((a, b) => b.score - a.score)
      .map((item) => item.attr);

    return scored;
  };

  // Create collections with filtered attributes for each filter
  const getAttributeCollection = (inputValue: string, currentIndex: number) => {
    const items = getFilteredAttributes(inputValue, currentIndex);
    // Ensure all items are valid objects with value and label
    const validItems = items.filter(item => item && typeof item === 'object' && item.value && item.label);
    return createListCollection({
      items: validItems,
    });
  };

  const hasAnyFilter = selectedAttributes.some(attr => attr !== null);

  // Can only add more filters if we haven't reached 5 AND there are available attributes
  const selectedAttributeNames = selectedAttributes.filter((attr) => attr !== null) as string[];
  const availableAttributeCount = cyclerapAttributes.length + 1; // Total unique attributes + "Project"
  const canAddMoreFilters = selectedAttributes.length < 5 && selectedAttributeNames.length < availableAttributeCount;

  return (
    <Box
      borderWidth="1px"
      borderRadius="lg"
      p="6"
      bg="bg.panel"
    >
      {/* Header */}
      <Flex justify="space-between" align="center" mb="4">
        <Text fontSize="md" fontWeight="bold">
          Filter Segment
        </Text>
        {hasAnyFilter && (
          <Button
            variant="ghost"
            size="sm"
            onClick={handleResetFilters}
            colorPalette="red"
          >
            Clear All
          </Button>
        )}
      </Flex>

      {/* Multiple Attribute Filters */}
      <Box>
        <Text fontSize="sm" color="fg.muted" mb="4">
          Add up to 5 filters to visualize segments with multiple attributes
        </Text>

        {/* Render all filters horizontally */}
        <Flex gap="4" flexWrap="wrap" align="flex-start" mb="4">
          {selectedAttributes.map((selectedAttribute, index) => {
            const currentValue = selectedAttribute || "Not Selected";
            const inputValue = inputValues[index] || "";
            const attributeCollection = getAttributeCollection(inputValue, index);
            // Use the stable ID as the key
            const key = filterIds[index] || `fallback-${index}`;

            return (
              <Box key={key} minW="280px">
                <Text fontSize="sm" fontWeight="semibold" mb="2">
                  {getFilterLabel(index)} Filter
                </Text>
                <Flex gap="2" align="flex-end">
                  <Box flex="1">
                    <Combobox.Root
                      collection={attributeCollection}
                      value={[currentValue]}
                      open={openComboboxes[index]}
                      onOpenChange={(details) => {
                        // Keep dropdown open if there's text in the field
                        if (inputValue.length > 0) {
                          const newOpenComboboxes = [...openComboboxes];
                          newOpenComboboxes[index] = true;
                          setOpenComboboxes(newOpenComboboxes);
                        } else {
                          const newOpenComboboxes = [...openComboboxes];
                          newOpenComboboxes[index] = details.open;
                          setOpenComboboxes(newOpenComboboxes);
                        }
                      }}
                      onValueChange={(e) => {
                        // Only handle the change if a valid value is selected
                        if (e.value[0]) {
                          handleAttributeChange(index, e.value[0]);
                          // Close dropdown and clear input after selection
                          const newOpenComboboxes = [...openComboboxes];
                          newOpenComboboxes[index] = false;
                          setOpenComboboxes(newOpenComboboxes);
                          setInputValues(inputValues.map((v, i) => i === index ? "" : v));
                        }
                      }}
                      inputValue={inputValue}
                      onInputValueChange={(e) => setInputValues(inputValues.map((v, i) => i === index ? e.inputValue : v))}
                    >
# … (truncated, 86 more lines — see source file)
```

## Callees (6)
- [[fn-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx--getlabelforvalue|getLabelForValue]]
- [[fn-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx--getattributecollection|getAttributeCollection]]
- [[fn-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx--getfilterlabel|getFilterLabel]]
- [[fn-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx--handleattributechange|handleAttributeChange]]
- [[fn-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx--rendergroupedattributes|renderGroupedAttributes]]
- [[fn-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx--handleremovefilter|handleRemoveFilter]]

## External / unresolved calls (23)
- `map` ×7
- `Box` ×6
- `Flex` ×4
- `Text` ×4
- `setOpenComboboxes` ×4
- `useState` ×3
- `Button` ×3
- `setInputValues` ×2
- `substr`
- `toString`
- `random`
- `some`
- `filter`
- `Root`
- `Control`
- `Input`
- `IndicatorGroup`
- `ClearTrigger`
- `Trigger`
- `Portal`
- `Positioner`
- `Content`
- `Empty`
