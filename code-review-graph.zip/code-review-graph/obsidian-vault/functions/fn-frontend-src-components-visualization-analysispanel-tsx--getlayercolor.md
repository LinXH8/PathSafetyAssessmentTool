---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/AnalysisPanel.tsx::getLayerColor", "getLayerColor"]
tags: [function, tsx]
file: "frontend/src/components/visualization/AnalysisPanel.tsx"
lines: "37-44"
---

# getLayerColor

**Kind:** Function
**File:** [[file-frontend-src-components-visualization-analysispanel-tsx|AnalysisPanel.tsx]]  `frontend/src/components/visualization/AnalysisPanel.tsx`
**Lines:** 37-44
**Community:** [[com-visualization-width|visualization-width]]
**Signature:** `def getLayerColor((layer: string)) -> : string`

## Source

```tsx
function getLayerColor(layer: string): string {
  const colors: Record<string, string> = {
    cycling: '#00B400',
    shared:  '#E68C00',
    footpath:'#1E90FF',
  };
  return colors[layer] || '#888';
}
```

## Callers (1)
- [[fn-frontend-src-components-visualization-analysispanel-tsx--layerdot|LayerDot]]
