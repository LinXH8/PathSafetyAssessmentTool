---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/Projects/projects.tsx::handleEditSuccess", "handleEditSuccess"]
tags: [function, tsx]
file: "frontend/src/pages/Projects/projects.tsx"
lines: "268-292"
---

# handleEditSuccess

**Kind:** Function
**File:** [[file-frontend-src-pages-projects-projects-tsx|projects.tsx]]  `frontend/src/pages/Projects/projects.tsx`
**Lines:** 268-292
**Community:** [[com-projects-tag|projects-tag]]
**Signature:** `def handleEditSuccess((newName: string, newTags: string[]))`

## Source

```tsx
  const handleEditSuccess = (newName: string, newTags: string[]) => {
    if (!editingProject) return;

    const oldName = editingProject.name;

    // Update local list
    setProjectList((prev) => {
      if (!prev) return prev;
      return {
        projects: prev.projects.map((p) =>
          p.name === oldName ? { name: newName, tags: newTags } : p
        ),
      };
    });

    // If edited project is currently selected and name changed, update selection
    if (selected.has(oldName) && newName !== oldName) {
      setSelected(prev => {
        const newSet = new Set(prev);
        newSet.delete(oldName);
        newSet.add(newName);
        return newSet;
      });
    }
  };
```

## External / unresolved calls (4)
- `setProjectList`
- `map`
- `has`
- `setSelected`
