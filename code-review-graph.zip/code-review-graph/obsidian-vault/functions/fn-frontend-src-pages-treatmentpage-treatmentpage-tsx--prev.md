---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/TreatmentPage/treatmentPage.tsx::prev", "prev"]
tags: [function, tsx]
file: "frontend/src/pages/TreatmentPage/treatmentPage.tsx"
lines: "174-179"
---

# prev

**Kind:** Function
**File:** [[file-frontend-src-pages-treatmentpage-treatmentpage-tsx|treatmentPage.tsx]]  `frontend/src/pages/TreatmentPage/treatmentPage.tsx`
**Lines:** 174-179
**Community:** [[com-treatmentpage-tag|treatmentpage-tag]]
**Signature:** `def prev()`

## Source

```tsx
      setSelected(prev => {
        const newSet = new Set(prev);
        newSet.delete(oldName);
        newSet.add(newName);
        return newSet;
      });
```

## External / unresolved calls (3)
- `delete` ×2
- `add` ×2
- `has`
