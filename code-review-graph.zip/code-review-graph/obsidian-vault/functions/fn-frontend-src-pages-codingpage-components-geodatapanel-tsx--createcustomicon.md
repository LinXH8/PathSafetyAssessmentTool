---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/CodingPage/components/GeoDataPanel.tsx::createCustomIcon", "createCustomIcon"]
tags: [function, tsx]
file: "frontend/src/pages/CodingPage/components/GeoDataPanel.tsx"
lines: "121-136"
---

# createCustomIcon

**Kind:** Function
**File:** [[file-frontend-src-pages-codingpage-components-geodatapanel-tsx|GeoDataPanel.tsx]]  `frontend/src/pages/CodingPage/components/GeoDataPanel.tsx`
**Lines:** 121-136
**Community:** [[com-components-bounds|components-bounds]]
**Signature:** `def createCustomIcon((color: string))`

## Source

```tsx
const createCustomIcon = (color: string) => {
  return divIcon({
    className: "custom-polygon-marker",
    html: `<div style="
      background-color: ${color};
      width: 10px;
      height: 10px;
      border-radius: 50%;
      border: 2px solid white;
      box-shadow: 0 0 4px rgba(0,0,0,0.4);
      cursor: grab;
    "></div>`,
    iconSize: [20, 20], // Hit box size
    iconAnchor: [10, 10], // Centered (half of 20)
  });
};
```

## Callers (1)
- [[fn-frontend-src-pages-codingpage-components-geodatapanel-tsx--polygondrawingtool|PolygonDrawingTool]]

## External / unresolved calls (1)
- `divIcon`
