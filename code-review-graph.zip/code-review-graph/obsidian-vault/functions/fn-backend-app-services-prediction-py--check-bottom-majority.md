---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/prediction.py::CycleRAP_Coding_Helper._check_bottom_majority", "_check_bottom_majority"]
tags: [function, python]
file: "backend/app/services/prediction.py"
lines: "293-305"
---

# _check_bottom_majority

**Kind:** Function
**File:** [[file-backend-app-services-prediction-py|prediction.py]]  `backend/app/services/prediction.py`
**Lines:** 293-305
**Community:** [[com-services-compute|services-compute]]
**Signature:** `def _check_bottom_majority((
        mask: np.ndarray,
        img_h: int,
        img_w: int,
        fraction: float = 0.10,
        threshold: float = 0.80,
    )) -> bool`

## Source

```python
    def _check_bottom_majority(
        mask: np.ndarray,
        img_h: int,
        img_w: int,
        fraction: float = 0.10,
        threshold: float = 0.80,
    ) -> bool:
        cutoff = int(img_h * (1.0 - fraction))
        region_pixels = (img_h - cutoff) * img_w
        if region_pixels == 0:
            return False
        ratio = float(np.sum(mask[cutoff:, :])) / region_pixels
        return ratio >= threshold
```

## Callers (1)
- [[fn-backend-app-services-prediction-py--assign-attributes|_assign_attributes]]

## External / unresolved calls (3)
- `int`
- `float`
- `sum`
