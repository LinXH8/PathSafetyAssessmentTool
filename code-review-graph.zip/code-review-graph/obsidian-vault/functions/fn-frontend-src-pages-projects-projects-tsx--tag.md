---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/Projects/projects.tsx::tag", "tag"]
tags: [function, tsx]
file: "frontend/src/pages/Projects/projects.tsx"
lines: "460-462"
---

# tag

**Kind:** Function
**File:** [[file-frontend-src-pages-projects-projects-tsx|projects.tsx]]  `frontend/src/pages/Projects/projects.tsx`
**Lines:** 460-462
**Community:** [[com-projects-tag|projects-tag]]
**Signature:** `def tag()`

## Source

```tsx
                      .filter(tag =>
                        tag.toLowerCase().includes(tagInputValue.toLowerCase()) &&
                        !tagFilters.includes(tag)
```

## External / unresolved calls (3)
- `includes` ×3
- `toLowerCase` ×2
- `add`
