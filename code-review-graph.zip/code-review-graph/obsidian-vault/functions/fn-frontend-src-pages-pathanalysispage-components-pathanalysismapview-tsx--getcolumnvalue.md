---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx::getColumnValue", "getColumnValue"]
tags: [function, tsx]
file: "frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx"
lines: "814-857"
---

# getColumnValue

**Kind:** Function
**File:** [[file-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx|PathAnalysisMapView.tsx]]  `frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx`
**Lines:** 814-857
**Community:** [[com-components-handle-2|components-handle]]
**Signature:** `def getColumnValue((point: any, columnKey: string)) -> : string`

## Source

```tsx
  function getColumnValue(point: any, columnKey: string): string {
    if (columnKey === "Project") return point.projectName;
    if (columnKey === "Segment #") return (point.idx + 1).toString();
    if (columnKey === "Image Reference") return point.f.properties?.["Image Reference"] ?? "-";
    if (columnKey === "Coordinates") return `${point.latlng[0].toFixed(6)}, ${point.latlng[1].toFixed(6)}`;
    if (columnKey === "Overall Risk Score") {
      const projectDataIndex = projectsData.findIndex(p => p.projectName === point.projectName);
      const score = getOverallRiskScore(projectDataIndex, point.idx);
      return score.toFixed(2);
    }
    if (columnKey === "Overall Risk Level") {
      const projectDataIndex = projectsData.findIndex(p => p.projectName === point.projectName);
      if (projectDataIndex < 0 || !projectsData[projectDataIndex].scores) {
        return "Low";
      }

      const segmentScores = projectsData[projectDataIndex].scores[point.idx];
      if (!segmentScores) {
        return "Low";
      }

      // Overall Risk Level = maximum category from the individual crash type bands
      // (same logic as Coding Page)
      let maxRiskLevel = 0; // 0: Low, 1: Med, 2: High, 3: Extreme

      // Optimize: If backend sends "Overall Risk Level Band", use it directly (1-4)
      if (segmentScores["Overall Risk Level Band"] !== undefined) {
        // Backend 1=Low (0), 2=Med (1), 3=High (2), 4=Extreme (3)
        maxRiskLevel = (segmentScores["Overall Risk Level Band"] as number) - 1;
      }

      if (maxRiskLevel === 3) return "Extreme";
      else if (maxRiskLevel === 2) return "High";
      else if (maxRiskLevel === 1) return "Medium";
      else return "Low";
    }

    // Dynamic attribute columns
    if (!point.attributes) return "-";
    const attrValue = point.attributes[columnKey];
    const result = getAttrText(columnKey, attrValue) || "-";

    return result;
  }
```

## Callers (3)
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--col|col]]
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--point|point]]
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--attributeanalysismapview|AttributeAnalysisMapView]]

## Callees (2)
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--getoverallriskscore|getOverallRiskScore]]
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--getattrtext|getAttrText]]

## External / unresolved calls (3)
- `toFixed` ×2
- `findIndex` ×2
- `toString`
