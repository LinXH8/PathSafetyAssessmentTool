---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/Projects/projects.tsx::renderHeader", "renderHeader"]
tags: [function, tsx]
file: "frontend/src/pages/Projects/projects.tsx"
lines: "370-394"
---

# renderHeader

**Kind:** Function
**File:** [[file-frontend-src-pages-projects-projects-tsx|projects.tsx]]  `frontend/src/pages/Projects/projects.tsx`
**Lines:** 370-394
**Community:** [[com-projects-tag|projects-tag]]
**Signature:** `def renderHeader((label: string, key: string, width: number))`

## Source

```tsx
  const renderHeader = (label: string, key: string, width: number) => {
    const meta = getSortMeta(key);
    return (
      <th
        style={{ width, cursor: "pointer", userSelect: "none" }}
        onClick={(e) => handleSort(key, e)}
      >
        <div style={{ display: "flex", alignItems: "center", gap: "4px" }}>
          {label}
          {meta ? (
            <div style={{ display: "flex", alignItems: "center" }}>
              {meta.direction === 'asc' ? <LuArrowUp size={14} /> : <LuArrowDown size={14} />}
              {sortConfig.length > 1 && (
                <span style={{ fontSize: "10px", marginLeft: "2px", fontWeight: "bold" }}>
                  {meta.priority}
                </span>
              )}
            </div>
          ) : (
            <LuArrowUpDown size={14} style={{ opacity: 0.3 }} />
          )}
        </div>
      </th>
    );
  };
```

## Callers (1)
- [[fn-frontend-src-pages-projects-projects-tsx--home|Home]]

## Callees (2)
- [[fn-frontend-src-pages-projects-projects-tsx--getsortmeta|getSortMeta]]
- [[fn-frontend-src-pages-projects-projects-tsx--handlesort|handleSort]]

## External / unresolved calls (3)
- `LuArrowUp`
- `LuArrowDown`
- `LuArrowUpDown`
