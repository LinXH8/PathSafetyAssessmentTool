---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/gis_mapping.py::GIS.get_area_type", "get_area_type"]
tags: [function, python]
file: "backend/app/services/gis_mapping.py"
lines: "257-262"
---

# get_area_type

**Kind:** Function
**File:** [[file-backend-app-services-gis-mapping-py|gis_mapping.py]]  `backend/app/services/gis_mapping.py`
**Lines:** 257-262
**Community:** [[com-services-width|services-width]]
**Signature:** `def get_area_type((self, point, tol=20))`

## Source

```python
    def get_area_type(self, point, tol=20):
        pt = self.store.to_metric_point(point)
        if self._poly("inner", pt, tol): return 1
        if self._poly("industrial", pt, tol): return 4
        if self._poly("rural", pt, tol): return 3
        return 2
```

## Callees (2)
- [[fn-backend-app-services-gis-mapping-py--to-metric-point|to_metric_point]]
- [[fn-backend-app-services-gis-mapping-py--poly|_poly]]
