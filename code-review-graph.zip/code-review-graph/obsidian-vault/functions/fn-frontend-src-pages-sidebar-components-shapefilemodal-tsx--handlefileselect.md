---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/sidebar/components/ShapefileModal.tsx::handleFileSelect", "handleFileSelect"]
tags: [function, tsx]
file: "frontend/src/pages/sidebar/components/ShapefileModal.tsx"
lines: "116-121"
---

# handleFileSelect

**Kind:** Function
**File:** [[file-frontend-src-pages-sidebar-components-shapefilemodal-tsx|ShapefileModal.tsx]]  `frontend/src/pages/sidebar/components/ShapefileModal.tsx`
**Lines:** 116-121
**Community:** [[com-components-handle-7|components-handle]]
**Signature:** `def handleFileSelect((e: React.ChangeEvent<HTMLInputElement>))`

## Source

```tsx
  function handleFileSelect(e: React.ChangeEvent<HTMLInputElement>) {
    if (e.target.files) {
      const selectedFiles = Array.from(e.target.files);
      addFiles(selectedFiles);
    }
  }
```

## Callees (1)
- [[fn-frontend-src-pages-sidebar-components-shapefilemodal-tsx--addfiles|addFiles]]

## External / unresolved calls (1)
- `from`
