---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/prediction.py::CycleRAP_Coding_Helper._compute_adjroad", "_compute_adjroad"]
tags: [function, python]
file: "backend/app/services/prediction.py"
lines: "255-282"
---

# _compute_adjroad

**Kind:** Function
**File:** [[file-backend-app-services-prediction-py|prediction.py]]  `backend/app/services/prediction.py`
**Lines:** 255-282
**Community:** [[com-services-compute|services-compute]]
**Signature:** `def _compute_adjroad((
        road_mask: np.ndarray,
        crossing_mask: np.ndarray,
        img_h: int,
        img_w: int,
    )) -> tuple[str, str]`

## Source

```python
    def _compute_adjroad(
        road_mask: np.ndarray,
        crossing_mask: np.ndarray,
        img_h: int,
        img_w: int,
    ) -> tuple[str, str]:
        # Logic 1 – bottom 20 %
        bottom_start = int(0.8 * img_h)
        bottom_pixels = (img_h - bottom_start) * img_w
        bottom_road_ratio = int(np.sum(road_mask[bottom_start:, :])) / max(bottom_pixels, 1)
        crossing_in_bottom = bool(np.any(crossing_mask[bottom_start:, :]))

        if bottom_road_ratio >= 0.75 or crossing_in_bottom:
            return ("Present", "Not Present")

        # Logic 2 – half-width split
        mid_x = img_w // 2
        combined = np.clip(road_mask + crossing_mask, 0, 1)
        left_ratio = int(np.sum(combined[:, :mid_x])) / max(img_h * mid_x, 1)
        right_ratio = int(np.sum(combined[:, mid_x:])) / max(img_h * (img_w - mid_x), 1)
        max_ratio = max(left_ratio, right_ratio)

        if max_ratio > 0.07:
            return ("Present", "Not Present")
        elif max_ratio >= 0.05:
            return ("Not Present", "Present")
        else:
            return ("Not Present", "Not Present")
```

## Callers (1)
- [[fn-backend-app-services-prediction-py--assign-attributes|_assign_attributes]]

## External / unresolved calls (6)
- `int` ×4
- `max` ×4
- `sum` ×3
- `bool`
- `any`
- `clip`
