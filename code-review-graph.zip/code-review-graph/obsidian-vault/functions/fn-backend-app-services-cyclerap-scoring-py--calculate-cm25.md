---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/cyclerap_scoring.py::calculate_cm25", "calculate_cm25"]
tags: [function, python]
file: "backend/app/services/cyclerap_scoring.py"
lines: "230-249"
---

# calculate_cm25

**Kind:** Function
**File:** [[file-backend-app-services-cyclerap-scoring-py|cyclerap_scoring.py]]  `backend/app/services/cyclerap_scoring.py`
**Lines:** 230-249
**Community:** [[com-services-calculate|services-calculate]]
**Signature:** `def calculate_cm25((row: pd.Series)) -> float`

## Description

> Calculate CM25 component (speed-related incidents)

## Source

```python
def calculate_cm25(row: pd.Series) -> float:
    """Calculate CM25 component (speed-related incidents)"""
    cq25_triggers = [
        get_cond('tram_rails', row.get(TRAM_RAILS, 2)),
        get_cond('surface_deformation', row.get(SURFACE_DEFORMATION, 2)),
    ]
    cq_sum = sum(cq25_triggers)
    if cq_sum == 0:
        return 0

    cu25_factors = [
        get_risk('street_lighting', row.get(STREET_LIGHTING, 1)),
        get_risk('bicycle_speed', row.get(BICYCLE_SPEED, 1)),
        get_risk('grade', row.get(GRADE, 1)),
        get_risk('facility_width', row.get(FACILITY_WIDTH, 3)),
        get_risk('flow_direction', row.get(FLOW_DIRECTION, 1)),
        get_risk('tram_rails', row.get(TRAM_RAILS, 2)),
    ]
    cu25_product = np.prod(cu25_factors)
    return cu25_product ** (1 + cq_sum * 0.1)
```

## Callers (1)
- [[fn-backend-app-services-cyclerap-scoring-py--calculate-cyclerap-score-native|calculate_cyclerap_score_native]]

## Callees (2)
- [[fn-backend-app-services-cyclerap-scoring-py--get-cond|get_cond]]
- [[fn-backend-app-services-cyclerap-scoring-py--get-risk|get_risk]]

## External / unresolved calls (3)
- `get` ×8
- `sum`
- `prod`
