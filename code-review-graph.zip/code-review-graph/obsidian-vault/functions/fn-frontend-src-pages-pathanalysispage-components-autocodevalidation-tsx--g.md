---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/AutocodeValidation.tsx::g", "g"]
tags: [function, tsx]
file: "frontend/src/pages/PathAnalysisPage/components/AutocodeValidation.tsx"
lines: "334-334"
---

# g

**Kind:** Function
**File:** [[file-frontend-src-pages-pathanalysispage-components-autocodevalidation-tsx|AutocodeValidation.tsx]]  `frontend/src/pages/PathAnalysisPage/components/AutocodeValidation.tsx`
**Lines:** 334-334
**Community:** [[com-components-algrade|components-algrade]]
**Signature:** `def g()`

## Source

```tsx
    return GROUP_ORDER.filter(g => (validationStats[g] ?? []).length > 0);
```
