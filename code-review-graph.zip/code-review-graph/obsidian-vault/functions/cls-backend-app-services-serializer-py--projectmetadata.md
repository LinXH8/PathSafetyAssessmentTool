---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/serializer.py::ProjectMetadata", "ProjectMetadata"]
tags: [class, python]
file: "backend/app/services/serializer.py"
lines: "375-437"
---

# ProjectMetadata

**Kind:** Class
**File:** [[file-backend-app-services-serializer-py|serializer.py]]  `backend/app/services/serializer.py`
**Lines:** 375-437
**Community:** [[com-services-fields|services-fields]]
**Signature:** `class ProjectMetadata`

## Source

```python
class ProjectMetadata:
    # === INIT ===

    def __init__(self):
        self.project_name : str             = None
        self.date_created : datetime        = None
        self.last_updated : datetime        = None
        self.created_by   : str             = None
        self.dataset      : str             = None
        self.progress     : int             = None
        self.size         : int             = None
        self.tags         : list[str]       = None
        self.verified     : bool            = False
        self.verified_segment_count : int   = 0
        self.autocoded_segment_count : int  = 0

    # === SERIALIZATION ===

    def parse(self, file_path: Path):
        with open(file_path, 'r') as f:
            data = json.load(f)
            self.project_name = data.get("project_name")
            
            # Helper to safely parse datetime or date
            def parse_datetime(s):
                if not s: return None
                try:
                    return datetime.fromisoformat(s)
                except ValueError:
                    # Fallback for old date-only strings or other formats if needed
                    return None

            self.date_created = parse_datetime(data.get("date_created"))
            self.last_updated = parse_datetime(data.get("last_updated"))
            self.created_by = data.get("created_by")
            self.dataset    = data.get("dataset")
            self.progress   = data.get("progress")
            self.size       = data.get("size")
            self.tags       = data.get("tags")
            self.verified   = data.get("verified", False)
            self.verified_segment_count = data.get("verified_segment_count", 0)
            self.autocoded_segment_count = data.get("autocoded_segment_count", 0)

    def to_dict(self):
        return {
            "project_name": self.project_name,
            "date_created": self.date_created.isoformat() if self.date_created else None,
            "last_updated": self.last_updated.isoformat() if self.last_updated else None,
            "created_by": self.created_by,
            "dataset": self.dataset,
            "progress": self.progress,
            "size": self.size,
            "tags": self.tags,
            "verified": self.verified,
            "verified_segment_count": self.verified_segment_count,
            "autocoded_segment_count": self.autocoded_segment_count
        }

    def serialize(self, to_dir: Path):
        to_dir.mkdir(parents=True, exist_ok=True)
        file_path = to_dir / "project_metadata.json"
        with open(file_path, 'w') as f:
            json.dump(self.to_dict(), f, indent=4)
```
