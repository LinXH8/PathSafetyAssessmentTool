---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx::selectedAttributes", "selectedAttributes"]
tags: [function, tsx]
file: "frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx"
lines: "460-460"
---

# selectedAttributes

**Kind:** Function
**File:** [[file-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx|PathAnalysisMapView.tsx]]  `frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx`
**Lines:** 460-460
**Community:** [[com-components-handle-2|components-handle]]
**Signature:** `def selectedAttributes(())`

## Source

```tsx
  const activeFilters = useMemo(() => selectedAttributes, [selectedAttributes]);
```
