---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/CodingPage/components/AttributesPanel.tsx::groupEntries", "groupEntries"]
tags: [function, tsx]
file: "frontend/src/pages/CodingPage/components/AttributesPanel.tsx"
lines: "163-209"
---

# groupEntries

**Kind:** Function
**File:** [[file-frontend-src-pages-codingpage-components-attributespanel-tsx|AttributesPanel.tsx]]  `frontend/src/pages/CodingPage/components/AttributesPanel.tsx`
**Lines:** 163-209
**Community:** [[com-components-group|components-group]]
**Signature:** `def groupEntries((row: AttributeRow))`

## Description

> ====== Utils ======

## Source

```tsx
function groupEntries(row: AttributeRow) {
  // Build a copy of the row that includes any missing fields defined in GROUP_RULES
  // (so new attributes like "Line of Sight" appear even for old project CSVs)
  const rowWithDefaults: AttributeRow = { ...row };
  for (const group of GROUP_ORDER) {
    for (const displayName of GROUP_RULES[group]) {
      const realKey = KEY_ALIASES[displayName] ?? displayName;
      if (!(realKey in rowWithDefaults)) {
        rowWithDefaults[realKey] = null;
      }
    }
  }

  const allEntries = Object.entries(rowWithDefaults) as [string, unknown][];

  // reverse index: real key -> group & order
  const keyToGroup: Record<string, { group: string; order: number }> = {};
  for (const group of GROUP_ORDER) {
    const list = GROUP_RULES[group];
    list.forEach((displayName, i) => {
      const key = KEY_ALIASES[displayName] ?? displayName;
      keyToGroup[key] = { group, order: i };
    });
  }

  const grouped: Record<string, Array<[string, unknown]>> = Object.fromEntries(
    GROUP_ORDER.map((g) => [g, []]),
  );

  for (const [k, v] of allEntries) {
    const hit = keyToGroup[k];
    if (hit) {
      grouped[hit.group].push([k, v]);
    }
  }

  // keep original order as in GROUP_RULES
  for (const g of GROUP_ORDER) {
    grouped[g].sort((a, b) => {
      const oa = keyToGroup[a[0]]?.order ?? 1e9;
      const ob = keyToGroup[b[0]]?.order ?? 1e9;
      return oa - ob;
    });
  }

  return grouped;
}
```

## Callers (1)
- [[fn-frontend-src-pages-codingpage-components-attributespanel-tsx--attributespanel|AttributesPanel]]

## External / unresolved calls (6)
- `entries`
- `forEach`
- `fromEntries`
- `map`
- `push`
- `sort`
