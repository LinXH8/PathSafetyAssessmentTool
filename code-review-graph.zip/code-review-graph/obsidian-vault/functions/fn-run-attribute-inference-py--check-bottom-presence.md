---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/run_attribute_inference.py::check_bottom_presence", "check_bottom_presence"]
tags: [function, python]
file: "run_attribute_inference.py"
lines: "312-315"
---

# check_bottom_presence

**Kind:** Function
**File:** [[file-run-attribute-inference-py|run_attribute_inference.py]]  `run_attribute_inference.py`
**Lines:** 312-315
**Community:** [[com-pathsafetyassessmenttool-compute|pathsafetyassessmenttool-compute]]
**Signature:** `def check_bottom_presence((mask: np.ndarray, img_h: int, fraction: float)) -> bool`

## Description

> True if *any* pixel in the bottom `fraction` of the image is nonzero.

## Source

```python
def check_bottom_presence(mask: np.ndarray, img_h: int, fraction: float) -> bool:
    """True if *any* pixel in the bottom `fraction` of the image is nonzero."""
    cutoff = int(img_h * (1.0 - fraction))
    return bool(np.any(mask[cutoff:, :]))
```

## Callers (1)
- [[fn-run-attribute-inference-py--assign-attributes|assign_attributes]]

## External / unresolved calls (3)
- `int`
- `bool`
- `any`
