---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/projects/routes.py::apply_all_treatments", "apply_all_treatments"]
tags: [function, python]
file: "backend/app/api/projects/routes.py"
lines: "1655-1813"
---

# apply_all_treatments

**Kind:** Function
**File:** [[file-backend-app-api-projects-routes-py|routes.py]]  `backend/app/api/projects/routes.py`
**Lines:** 1655-1813
**Community:** [[com-projects-treatments|projects-treatments]]
**Signature:** `def apply_all_treatments((project_name: str))`

## Description

> Apply all applicable recommended treatments to all segments within a project.
>
> This endpoint analyzes each segment, identifies applicable treatments,
> and applies all recommended treatments to it.
>
> Response:
>     {
>         "ok": true,
>         "total_segments": 50,
>         "segments_treated": 48,
>         "segments_skipped": 2,
>         "details": [
>             {
>                 "segment_index": 0,
>                 "treatment_ids": [1, 9, 14],
>                 "before_scores": { "BB": 2.5, ... },
>                 "after_scores": { "BB": 1.8, ... }
>             },
>             ...
>         ]
>     }

## Source

```python
def apply_all_treatments(project_name: str):
    """
    Apply all applicable recommended treatments to all segments within a project.

    This endpoint analyzes each segment, identifies applicable treatments,
    and applies all recommended treatments to it.

    Response:
        {
            "ok": true,
            "total_segments": 50,
            "segments_treated": 48,
            "segments_skipped": 2,
            "details": [
                {
                    "segment_index": 0,
                    "treatment_ids": [1, 9, 14],
                    "before_scores": { "BB": 2.5, ... },
                    "after_scores": { "BB": 1.8, ... }
                },
                ...
            ]
        }
    """
    try:
        ctx = get_ctx()
        proj: Project = ctx["pm"].project(project_name)
        ver = proj.latest()

        # Load attributes and treatment dataframes
        attrs_df = ver.attributes.df
        treatment_df = ver.treatment.df.copy()

        # Ensure treatment dataframe has all attribute columns
        for col in attrs_df.columns:
            if col not in treatment_df.columns:
                # Initialize column with None for all rows
                treatment_df[col] = None  # Use None first for proper pandas handling

        # Ensure treatment dataframe has same number of rows as attributes dataframe
        if len(treatment_df) < len(attrs_df):
            # Expand treatment dataframe to match attributes size
            new_rows = [treatment_df.iloc[0].copy() if len(treatment_df) > 0 else {}] * (len(attrs_df) - len(treatment_df))
            treatment_df = pd.concat([treatment_df, pd.DataFrame(new_rows)], ignore_index=True)

        # Helper function to get applicable treatments for a segment
        def get_applicable_treatments(attr_row):
            # Recreate the trigger logic from frontend
            applicable = []
            for treatment in TREATMENTS:
                for trigger_set in treatment.get("triggers", []):
                    # Check if all conditions in this trigger set are met
                    all_match = True
                    for attr_name, required_values in trigger_set.items():
                        if attr_name not in attr_row:
                            all_match = False
                            break
                        if attr_row[attr_name] not in required_values:
                            all_match = False
                            break

                    if all_match:
                        applicable.append(treatment)
                        break  # Only need one trigger set to match
            return applicable

        # Process each segment
        details = []
        total_treated = 0

        for segment_index in range(len(attrs_df)):
            try:
                original_row = dict(attrs_df.iloc[segment_index])

                # Get applicable treatments for this segment
                applicable_treatments = get_applicable_treatments(original_row)

                if not applicable_treatments:
                    continue  # Skip if no applicable treatments

                # Collect all treatment IDs for this segment
                treatment_ids = [t["id"] for t in applicable_treatments]

                # Apply treatment effects
                modified_row = original_row.copy()
                for treatment in applicable_treatments:
                    for attr_name, new_value in treatment['effects'].items():
                        modified_row[attr_name] = new_value

                # Calculate before scores
                original_df = pd.DataFrame([original_row])
                before_scores_df = calculate_cyclerap_score_native(original_df)
                before_scores = {
                    "BB": float(before_scores_df["BB"].iloc[0]),
                    "BP": float(before_scores_df["BP"].iloc[0]),
                    "SB": float(before_scores_df["SB"].iloc[0]),
                    "VB": float(before_scores_df["VB"].iloc[0]),
                    "Overall Risk Level": float(before_scores_df["Overall Risk Level"].iloc[0])
                }

                # Calculate after scores
                modified_df = pd.DataFrame([modified_row])
                after_scores_df = calculate_cyclerap_score_native(modified_df)
                after_scores = {
                    "BB": float(after_scores_df["BB"].iloc[0]),
                    "BP": float(after_scores_df["BP"].iloc[0]),
                    "SB": float(after_scores_df["SB"].iloc[0]),
                    "VB": float(after_scores_df["VB"].iloc[0]),
                    "Overall Risk Level": float(after_scores_df["Overall Risk Level"].iloc[0])
                }

                # Update treatment dataframe
                if len(treatment_df) <= segment_index:
                    new_rows = [treatment_df.iloc[0].copy() if len(treatment_df) > 0 else {}] * (segment_index - len(treatment_df) + 1)
                    treatment_df = pd.concat([treatment_df, pd.DataFrame(new_rows)], ignore_index=True)

                # Update the row with modified attributes
                for col in modified_row.keys():
                    if col in treatment_df.columns:
                        treatment_df.at[segment_index, col] = modified_row[col]

                # Update "Treatments Applied" column
                if "Treatments Applied" not in treatment_df.columns:
                    treatment_df.insert(0, "Treatments Applied", "")

                treatment_df.at[segment_index, "Treatments Applied"] = ",".join(str(tid) for tid in treatment_ids)

                # Record details
                details.append({
                    "segment_index": segment_index,
                    "treatment_ids": treatment_ids,
                    "before_scores": before_scores,
                    "after_scores": after_scores
                })

                total_treated += 1

            except Exception:
                continue

        # Mark treatment dataframe as dirty but don't save yet
        # User must click "Save" button to persist changes
        # Directly assign to the existing treatment object's df property
        # This sets df_dirty=True via the property setter
        ver.treatment.df = treatment_df
        # NOTE: NOT calling proj.save_all() here - changes will be saved only when user clicks Save

        return jsonify({
            "ok": True,
            "total_segments": int(len(attrs_df)),
            "segments_treated": int(total_treated),
            "segments_skipped": int(len(attrs_df) - total_treated),
            "details": details
        })

    except Exception as e:
        import traceback
        traceback.print_exc()
        return fail(f"Error applying all treatments: {str(e)}", 500)
```

## Callees (4)
- [[fn-backend-app-api-projects-routes-py--get-ctx|get_ctx]]
- [[fn-backend-app-api-projects-routes-py--get-applicable-treatments|get_applicable_treatments]]
- [[fn-backend-app-services-cyclerap-scoring-py--calculate-cyclerap-score-native|calculate_cyclerap_score_native]]
- [[fn-backend-app-api-projects-routes-py--fail|fail]]

## External / unresolved calls (18)
- `float` ×10
- `len` ×7
- `copy` ×4
- `DataFrame` ×4
- `int` ×3
- `concat` ×2
- `str` ×2
- `project`
- `latest`
- `range`
- `dict`
- `items`
- `keys`
- `insert`
- `join`
- `append`
- `jsonify`
- `print_exc`
