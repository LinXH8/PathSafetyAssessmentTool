---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/serializer.py::LocWrapper", "LocWrapper"]
tags: [class, python]
file: "backend/app/services/serializer.py"
lines: "53-62"
---

# LocWrapper

**Kind:** Class
**File:** [[file-backend-app-services-serializer-py|serializer.py]]  `backend/app/services/serializer.py`
**Lines:** 53-62
**Community:** [[com-services-fields|services-fields]]
**Signature:** `class LocWrapper`

## Source

```python
class LocWrapper:
    def __init__(self, parent):
        self._parent = parent

    def __getitem__(self, key):
        return self._parent.df.loc[key]

    def __setitem__(self, key, value):
        self._parent.df.loc[key] = value
        self._parent.df_dirty = True
```

## Callers (2)
- [[fn-backend-app-services-serializer-py--init-2|__init__]]
- [[fn-backend-app-services-serializer-py--init-7|__init__]]
