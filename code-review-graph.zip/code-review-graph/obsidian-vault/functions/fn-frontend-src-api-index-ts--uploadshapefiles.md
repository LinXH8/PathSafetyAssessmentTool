---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/api/index.ts::uploadShapefiles", "uploadShapefiles"]
tags: [function, typescript]
file: "frontend/src/api/index.ts"
lines: "456-469"
---

# uploadShapefiles

**Kind:** Function
**File:** [[file-frontend-src-api-index-ts|index.ts]]  `frontend/src/api/index.ts`
**Lines:** 456-469
**Community:** [[com-api-project|api-project]]
**Signature:** `def uploadShapefiles((files: File[], category?: string)) -> : Promise<UploadResult>`

## Description

> Upload new shapefiles (ZIP or individual files)
> @param files - Array of File objects to upload
> @param category - Optional category/subdirectory name

## Source

```typescript
export async function uploadShapefiles(files: File[], category?: string): Promise<UploadResult> {
  const formData = new FormData();
  files.forEach(file => formData.append("files", file));
  if (category) {
    formData.append("category", category);
  }

  const res = await fetch("/api/shapefiles/upload", {
    method: "POST",
    body: formData,
  });
  if (!res.ok) throw new Error(await readError(res));
  return res.json();
}
```

## Callees (1)
- [[fn-frontend-src-api-index-ts--readerror|readError]]

## External / unresolved calls (4)
- `forEach`
- `append`
- `fetch`
- `json`
