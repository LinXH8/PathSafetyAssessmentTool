---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/serializer.py::Treatment", "Treatment"]
tags: [class, python]
file: "backend/app/services/serializer.py"
lines: "290-304"
---

# Treatment

**Kind:** Class
**File:** [[file-backend-app-services-serializer-py|serializer.py]]  `backend/app/services/serializer.py`
**Lines:** 290-304
**Community:** [[com-services-fields|services-fields]]
**Signature:** `class Treatment`

## Source

```python
class Treatment(BaseTable):
    class Fields:
        TREATMENTS_APPLIED_STR  = "Treatments Applied"
        IMAGE_REFERENCE_STR     = "Image Reference"
        TREATMENT_RANK_STR      = "Treatment Rank"
        TREATMENT_ID_STR        = "Treatment ID"
        TREATMENT_NAME_STR      = "Name"
        BB_REMEDIED_STR         = "BB"
        BP_REMEDIED_STR         = "BP"
        SB_REMEDIED_STR         = "SB"
        VB_REMEDIED_STR         = "VB"
        SCORE_REMEDIED_STR      = "Overall Risk Level"

    def __init__(self, size=0):
        super().__init__(self.Fields, size=size)
```

## Callers (1)
- [[fn-backend-app-services-cyclerap-interface-py--evaluate-treatment-suggestions|evaluate_treatment_suggestions]]
