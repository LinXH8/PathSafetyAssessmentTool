---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/sidebar/Sidebar.tsx::openShapefileModal", "openShapefileModal"]
tags: [function, tsx]
file: "frontend/src/pages/sidebar/Sidebar.tsx"
lines: "30-32"
---

# openShapefileModal

**Kind:** Function
**File:** [[file-frontend-src-pages-sidebar-sidebar-tsx|Sidebar.tsx]]  `frontend/src/pages/sidebar/Sidebar.tsx`
**Lines:** 30-32
**Community:** [[com-sidebar-shapefile|sidebar-shapefile]]
**Signature:** `def openShapefileModal(())`

## Source

```tsx
  const openShapefileModal = () => {
    setShapefileModalOpen(true);
  };
```

## External / unresolved calls (1)
- `setShapefileModalOpen`
