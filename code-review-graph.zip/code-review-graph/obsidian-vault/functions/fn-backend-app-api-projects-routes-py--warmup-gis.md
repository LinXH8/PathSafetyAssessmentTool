---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/projects/routes.py::warmup_gis", "warmup_gis"]
tags: [function, python]
file: "backend/app/api/projects/routes.py"
lines: "57-77"
---

# warmup_gis

**Kind:** Function
**File:** [[file-backend-app-api-projects-routes-py|routes.py]]  `backend/app/api/projects/routes.py`
**Lines:** 57-77
**Community:** [[com-projects-treatments|projects-treatments]]
**Signature:** `def warmup_gis(()) -> None`

## Description

> Pre-warm the GIS singleton in a background thread at app startup.
>
> Called once from create_app() so shapefiles are loaded before the first
> real request arrives, eliminating the cold-start penalty for end users.
> Any error is logged but never raised — the app remains fully functional,
> _get_gis() will just re-attempt construction on first use.

## Source

```python
def warmup_gis() -> None:
    """Pre-warm the GIS singleton in a background thread at app startup.

    Called once from create_app() so shapefiles are loaded before the first
    real request arrives, eliminating the cold-start penalty for end users.
    Any error is logged but never raised — the app remains fully functional,
    _get_gis() will just re-attempt construction on first use.
    """
    import threading

    def _warm():
        try:
            g = _get_gis()
            # Pre-load all registered layers so the first toggle is instant
            g.store.reload()
        except Exception as exc:  # pragma: no cover
            import logging
            logging.getLogger(__name__).warning("GIS warmup failed: %s", exc)

    t = threading.Thread(target=_warm, name="gis-warmup", daemon=True)
    t.start()
```

## External / unresolved calls (2)
- `Thread`
- `start`
