---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/serializer.py::ProjectMetadata.parse", "parse"]
tags: [function, python]
file: "backend/app/services/serializer.py"
lines: "393-416"
---

# parse

**Kind:** Function
**File:** [[file-backend-app-services-serializer-py|serializer.py]]  `backend/app/services/serializer.py`
**Lines:** 393-416
**Community:** [[com-services-fields|services-fields]]
**Signature:** `def parse((self, file_path: Path))`

## Source

```python
    def parse(self, file_path: Path):
        with open(file_path, 'r') as f:
            data = json.load(f)
            self.project_name = data.get("project_name")
            
            # Helper to safely parse datetime or date
            def parse_datetime(s):
                if not s: return None
                try:
                    return datetime.fromisoformat(s)
                except ValueError:
                    # Fallback for old date-only strings or other formats if needed
                    return None

            self.date_created = parse_datetime(data.get("date_created"))
            self.last_updated = parse_datetime(data.get("last_updated"))
            self.created_by = data.get("created_by")
            self.dataset    = data.get("dataset")
            self.progress   = data.get("progress")
            self.size       = data.get("size")
            self.tags       = data.get("tags")
            self.verified   = data.get("verified", False)
            self.verified_segment_count = data.get("verified_segment_count", 0)
            self.autocoded_segment_count = data.get("autocoded_segment_count", 0)
```

## Callees (1)
- [[fn-backend-app-services-serializer-py--parse-datetime|parse_datetime]]

## External / unresolved calls (3)
- `get` ×11
- `open`
- `load`
