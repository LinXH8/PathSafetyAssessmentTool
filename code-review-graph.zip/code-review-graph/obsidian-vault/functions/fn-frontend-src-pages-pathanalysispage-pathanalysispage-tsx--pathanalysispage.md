---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/pathAnalysisPage.tsx::PathAnalysisPage", "PathAnalysisPage"]
tags: [function, tsx]
file: "frontend/src/pages/PathAnalysisPage/pathAnalysisPage.tsx"
lines: "23-98"
---

# PathAnalysisPage

**Kind:** Function
**File:** [[file-frontend-src-pages-pathanalysispage-pathanalysispage-tsx|pathAnalysisPage.tsx]]  `frontend/src/pages/PathAnalysisPage/pathAnalysisPage.tsx`
**Lines:** 23-98
**Community:** [[com-pathanalysispage-load|pathanalysispage-load]]
**Signature:** `def PathAnalysisPage(())`

## Source

```tsx
export default function PathAnalysisPage() {
  const [loadedProjects] = useState<string[]>(() => loadState("loadedProjects", []));

  // Active filter attributes (passed to FilterPanel for master toggles and MapView for filtering)
  const [activeFilters, setActiveFilters] = useState<string[]>(() =>
    loadState("activeFilters", [])
  );

  // Chart data state
  const [chartData, setChartData] = useState<{
    categoryDistributionData: { category: string; count: number; color: string }[];
    primaryFocusAttribute: string | null;
    categoryStatus: { attribute: string; categories: { category: string; isActive: boolean; color: string }[] }[];
  }>({
    categoryDistributionData: [],
    primaryFocusAttribute: null,
    categoryStatus: [],
  });

  // Save state to session storage
  useEffect(() => {
    sessionStorage.setItem(SESSION_KEY_PREFIX + "activeFilters", JSON.stringify(activeFilters));
  }, [activeFilters]);

  return (
    <Box w="100%" h="100vh" overflowY="auto" p="6">
      {/* Header */}
      <Box mb="6">
        <Text fontSize="2xl" fontWeight="bold" mb="2">
          Path Analysis
        </Text>
      </Box>

      {/* Aggregated Score Band Distribution Panel */}
      {loadedProjects.length > 0 && (
        <Box mb="6">
          <AggregatedScoreBandPanel selectedProjects={loadedProjects} />
        </Box>
      )}

      {/* Filter Panel */}
      <Box mb="6">
        <FilterPanel
          activeFilters={activeFilters}
          onActiveFiltersChange={setActiveFilters}
        />
      </Box>

      {/* Map/Table Section */}
      <Box mb="6">
        <PathAnalysisMapView
          selectedProjects={loadedProjects}
          selectedAttributes={activeFilters}
          onChartDataUpdate={setChartData}
        />
      </Box>

      {/* Charts Section - Displayed Below Map/Table */}
      {chartData.primaryFocusAttribute && chartData.categoryDistributionData.length > 0 && (
        <Box
          borderWidth="1px"
          borderRadius="lg"
          p="6"
          bg="white"
          _dark={{ bg: "gray.800" }}
        >
          <AttributeDistributionChart
            categoryData={chartData.categoryDistributionData}
            selectedAttribute={chartData.primaryFocusAttribute}
            categoryStatus={chartData.categoryStatus}
          />
        </Box>
      )}
    </Box>
  );
}
```

## Callers (1)
- [[fn-frontend-src-app-tsx--app|App]]

## Callees (4)
- [[fn-frontend-src-pages-pathanalysispage-pathanalysispage-tsx--loadstate|loadState]]
- [[fn-frontend-src-pages-pathanalysispage-components-aggregatedscorebandpanel-tsx--aggregatedscorebandpanel|AggregatedScoreBandPanel]]
- [[fn-frontend-src-pages-pathanalysispage-components-filterpanel-tsx--filterpanel|FilterPanel]]
- [[fn-frontend-src-pages-pathanalysispage-components-attributedistributionchart-tsx--attributedistributionchart|AttributeDistributionChart]]

## External / unresolved calls (7)
- `Box` ×6
- `useState` ×3
- `useEffect`
- `setItem`
- `stringify`
- `Text`
- `/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx::PathAnalysisMapView`
