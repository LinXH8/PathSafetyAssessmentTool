---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/gis_mapping.py::GIS.get_curvature_visualization", "get_curvature_visualization"]
tags: [function, python]
file: "backend/app/services/gis_mapping.py"
lines: "1242-1508"
---

# get_curvature_visualization

**Kind:** Function
**File:** [[file-backend-app-services-gis-mapping-py|gis_mapping.py]]  `backend/app/services/gis_mapping.py`
**Lines:** 1242-1508
**Community:** [[com-services-width|services-width]]
**Signature:** `def get_curvature_visualization((self, point, collect_radius=5.0))`

## Description

> Generate visualization data for curvature analysis at a given point.
>
> This method returns all the data needed to visualize the curvature calculation:
> - The analysis point (red dot)
> - The 5-meter analysis window (black circle)
> - Path centerlines within the window (color-coded by type)
> - Calculated radius and width values
>
> Args:
>     point: Shapely Point or (lon, lat) tuple in WGS84
>     collect_radius: Radius in meters for the analysis window (default: 5.0m)
>
> Returns:
>     dict: Visualization data containing:
>         - point: {"lon": float, "lat": float} - Analysis point in WGS84
>         - radius: float or None - Calculated curvature radius in meters
>         - width: float or None - Path width in meters
>         - circle_geojson: GeoJSON Feature - The analysis circle
>         - paths: list[dict] - Path segments with type and coordinates
>         - layer_used: str or None - Which layer provided the data ("cycling", "shared", "footpath")

## Source

```python
    def get_curvature_visualization(self, point, collect_radius=5.0):
        """
        Generate visualization data for curvature analysis at a given point.

        This method returns all the data needed to visualize the curvature calculation:
        - The analysis point (red dot)
        - The 5-meter analysis window (black circle)
        - Path centerlines within the window (color-coded by type)
        - Calculated radius and width values

        Args:
            point: Shapely Point or (lon, lat) tuple in WGS84
            collect_radius: Radius in meters for the analysis window (default: 5.0m)

        Returns:
            dict: Visualization data containing:
                - point: {"lon": float, "lat": float} - Analysis point in WGS84
                - radius: float or None - Calculated curvature radius in meters
                - width: float or None - Path width in meters
                - circle_geojson: GeoJSON Feature - The analysis circle
                - paths: list[dict] - Path segments with type and coordinates
                - layer_used: str or None - Which layer provided the data ("cycling", "shared", "footpath")
        """
        # Convert point to metric CRS (EPSG:3414)
        pt = self.store.to_metric_point(point)

        # Calculate radius and width using the two-stage process
        min_radius, width = self.get_radius_and_width_at_point(
            point=point,
            collect_radius=collect_radius
        )

        # Create the analysis circle (5m buffer in EPSG:3414)
        circle_geom_3414 = pt.buffer(collect_radius)

        # Transform circle to WGS84 for frontend display
        from pyproj import Transformer
        transformer = Transformer.from_crs("EPSG:3414", "EPSG:4326", always_xy=True)

        # Transform circle coordinates
        circle_coords_wgs84 = []
        for x, y in circle_geom_3414.exterior.coords:
            lon, lat = transformer.transform(x, y)
            circle_coords_wgs84.append([lon, lat])

        circle_geojson = {
            "type": "Feature",
            "geometry": {
                "type": "Polygon",
                "coordinates": [circle_coords_wgs84]
            },
            "properties": {
                "radius_m": collect_radius,
                "style": {
                    "color": "#000000",
                    "weight": 2,
                    "fill": False
                }
            }
        }

        # Load path layers and collect paths within the circle
        priority = ["cycling", "shared", "footpath"]
        layer_names = {
            "cycling": "cycling_path",
            "shared": "shared_path",
            "footpath": "footpath"
        }
        color_map = {
            "cycling": [0, 180, 0],      # Green
            "shared": [230, 140, 0],     # Orange
            "footpath": [30, 144, 255]   # Blue
        }

        paths = []

        # Determine which layer was used for calculation (if any)
        # We need to run the width search again to find out which layer provided data
        found_layer = None
        current_radius = 1.0
        while current_radius <= 5.0 and found_layer is None:
            buffer_ring = pt.buffer(current_radius)
            for layer_key in priority:
                try:
                    gdf = self.store.get(layer_names[layer_key])
                    if gdf is None or gdf.empty:
                        continue

                    if gdf.crs.to_epsg() != 3414:
                        gdf = gdf.to_crs("EPSG:3414")

                    candidate_indices = list(gdf.sindex.intersection(buffer_ring.bounds))
                    if not candidate_indices:
                        continue

                    candidates = gdf.iloc[candidate_indices]
                    intersecting = candidates[candidates.intersects(buffer_ring)]

                    if not intersecting.empty:
                        found_layer = layer_key
                        break
                except Exception:
                    continue
            current_radius += 1.0

        # Collect paths from all layers within the circle for visualization
        for layer_key in priority:
            try:
                gdf = self.store.get(layer_names[layer_key])
                if gdf is None or gdf.empty:
                    continue

                # Ensure metric CRS
                if gdf.crs.to_epsg() != 3414:
                    gdf = gdf.to_crs("EPSG:3414")

                # Remove Z-coordinates if present
                if len(gdf) > 0 and gdf.geometry.iloc[0].has_z:
                    gdf.geometry = gdf.geometry.apply(
                        lambda geom: self._remove_z_coordinate(geom) if geom is not None else None
                    )

                # Filter to valid geometries
                gdf = gdf[gdf.geometry.notna() & gdf.geometry.is_valid].copy()
                if gdf.empty:
                    continue

                # Spatial query using index
                candidate_indices = list(gdf.sindex.intersection(circle_geom_3414.bounds))
                if not candidate_indices:
                    continue

                candidates = gdf.iloc[candidate_indices]
                intersecting = candidates[candidates.intersects(circle_geom_3414)]

                if intersecting.empty:
                    continue

                # Process each intersecting path
                for geom in intersecting.geometry:
                    if geom is None or geom.is_empty:
                        continue

                    try:
                        # Clip to circle
                        clipped = geom.intersection(circle_geom_3414)
                    except Exception:
                        clipped = geom.buffer(0).intersection(circle_geom_3414)

                    # Extract LineStrings from clipped geometry
                    lines = []

                    if clipped.geom_type == 'LineString':
                        lines = [clipped]
                    elif clipped.geom_type == 'MultiLineString':
                        lines = list(clipped.geoms)
                    elif clipped.geom_type == 'GeometryCollection':
                        lines = [g for g in clipped.geoms if g.geom_type == 'LineString']

                    # Transform each line to WGS84 and add to paths
                    for line in lines:
                        if line.is_empty:
                            continue

                        coords_wgs84 = []
                        for x, y in line.coords:
                            lon, lat = transformer.transform(x, y)
                            coords_wgs84.append([lon, lat])

                        paths.append({
                            "type": layer_key,
                            "color": color_map.get(layer_key, [0, 0, 0]),
                            "coordinates": coords_wgs84,
                            "is_analysis_layer": (layer_key == found_layer)
                        })

            except Exception as e:
                print(f"Warning: Error collecting paths from {layer_key} for visualization: {e}")
                continue

        # Get point coordinates in WGS84
        if isinstance(point, tuple):
            point_lon, point_lat = point
        else:
            # Transform from metric to WGS84
            point_lon, point_lat = transformer.transform(pt.x, pt.y)

        # Generate detailed diagnostics if curvature was calculated
        diagnostics = None
        if found_layer is not None and min_radius is not None:
            try:
                # Re-run calculation with details for diagnostics
                gdf = self.store.get(layer_names[found_layer])
                if gdf is not None and not gdf.empty:
                    if gdf.crs.to_epsg() != 3414:
                        gdf = gdf.to_crs("EPSG:3414")

                    if len(gdf) > 0 and gdf.geometry.iloc[0].has_z:
                        gdf.geometry = gdf.geometry.apply(
                            lambda geom: self._remove_z_coordinate(geom) if geom is not None else None
                        )

                    gdf = gdf[gdf.geometry.notna() & gdf.geometry.is_valid].copy()

                    if not gdf.empty:
                        buffer_curv = pt.buffer(collect_radius)
                        candidate_indices = list(gdf.sindex.intersection(buffer_curv.bounds))

                        if candidate_indices:
                            candidates = gdf.iloc[candidate_indices]
                            intersecting_curv = candidates[candidates.intersects(buffer_curv)]

                            if not intersecting_curv.empty:
                                from shapely.ops import linemerge, unary_union
                                merged_geom = unary_union(intersecting_curv.geometry.tolist())

                                if merged_geom.geom_type == 'MultiLineString':
                                    merged_geom = linemerge(merged_geom)

                                clipped_geom = merged_geom.intersection(buffer_curv)

                                # Get densified coordinates
                                lines_to_process = []
                                if clipped_geom.geom_type == 'LineString':
                                    lines_to_process = [clipped_geom]
                                elif clipped_geom.geom_type == 'MultiLineString':
                                    lines_to_process = list(clipped_geom.geoms)
                                elif clipped_geom.geom_type == 'GeometryCollection':
                                    lines_to_process = [g for g in clipped_geom.geoms if g.geom_type == 'LineString']

                                # Calculate with details for the first line
                                if lines_to_process:
                                    line = lines_to_process[0]
                                    if not line.is_empty and line.length >= 1.0:
                                        # Densify
                                        densified_coords = []
                                        num_points = int(line.length / 1.0)
                                        for i in range(num_points + 1):
                                            distance = min(i * 1.0, line.length)
                                            point_on_line = line.interpolate(distance)
                                            densified_coords.append((point_on_line.x, point_on_line.y))

                                        if len(densified_coords) > 0:
                                            last_coord = list(line.coords)[-1]
                                            if densified_coords[-1] != last_coord:
                                                densified_coords.append(last_coord)

                                        if len(densified_coords) >= 3:
                                            _, details = self._calculate_min_radius_triplet(densified_coords, epsilon=1e-6, return_details=True)
                                            diagnostics = details
# … (truncated, 17 more lines — see source file)
```

## Callees (5)
- [[fn-backend-app-services-gis-mapping-py--to-metric-point|to_metric_point]]
- [[fn-backend-app-utils-path-width-curvature-py--get-radius-and-width-at-point|get_radius_and_width_at_point]]
- [[fn-backend-app-services-gis-mapping-py--get|get]]
- [[fn-backend-app-services-gis-mapping-py--remove-z-coordinate|_remove_z_coordinate]]
- [[fn-backend-app-services-gis-mapping-py--calculate-min-radius-triplet|_calculate_min_radius_triplet]]

## External / unresolved calls (22)
- `list` ×6
- `intersection` ×6
- `append` ×5
- `buffer` ×4
- `len` ×4
- `transform` ×3
- `to_epsg` ×3
- `to_crs` ×3
- `intersects` ×3
- `apply` ×2
- `copy` ×2
- `notna` ×2
- `print` ×2
- `from_crs`
- `isinstance`
- `unary_union`
- `tolist`
- `linemerge`
- `int`
- `range`
- `min`
- `interpolate`
