---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/gis_layers/routes.py::_companion_extensions", "_companion_extensions"]
tags: [function, python]
file: "backend/app/api/gis_layers/routes.py"
lines: "119-122"
---

# _companion_extensions

**Kind:** Function
**File:** [[file-backend-app-api-gis-layers-routes-py|routes.py]]  `backend/app/api/gis_layers/routes.py`
**Lines:** 119-122
**Community:** [[com-gis-layers-shapefiles|gis-layers-shapefiles]]
**Signature:** `def _companion_extensions(()) -> List[str]`

## Source

```python
def _companion_extensions() -> List[str]:
    return [".shp", ".shx", ".dbf", ".prj", ".cpg", ".sbn", ".sbx",
            ".fbn", ".fbx", ".ain", ".aih", ".ixs", ".mxs", ".atx",
            ".xml", ".qmd"]
```

## Callers (3)
- [[fn-backend-app-api-gis-layers-routes-py--file-info|_file_info]]
- [[fn-backend-app-api-gis-layers-routes-py--replace-shapefiles|replace_shapefiles]]
- [[fn-backend-app-api-gis-layers-routes-py--delete-shapefile|delete_shapefile]]
