---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/TreatmentPage/treatmentDetailPage.tsx::p", "p"]
tags: [function, tsx]
file: "frontend/src/pages/TreatmentPage/treatmentDetailPage.tsx"
lines: "760-760"
---

# p

**Kind:** Function
**File:** [[file-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx|treatmentDetailPage.tsx]]  `frontend/src/pages/TreatmentPage/treatmentDetailPage.tsx`
**Lines:** 760-760
**Community:** [[com-treatmentpage-treatment|treatmentpage-treatment]]
**Signature:** `def p()`

## Source

```tsx
            const project = projectMap.find(p => p.name === projectName);
```
