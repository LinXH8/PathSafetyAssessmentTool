---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/serializer.py::SnapshotMetadata.Fields", "Fields"]
tags: [class, python]
file: "backend/app/services/serializer.py"
lines: "280-284"
---

# Fields

**Kind:** Class
**File:** [[file-backend-app-services-serializer-py|serializer.py]]  `backend/app/services/serializer.py`
**Lines:** 280-284
**Community:** [[com-services-fields|services-fields]]
**Signature:** `class Fields`

## Source

```python
    class Fields:
        CODER_NAME_STR      = "Coder Name"
        CODING_DATE_STR     = "Coding Date"
        DESCRIPTION_STR     = "Description"
        STATUS_STR          = "Status"
```
