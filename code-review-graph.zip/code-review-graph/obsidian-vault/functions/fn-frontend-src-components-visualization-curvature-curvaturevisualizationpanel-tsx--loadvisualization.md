---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/curvature/CurvatureVisualizationPanel.tsx::loadVisualization", "loadVisualization"]
tags: [function, tsx]
file: "frontend/src/components/visualization/curvature/CurvatureVisualizationPanel.tsx"
lines: "23-35"
---

# loadVisualization

**Kind:** Function
**File:** [[file-frontend-src-components-visualization-curvature-curvaturevisualizationpanel-tsx|CurvatureVisualizationPanel.tsx]]  `frontend/src/components/visualization/curvature/CurvatureVisualizationPanel.tsx`
**Lines:** 23-35
**Community:** [[com-curvature-visualization|curvature-visualization]]
**Signature:** `def loadVisualization(())`

## Source

```tsx
    async function loadVisualization() {
      try {
        setLoading(true);
        setError(null);
        const result = await fetchCurvatureVisualization(projectName, coordinates, segmentIndex);
        setData(result);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load visualization');
        
      } finally {
        setLoading(false);
      }
    }
```

## Callers (1)
- [[fn-frontend-src-components-visualization-curvature-curvaturevisualizationpanel-tsx--curvaturevisualizationpanel|CurvatureVisualizationPanel]]

## Callees (1)
- [[fn-frontend-src-api-curvaturevisualization-ts--fetchcurvaturevisualization|fetchCurvatureVisualization]]

## External / unresolved calls (3)
- `setLoading` ×2
- `setError` ×2
- `setData`
