---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/shapefile_validator.py::ShapefileValidator._validate_spatial_bounds", "_validate_spatial_bounds"]
tags: [function, python]
file: "backend/app/services/shapefile_validator.py"
lines: "277-307"
---

# _validate_spatial_bounds

**Kind:** Function
**File:** [[file-backend-app-services-shapefile-validator-py|shapefile_validator.py]]  `backend/app/services/shapefile_validator.py`
**Lines:** 277-307
**Community:** [[com-services-validate|services-validate]]
**Signature:** `def _validate_spatial_bounds((new_gdf, old_gdf)) -> Dict`

## Description

> Warn if spatial bounds differ drastically

## Source

```python
    def _validate_spatial_bounds(new_gdf, old_gdf) -> Dict:
        """Warn if spatial bounds differ drastically"""
        result = {"warning": None}

        try:
            old_bounds = old_gdf.total_bounds  # [minx, miny, maxx, maxy]
            new_bounds = new_gdf.total_bounds

            # Calculate area of bounding boxes
            old_area = (old_bounds[2] - old_bounds[0]) * (
                old_bounds[3] - old_bounds[1]
            )
            new_area = (new_bounds[2] - new_bounds[0]) * (
                new_bounds[3] - new_bounds[1]
            )

            if old_area == 0:
                return result

            area_change_pct = abs(new_area - old_area) / old_area * 100

            # Warn if bounds changed more than 30%
            if area_change_pct > 30:
                result["warning"] = (
                    f"Spatial extent changed significantly ({area_change_pct:+.1f}%). "
                    f"Verify coverage area is correct."
                )
        except Exception as e:
            logger.warning(f"Could not validate spatial bounds: {e}")

        return result
```

## Callers (1)
- [[fn-backend-app-services-shapefile-validator-py--validate-replacement|validate_replacement]]

## External / unresolved calls (2)
- `abs`
- `warning`
