---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/LandingPage/landingPage.tsx::LandingPage", "LandingPage"]
tags: [function, tsx]
file: "frontend/src/pages/LandingPage/landingPage.tsx"
lines: "8-53"
---

# LandingPage

**Kind:** Function
**File:** [[file-frontend-src-pages-landingpage-landingpage-tsx|landingPage.tsx]]  `frontend/src/pages/LandingPage/landingPage.tsx`
**Lines:** 8-53
**Community:** [[com-landingpage-landing|landingpage-landing]]
**Signature:** `def LandingPage(())`

## Source

```tsx
export default function LandingPage() {
  const navigate = useNavigate();
  const startPSAT = () => navigate("/home");

  return (
    <main className="landing-root" role="main">
      {/* 右侧品牌区：logo + 文字 */}
      <aside className="right-rail" aria-label="PSAT branding">
        <img
          src={psatLogo2}
          alt="PSAT logo"
          className="psat-logo"
          loading="eager"
          decoding="async"
          draggable={false}
        />

        <h1 className="psat-logo name">path safety assessment tool</h1>

        <p className="psat-logo description">an evidence-based risk evaluation model for active mobility users</p>

        <button
          type="button"
          className="start-btn"
          onClick={startPSAT}
          aria-label="Start PSAT"
        >
          START
        </button>
      </aside>


      <footer className="landing-footer">
        <span className="version-info">v{APP_META.version} ({APP_META.buildDate})</span>
        <img
          src={cyclerapLogo}
          alt="CycleRAP logo"
          className="cyclerap-logo-bottom"
          loading="lazy"
          decoding="async"
          draggable={false}
        />
      </footer>
    </main>
  );
}
```

## Callers (1)
- [[fn-frontend-src-app-tsx--app|App]]

## External / unresolved calls (1)
- `useNavigate`
