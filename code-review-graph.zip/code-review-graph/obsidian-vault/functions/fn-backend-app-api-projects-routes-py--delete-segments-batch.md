---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/projects/routes.py::delete_segments_batch", "delete_segments_batch"]
tags: [function, python]
file: "backend/app/api/projects/routes.py"
lines: "598-631"
---

# delete_segments_batch

**Kind:** Function
**File:** [[file-backend-app-api-projects-routes-py|routes.py]]  `backend/app/api/projects/routes.py`
**Lines:** 598-631
**Community:** [[com-projects-treatments|projects-treatments]]
**Signature:** `def delete_segments_batch((project_name))`

## Description

> Batch delete segments from a project at user-specified indices.
> POST body: { "indices": [0, 1, 5] }

## Source

```python
def delete_segments_batch(project_name):
    """
    Batch delete segments from a project at user-specified indices.
    POST body: { "indices": [0, 1, 5] }
    """
    ctx = get_ctx()
    pm = ctx["pm"]
    project = pm.project(project_name)
    if project is None:
        abort(404, description="Project not found")

    data = request.get_json()
    if not data or "indices" not in data:
        abort(400, description="Missing 'indices' in request body")

    indices = data["indices"]
    if not isinstance(indices, list):
        abort(400, description="'indices' must be a list of integers")

    # Sort indices in descending order to avoid index shifting issues if we were doing iterative deletion
    # But for batch drop it doesn't matter as much, still good practice
    # Actuallly, df.drop handles list of indices regardless of order.
    # However, for consistency and logging:
    indices = sorted(indices, reverse=True)

    try:
        project.delete_segments(indices)
    except Exception as e:
        traceback.print_exc()
        abort(500, description=f"Failed to delete segments: {e}")

    # Return updated metadata
    meta = project.metadata.to_dict() if project.metadata else {}
    return jsonify(meta)
```

## Callees (1)
- [[fn-backend-app-api-projects-routes-py--get-ctx|get_ctx]]

## External / unresolved calls (9)
- `abort` ×4
- `project`
- `get_json`
- `isinstance`
- `sorted`
- `delete_segments`
- `print_exc`
- `to_dict`
- `jsonify`
