---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/ShapefileManagement/components/ReplaceShapefileView.tsx::handleReplace", "handleReplace"]
tags: [function, tsx]
file: "frontend/src/pages/ShapefileManagement/components/ReplaceShapefileView.tsx"
lines: "93-158"
---

# handleReplace

**Kind:** Function
**File:** [[file-frontend-src-pages-shapefilemanagement-components-replaceshapefileview-tsx|ReplaceShapefileView.tsx]]  `frontend/src/pages/ShapefileManagement/components/ReplaceShapefileView.tsx`
**Lines:** 93-158
**Community:** [[com-components-handle-4|components-handle]]
**Signature:** `def handleReplace(())`

## Source

```tsx
  async function handleReplace() {
    // First, upload files to temp location
    const filesWithoutTarget = uploadedFiles.filter((f) => !f.targetPath);
    if (filesWithoutTarget.length > 0) {
      toaster.create({
        description: "Please select a target shapefile for all uploaded files",
        type: "warning",
      });
      return;
    }

    try {
      setUploading(true);

      // Step 1: Upload files to temporary category
      const uploadResult = await api.uploadShapefiles(
        uploadedFiles.map((uf) => uf.file),
        "temp_replace"
      );

      if (uploadResult.errors.length > 0) {
        toaster.create({
          description: `Upload failed: ${uploadResult.errors.join(", ")}`,
          type: "error",
        });
        return;
      }

      setUploading(false);
      setReplacing(true);

      // Step 2: Perform replacements
      const replacements = uploadedFiles.map((uf, idx) => {
        // Find the uploaded file path from result
        const uploaded = uploadResult.uploaded[idx];
        return {
          uploaded_path: `temp_replace/${uploaded.name}`,
          target_path: uf.targetPath!,
        };
      });

      const replaceResult = await api.replaceShapefiles(replacements);

      if (replaceResult.errors.length > 0) {
        toaster.create({
          description: `Replaced ${replaceResult.count} with ${replaceResult.errors.length} error(s)`,
          type: "warning",
        });
      } else {
        toaster.create({
          description: `Successfully replaced ${replaceResult.count} shapefile(s)`,
          type: "success",
        });
      }

      onComplete();
    } catch (error) {
      toaster.create({
        description: `Replace failed: ${error}`,
        type: "error",
      });
    } finally {
      setUploading(false);
      setReplacing(false);
    }
  }
```

## External / unresolved calls (9)
- `create` ×5
- `setUploading` ×3
- `map` ×2
- `setReplacing` ×2
- `filter`
- `uploadShapefiles`
- `join`
- `replaceShapefiles`
- `onComplete`
