---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/serializer.py::data_loader.APIcall", "APIcall"]
tags: [function, python]
file: "backend/app/services/serializer.py"
lines: "511-520"
---

# APIcall

**Kind:** Function
**File:** [[file-backend-app-services-serializer-py|serializer.py]]  `backend/app/services/serializer.py`
**Lines:** 511-520
**Community:** [[com-services-fields|services-fields]]
**Signature:** `def APIcall((cls, url)) -> pd.DataFrame`

## Source

```python
    def APIcall(cls, url) -> pd.DataFrame: 
        headers = {
            "AccountKey": cls.key,
            "accept": "application/json",
        }
        resp = requests.get(url, headers=headers)
        resp.raise_for_status()
        payload = resp.json()
        records = payload.get("value", payload)
        return pd.json_normalize(records)
```

## Callers (2)
- [[fn-backend-app-services-serializer-py--gettrafficflow-df|getTrafficFlow_df]]
- [[fn-backend-app-services-serializer-py--gettrafficspeedbands-df|getTrafficSpeedBands_df]]

## External / unresolved calls (4)
- `get` ×2
- `raise_for_status`
- `json`
- `json_normalize`
