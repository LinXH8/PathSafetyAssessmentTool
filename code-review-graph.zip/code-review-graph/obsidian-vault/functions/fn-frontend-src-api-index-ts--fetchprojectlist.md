---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/api/index.ts::fetchProjectList", "fetchProjectList"]
tags: [function, typescript]
file: "frontend/src/api/index.ts"
lines: "26-30"
---

# fetchProjectList

**Kind:** Function
**File:** [[file-frontend-src-api-index-ts|index.ts]]  `frontend/src/api/index.ts`
**Lines:** 26-30
**Community:** [[com-api-project|api-project]]
**Signature:** `def fetchProjectList(()) -> : Promise<FileResponse>`

## Source

```typescript
export async function fetchProjectList(): Promise<FileResponse> {
  const res = await fetch('/api/projects')
  if (!res.ok) throw new Error('Failed /api/projects')
  return res.json()
}
```

## Callers (8)
- [[fn-frontend-src-pages-analysispage-analysispage-tsx--analysispage|AnalysisPage]]
- [[fn-frontend-src-pages-createprojectpage-createprojectpage-tsx--loadfolders|loadFolders]]
- [[fn-frontend-src-pages-home-home-tsx--home|Home]]
- [[fn-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx--addsegmentsdialog|AddSegmentsDialog]]
- [[fn-frontend-src-pages-posttreatmentanalysispage-posttreatmentanalysispage-tsx--posttreatmentanalysispage|PostTreatmentAnalysisPage]]
- [[fn-frontend-src-pages-pretreatmentanalysispage-pretreatmentanalysispage-tsx--pretreatmentanalysispage|PreTreatmentAnalysisPage]]
- [[fn-frontend-src-pages-projects-projects-tsx--home|Home]]
- [[fn-frontend-src-pages-treatmentpage-treatmentpage-tsx--treatmentpage|TreatmentPage]]

## External / unresolved calls (2)
- `fetch`
- `json`
