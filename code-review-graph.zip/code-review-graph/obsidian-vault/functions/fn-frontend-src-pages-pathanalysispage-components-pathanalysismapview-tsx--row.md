---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx::row", "row"]
tags: [function, tsx]
file: "frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx"
lines: "1410-1410"
---

# row

**Kind:** Function
**File:** [[file-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx|PathAnalysisMapView.tsx]]  `frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx`
**Lines:** 1410-1410
**Community:** [[com-components-handle-2|components-handle]]
**Signature:** `def row()`

## Source

```tsx
      .map(row => row.map(escapeCSV).join(","))
```

## External / unresolved calls (4)
- `Number`
- `isNaN`
- `join`
- `map`
