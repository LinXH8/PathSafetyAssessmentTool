---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/projects/routes.py::_log_incoming", "_log_incoming"]
tags: [function, python]
file: "backend/app/api/projects/routes.py"
lines: "541-542"
---

# _log_incoming

**Kind:** Function
**File:** [[file-backend-app-api-projects-routes-py|routes.py]]  `backend/app/api/projects/routes.py`
**Lines:** 541-542
**Community:** [[com-projects-treatments|projects-treatments]]
**Signature:** `def _log_incoming(())`

## Source

```python
def _log_incoming():
    print(f"[Flask] >>> {request.method} {request.path}", flush=True)
```

## External / unresolved calls (1)
- `print`
