---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/width/WidthVisualizationPanel.tsx::getCategoryColor", "getCategoryColor"]
tags: [function, tsx]
file: "frontend/src/components/visualization/width/WidthVisualizationPanel.tsx"
lines: "62-69"
---

# getCategoryColor

**Kind:** Function
**File:** [[file-frontend-src-components-visualization-width-widthvisualizationpanel-tsx|WidthVisualizationPanel.tsx]]  `frontend/src/components/visualization/width/WidthVisualizationPanel.tsx`
**Lines:** 62-69
**Community:** [[com-width-visualization|width-visualization]]
**Signature:** `def getCategoryColor((category: number)) -> : string`

## Source

```tsx
  const getCategoryColor = (category: number): string => {
    switch (category) {
      case 1: return '#E74C3C'; // Red for Very Narrow
      case 2: return '#F39C12'; // Orange for Narrow
      case 3: return '#27AE60'; // Green for Wide
      default: return '#95A5A6';
    }
  };
```

## Callers (1)
- [[fn-frontend-src-components-visualization-width-widthvisualizationpanel-tsx--widthvisualizationpanel|WidthVisualizationPanel]]
