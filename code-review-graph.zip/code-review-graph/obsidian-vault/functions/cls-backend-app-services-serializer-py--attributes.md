---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/serializer.py::Attributes", "Attributes"]
tags: [class, python]
file: "backend/app/services/serializer.py"
lines: "144-253"
---

# Attributes

**Kind:** Class
**File:** [[file-backend-app-services-serializer-py|serializer.py]]  `backend/app/services/serializer.py`
**Lines:** 144-253
**Community:** [[com-services-fields|services-fields]]
**Signature:** `class Attributes`

## Source

```python
class Attributes(BaseTable):
    class Fields:
        AREA_TYPE_STR                   = "Area type"
        FACILITY_TYPE_STR               = "Facility Type"
        FACILITY_ACCESS_STR             = "Facility access"
        LINE_OF_SIGHT_STR               = "Line of Sight"
        LOOSE_SLIPPERY_SURFACE_STR      = "Loose or slippery surface"
        TRAM_TRAIN_RAIL_STR             = "Tram or Train Rails"
        DEFORMATION_DRAIN_STR           = "Major Surface Deformation or Drain Opening"
        FIXED_OBSTACLE_STR              = "Fixed Obstacle on Facility"
        FIXED_OBSTACLE_TYPE_STR         = "FO Type"
        NON_FIXED_OBSTACLE_STR          = "Non-Fixed Obstacle on Facility"
        NON_FIXED_OBSTACLE_TYPE_STR     = "NFO Type"
        DELINEATION_STR                 = "Delineation"
        LIGHT_SEGREGATION_STR           = "Light Segregation"
        FACILITY_WIDTH_STR              = "Facility Width per Direction"
        FLOW_DIR_STR                    = "Flow Direction"
        WIDTH_RESTRICTION_STR           = "Width Restriction"
        ADJ_ROAD_LANE_01M_STR           = "Adjacent Road Lane 0-1m"
        ADJ_VHCL_PARKING_01M_STR        = "Adjacent Vehicle Parking 0-1m"
        ADJ_SVR_PARKING_01M_STR         = "Adjacent Severe Hazard 0-1m"
        ADJ_OBJ_LVL_CHGE_01M_STR        = "Adjacent object or level change 0-1m"
        ADJ_SIDEWALK_01M_STR            = "Adjacent Sidewalk 0-1m"
        ADJ_ROAD_LANE_13M_STR           = "Adjacent Road Lane 1-3m"
        ADJ_VHCL_PARKING_13M_STR        = "Adjacent Vehicle Parking 1-3m"
        ADJ_SVR_HAZARD_13M_STR          = "Adjacent Severe Hazard 1-3m"
        ADJ_OBJ_LVL_CHGE_13M_STR        = "Adjacent object or level change 1-3m"
        ADJ_SIDEWALK_13M_STR            = "Adjacent Sidewalk 1-3m"
        GRADE_STR                       = "Grade"
        CURV_STR                        = "Curvature"
        STREET_LIGHT_STR                = "Street Lighting"
        PED_CROSS_STR                   = "Pedestrian Crossing"
        INTERSECT_FACILITY_STR          = "Intersecting Bicycle Facility"
        INTERSECT_APPRCH_STR            = "Intersection Approach"
        INTERSECT_ROAD_CROSS_STR        = "Intersection or Road Crossing"
        CROSS_FACILITY_STR              = "Crossing Facility"
        CROSSING_TYPE_STR               = "Crossing Type"
        NOL_ADJ_ROAD_STR                = "Number of lanes – adjacent road"
        NOL_INTERSECT_ROAD_STR          = "Number of lanes – intersecting road"
        PROP_ACCESS_STR                 = "Property Access"
        PEAK_PED_FLOW_STR               = "Peak pedestrian flow along or across facility"
        PEAK_BICYCLE_TRAFFIC_FLOW_STR   = "Peak bicycle/LV traffic flow"
        OBSERVED_PROPORTION_STR         = "Observed proportion of cargo bikes and mopeds"
        BICYCLE_SPD_AVG_STR             = "Bicycle/LV speed – average"
        BICYCLE_SPD_DIFF_STR            = "Bicycle/LV speed differential"
        ROAD_AADT_STR                   = "Road AADT"
        HEAVY_VHCL_FLOW_STR             = "Heavy vehicle flow"
        SPD_LIMIT_STR                   = "Road speed limit"
        ROAD_OPR_SPEED_AVG_STR          = "Road operating speed (mean)"
        SPEED_UNIT_STR                  = "Road operating speed (unit)"
        FACILITY_WIDTH_SUBCAT_STR       = "Facility Width Sub-category"
        CURVATURE_SUBCAT_STR            = "Curvature Sub-category"

        @classmethod
        def values(cls) -> list[str]:
            return [v for k, v in cls.__dict__.items() if not k.startswith("__") and isinstance(v, str)]

    CHOICES = {
        Fields.AREA_TYPE_STR:                   area_type_mapping,
        Fields.FACILITY_TYPE_STR:               facility_type_mapping,
        Fields.FACILITY_ACCESS_STR:             adequecy_mapping,
        "Line of Sight":                        adequecy_mapping,
        Fields.LOOSE_SLIPPERY_SURFACE_STR:      presence_mapping,
        Fields.TRAM_TRAIN_RAIL_STR:             presence_mapping,
        Fields.DEFORMATION_DRAIN_STR:           presence_mapping,
        Fields.FIXED_OBSTACLE_STR:              presence_mapping,
        Fields.FIXED_OBSTACLE_TYPE_STR:         None,
        Fields.NON_FIXED_OBSTACLE_STR:          presence_mapping,
        Fields.NON_FIXED_OBSTACLE_TYPE_STR:     None,
        Fields.DELINEATION_STR:                 presence_mapping,
        Fields.LIGHT_SEGREGATION_STR:           presence_mapping,
        Fields.FACILITY_WIDTH_STR:              facility_width_mapping,
        Fields.FLOW_DIR_STR:                    flow_direction_mapping,
        Fields.WIDTH_RESTRICTION_STR:           presence_mapping,
        Fields.ADJ_ROAD_LANE_01M_STR:           presence_mapping,
        Fields.ADJ_VHCL_PARKING_01M_STR:        presence_mapping,
        Fields.ADJ_SVR_PARKING_01M_STR:         presence_mapping,
        Fields.ADJ_OBJ_LVL_CHGE_01M_STR:        presence_mapping,
        Fields.ADJ_SIDEWALK_01M_STR:            presence_mapping,
        Fields.ADJ_ROAD_LANE_13M_STR:           presence_mapping,
        Fields.ADJ_VHCL_PARKING_13M_STR:        presence_mapping,
        Fields.ADJ_SVR_HAZARD_13M_STR:          presence_mapping,
        Fields.ADJ_OBJ_LVL_CHGE_13M_STR:        presence_mapping,
        Fields.ADJ_SIDEWALK_13M_STR:            presence_mapping,
        Fields.GRADE_STR:                       within_5deg_mapping,
        Fields.CURV_STR:                        sharp_turn_mapping,
        Fields.STREET_LIGHT_STR:                presence_mapping,
        Fields.PED_CROSS_STR:                   presence_mapping,
        Fields.INTERSECT_FACILITY_STR:          presence_mapping,
        Fields.INTERSECT_APPRCH_STR:            shared_mapping,
        Fields.INTERSECT_ROAD_CROSS_STR:        presence_mapping,
        Fields.CROSS_FACILITY_STR:              presence_mapping,
        Fields.CROSSING_TYPE_STR:               None,
        Fields.NOL_ADJ_ROAD_STR:                NoL_mapping,
        Fields.NOL_INTERSECT_ROAD_STR:          NoL_mapping,
        Fields.PROP_ACCESS_STR:                 presence_mapping,
        Fields.PEAK_PED_FLOW_STR:               none_low_modhigh_mapping,
        Fields.PEAK_BICYCLE_TRAFFIC_FLOW_STR:   low_modhigh_mapping,
        Fields.OBSERVED_PROPORTION_STR:         low_modhigh_mapping,
        Fields.BICYCLE_SPD_AVG_STR:             less_more_20_mapping,
        Fields.BICYCLE_SPD_DIFF_STR:            less_more_10_mapping,
        Fields.ROAD_AADT_STR:                   None,
        Fields.HEAVY_VHCL_FLOW_STR:             low_modhigh_mapping,
        Fields.SPD_LIMIT_STR:                   road_speed_limit_mapping,
        Fields.ROAD_OPR_SPEED_AVG_STR:          None,
        Fields.SPEED_UNIT_STR:                  operating_speed_unit_mapping,
    }

    def __init__(self, size=0, values=None):
        super().__init__(self.Fields, size, values)
```
