---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/cycleRAP_interface.py::cycleRAP_interface._write_default_config", "_write_default_config"]
tags: [function, python]
file: "backend/app/services/cycleRAP_interface.py"
lines: "260-349"
---

# _write_default_config

**Kind:** Function
**File:** [[file-backend-app-services-cyclerap-interface-py|cycleRAP_interface.py]]  `backend/app/services/cycleRAP_interface.py`
**Lines:** 260-349
**Community:** [[com-services-cycle|services-cycle]]
**Signature:** `def _write_default_config((path: Path))`

## Source

```python
    def _write_default_config(path: Path):
        # Build default attribute dict
        default_attrs = {
            Attributes.Fields.AREA_TYPE_STR                     : 2,
            Attributes.Fields.FACILITY_TYPE_STR                 : 2,
            Attributes.Fields.FACILITY_ACCESS_STR               : 1,
            Attributes.Fields.LOOSE_SLIPPERY_SURFACE_STR        : 2,
            Attributes.Fields.TRAM_TRAIN_RAIL_STR               : 2,
            Attributes.Fields.DEFORMATION_DRAIN_STR             : 2,
            Attributes.Fields.FIXED_OBSTACLE_STR                : 2,
            Attributes.Fields.NON_FIXED_OBSTACLE_STR            : 2,
            Attributes.Fields.DELINEATION_STR                   : 1,
            Attributes.Fields.LIGHT_SEGREGATION_STR             : 1,
            Attributes.Fields.FACILITY_WIDTH_STR                : 2,
            Attributes.Fields.FLOW_DIR_STR                      : 2,
            Attributes.Fields.WIDTH_RESTRICTION_STR             : 2,
            Attributes.Fields.ADJ_ROAD_LANE_01M_STR             : 2,
            Attributes.Fields.ADJ_VHCL_PARKING_01M_STR          : 2,
            Attributes.Fields.ADJ_SVR_PARKING_01M_STR           : 2,
            Attributes.Fields.ADJ_OBJ_LVL_CHGE_01M_STR          : 2,
            Attributes.Fields.ADJ_SIDEWALK_01M_STR              : 2,
            Attributes.Fields.ADJ_ROAD_LANE_13M_STR             : 2,
            Attributes.Fields.ADJ_VHCL_PARKING_13M_STR          : 2,
            Attributes.Fields.ADJ_SVR_HAZARD_13M_STR            : 2,
            Attributes.Fields.ADJ_OBJ_LVL_CHGE_13M_STR          : 2,
            Attributes.Fields.ADJ_SIDEWALK_13M_STR              : 2,
            Attributes.Fields.GRADE_STR                         : 1,
            Attributes.Fields.CURV_STR                          : 2,
            Attributes.Fields.STREET_LIGHT_STR                  : 1,
            Attributes.Fields.PED_CROSS_STR                     : 2,
            Attributes.Fields.INTERSECT_FACILITY_STR            : 2,
            Attributes.Fields.INTERSECT_APPRCH_STR              : 2,
            Attributes.Fields.INTERSECT_ROAD_CROSS_STR          : 2,
            Attributes.Fields.CROSS_FACILITY_STR                : 2,
            Attributes.Fields.NOL_ADJ_ROAD_STR                  : 2,
            Attributes.Fields.NOL_INTERSECT_ROAD_STR            : 1,
            Attributes.Fields.PROP_ACCESS_STR                   : 2,
            Attributes.Fields.PEAK_PED_FLOW_STR                 : 1,
            Attributes.Fields.PEAK_BICYCLE_TRAFFIC_FLOW_STR     : 1,
            Attributes.Fields.OBSERVED_PROPORTION_STR           : 1,
            Attributes.Fields.BICYCLE_SPD_AVG_STR               : 1,
            Attributes.Fields.BICYCLE_SPD_DIFF_STR              : 1,
            Attributes.Fields.ROAD_AADT_STR                     : 6000,
            Attributes.Fields.HEAVY_VHCL_FLOW_STR               : 1,
            Attributes.Fields.SPD_LIMIT_STR                     : 10,
            Attributes.Fields.ROAD_OPR_SPEED_AVG_STR            : 30,
            Attributes.Fields.SPEED_UNIT_STR                    : 1
        }

        # Build default treatment list
        default_treatments = [
            {"description": "Upgrade existing facility to an on-road bicycle lane with light segregation", "attribute_1": 14, "code_remedy_1": 4,  "attribute_2": 22, "code_remedy_2": 1,  "attribute_3": 15, "code_remedy_3": 1},
            {"description": "Upgrade existing facility to an on-road bicycle lane with safety barrier (Adjacent road lane 0-1m)", "attribute_1": 26, "code_remedy_1": 2,  "attribute_2": 15, "code_remedy_2": 1,  "attribute_3": None, "code_remedy_3": None},
            {"description": "Upgrade existing facility to an on-road bicycle lane with safety barrier (Adjacent road lane 1-3m)", "attribute_1": 31, "code_remedy_1": 2,  "attribute_2": 15, "code_remedy_2": 2,  "attribute_3": None, "code_remedy_3": None},
            {"description": "Upgrade existing facility to a cycling-priority street", "attribute_1": 55, "code_remedy_1": 20, "attribute_2": 15, "code_remedy_2": 1,  "attribute_3": None, "code_remedy_3": None},
            {"description": "Upgrade existing facility to a cycling-priority street (mph)", "attribute_1": 55, "code_remedy_1": 12, "attribute_2": 15, "code_remedy_2": 2,  "attribute_3": None, "code_remedy_3": None},
            {"description": "Upgrade existing facility to a multi-use path", "attribute_1": 14, "code_remedy_1": 2,  "attribute_2": 23, "code_remedy_2": 3,  "attribute_3": 15, "code_remedy_3": 1},
            {"description": "Upgrade existing facility to an off-road bicycle path", "attribute_1": 14, "code_remedy_1": 3,  "attribute_2": 15, "code_remedy_2": 1,  "attribute_3": None, "code_remedy_3": None},
            {"description": "Upgrade existing facility to a one-way bicycle facility", "attribute_1": 24, "code_remedy_1": 1,  "attribute_2": 15, "code_remedy_2": 1,  "attribute_3": None, "code_remedy_3": None},
            {"description": "Improve surface conditions", "attribute_1": 16, "code_remedy_1": 2,  "attribute_2": None, "code_remedy_2": None, "attribute_3": None, "code_remedy_3": None},
            {"description": "Install light segregation", "attribute_1": 22, "code_remedy_1": 1,  "attribute_2": None, "code_remedy_2": None, "attribute_3": None, "code_remedy_3": None},
            {"description": "Install lighting", "attribute_1": 38, "code_remedy_1": 1,  "attribute_2": None, "code_remedy_2": None, "attribute_3": None, "code_remedy_3": None},
            {"description": "Clear facility – Remove fixed obstacle/s", "attribute_1": 19, "code_remedy_1": 2,  "attribute_2": None, "code_remedy_2": None, "attribute_3": None, "code_remedy_3": None},
            {"description": "Clear facility – Remove non-fixed obstacle/s", "attribute_1": 20, "code_remedy_1": 2,  "attribute_2": None, "code_remedy_2": None, "attribute_3": None, "code_remedy_3": None},
            {"description": "Clear facility – Remove width restriction", "attribute_1": 25, "code_remedy_1": 2,  "attribute_2": None, "code_remedy_2": None, "attribute_3": None, "code_remedy_3": None},
            {"description": "Improve facility access", "attribute_1": 15, "code_remedy_1": 1,  "attribute_2": None, "code_remedy_2": None, "attribute_3": None, "code_remedy_3": None},
            {"description": "Redesign the curve", "attribute_1": 37, "code_remedy_1": 2,  "attribute_2": None, "code_remedy_2": None, "attribute_3": None, "code_remedy_3": None},
            {"description": "Widen the facility", "attribute_1": 23, "code_remedy_1": 3,  "attribute_2": None, "code_remedy_2": None, "attribute_3": None, "code_remedy_3": None},
            {"description": "Install protective barrier", "attribute_1": 28, "code_remedy_1": 2,  "attribute_2": None, "code_remedy_2": None, "attribute_3": None, "code_remedy_3": None},
            {"description": "Improve delineation", "attribute_1": 21, "code_remedy_1": 1,  "attribute_2": None, "code_remedy_2": None, "attribute_3": None, "code_remedy_3": None},
            {"description": "Review intersection approach", "attribute_1": 41, "code_remedy_1": 2,  "attribute_2": None, "code_remedy_2": None, "attribute_3": None, "code_remedy_3": None},
            {"description": "Improve safety of crossing design", "attribute_1": 43, "code_remedy_1": 1,  "attribute_2": None, "code_remedy_2": None, "attribute_3": None, "code_remedy_3": None},
            {"description": "Evaluate need for grade separation", "attribute_1": 42, "code_remedy_1": 2,  "attribute_2": None, "code_remedy_2": None, "attribute_3": None, "code_remedy_3": None},
            {"description": "Reconfigure or remove parking", "attribute_1": 27, "code_remedy_1": 2,  "attribute_2": None, "code_remedy_2": None, "attribute_3": None, "code_remedy_3": None},
            {"description": "Review configuration of train/tram rails", "attribute_1": 17, "code_remedy_1": 2,  "attribute_2": None, "code_remedy_2": None, "attribute_3": None, "code_remedy_3": None},
            {"description": "Install traffic calming (km/h)", "attribute_1": 55, "code_remedy_1": 30, "attribute_2": None, "code_remedy_2": None, "attribute_3": None, "code_remedy_3": None},
            {"description": "Install traffic calming (mph)", "attribute_1": 55, "code_remedy_1": 20, "attribute_2": None, "code_remedy_2": None, "attribute_3": None, "code_remedy_3": None},
            {"description": "Vehicles speed control", "attribute_1": 55, "code_remedy_1": 30, "attribute_2": None, "code_remedy_2": None, "attribute_3": None, "code_remedy_3": None},
            {"description": "Bicycles speed control", "attribute_1": 50, "code_remedy_1": 1,  "attribute_2": None, "code_remedy_2": None, "attribute_3": None, "code_remedy_3": None}
        ]

        # Dump them into one JSON
        payload = {
            "attribute_default": default_attrs,
            "treatment_remedy": default_treatments
        }

        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=4)
```

## Callers (1)
- [[fn-backend-app-services-cyclerap-interface-py--initialise|initialise]]

## External / unresolved calls (3)
- `mkdir`
- `open`
- `dump`
