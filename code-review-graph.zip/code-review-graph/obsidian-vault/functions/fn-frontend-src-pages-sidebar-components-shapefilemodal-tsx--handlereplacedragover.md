---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/sidebar/components/ShapefileModal.tsx::handleReplaceDragOver", "handleReplaceDragOver"]
tags: [function, tsx]
file: "frontend/src/pages/sidebar/components/ShapefileModal.tsx"
lines: "215-218"
---

# handleReplaceDragOver

**Kind:** Function
**File:** [[file-frontend-src-pages-sidebar-components-shapefilemodal-tsx|ShapefileModal.tsx]]  `frontend/src/pages/sidebar/components/ShapefileModal.tsx`
**Lines:** 215-218
**Community:** [[com-components-handle-7|components-handle]]
**Signature:** `def handleReplaceDragOver((e: React.DragEvent))`

## Source

```tsx
  function handleReplaceDragOver(e: React.DragEvent) {
    e.preventDefault();
    e.stopPropagation();
  }
```

## External / unresolved calls (2)
- `preventDefault`
- `stopPropagation`
