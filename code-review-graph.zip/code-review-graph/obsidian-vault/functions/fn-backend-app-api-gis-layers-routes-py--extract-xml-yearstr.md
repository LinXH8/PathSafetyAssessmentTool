---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/gis_layers/routes.py::_extract_xml_yearStr", "_extract_xml_yearStr"]
tags: [function, python]
file: "backend/app/api/gis_layers/routes.py"
lines: "77-93"
---

# _extract_xml_yearStr

**Kind:** Function
**File:** [[file-backend-app-api-gis-layers-routes-py|routes.py]]  `backend/app/api/gis_layers/routes.py`
**Lines:** 77-93
**Community:** [[com-gis-layers-shapefiles|gis-layers-shapefiles]]
**Signature:** `def _extract_xml_yearStr((shp_path: Path)) -> str | None`

## Description

> Attempt to parse `<CreaDate>`, `<ModDate>`, `<SyncDate>`, or `<pubDate>` from native XML metadata.

## Source

```python
def _extract_xml_yearStr(shp_path: Path) -> str | None:
    """Attempt to parse `<CreaDate>`, `<ModDate>`, `<SyncDate>`, or `<pubDate>` from native XML metadata."""
    xml_path = shp_path.with_suffix('.shp.xml')
    if not xml_path.exists():
        xml_path = shp_path.with_suffix('.xml')
    
    if xml_path.exists():
        try:
            tree = ET.parse(str(xml_path))
            root = tree.getroot()
            for tag in ['.//CreaDate', './/ModDate', './/SyncDate', './/pubDate']:
                elem = root.find(tag)
                if elem is not None and elem.text and len(elem.text) >= 4:
                    return elem.text[:4] # Format usually 'YYYYMMDD'
        except Exception:
            pass
    return None
```

## Callers (1)
- [[fn-backend-app-api-gis-layers-routes-py--file-info|_file_info]]

## External / unresolved calls (7)
- `with_suffix` ×2
- `exists` ×2
- `parse`
- `str`
- `getroot`
- `find`
- `len`
