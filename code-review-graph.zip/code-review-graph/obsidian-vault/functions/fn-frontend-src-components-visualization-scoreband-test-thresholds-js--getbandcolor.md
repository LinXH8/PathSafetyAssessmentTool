---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/scoreband/test_thresholds.js::getBandColor", "getBandColor"]
tags: [function, javascript]
file: "frontend/src/components/visualization/scoreband/test_thresholds.js"
lines: "9-23"
---

# getBandColor

**Kind:** Function
**File:** [[file-frontend-src-components-visualization-scoreband-test-thresholds-js|test_thresholds.js]]  `frontend/src/components/visualization/scoreband/test_thresholds.js`
**Lines:** 9-23
**Community:** [[com-scoreband-band|scoreband-band]]
**Signature:** `def getBandColor((score, type))`

## Source

```javascript
const getBandColor = (score, type) => {
    // BB, BP, SB use stricter thresholds
    if (['BB', 'BP', 'SB'].includes(type)) {
        if (score < 5) return RISK_BAND_COLORS.LOW;
        if (score <= 10) return RISK_BAND_COLORS.MEDIUM;
        if (score <= 20) return RISK_BAND_COLORS.HIGH;
        return RISK_BAND_COLORS.EXTREME;
    }

    // VB and others (default)
    if (score < 10) return RISK_BAND_COLORS.LOW;
    if (score <= 25) return RISK_BAND_COLORS.MEDIUM;
    if (score <= 60) return RISK_BAND_COLORS.HIGH;
    return RISK_BAND_COLORS.EXTREME;
};
```

## External / unresolved calls (1)
- `includes`
