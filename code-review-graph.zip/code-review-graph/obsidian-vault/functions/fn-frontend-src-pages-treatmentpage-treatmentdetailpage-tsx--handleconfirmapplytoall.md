---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/TreatmentPage/treatmentDetailPage.tsx::handleConfirmApplyToAll", "handleConfirmApplyToAll"]
tags: [function, tsx]
file: "frontend/src/pages/TreatmentPage/treatmentDetailPage.tsx"
lines: "899-927"
---

# handleConfirmApplyToAll

**Kind:** Function
**File:** [[file-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx|treatmentDetailPage.tsx]]  `frontend/src/pages/TreatmentPage/treatmentDetailPage.tsx`
**Lines:** 899-927
**Community:** [[com-treatmentpage-treatment|treatmentpage-treatment]]
**Signature:** `def handleConfirmApplyToAll(())`

## Source

```tsx
  const handleConfirmApplyToAll = async () => {
    if (selectedTreatments.size === 0) return;
    setApplyLoading(true);
    setOpenConfirmAlert(false);
    try {
        const allDetails: any[] = [];
        // Apply selected treatments across ALL loaded projects
        for (const proj of projectNames) {
          for (const id of Array.from(selectedTreatments)) {
            try {
              const res = await applySpecificTreatment(proj, id);
              if (res.details) {
                res.details.forEach((d: any) => d.projectName = proj);
                allDetails.push(...res.details);
              }
            } catch (e: any) {
              console.error(`Apply treatment ${id} to ${proj} failed:`, e);
            }
          }
        }
        window.dispatchEvent(new CustomEvent("psat:treat:all:completed", { detail: allDetails }));
        setSelectedTreatments(new Set());
    } catch (e: any) {
        console.error("Apply specific failed:", e);
        alert(e.message || "Failed to apply treatment");
    } finally {
        setApplyLoading(false);
    }
  };
```

## Callees (1)
- [[fn-frontend-src-api-index-ts--applyspecifictreatment|applySpecificTreatment]]

## External / unresolved calls (9)
- `setApplyLoading` ×2
- `error` ×2
- `setOpenConfirmAlert`
- `from`
- `forEach`
- `push`
- `dispatchEvent`
- `setSelectedTreatments`
- `alert`
