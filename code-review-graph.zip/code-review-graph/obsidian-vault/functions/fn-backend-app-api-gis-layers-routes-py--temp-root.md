---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/gis_layers/routes.py::_temp_root", "_temp_root"]
tags: [function, python]
file: "backend/app/api/gis_layers/routes.py"
lines: "97-101"
---

# _temp_root

**Kind:** Function
**File:** [[file-backend-app-api-gis-layers-routes-py|routes.py]]  `backend/app/api/gis_layers/routes.py`
**Lines:** 97-101
**Community:** [[com-gis-layers-shapefiles|gis-layers-shapefiles]]
**Signature:** `def _temp_root(()) -> Path`

## Description

> Writable temp area that is NOT inside shapefiles/ (avoids gitignore).

## Source

```python
def _temp_root() -> Path:
    """Writable temp area that is NOT inside shapefiles/ (avoids gitignore)."""
    p = Path(__file__).resolve().parents[3] / "temp_uploads"
    p.mkdir(exist_ok=True)
    return p
```

## Callers (2)
- [[fn-backend-app-api-gis-layers-routes-py--validate-shapefile|validate_shapefile]]
- [[fn-backend-app-api-gis-layers-routes-py--upload-shapefiles|upload_shapefiles]]

## External / unresolved calls (3)
- `resolve`
- `Path`
- `mkdir`
