---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/CodingPage/codingPage.tsx::row", "row"]
tags: [function, tsx]
file: "frontend/src/pages/CodingPage/codingPage.tsx"
lines: "944-948"
---

# row

**Kind:** Function
**File:** [[file-frontend-src-pages-codingpage-codingpage-tsx|codingPage.tsx]]  `frontend/src/pages/CodingPage/codingPage.tsx`
**Lines:** 944-948
**Community:** [[com-codingpage-handle|codingpage-handle]]
**Signature:** `def row()`

## Source

```tsx
        attributes.forEach(row => {
          const r = row as any;
          const ref = r["Image Reference"] ?? r["image"] ?? r["img"];
          if (ref) uniqueRefs.add(ref);
        });
```

## External / unresolved calls (4)
- `entries` ×2
- `test` ×2
- `Number` ×2
- `add`
