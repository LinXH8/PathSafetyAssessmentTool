---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/api/index.ts::saveTreatments", "saveTreatments"]
tags: [function, typescript]
file: "frontend/src/api/index.ts"
lines: "819-831"
---

# saveTreatments

**Kind:** Function
**File:** [[file-frontend-src-api-index-ts|index.ts]]  `frontend/src/api/index.ts`
**Lines:** 819-831
**Community:** [[com-api-project|api-project]]
**Signature:** `def saveTreatments((
  project: string
)) -> : Promise<SaveTreatmentsResult>`

## Source

```typescript
export async function saveTreatments(
  project: string
): Promise<SaveTreatmentsResult> {
  const res = await fetch(
    `/api/projects/${encodeURIComponent(project)}/treatments/save`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
    }
  );
  if (!res.ok) throw new Error(await readError(res));
  return res.json();
}
```

## Callers (1)
- [[fn-frontend-src-pages-sidebar-sidebar-tsx--sidebar|Sidebar]]

## Callees (1)
- [[fn-frontend-src-api-index-ts--readerror|readError]]

## External / unresolved calls (3)
- `fetch`
- `encodeURIComponent`
- `json`
