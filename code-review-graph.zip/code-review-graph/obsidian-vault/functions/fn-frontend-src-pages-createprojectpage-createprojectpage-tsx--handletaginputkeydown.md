---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/CreateProjectPage/createProjectPage.tsx::handleTagInputKeyDown", "handleTagInputKeyDown"]
tags: [function, tsx]
file: "frontend/src/pages/CreateProjectPage/createProjectPage.tsx"
lines: "91-103"
---

# handleTagInputKeyDown

**Kind:** Function
**File:** [[file-frontend-src-pages-createprojectpage-createprojectpage-tsx|createProjectPage.tsx]]  `frontend/src/pages/CreateProjectPage/createProjectPage.tsx`
**Lines:** 91-103
**Community:** [[com-createprojectpage-tag|createprojectpage-tag]]
**Signature:** `def handleTagInputKeyDown((e: KeyboardEvent<HTMLInputElement>))`

## Source

```tsx
  const handleTagInputKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "," || e.key === "Enter") {
      e.preventDefault();
      const trimmedTag = tagInput.trim();
      if (trimmedTag && !tags.includes(trimmedTag)) {
        setTags([...tags, trimmedTag]);
      }
      setTagInput("");
    } else if (e.key === "Backspace" && tagInput === "" && tags.length > 0) {
      // Remove last tag on backspace if input is empty
      setTags(tags.slice(0, -1));
    }
  };
```

## External / unresolved calls (6)
- `setTags` ×2
- `preventDefault`
- `trim`
- `includes`
- `setTagInput`
- `slice`
