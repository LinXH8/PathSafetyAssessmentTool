---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/sidebar/Sidebar.tsx::onSave", "onSave"]
tags: [function, tsx]
file: "frontend/src/pages/sidebar/Sidebar.tsx"
lines: "180-189"
---

# onSave

**Kind:** Function
**File:** [[file-frontend-src-pages-sidebar-sidebar-tsx|Sidebar.tsx]]  `frontend/src/pages/sidebar/Sidebar.tsx`
**Lines:** 180-189
**Community:** [[com-sidebar-shapefile|sidebar-shapefile]]
**Signature:** `def onSave(())`

## Source

```tsx
  const onSave = async () => {
    // 发出保存请求；让 CodingPage 去真正保存
    window.dispatchEvent(new CustomEvent("psat:save"));

    toaster.create({
      title: "Save requested",
      description: "Saving current attributes…",
      type: "success",
    });
  };
```

## External / unresolved calls (2)
- `dispatchEvent`
- `create`
