---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/utils/path_width_curvature.py::remove_z", "remove_z"]
tags: [function, python]
file: "backend/app/utils/path_width_curvature.py"
lines: "20-44"
---

# remove_z

**Kind:** Function
**File:** [[file-backend-app-utils-path-width-curvature-py|path_width_curvature.py]]  `backend/app/utils/path_width_curvature.py`
**Lines:** 20-44
**Community:** [[com-utils-width|utils-width]]
**Signature:** `def remove_z((geom: BaseGeometry)) -> BaseGeometry`

## Description

> Remove Z coordinates from a geometry (convert 3D → 2D).
> Returns the geometry unchanged if it has no Z values.

## Source

```python
def remove_z(geom: BaseGeometry) -> BaseGeometry:
    """
    Remove Z coordinates from a geometry (convert 3D → 2D).
    Returns the geometry unchanged if it has no Z values.
    """
    if geom is None or geom.is_empty or not getattr(geom, "has_z", False):
        return geom

    def to_2d(coords):
        return [(x, y) for x, y, *_ in coords]

    gt = geom.geom_type
    if gt == "Point":
        x, y, *_ = geom.coords[0]
        return Point(x, y)
    if gt == "LineString":
        return LineString(to_2d(geom.coords))
    if gt == "Polygon":
        return Polygon(to_2d(geom.exterior.coords),
                       [to_2d(r.coords) for r in geom.interiors])
    if gt == "MultiLineString":
        return MultiLineString([remove_z(g) for g in geom.geoms])
    if gt == "MultiPolygon":
        return MultiPolygon([remove_z(g) for g in geom.geoms])
    return geom  # Fallback
```

## Callers (1)
- [[fn-backend-app-utils-path-width-curvature-py--remove-z|remove_z]]

## Callees (2)
- [[fn-backend-app-utils-path-width-curvature-py--to-2d|to_2d]]
- [[fn-backend-app-utils-path-width-curvature-py--remove-z|remove_z]]

## External / unresolved calls (6)
- `getattr`
- `Point`
- `LineString`
- `Polygon`
- `MultiLineString`
- `MultiPolygon`
