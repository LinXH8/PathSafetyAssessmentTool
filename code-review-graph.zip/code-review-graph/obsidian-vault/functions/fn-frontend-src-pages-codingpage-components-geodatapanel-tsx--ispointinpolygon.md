---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/CodingPage/components/GeoDataPanel.tsx::isPointInPolygon", "isPointInPolygon"]
tags: [function, tsx]
file: "frontend/src/pages/CodingPage/components/GeoDataPanel.tsx"
lines: "264-279"
---

# isPointInPolygon

**Kind:** Function
**File:** [[file-frontend-src-pages-codingpage-components-geodatapanel-tsx|GeoDataPanel.tsx]]  `frontend/src/pages/CodingPage/components/GeoDataPanel.tsx`
**Lines:** 264-279
**Community:** [[com-components-bounds|components-bounds]]
**Signature:** `def isPointInPolygon((point: [number, number], vs: [number, number][]))`

## Source

```tsx
const isPointInPolygon = (point: [number, number], vs: [number, number][]) => {
  // point: [lat, lon], vs: [[lat, lon], ...]
  // x = lon, y = lat
  const x = point[1], y = point[0];

  let inside = false;
  for (let i = 0, j = vs.length - 1; i < vs.length; j = i++) {
    const xi = vs[i][1], yi = vs[i][0];
    const xj = vs[j][1], yj = vs[j][0];

    const intersect = ((yi > y) !== (yj > y))
      && (x < (xj - xi) * (y - yi) / (yj - yi) + xi);
    if (intersect) inside = !inside;
  }
  return inside;
};
```

## Callers (1)
- [[fn-frontend-src-pages-codingpage-components-geodatapanel-tsx--p|p]]
