---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/CreateProjectPage/createProjectPage.tsx::p", "p"]
tags: [function, tsx]
file: "frontend/src/pages/CreateProjectPage/createProjectPage.tsx"
lines: "67-69"
---

# p

**Kind:** Function
**File:** [[file-frontend-src-pages-createprojectpage-createprojectpage-tsx|createProjectPage.tsx]]  `frontend/src/pages/CreateProjectPage/createProjectPage.tsx`
**Lines:** 67-69
**Community:** [[com-createprojectpage-tag|createprojectpage-tag]]
**Signature:** `def p()`

## Source

```tsx
      projectsData.projects.forEach(p => {
        p.tags?.forEach(tag => tagSet.add(tag));
      });
```

## External / unresolved calls (1)
- `forEach`
