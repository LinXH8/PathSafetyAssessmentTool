---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/gis_layers/routes.py::delete_shapefile", "delete_shapefile"]
tags: [function, python]
file: "backend/app/api/gis_layers/routes.py"
lines: "496-513"
---

# delete_shapefile

**Kind:** Function
**File:** [[file-backend-app-api-gis-layers-routes-py|routes.py]]  `backend/app/api/gis_layers/routes.py`
**Lines:** 496-513
**Community:** [[com-gis-layers-shapefiles|gis-layers-shapefiles]]
**Signature:** `def delete_shapefile((shapefile_path: str))`

## Description

> Delete a shapefile and all its companion files (.shx, .dbf, .prj, etc.)
>
> URL param: relative path, e.g. area_type/Central.shp

## Source

```python
def delete_shapefile(shapefile_path: str):
    """
    Delete a shapefile and all its companion files (.shx, .dbf, .prj, etc.)

    URL param: relative path, e.g. area_type/Central.shp
    """
    abs_path = _safe_relative(shapefile_path)
    if abs_path is None or not abs_path.exists():
        return jsonify({"error": f"Shapefile not found: {shapefile_path}"}), 404

    deleted = []
    for ext in _companion_extensions():
        companion = abs_path.with_suffix(ext)
        if companion.exists():
            companion.unlink()
            deleted.append(companion.name)

    return jsonify({"message": f"Deleted {len(deleted)} file(s)", "deleted_files": deleted})
```

## Callees (2)
- [[fn-backend-app-api-gis-layers-routes-py--safe-relative|_safe_relative]]
- [[fn-backend-app-api-gis-layers-routes-py--companion-extensions|_companion_extensions]]

## External / unresolved calls (6)
- `exists` ×2
- `jsonify` ×2
- `with_suffix`
- `unlink`
- `append`
- `len`
