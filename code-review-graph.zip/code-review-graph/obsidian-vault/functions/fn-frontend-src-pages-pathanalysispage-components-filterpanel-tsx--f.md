---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/FilterPanel.tsx::f", "f"]
tags: [function, tsx]
file: "frontend/src/pages/PathAnalysisPage/components/FilterPanel.tsx"
lines: "28-28"
---

# f

**Kind:** Function
**File:** [[file-frontend-src-pages-pathanalysispage-components-filterpanel-tsx|FilterPanel.tsx]]  `frontend/src/pages/PathAnalysisPage/components/FilterPanel.tsx`
**Lines:** 28-28
**Community:** [[com-components-filter|components-filter]]
**Signature:** `def f()`

## Source

```tsx
      onActiveFiltersChange(activeFilters.filter(f => f !== attrName));
```
