---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/prediction.py::CycleRAP_Coding_Helper.autocode", "autocode"]
tags: [function, python]
file: "backend/app/services/prediction.py"
lines: "477-522"
---

# autocode

**Kind:** Function
**File:** [[file-backend-app-services-prediction-py|prediction.py]]  `backend/app/services/prediction.py`
**Lines:** 477-522
**Community:** [[com-services-compute|services-compute]]
**Signature:** `def autocode((cls, image_path: Path)) -> dict`

## Source

```python
    def autocode(cls, image_path: Path) -> dict:
        if not cls.path_segmentation_model:
            raise RuntimeError("Path segmentation model is not initialised.")

        CONF_THRESH = 0.5

        # 1. Run path segmentation
        results = cls.path_segmentation_model.predict(
            source=str(image_path), conf=CONF_THRESH, verbose=False
        )
        result = results[0]
        img_h, img_w = result.orig_shape

        # 2. Build binary masks
        masks = cls._build_masks(result, cls.class_sets, img_h, img_w, CONF_THRESH)

        # 3. Detect obstacles
        if cls.obstacle_detector_model is not None:
            fixed_obs, non_fixed_obs, detections = cls._detect_obstacles(
                image_path, cls.obstacle_detector_model, CONF_THRESH
            )
        else:
            fixed_obs, non_fixed_obs, detections = "Not Present", "Not Present", []

        # 4. Compute width restriction
        width_restriction, blocking_fixed, blocking_non_fixed = cls._compute_width_restriction(masks["pathway"], detections)

        # 5. Collect all detected obstacle class names for FO Type / NFO Type
        all_fixed_classes = sorted(set(d["class_name"] for d in detections if d["group"] == "fixed"))
        all_non_fixed_classes = sorted(set(d["class_name"] for d in detections if d["group"] == "non_fixed"))
        fo_type_str = ", ".join(all_fixed_classes) if all_fixed_classes else None
        nfo_type_str = ", ".join(all_non_fixed_classes) if all_non_fixed_classes else None

        # 6. Assign attributes (string values)
        str_attrs = cls._assign_attributes(
            masks, img_h, img_w, fixed_obs, non_fixed_obs, width_restriction,
            blocking_fixed_classes=fo_type_str,
            blocking_non_fixed_classes=nfo_type_str,
        )

        print(f"[Autocode] [{Path(image_path).name}] {str_attrs['Facility Type']} | "
              f"Fixed: {fixed_obs} | Non-Fixed: {non_fixed_obs} | "
              f"FO Type: {fo_type_str} | NFO Type: {nfo_type_str}", flush=True)

        # 7. Convert to integer-coded dict
        return cls._convert_to_coded(str_attrs)
```

## Callees (5)
- [[fn-backend-app-services-prediction-py--build-masks|_build_masks]]
- [[fn-backend-app-services-prediction-py--detect-obstacles|_detect_obstacles]]
- [[fn-backend-app-services-prediction-py--compute-width-restriction|_compute_width_restriction]]
- [[fn-backend-app-services-prediction-py--assign-attributes|_assign_attributes]]
- [[fn-backend-app-services-prediction-py--convert-to-coded|_convert_to_coded]]

## External / unresolved calls (8)
- `sorted` ×2
- `set` ×2
- `join` ×2
- `RuntimeError`
- `predict`
- `str`
- `print`
- `Path`
