---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/AddSegmentsDialog.tsx::removeTag", "removeTag"]
tags: [function, tsx]
file: "frontend/src/pages/PathAnalysisPage/components/AddSegmentsDialog.tsx"
lines: "120-122"
---

# removeTag

**Kind:** Function
**File:** [[file-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx|AddSegmentsDialog.tsx]]  `frontend/src/pages/PathAnalysisPage/components/AddSegmentsDialog.tsx`
**Lines:** 120-122
**Community:** [[com-components-tag|components-tag]]
**Signature:** `def removeTag((tagToRemove: string))`

## Source

```tsx
    const removeTag = (tagToRemove: string) => {
        setTags(tags.filter((t) => t !== tagToRemove));
    };
```

## Callers (1)
- [[fn-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx--addsegmentsdialog|AddSegmentsDialog]]

## External / unresolved calls (2)
- `setTags`
- `filter`
