---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/TreatmentPage/treatmentDetailPage.tsx::t", "t"]
tags: [function, tsx]
file: "frontend/src/pages/TreatmentPage/treatmentDetailPage.tsx"
lines: "1369-1369"
---

# t

**Kind:** Function
**File:** [[file-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx|treatmentDetailPage.tsx]]  `frontend/src/pages/TreatmentPage/treatmentDetailPage.tsx`
**Lines:** 1369-1369
**Community:** [[com-treatmentpage-treatment|treatmentpage-treatment]]
**Signature:** `def t()`

## Source

```tsx
                        setSelectedTreatments(new Set(allApplicableTreatments.map(t => t.id)));
```

## Callees (3)
- [[fn-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx--istreatmentapplicable|isTreatmentApplicable]]
- [[fn-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx--set|set]]
- [[fn-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx--getapplicabletreatments|getApplicableTreatments]]

## External / unresolved calls (4)
- `has`
- `some`
- `includes`
- `add`
