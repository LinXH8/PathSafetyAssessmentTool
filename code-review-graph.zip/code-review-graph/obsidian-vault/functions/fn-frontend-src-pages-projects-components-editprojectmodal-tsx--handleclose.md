---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/Projects/components/EditProjectModal.tsx::handleClose", "handleClose"]
tags: [function, tsx]
file: "frontend/src/pages/Projects/components/EditProjectModal.tsx"
lines: "64-69"
---

# handleClose

**Kind:** Function
**File:** [[file-frontend-src-pages-projects-components-editprojectmodal-tsx|EditProjectModal.tsx]]  `frontend/src/pages/Projects/components/EditProjectModal.tsx`
**Lines:** 64-69
**Community:** [[com-components-tag-2|components-tag]]
**Signature:** `def handleClose(())`

## Source

```tsx
  function handleClose() {
    setNewName(projectName);
    setTags(projectTags);
    setTagInput("");
    onClose();
  }
```

## Callers (2)
- [[fn-frontend-src-pages-projects-components-editprojectmodal-tsx--handlesave|handleSave]]
- [[fn-frontend-src-pages-projects-components-editprojectmodal-tsx--editprojectmodal|EditProjectModal]]

## External / unresolved calls (4)
- `setNewName`
- `setTags`
- `setTagInput`
- `onClose`
