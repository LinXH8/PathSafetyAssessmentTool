---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/projects/routes.py::delete_segment", "delete_segment"]
tags: [function, python]
file: "backend/app/api/projects/routes.py"
lines: "767-792"
---

# delete_segment

**Kind:** Function
**File:** [[file-backend-app-api-projects-routes-py|routes.py]]  `backend/app/api/projects/routes.py`
**Lines:** 767-792
**Community:** [[com-projects-treatments|projects-treatments]]
**Signature:** `def delete_segment((project_name: str, segment_index: int))`

## Description

> Delete a specific segment (point) from the project.

## Source

```python
def delete_segment(project_name: str, segment_index: int):
    """
    Delete a specific segment (point) from the project.
    """
    try:
        ctx = get_ctx()
        pm = ctx["pm"]
        proj = pm.project(project_name)
        
        # Verify index is within bounds
        # Check latest attributes for size
        current_size = len(proj.latest().attributes.df)
        if segment_index < 0 or segment_index >= current_size:
            return fail(f"Segment index {segment_index} out of bounds (0-{current_size-1})", 400)

        proj.delete_segment(segment_index)
        
        return jsonify({
            "ok": True,
            "message": f"Segment {segment_index} deleted successfully",
            "remaining_segments": current_size - 1
        })
    except Exception as e:
        import traceback
        traceback.print_exc()
        return fail(f"Error deleting segment: {str(e)}", 500)
```

## Callers (1)
- [[fn-backend-app-api-projects-routes-py--delete-segment|delete_segment]]

## Callees (3)
- [[fn-backend-app-api-projects-routes-py--get-ctx|get_ctx]]
- [[fn-backend-app-api-projects-routes-py--fail|fail]]
- [[fn-backend-app-api-projects-routes-py--delete-segment|delete_segment]]

## External / unresolved calls (6)
- `project`
- `len`
- `latest`
- `jsonify`
- `print_exc`
- `str`
