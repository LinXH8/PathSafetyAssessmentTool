---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/AttributesDropdown.tsx::handleAttributeChange", "handleAttributeChange"]
tags: [function, tsx]
file: "frontend/src/pages/PathAnalysisPage/components/AttributesDropdown.tsx"
lines: "727-747"
---

# handleAttributeChange

**Kind:** Function
**File:** [[file-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx|AttributesDropdown.tsx]]  `frontend/src/pages/PathAnalysisPage/components/AttributesDropdown.tsx`
**Lines:** 727-747
**Community:** [[com-components-handle|components-handle]]
**Signature:** `def handleAttributeChange((index: number, value: string))`

## Source

```tsx
  const handleAttributeChange = (index: number, value: string) => {
    const newAttributes = [...selectedAttributes];

    // If "Not Selected" is chosen, clear that filter
    if (value === "Not Selected") {
      newAttributes[index] = null;
    } else {
      // Check if this attribute is already selected in another filter
      const isDuplicate = selectedAttributes.some(
        (attr, i) => attr === value && i !== index
      );

      if (isDuplicate) {
        return; // Don't allow duplicate
      }

      newAttributes[index] = value;
    }

    onAttributeChange(newAttributes);
  };
```

## Callers (1)
- [[fn-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx--attributesdropdown|AttributesDropdown]]

## External / unresolved calls (2)
- `some`
- `onAttributeChange`
