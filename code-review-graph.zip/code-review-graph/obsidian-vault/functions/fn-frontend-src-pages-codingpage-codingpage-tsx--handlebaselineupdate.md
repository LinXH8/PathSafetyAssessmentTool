---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/CodingPage/codingPage.tsx::handleBaselineUpdate", "handleBaselineUpdate"]
tags: [function, tsx]
file: "frontend/src/pages/CodingPage/codingPage.tsx"
lines: "1040-1053"
---

# handleBaselineUpdate

**Kind:** Function
**File:** [[file-frontend-src-pages-codingpage-codingpage-tsx|codingPage.tsx]]  `frontend/src/pages/CodingPage/codingPage.tsx`
**Lines:** 1040-1053
**Community:** [[com-codingpage-handle|codingpage-handle]]
**Signature:** `def handleBaselineUpdate(())`

## Source

```tsx
    const handleBaselineUpdate = async () => {
      if (!currentProjectName) return;

      try {
        const res = await fetch(`/api/projects/${encodeURIComponent(currentProjectName)}/baseline`);
        if (!res.ok) {
          setBaselineRows([]);
          return;
        }
        const data = await res.json();
        setBaselineRows(data.rows || []);
      } catch (e) {
      }
    };
```

## External / unresolved calls (4)
- `setBaselineRows` ×2
- `fetch`
- `encodeURIComponent`
- `json`
