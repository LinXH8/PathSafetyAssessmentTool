---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/CodingPage/components/GeoDataPanel.tsx::ZoomToGIS", "ZoomToGIS"]
tags: [function, tsx]
file: "frontend/src/pages/CodingPage/components/GeoDataPanel.tsx"
lines: "102-117"
---

# ZoomToGIS

**Kind:** Function
**File:** [[file-frontend-src-pages-codingpage-components-geodatapanel-tsx|GeoDataPanel.tsx]]  `frontend/src/pages/CodingPage/components/GeoDataPanel.tsx`
**Lines:** 102-117
**Community:** [[com-components-bounds|components-bounds]]
**Signature:** `def ZoomToGIS(({ center, anyLayerOn }: { center: [number, number] | null; anyLayerOn: boolean }))`

## Source

```tsx
function ZoomToGIS({ center, anyLayerOn }: { center: [number, number] | null; anyLayerOn: boolean }) {
  const map = useMap();
  const prevLayerOnRef = useRef(false);
  useEffect(() => {
    // Zoom in when a layer is turned on (transition from off->on)
    if (anyLayerOn && !prevLayerOnRef.current && center) {
      map.setView(center, 17, { animate: true });
    }
    // When all layers turned off, fit the full route again
    if (!anyLayerOn && prevLayerOnRef.current && center) {
      // Don't force re-fit — just let user navigate freely
    }
    prevLayerOnRef.current = anyLayerOn;
  }, [anyLayerOn, center, map]);
  return null;
}
```

## Callers (1)
- [[fn-frontend-src-pages-codingpage-components-geodatapanel-tsx--geodatapanel|GeoDataPanel]]

## External / unresolved calls (4)
- `useMap`
- `useRef`
- `useEffect`
- `setView`
