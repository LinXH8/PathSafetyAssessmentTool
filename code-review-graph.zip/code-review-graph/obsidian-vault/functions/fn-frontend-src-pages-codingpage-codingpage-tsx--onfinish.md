---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/CodingPage/codingPage.tsx::onFinish", "onFinish"]
tags: [function, tsx]
file: "frontend/src/pages/CodingPage/codingPage.tsx"
lines: "970-977"
---

# onFinish

**Kind:** Function
**File:** [[file-frontend-src-pages-codingpage-codingpage-tsx|codingPage.tsx]]  `frontend/src/pages/CodingPage/codingPage.tsx`
**Lines:** 970-977
**Community:** [[com-codingpage-handle|codingpage-handle]]
**Signature:** `def onFinish(())`

## Source

```tsx
            const onFinish = () => {
              loadedCount++;
              const pct = Math.round((loadedCount / refList.length) * 100);
              setImageLoadingProgress(pct);
              if (loadedCount >= refList.length) {
                setImagesLoaded(true);
              }
            };
```

## External / unresolved calls (3)
- `round`
- `setImageLoadingProgress`
- `setImagesLoaded`
