---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/project_manager.py::project_manager.delete_project", "delete_project"]
tags: [function, python]
file: "backend/app/services/project_manager.py"
lines: "793-800"
---

# delete_project

**Kind:** Function
**File:** [[file-backend-app-services-project-manager-py|project_manager.py]]  `backend/app/services/project_manager.py`
**Lines:** 793-800
**Community:** [[com-services-project|services-project]]
**Signature:** `def delete_project((self, project_name: str))`

## Source

```python
    def delete_project(self, project_name: str):
        for proj in self.projects:
            if proj.metadata.project_name == project_name:
                proj._delete()
                self.projects.remove(proj)
                return True
            
        raise KeyError(f"Project not found: {project_name}")
```

## Callees (1)
- [[fn-backend-app-services-project-manager-py--delete|_delete]]

## External / unresolved calls (2)
- `remove`
- `KeyError`
