---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/gis_mapping.py::LayerStore.__init__", "__init__"]
tags: [function, python]
file: "backend/app/services/gis_mapping.py"
lines: "48-53"
---

# __init__

**Kind:** Function
**File:** [[file-backend-app-services-gis-mapping-py|gis_mapping.py]]  `backend/app/services/gis_mapping.py`
**Lines:** 48-53
**Community:** [[com-services-width|services-width]]
**Signature:** `def __init__((self, metric_crs=CRS_METRIC))`

## Source

```python
    def __init__(self, metric_crs=CRS_METRIC):
        self.metric_crs = metric_crs
        self.paths: dict[str, Path] = {}
        self.layers: dict[str, gpd.GeoDataFrame] = {}
        # Added for Road Operating Speed (mean)
        self.speed_data: pd.DataFrame | None = None  # Cache for speed CSV data
```
