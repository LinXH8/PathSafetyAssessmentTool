---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/TreatmentPage/components/MapView.tsx::MapView", "MapView"]
tags: [function, tsx]
file: "frontend/src/pages/TreatmentPage/components/MapView.tsx"
lines: "22-46"
---

# MapView

**Kind:** Function
**File:** [[file-frontend-src-pages-treatmentpage-components-mapview-tsx|MapView.tsx]]  `frontend/src/pages/TreatmentPage/components/MapView.tsx`
**Lines:** 22-46
**Community:** [[com-components-view-2|components-view]]
**Signature:** `def MapView(())`

## Source

```tsx
export default function MapView() {
  return (
    <Box
      borderWidth="1px"
      borderRadius="lg"
      overflow="hidden"
      bg="white"
      _dark={{ bg: "gray.800" }}
      h="650px"
    >
      <MapContainer
        center={SINGAPORE_CENTER}
        zoom={DEFAULT_ZOOM}
        style={{ height: "100%", width: "100%" }}
        scrollWheelZoom={true}
      >
        <SetViewOnLoad />
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
      </MapContainer>
    </Box>
  );
}
```

## Callees (1)
- [[fn-frontend-src-pages-treatmentpage-components-mapview-tsx--setviewonload|SetViewOnLoad]]

## External / unresolved calls (3)
- `Box`
- `MapContainer`
- `TileLayer`
