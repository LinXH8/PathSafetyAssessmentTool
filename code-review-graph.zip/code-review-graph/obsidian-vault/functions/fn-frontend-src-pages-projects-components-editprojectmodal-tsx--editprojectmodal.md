---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/Projects/components/EditProjectModal.tsx::EditProjectModal", "EditProjectModal"]
tags: [function, tsx]
file: "frontend/src/pages/Projects/components/EditProjectModal.tsx"
lines: "43-228"
---

# EditProjectModal

**Kind:** Function
**File:** [[file-frontend-src-pages-projects-components-editprojectmodal-tsx|EditProjectModal.tsx]]  `frontend/src/pages/Projects/components/EditProjectModal.tsx`
**Lines:** 43-228
**Community:** [[com-components-tag-2|components-tag]]
**Signature:** `def EditProjectModal(({
  open,
  onClose,
  projectName,
  projectTags,
  onSuccess,
}: EditProjectModalProps))`

## Source

```tsx
export default function EditProjectModal({
  open,
  onClose,
  projectName,
  projectTags,
  onSuccess,
}: EditProjectModalProps) {
  const [newName, setNewName] = useState(projectName);
  const [tags, setTags] = useState<string[]>(projectTags);
  const [tagInput, setTagInput] = useState("");
  const [saving, setSaving] = useState(false);

  // Reset state when modal opens
  useEffect(() => {
    if (open) {
      setNewName(projectName);
      setTags(projectTags);
      setTagInput("");
    }
  }, [open, projectName, projectTags]);

  function handleClose() {
    setNewName(projectName);
    setTags(projectTags);
    setTagInput("");
    onClose();
  }

  function handleTagInputKeyDown(e: KeyboardEvent<HTMLInputElement>) {
    if (e.key === "," || e.key === "Enter") {
      e.preventDefault();
      const trimmedTag = tagInput.trim();
      if (trimmedTag && !tags.includes(trimmedTag)) {
        setTags([...tags, trimmedTag]);
      }
      setTagInput("");
    } else if (e.key === "Backspace" && tagInput === "" && tags.length > 0) {
      // Remove last tag on backspace if input is empty
      setTags(tags.slice(0, -1));
    }
  }

  function removeTag(tagToRemove: string) {
    setTags(tags.filter((t) => t !== tagToRemove));
  }

  async function handleSave() {
    if (!newName.trim()) {
      toaster.create({
        title: "Validation Error",
        description: "Project name cannot be empty",
        type: "error",
      });
      return;
    }

    try {
      setSaving(true);
      const updates: { new_name?: string; tags?: string[] } = {};

      // Only send changed fields
      if (newName !== projectName) {
        updates.new_name = newName;
      }
      if (JSON.stringify(tags) !== JSON.stringify(projectTags)) {
        updates.tags = tags;
      }

      if (Object.keys(updates).length === 0) {
        toaster.create({
          title: "No Changes",
          description: "No changes to save",
          type: "info",
        });
        handleClose();
        return;
      }

      const result = await api.updateProject(projectName, updates);

      toaster.create({
        title: "Success",
        description: "Project updated successfully",
        type: "success",
      });

      onSuccess(result.name || newName, result.tags || tags);
      handleClose();
    } catch (error: any) {
      toaster.create({
        title: "Update Failed",
        description: error?.message || "Failed to update project",
        type: "error",
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog.Root open={open} onOpenChange={(d) => !d.open && handleClose()}>
      <Portal>
        <Dialog.Backdrop className="edit-modal-backdrop" />
        <Dialog.Positioner>
          <Dialog.Content className="edit-modal-content">
            <Dialog.Header>
              <Dialog.Title>Edit Project</Dialog.Title>
            </Dialog.Header>

            <Dialog.Body className="edit-modal-body">
              <Box className="edit-form-group">
                <Text className="edit-form-label">Project Name</Text>
                <Input
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="Enter project name"
                  className="edit-input"
                />
              </Box>

              <Box className="edit-form-group">
                <Text className="edit-form-label">Tags</Text>
                <Box className="tag-input-container">
                  <Box className="tag-input-wrapper">
                    {tags.map((tag) => (
                      <Box
                        key={tag}
                        className="tag-chip"
                        style={{
                          backgroundColor: getTagColor(tag),
                        }}
                      >
                        <span className="tag-chip-text">{tag}</span>
                        <button
                          className="tag-chip-remove"
                          onClick={() => removeTag(tag)}
                          aria-label={`Remove ${tag}`}
                        >
                          ×
                        </button>
                      </Box>
                    ))}
                    <Input
                      value={tagInput}
                      onChange={(e) => setTagInput(e.target.value)}
                      onKeyDown={handleTagInputKeyDown}
                      placeholder="Type tag and press comma or enter"
                      className="tag-input-field"
                    />
                  </Box>
                </Box>
                <Text className="edit-form-hint">
                  Press comma (,) or Enter to add a tag
                </Text>
              </Box>
            </Dialog.Body>

            <Dialog.Footer className="edit-modal-footer">
              <Dialog.ActionTrigger asChild>
                <Button
                  variant="outline"
                  disabled={saving}
                  className="edit-btn edit-btn-cancel"
                >
                  Cancel
                </Button>
              </Dialog.ActionTrigger>
              <Button
                colorPalette="blue"
                onClick={handleSave}
                loading={saving}
                className="edit-btn edit-btn-save"
              >
                Save Changes
              </Button>
            </Dialog.Footer>

            <Dialog.CloseTrigger asChild>
              <CloseButton size="sm" className="edit-close-btn" />
            </Dialog.CloseTrigger>
          </Dialog.Content>
        </Dialog.Positioner>
      </Portal>
    </Dialog.Root>
  );
}
```

## Callers (2)
- [[fn-frontend-src-pages-projects-projects-tsx--home|Home]]
- [[fn-frontend-src-pages-treatmentpage-treatmentpage-tsx--treatmentpage|TreatmentPage]]

## Callees (3)
- [[fn-frontend-src-pages-projects-components-editprojectmodal-tsx--handleclose|handleClose]]
- [[fn-frontend-src-pages-projects-components-editprojectmodal-tsx--gettagcolor|getTagColor]]
- [[fn-frontend-src-pages-projects-components-editprojectmodal-tsx--removetag|removeTag]]

## External / unresolved calls (22)
- `Box` ×5
- `useState` ×4
- `Text` ×3
- `setNewName` ×2
- `setTagInput` ×2
- `Input` ×2
- `Button` ×2
- `useEffect`
- `setTags`
- `Root`
- `Portal`
- `Backdrop`
- `Positioner`
- `Content`
- `Header`
- `Title`
- `Body`
- `map`
- `Footer`
- `ActionTrigger`
- `CloseTrigger`
- `CloseButton`
