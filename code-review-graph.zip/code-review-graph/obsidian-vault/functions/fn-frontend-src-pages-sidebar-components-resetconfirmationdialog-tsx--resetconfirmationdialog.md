---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/sidebar/components/ResetConfirmationDialog.tsx::ResetConfirmationDialog", "ResetConfirmationDialog"]
tags: [function, tsx]
file: "frontend/src/pages/sidebar/components/ResetConfirmationDialog.tsx"
lines: "11-64"
---

# ResetConfirmationDialog

**Kind:** Function
**File:** [[file-frontend-src-pages-sidebar-components-resetconfirmationdialog-tsx|ResetConfirmationDialog.tsx]]  `frontend/src/pages/sidebar/components/ResetConfirmationDialog.tsx`
**Lines:** 11-64
**Community:** [[com-components-reset|components-reset]]
**Signature:** `def ResetConfirmationDialog(({
    open,
    onConfirm,
    onCancel,
    isResetting = false,
}: ResetConfirmationDialogProps))`

## Source

```tsx
export default function ResetConfirmationDialog({
    open,
    onConfirm,
    onCancel,
    isResetting = false,
}: ResetConfirmationDialogProps) {
    return (
        <Dialog.Root open={open} onOpenChange={(e) => !e.open && onCancel()} size="md">
            <Portal>
                <Dialog.Backdrop />
                <Dialog.Positioner>
                    <Dialog.Content>
                        <Dialog.Header>
                            <Dialog.Title>Reset All Treatments</Dialog.Title>
                            <Dialog.CloseTrigger />
                        </Dialog.Header>

                        <Dialog.Body>
                            <Box display="flex" gap={4}>
                                <Box fontSize="2xl" color="red.500" flexShrink={0}>
                                    <LuTrash />
                                </Box>
                                <Box>
                                    <Text fontWeight="600" mb={2}>
                                        Are you sure you want to reset all applied treatments?
                                    </Text>
                                    <Text color="fg.muted" fontSize="sm">
                                        This action returns all segments to their original state and cannot be undone.
                                    </Text>
                                </Box>
                            </Box>
                        </Dialog.Body>

                        <Dialog.Footer>
                            <Box display="flex" gap={3} width="100%" justifyContent="flex-end">
                                <Button variant="outline" onClick={onCancel} disabled={isResetting}>
                                    Cancel
                                </Button>
                                <Button
                                    colorPalette="red"
                                    onClick={onConfirm}
                                    loading={isResetting}
                                    disabled={isResetting}
                                >
                                    {isResetting ? "Resetting..." : "Yes, Reset All"}
                                </Button>
                            </Box>
                        </Dialog.Footer>
                    </Dialog.Content>
                </Dialog.Positioner>
            </Portal>
        </Dialog.Root>
    );
}
```

## Callers (1)
- [[fn-frontend-src-pages-sidebar-sidebar-tsx--sidebar|Sidebar]]

## External / unresolved calls (15)
- `Box` ×4
- `Text` ×2
- `Button` ×2
- `Root`
- `onCancel`
- `Portal`
- `Backdrop`
- `Positioner`
- `Content`
- `Header`
- `Title`
- `CloseTrigger`
- `Body`
- `LuTrash`
- `Footer`
