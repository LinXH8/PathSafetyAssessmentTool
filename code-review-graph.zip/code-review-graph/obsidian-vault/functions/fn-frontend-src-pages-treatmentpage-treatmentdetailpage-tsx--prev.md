---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/TreatmentPage/treatmentDetailPage.tsx::prev", "prev"]
tags: [function, tsx]
file: "frontend/src/pages/TreatmentPage/treatmentDetailPage.tsx"
lines: "789-789"
---

# prev

**Kind:** Function
**File:** [[file-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx|treatmentDetailPage.tsx]]  `frontend/src/pages/TreatmentPage/treatmentDetailPage.tsx`
**Lines:** 789-789
**Community:** [[com-treatmentpage-treatment|treatmentpage-treatment]]
**Signature:** `def prev()`

## Source

```tsx
      setRefreshTrigger(prev => prev + 1);
```
