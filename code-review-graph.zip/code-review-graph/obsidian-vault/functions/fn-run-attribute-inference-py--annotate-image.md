---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/run_attribute_inference.py::annotate_image", "annotate_image"]
tags: [function, python]
file: "run_attribute_inference.py"
lines: "455-560"
---

# annotate_image

**Kind:** Function
**File:** [[file-run-attribute-inference-py|run_attribute_inference.py]]  `run_attribute_inference.py`
**Lines:** 455-560
**Community:** [[com-pathsafetyassessmenttool-compute|pathsafetyassessmenttool-compute]]
**Signature:** `def annotate_image((
    img_path: Path,
    attrs: dict[str, str],
    output_dir: Path,
    detections: list[dict] | None = None,
    pathway_mask: np.ndarray | None = None,
)) -> None`

## Description

> Draw obstacle annotations on the image:
>   - Bounding boxes for detected fixed/non-fixed obstacles
>   - For blocking obstacles: bottom-edge circles (obstacle centre + path centre)
>     and a connecting line, mirroring obstacle-visualizer/backend/logic.py
>   - A small panel showing Fixed/Non-Fixed Obstacle and Width Restriction status

## Source

```python
def annotate_image(
    img_path: Path,
    attrs: dict[str, str],
    output_dir: Path,
    detections: list[dict] | None = None,
    pathway_mask: np.ndarray | None = None,
) -> None:
    """
    Draw obstacle annotations on the image:
      - Bounding boxes for detected fixed/non-fixed obstacles
      - For blocking obstacles: bottom-edge circles (obstacle centre + path centre)
        and a connecting line, mirroring obstacle-visualizer/backend/logic.py
      - A small panel showing Fixed/Non-Fixed Obstacle and Width Restriction status
    """
    img = Image.open(img_path).convert("RGBA")
    W, H = img.size

    overlay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay, "RGBA")

    # Fonts shared by both sections
    det_font_size  = max(11, int(H / 60))
    panel_font_size = max(14, int(H / 42))
    try:
        det_font   = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", size=det_font_size)
        panel_font = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", size=panel_font_size)
        panel_lbl_font = ImageFont.truetype(
            "/System/Library/Fonts/Helvetica.ttc",
            size=max(12, int(panel_font_size * 0.85)),
        )
    except Exception:
        det_font = panel_font = panel_lbl_font = ImageFont.load_default()

    r = PATH_CENTER_RADIUS

    # --- 1. Obstacle bounding boxes + blocking overlay ---
    if detections:
        for det in detections:
            color = FIXED_COLOR if det["group"] == "fixed" else NON_FIXED_COLOR
            x1, y1, x2, y2 = det["x1"], det["y1"], det["x2"], det["y2"]

            # Bounding box border (2 px)
            draw.rectangle([(x1, y1), (x2, y2)], outline=(*color, 255), width=2)

            # Class label above the box
            label = det["class_name"]
            lbbox = draw.textbbox((0, 0), label, font=det_font)
            lw, lh = lbbox[2] - lbbox[0], lbbox[3] - lbbox[1]
            lx, ly = x1, max(y1 - lh - 4, 0)
            draw.rectangle([(lx, ly), (lx + lw + 4, ly + lh + 4)], fill=(*color, 200))
            draw.text((lx + 2, ly + 2), label, font=det_font, fill=(255, 255, 255, 255))

            # Blocking analysis overlay (mirrors obstacle-visualizer logic.py)
            if pathway_mask is not None:
                box = (x1, y1, x2, y2)
                is_blocking, _, p_cx, o_cx = analyze_obstacle(box, pathway_mask)
                if is_blocking and p_cx > 0 and o_cx > 0:
                    bottom_y = min(y2, H - 1)
                    # Obstacle centre dot (detection colour)
                    draw.ellipse(
                        [(o_cx - r, bottom_y - r), (o_cx + r, bottom_y + r)],
                        fill=(*color, 255),
                    )
                    # Path centre dot (magenta)
                    draw.ellipse(
                        [(p_cx - r, bottom_y - r), (p_cx + r, bottom_y + r)],
                        fill=(*BLOCKING_LINE_COLOR, 255),
                    )
                    # Connecting line (magenta)
                    draw.line(
                        [(o_cx, bottom_y), (p_cx, bottom_y)],
                        fill=(*BLOCKING_LINE_COLOR, 255),
                        width=2,
                    )

    # --- 2. Small obstacle-status panel ---
    panel_attrs = {
        k: v for k, v in attrs.items()
        if k in ("Fixed Obstacles", "Non-Fixed Obstacles", "Width Restriction")
    }

    row_height = int(panel_font_size * 1.6)
    panel_h    = row_height * len(panel_attrs) + int(row_height * 0.6)
    panel_w    = min(int(W * 0.45), 480)

    draw.rectangle([(0, 0), (panel_w, panel_h)], fill=(0, 0, 0, 170))
    # Left accent bar
    draw.rectangle([(0, 0), (5, panel_h)], fill=(180, 180, 180, 255))

    y = int(row_height * 0.3)
    padding = 14
    for attr_name, attr_value in panel_attrs.items():
        draw.text((padding, y), f"{attr_name}:", font=panel_lbl_font, fill=(180, 180, 180, 255))
        value_x = padding + int(panel_w * 0.62)
        if attr_value == "Present":
            value_color = (120, 255, 120, 255)
        elif attr_value == "Not Present":
            value_color = (255, 130, 130, 255)
        else:
            value_color = (255, 255, 255, 255)
        draw.text((value_x, y), attr_value, font=panel_font, fill=value_color)
        y += row_height

    img = Image.alpha_composite(img, overlay)
    img = img.convert("RGB")
    img.save(output_dir / img_path.name)
```

## Callers (1)
- [[fn-run-attribute-inference-py--process-images|process_images]]

## Callees (1)
- [[fn-run-attribute-inference-py--analyze-obstacle|analyze_obstacle]]

## External / unresolved calls (18)
- `int` ×8
- `max` ×4
- `rectangle` ×4
- `truetype` ×3
- `text` ×3
- `convert` ×2
- `min` ×2
- `ellipse` ×2
- `items` ×2
- `open`
- `new`
- `Draw`
- `load_default`
- `textbbox`
- `line`
- `len`
- `alpha_composite`
- `save`
