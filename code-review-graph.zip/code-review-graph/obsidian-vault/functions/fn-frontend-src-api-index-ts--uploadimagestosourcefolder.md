---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/api/index.ts::uploadImagesToSourceFolder", "uploadImagesToSourceFolder"]
tags: [function, typescript]
file: "frontend/src/api/index.ts"
lines: "838-858"
---

# uploadImagesToSourceFolder

**Kind:** Function
**File:** [[file-frontend-src-api-index-ts|index.ts]]  `frontend/src/api/index.ts`
**Lines:** 838-858
**Community:** [[com-api-project|api-project]]
**Signature:** `def uploadImagesToSourceFolder((
  folderName: string,
  files: File[]
)) -> : Promise<{ count: number; errors: string[] }>`

## Description

> Upload images to a source folder in the /in directory
> @param folderName - Name of the folder to create/upload to in /in directory
> @param files - Array of image files to upload

## Source

```typescript
export async function uploadImagesToSourceFolder(
  folderName: string,
  files: File[]
): Promise<{ count: number; errors: string[] }> {
  const formData = new FormData();
  formData.append("folder_name", folderName);
  
  files.forEach(file => {
    // If the file was dropped as part of a folder, it will have webkitRelativePath
    // Fallback to name if it's just a regular file selection
    const path = file.webkitRelativePath || file.name;
    formData.append("images", file, path);
  });

  const res = await fetch("/api/projects/folders/upload-images", {
    method: "POST",
    body: formData,
  });
  if (!res.ok) throw new Error(await readError(res));
  return res.json();
}
```

## Callees (1)
- [[fn-frontend-src-api-index-ts--readerror|readError]]

## External / unresolved calls (4)
- `append`
- `forEach`
- `fetch`
- `json`
