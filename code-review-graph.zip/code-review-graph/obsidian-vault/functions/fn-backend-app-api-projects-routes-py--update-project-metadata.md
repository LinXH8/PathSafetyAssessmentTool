---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/projects/routes.py::update_project_metadata", "update_project_metadata"]
tags: [function, python]
file: "backend/app/api/projects/routes.py"
lines: "2369-2538"
---

# update_project_metadata

**Kind:** Function
**File:** [[file-backend-app-api-projects-routes-py|routes.py]]  `backend/app/api/projects/routes.py`
**Lines:** 2369-2538
**Community:** [[com-projects-treatments|projects-treatments]]
**Signature:** `def update_project_metadata((project_name: str))`

## Description

> Update project metadata (name, tags, verified status, and/or verified segment count):
> PATCH /api/projects/<project_name>
> Body: { "new_name": "...", "tags": [...], "verified": true/false, "verified_segment_count": 0 }

## Source

```python
def update_project_metadata(project_name: str):
    """
    Update project metadata (name, tags, verified status, and/or verified segment count):
    PATCH /api/projects/<project_name>
    Body: { "new_name": "...", "tags": [...], "verified": true/false, "verified_segment_count": 0 }
    """
    ctx = get_ctx()
    pm = ctx["pm"]

    try:
        payload = request.get_json(force=True, silent=True) or {}
        new_name = payload.get("new_name")
        new_tags = payload.get("tags")
        new_verified = payload.get("verified")
        new_verified_segment_count = payload.get("verified_segment_count")
        new_autocoded_segment_count = payload.get("autocoded_segment_count")

        # While YOLO inference is running, skip all disk I/O to avoid holding
        # the GIL and slowing down inference (10-20x overhead observed).
        # Name renames are never batched by the frontend during autocode, so
        # it is safe to defer counter/tag updates until inference finishes.
        if _INFERENCE_DEPTH > 0 and new_name is None:
            return ok({"ok": True, "deferred": True})

        # Get the project
        try:
            proj = pm.project(project_name)
        except KeyError:
            return fail("Project not found", 404)

        # Check if any metadata needs updating
        metadata_updated = False

        # Update tags if provided
        if new_tags is not None:
            if not isinstance(new_tags, list):
                return fail("Tags must be an array", 400)
            proj.metadata.tags = new_tags
            metadata_updated = True

        # Update verified status if provided
        if new_verified is not None:
            proj.metadata.verified = bool(new_verified)
            metadata_updated = True

        # Update verified segment count if provided
        if new_verified_segment_count is not None:
            proj.metadata.verified_segment_count = int(new_verified_segment_count)
            metadata_updated = True

        # Update autocoded segment count if provided
        if new_autocoded_segment_count is not None:
            proj.metadata.autocoded_segment_count = int(new_autocoded_segment_count)
            metadata_updated = True

        # Serialize once after all metadata updates
        if metadata_updated:
            proj.metadata.last_updated = datetime.datetime.now()
            proj.metadata.serialize(proj.project_path)

        # Update name if provided (requires renaming directory)
        if new_name and new_name != project_name:
            if not new_name.strip():
                return fail("New name cannot be empty", 400)

            # Check if new name already exists
            if new_name in pm.list_names():
                return fail(f"Project '{new_name}' already exists", 400)

            # Rename the directory
            old_path = proj.project_path
            new_path = old_path.parent / new_name

            try:
                old_path.rename(new_path)

                # Rename images inside the project folder
                try:
                    import re
                    images_dir = new_path / global_var.PROJECT_IMAGES_FOLDER
                    if images_dir.exists() and images_dir.is_dir():
                        for img_file in images_dir.iterdir():
                            if img_file.is_file():
                                match = re.search(r"(?:^|_)(Cam\d+.*)", img_file.name, re.IGNORECASE)
                                if match:
                                    suffix = match.group(1)
                                    new_filename = f"{new_name}_{suffix}"
                                    
                                    if new_filename != img_file.name:
                                        img_file.rename(images_dir / new_filename)
                except Exception:
                    pass

                # Update metadata
                proj.project_path = new_path
                proj.metadata.project_name = new_name

                # --- Update Internal Paths & Image References ---
                # 1. Update paths for all versions so they point to the new directory
                if proj.versions:
                    for v in proj.versions:
                        # v.path is absolute, so we must rebase it to the new project path
                        # Current v.path: .../OldName/versions/YYYYMMDD
                        # New v.path:     .../NewName/versions/YYYYMMDD
                        v.path = new_path / "versions" / v.path.name

                # 2. Update Image References in DataFrames to match new filenames
                def update_image_ref_in_df(df, col_name):
                    if col_name not in df.columns:
                        return False
                    
                    def _update_ref(ref):
                        if not isinstance(ref, str): return ref
                        # Use same regex as file renaming
                        match = re.search(r"(?:^|_)(Cam\d+.*)", ref, re.IGNORECASE)
                        if match:
                            suffix = match.group(1)
                            new_ref = f"{new_name}_{suffix}"
                            return new_ref
                        return ref
                    
                    # Check if any change is needed to avoid unnecessary writes
                    # But easiest is just to apply
                    df[col_name] = df[col_name].apply(_update_ref)
                    return True

                try:
                    # A. Attributes (Latest Version)
                    latest_ver = proj.latest()
                    if update_image_ref_in_df(latest_ver.attributes.df, "Image reference"):
                         latest_ver.attributes.df_dirty = True
                    
                    # B. Treatment (Latest Version)
                    if update_image_ref_in_df(latest_ver.treatment.df, "Image Reference"):
                        latest_ver.treatment.df_dirty = True
                    
                    # C. Geo Data (Project Level)
                    # Force load geo_data from the new path
                    if update_image_ref_in_df(proj.geo_data.df, "Image Reference"):
                        proj.geo_data.df_dirty = True
                        
                    # Save all changes
                    proj.save_all()
                    
                except Exception as data_e:
                    traceback.print_exc()

                proj.metadata.last_updated = datetime.datetime.now()
                proj.metadata.serialize(new_path)

                # Reload the project list to reflect the changes
                pm.projects = [
                    Project(p) for p in pm.des_path.iterdir() if p.is_dir()
                ]

            except Exception as e:
                return fail(f"Failed to rename project: {e}", 500)

        return ok({
            "ok": True,
            "name": new_name if new_name else project_name,
            "tags": proj.metadata.tags or [],
            "verified": proj.metadata.verified,
            "verified_segment_count": proj.metadata.verified_segment_count,
            "autocoded_segment_count": proj.metadata.autocoded_segment_count
        })

    except Exception as e:
        traceback.print_exc()
        return fail(f"Update failed: {e}", 500)
```

## Callees (5)
- [[fn-backend-app-api-projects-routes-py--get-ctx|get_ctx]]
- [[fn-backend-app-api-projects-routes-py--ok|ok]]
- [[fn-backend-app-api-projects-routes-py--fail|fail]]
- [[fn-backend-app-api-projects-routes-py--update-image-ref-in-df|update_image_ref_in_df]]
- [[cls-backend-app-services-project-manager-py--project|Project]]

## External / unresolved calls (20)
- `get` ×5
- `int` ×2
- `now` ×2
- `serialize` ×2
- `rename` ×2
- `is_dir` ×2
- `iterdir` ×2
- `print_exc` ×2
- `get_json`
- `project`
- `isinstance`
- `bool`
- `strip`
- `list_names`
- `exists`
- `is_file`
- `search`
- `group`
- `latest`
- `save_all`
