---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/ShapefileManagement/components/AddShapefileView.tsx::removeFile", "removeFile"]
tags: [function, tsx]
file: "frontend/src/pages/ShapefileManagement/components/AddShapefileView.tsx"
lines: "74-76"
---

# removeFile

**Kind:** Function
**File:** [[file-frontend-src-pages-shapefilemanagement-components-addshapefileview-tsx|AddShapefileView.tsx]]  `frontend/src/pages/ShapefileManagement/components/AddShapefileView.tsx`
**Lines:** 74-76
**Community:** [[com-components-handle-3|components-handle]]
**Signature:** `def removeFile((index: number))`

## Source

```tsx
  function removeFile(index: number) {
    setFiles((prev) => prev.filter((_, i) => i !== index));
  }
```

## Callers (1)
- [[fn-frontend-src-pages-shapefilemanagement-components-addshapefileview-tsx--addshapefileview|AddShapefileView]]

## External / unresolved calls (2)
- `setFiles`
- `filter`
