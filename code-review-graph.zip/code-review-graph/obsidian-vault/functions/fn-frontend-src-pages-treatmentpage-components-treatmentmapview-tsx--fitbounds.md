---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/TreatmentPage/components/TreatmentMapView.tsx::FitBounds", "FitBounds"]
tags: [function, tsx]
file: "frontend/src/pages/TreatmentPage/components/TreatmentMapView.tsx"
lines: "25-33"
---

# FitBounds

**Kind:** Function
**File:** [[file-frontend-src-pages-treatmentpage-components-treatmentmapview-tsx|TreatmentMapView.tsx]]  `frontend/src/pages/TreatmentPage/components/TreatmentMapView.tsx`
**Lines:** 25-33
**Community:** [[com-components-to4326|components-to4326]]
**Signature:** `def FitBounds(({ points }: { points: [number, number][] }))`

## Source

```tsx
function FitBounds({ points }: { points: [number, number][] }) {
  const map = useMap();
  useEffect(() => {
    if (!points.length) return;
    const bounds = L.latLngBounds(points.map(([lat, lng]) => L.latLng(lat, lng)));
    map.fitBounds(bounds, { padding: [24, 24] });
  }, [points, map]);
  return null;
}
```

## Callers (1)
- [[fn-frontend-src-pages-treatmentpage-components-treatmentmapview-tsx--treatmentmapview|TreatmentMapView]]

## External / unresolved calls (6)
- `useMap`
- `useEffect`
- `latLngBounds`
- `map`
- `latLng`
- `fitBounds`
