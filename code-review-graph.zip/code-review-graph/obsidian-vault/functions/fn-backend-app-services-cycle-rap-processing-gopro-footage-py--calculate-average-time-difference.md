---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/cycle_rap_processing_gopro_footage.py::calculate_average_time_difference", "calculate_average_time_difference"]
tags: [function, python]
file: "backend/app/services/cycle_rap_processing_gopro_footage.py"
lines: "169-185"
---

# calculate_average_time_difference

**Kind:** Function
**File:** [[file-backend-app-services-cycle-rap-processing-gopro-footage-py|cycle_rap_processing_gopro_footage.py]]  `backend/app/services/cycle_rap_processing_gopro_footage.py`
**Lines:** 169-185
**Community:** [[com-services-extract|services-extract]]
**Signature:** `def calculate_average_time_difference((df))`

## Source

```python
def calculate_average_time_difference(df):
    # Convert 'TIMESTAMP' column to datetime objects
    df['TIMESTAMP'] = pd.to_datetime(df['TIMESTAMP'], format='%Y:%m:%d %H:%M:%S.%f')

    # Calculate time differences between consecutive timestamps
    df['TIME_DIFF'] = df['TIMESTAMP'].diff().dt.total_seconds()

    # Remove any NaN values in the 'TIME_DIFF' column (the first row will be NaN)
    df = df.dropna(subset=['TIME_DIFF'])

    # Calculate the average time difference
    avg_time_diff = df['TIME_DIFF'].mean()

    # Calculate frequency as the inverse of average time difference
    frequency = 1 / avg_time_diff if avg_time_diff > 0 else None

    return avg_time_diff, frequency
```

## External / unresolved calls (5)
- `to_datetime`
- `total_seconds`
- `diff`
- `dropna`
- `mean`
