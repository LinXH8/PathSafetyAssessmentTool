---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/project_manager.py::ProjectVersion.treatment", "treatment"]
tags: [function, python]
file: "backend/app/services/project_manager.py"
lines: "104-109"
---

# treatment

**Kind:** Function
**File:** [[file-backend-app-services-project-manager-py|project_manager.py]]  `backend/app/services/project_manager.py`
**Lines:** 104-109
**Community:** [[com-services-project|services-project]]
**Signature:** `def treatment((self, value: serializer.Treatment))`

## Source

```python
    def treatment(self, value: serializer.Treatment):
        if not isinstance(value, serializer.Treatment):
            raise TypeError("metadata must be serializer.Treatment")
        self._treatment = value
        self._treatment.df_dirty = True
        # print(f"SETTING TREATMENTS TO {value.df}")
```

## External / unresolved calls (4)
- `Treatment`
- `parse`
- `isinstance`
- `TypeError`
