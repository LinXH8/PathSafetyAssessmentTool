---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/serializer.py::ProjectMetadata.serialize", "serialize"]
tags: [function, python]
file: "backend/app/services/serializer.py"
lines: "433-437"
---

# serialize

**Kind:** Function
**File:** [[file-backend-app-services-serializer-py|serializer.py]]  `backend/app/services/serializer.py`
**Lines:** 433-437
**Community:** [[com-services-fields|services-fields]]
**Signature:** `def serialize((self, to_dir: Path))`

## Source

```python
    def serialize(self, to_dir: Path):
        to_dir.mkdir(parents=True, exist_ok=True)
        file_path = to_dir / "project_metadata.json"
        with open(file_path, 'w') as f:
            json.dump(self.to_dict(), f, indent=4)
```

## Callees (1)
- [[fn-backend-app-services-serializer-py--to-dict|to_dict]]

## External / unresolved calls (3)
- `mkdir`
- `open`
- `dump`
