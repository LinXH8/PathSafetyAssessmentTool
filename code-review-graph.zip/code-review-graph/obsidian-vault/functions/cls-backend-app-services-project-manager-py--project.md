---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/project_manager.py::Project", "Project"]
tags: [class, python]
file: "backend/app/services/project_manager.py"
lines: "185-733"
---

# Project

**Kind:** Class
**File:** [[file-backend-app-services-project-manager-py|project_manager.py]]  `backend/app/services/project_manager.py`
**Lines:** 185-733
**Community:** [[com-services-project|services-project]]
**Signature:** `class Project`

## Source

```python
class Project:
    def __init__(self, project_path: Path = None):
        self.project_path = project_path               #  …/ProjectA
        self._metadata : serializer.ProjectMetadata | None  = None
        self._geo_data : serializer.ProjectGeoData  | None  = None
        self._meta_dirty = False
        self._geo_dirty = False
        self.versions: list[ProjectVersion] = []

        if project_path is None:
            self._metadata : serializer.ProjectMetadata = serializer.ProjectMetadata()
            self._geo_data : serializer.ProjectGeoData  = serializer.ProjectGeoData()
            self.versions.insert(0, ProjectVersion())

    # ─── Version handling ─────────────────────────────────────
    def _discover_versions(self):
        version_dir = self.project_path / "versions"
        self.versions: list[ProjectVersion] = [
            ProjectVersion(p)
            for p in version_dir.iterdir()
            if p.is_dir() and p.name.isdigit() and len(p.name) == 8
        ]
        self.versions.sort(key=lambda v: v.date, reverse=True) # v is a ProjectVersion object, reverse=True sorts date in descending order

    def latest(self) -> ProjectVersion:
        if not self.versions:
            self._discover_versions()
            if not self.versions:
                raise ValueError(f"No dated sub-folders in {self.project_path}")
        return self.versions[0]

    def by_date(self, yyyymmdd: str) -> ProjectVersion:
        for v in self.versions:
            if v.path.name == yyyymmdd:
                return v
        raise ValueError(f"{yyyymmdd} not found in {self.project_path}")
    
    def create_new_version(self, version : ProjectVersion = None) -> ProjectVersion:
        yyyymmdd = datetime.datetime.now().strftime("%Y%m%d")
        ver_path = self.project_path / "versions" / yyyymmdd

        # 2) bail out if already present ---------------------------------------
        if ver_path.exists():
            raise FileExistsError(f"Version {yyyymmdd} already exists in {self.project_path}")

        # 3) create the directory ----------------------------------------------
        ver_path.mkdir(parents=True)

        # 4) build ProjectVersion object & register it -------------------------
        if version is not None:
            ver_obj = version
            ver_obj.path = ver_path
            # Mark all data as dirty so it gets saved to the new version directory
            # This ensures attributes, snapshot_metadata, etc. are copied forward
            # Access properties (not _internal) to trigger lazy loading if needed
            try:
                ver_obj.attributes.df_dirty = True
            except Exception:
                pass  # If attributes can't be loaded, skip
            try:
                ver_obj.snapshot_metadata.df_dirty = True
            except Exception:
                pass
            try:
                ver_obj.treatment.df_dirty = True
            except Exception:
                pass
            try:
                ver_obj.results.df_dirty = True
            except Exception:
                pass
        else:
            ver_obj = ProjectVersion(ver_path)

        self.versions.insert(0, ver_obj)

        return ver_obj
    
    def save_all(self):
        yyyymmdd = datetime.datetime.now().strftime("%Y%m%d")
        today_ver_path = self.project_path / "versions" / yyyymmdd
        if not today_ver_path.exists():
            # 只有在今天目录真的不存在时，才创建新版本
            self.create_new_version(self.latest())

        # NOTE: metadata is NOT serialized here intentionally.
        # Callers are responsible for setting last_updated and calling
        # metadata.serialize() explicitly, so only the intended project
        # gets its timestamp updated.
        if self.geo_data.df_dirty is True:
            self.geo_data.serialize(self.project_path)
        self.latest().save_all()
        return self.project_path
    
    def _delete(self):
        # Delete project directory
        shutil.rmtree(self.project_path, ignore_errors=True)

    def delete_segment(self, index: int):
        # 0. Delete Associated Image (from Geo Data info)
        try:
            if self.geo_data.df is not None and index < len(self.geo_data.df):
                row = self.geo_data.df.iloc[index]
                # Try common column names for image reference
                img_ref = None
                for col in ["Image Reference", "image", "img"]:
                    if col in row:
                        img_ref = row[col]
                        break
                
                if img_ref and isinstance(img_ref, str):
                    image_path = self.project_path / global_var.PROJECT_IMAGES_FOLDER / img_ref
                    if image_path.exists() and image_path.is_file():
                        os.remove(image_path)
        except Exception as e:
            print(f"Error deleting image for segment {index}: {e}")

        # Delete from Geo Data
        # Delete from Geo Data
        if self.geo_data.df is not None and index < len(self.geo_data.df):
            self.geo_data.df = self.geo_data.df.drop(index).reset_index(drop=True)
            self.geo_data.df_dirty = True
        
        # Delete from latest version data
        self.latest().delete_segment(index)

        # Update Metadata
        if self.metadata.size is not None and self.metadata.size > 0:
            self.metadata.size -= 1
        
        # We can't easily know if the deleted segment was verified or autocoded without checking previous state
        # But we can re-calculate verified count if needed, or just decrement if we tracked indices
        # For now, let's just save.
        
        self.save_all()

    def delete_segments(self, indices: list[int]):
        # 0. Delete Associated Images (from Geo Data info)
        try:
            if self.geo_data.df is not None:
                # Filter valid indices
                valid_indices = [i for i in indices if i < len(self.geo_data.df)]
                
                # Identify image paths to delete
                images_to_delete = []
                for idx in valid_indices:
                    row = self.geo_data.df.iloc[idx]
                    img_ref = None
                    for col in ["Image Reference", "image", "img"]:
                        if col in row:
                            img_ref = row[col]
                            break
                    
                    if img_ref and isinstance(img_ref, str):
                        image_path = self.project_path / global_var.PROJECT_IMAGES_FOLDER / img_ref
                        images_to_delete.append(image_path)
                
                # Delete images
                for img_path in images_to_delete:
                    try:
                        if img_path.exists() and img_path.is_file():
                            os.remove(img_path)
                    except Exception as e:
                        # Continue deleting others even if one fails
                        print(f"Error deleting image {img_path}: {e}")

        except Exception as e:
            print(f"Error in batch image deletion: {e}")

        # Delete from Geo Data
        if self.geo_data.df is not None:
            valid_indices = [i for i in indices if i < len(self.geo_data.df)]
            if valid_indices:
                self.geo_data.df = self.geo_data.df.drop(valid_indices).reset_index(drop=True)
                self.geo_data.df_dirty = True
        
        # Delete from latest version data
        self.latest().delete_segments(indices)

        # Update Metadata
        if self.metadata.size is not None:
            # We removed len(valid_indices), but safe to just recount or subtract
            # Recounting is safer if possible, but indices logic above assumes alignment
            # Subtracting the actual number of dropped rows
            count_removed = len(valid_indices) if 'valid_indices' in locals() else len(indices)
            self.metadata.size = max(0, self.metadata.size - count_removed)
        
        self.save_all()

        self.save_all()

    def check_collisions(self, indices: list[int], target_project: 'Project') -> list[str]:
        """
        Check if segments specified by indices already exist in target_project based on Image Reference.
        Returns a list of colliding Image References.
        """
        source_geo = self.geo_data.df
        valid_indices = [i for i in indices if i < len(source_geo)]
        if not valid_indices:
            return []
        
        subset_geo = source_geo.iloc[valid_indices]
        
        target_geo = target_project.geo_data.df
        if target_geo is None or target_geo.empty:
            return []
            
        collisions = []
        # optimization: get set of target image refs
        if "Image Reference" in target_geo.columns:
            # Drop NAs and ensure we ignore empty strings or "nan"
            # astype(str) converts NaN to "nan" if we are not careful with dropna first
            target_series = target_geo["Image Reference"].dropna()
            # Filter out empty or whitespace only strings, and literal "nan"
            target_imgs = {str(x) for x in target_series if str(x).strip() and str(x).lower() != 'nan'}
            
            source_name = self.metadata.project_name
            target_name = target_project.metadata.project_name

            for _, row in subset_geo.iterrows():
                img_ref = row.get("Image Reference")
                # Check for validity before string conversion to be safe
                if pd.notna(img_ref):
                    s_ref = str(img_ref).strip()
                    if s_ref and s_ref.lower() != 'nan':
                        # PREDICT renaming
                        check_ref = s_ref
                        if s_ref.startswith(source_name):
                             check_ref = s_ref.replace(source_name, target_name, 1)
                        
                        if check_ref in target_imgs:
                            collisions.append(check_ref)
        
        if collisions:
            print(f"DEBUG: Found {len(collisions)} collisions. Examples: {collisions[:3]}")
                
        return collisions

    def copy_segments(self, indices: list[int], target_project: 'Project', replace: bool = False):
        """
        Copy segments (and their images) specified by indices from self (source) to target_project.
        """
        # 1. Get filtered data from source (latest version + geo_data)
        # We can reuse the logic from search/create_temporary_project but specific to indices
        
        source_geo = self.geo_data.df
        source_attr = self.latest().attributes.df
        source_res = self.latest().results.df
        source_treat = self.latest().treatment.df
        source_imgs = []
# … (truncated, 299 more lines — see source file)
```

## Callers (7)
- [[fn-backend-app-api-projects-routes-py--copy-segments|copy_segments]]
- [[fn-backend-app-api-projects-routes-py--update-project-metadata|update_project_metadata]]
- [[fn-backend-app-services-project-manager-py--copy-segments|copy_segments]]
- [[fn-backend-app-services-project-manager-py--discover-projects|_discover_projects]]
- [[fn-backend-app-services-project-manager-py--create-project|create_project]]
- [[fn-backend-app-services-project-manager-py--merge-project-list|merge_project_list]]
- [[fn-backend-inspect-data-py--inspect-project|inspect_project]]
