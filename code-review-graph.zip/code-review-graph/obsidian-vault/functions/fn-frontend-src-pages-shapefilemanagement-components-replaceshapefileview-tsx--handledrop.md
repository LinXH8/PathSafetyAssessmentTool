---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/ShapefileManagement/components/ReplaceShapefileView.tsx::handleDrop", "handleDrop"]
tags: [function, tsx]
file: "frontend/src/pages/ShapefileManagement/components/ReplaceShapefileView.tsx"
lines: "47-54"
---

# handleDrop

**Kind:** Function
**File:** [[file-frontend-src-pages-shapefilemanagement-components-replaceshapefileview-tsx|ReplaceShapefileView.tsx]]  `frontend/src/pages/ShapefileManagement/components/ReplaceShapefileView.tsx`
**Lines:** 47-54
**Community:** [[com-components-handle-4|components-handle]]
**Signature:** `def handleDrop((e: React.DragEvent))`

## Source

```tsx
  function handleDrop(e: React.DragEvent) {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    const droppedFiles = Array.from(e.dataTransfer.files);
    addFiles(droppedFiles);
  }
```

## Callees (1)
- [[fn-frontend-src-pages-shapefilemanagement-components-replaceshapefileview-tsx--addfiles|addFiles]]

## External / unresolved calls (4)
- `preventDefault`
- `stopPropagation`
- `setDragActive`
- `from`
