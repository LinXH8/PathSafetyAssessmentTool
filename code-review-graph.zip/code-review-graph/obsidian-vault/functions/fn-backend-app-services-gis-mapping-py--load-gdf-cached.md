---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/gis_mapping.py::_load_gdf_cached", "_load_gdf_cached"]
tags: [function, python]
file: "backend/app/services/gis_mapping.py"
lines: "13-41"
---

# _load_gdf_cached

**Kind:** Function
**File:** [[file-backend-app-services-gis-mapping-py|gis_mapping.py]]  `backend/app/services/gis_mapping.py`
**Lines:** 13-41
**Community:** [[com-services-width|services-width]]
**Signature:** `def _load_gdf_cached((path_str: str, metric_crs: str, src_mtime: float))`

## Description

> Load shapefile → reproject → warm sindex.  Uses parquet cache for speed.

## Source

```python
def _load_gdf_cached(path_str: str, metric_crs: str, src_mtime: float):
    """Load shapefile → reproject → warm sindex.  Uses parquet cache for speed."""
    shp = Path(path_str)
    cache = shp.with_name(shp.stem + ".cache.parquet")

    # Fast path: read from parquet cache (skips shapefile parsing + CRS conversion)
    if cache.exists():
        try:
            if cache.stat().st_mtime >= src_mtime:
                gdf = gpd.read_parquet(cache)
                _ = gdf.sindex
                return gdf
        except Exception:
            pass  # corrupt / incompatible cache → fall through

    # Read shapefile via pyogrio (C-level GDAL reader — releases GIL, ~5x faster than fiona)
    gdf = gpd.read_file(path_str, engine="pyogrio")
    if gdf.crs is None:
        raise ValueError(f"{shp.name} missing CRS")
    gdf = gdf.to_crs(metric_crs)
    _ = gdf.sindex

    # Write parquet cache for next startup
    try:
        gdf.to_parquet(cache)
    except Exception:
        pass

    return gdf
```

## Callers (1)
- [[fn-backend-app-services-gis-mapping-py--get|get]]

## External / unresolved calls (9)
- `Path`
- `with_name`
- `exists`
- `stat`
- `read_parquet`
- `read_file`
- `ValueError`
- `to_crs`
- `to_parquet`
