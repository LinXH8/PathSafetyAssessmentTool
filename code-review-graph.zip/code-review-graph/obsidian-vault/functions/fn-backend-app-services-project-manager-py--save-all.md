---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/project_manager.py::ProjectVersion.save_all", "save_all"]
tags: [function, python]
file: "backend/app/services/project_manager.py"
lines: "120-128"
---

# save_all

**Kind:** Function
**File:** [[file-backend-app-services-project-manager-py|project_manager.py]]  `backend/app/services/project_manager.py`
**Lines:** 120-128
**Community:** [[com-services-project|services-project]]
**Signature:** `def save_all((self))`

## Source

```python
    def save_all(self):
        if self.snapshot_metadata.df_dirty is True:
            self.snapshot_metadata.serialize(self.path / self.STR_SNAPSHOT_METADATA)
        if self.attributes.df_dirty is True:
            self.attributes.serialize(self.path / self.STR_ATTRIBUTES)
        if self.results.df_dirty is True:
            self.results.serialize(self.path / self.STR_RESULTS)
        if self.treatment.df_dirty is True:
            self.treatment.serialize(self.path / self.STR_TREATMENT)
```

## Callers (5)
- [[fn-backend-app-services-project-manager-py--save-all-2|save_all]]
- [[fn-backend-app-services-project-manager-py--delete-segment-2|delete_segment]]
- [[fn-backend-app-services-project-manager-py--delete-segments-2|delete_segments]]
- [[fn-backend-app-services-project-manager-py--copy-segments|copy_segments]]
- [[fn-backend-app-services-project-manager-py--create-project|create_project]]

## External / unresolved calls (1)
- `serialize` ×4
