---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PostTreatmentAnalysisPage/postTreatmentAnalysisPage.tsx::getTagBorderColor", "getTagBorderColor"]
tags: [function, tsx]
file: "frontend/src/pages/PostTreatmentAnalysisPage/postTreatmentAnalysisPage.tsx"
lines: "11-15"
---

# getTagBorderColor

**Kind:** Function
**File:** [[file-frontend-src-pages-posttreatmentanalysispage-posttreatmentanalysispage-tsx|postTreatmentAnalysisPage.tsx]]  `frontend/src/pages/PostTreatmentAnalysisPage/postTreatmentAnalysisPage.tsx`
**Lines:** 11-15
**Community:** [[com-posttreatmentanalysispage-tag|posttreatmentanalysispage-tag]]
**Signature:** `def getTagBorderColor((tag: string)) -> : string`

## Source

```tsx
function getTagBorderColor(tag: string): string {
  if (tag === "Pre") return "#fb923c"; // orange.emphasized
  if (tag === "Post") return "#22c55e"; // green.emphasized
  return "rgba(0, 0, 0, 0.1)";
}
```

## Callers (1)
- [[fn-frontend-src-pages-posttreatmentanalysispage-posttreatmentanalysispage-tsx--posttreatmentanalysispage|PostTreatmentAnalysisPage]]
