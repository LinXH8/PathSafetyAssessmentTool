---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/serializer.py::ProjectGeoData.populate_linestring", "populate_linestring"]
tags: [function, python]
file: "backend/app/services/serializer.py"
lines: "344-350"
---

# populate_linestring

**Kind:** Function
**File:** [[file-backend-app-services-serializer-py|serializer.py]]  `backend/app/services/serializer.py`
**Lines:** 344-350
**Community:** [[com-services-fields|services-fields]]
**Signature:** `def populate_linestring((self, geometries: gpd.GeoSeries))`

## Source

```python
    def populate_linestring(self, geometries: gpd.GeoSeries):
        if geometries.crs.to_epsg() != 3414:
            geometries = geometries.to_crs("EPSG:3414")

        self.df[self.Fields.LINESTRING_STR] = geometries["geometry"]
        per_segment_lengths = geometries.length
        self.df[self.Fields.DISTANCE_STR] = per_segment_lengths.cumsum()
```

## External / unresolved calls (3)
- `to_epsg`
- `to_crs`
- `cumsum`
