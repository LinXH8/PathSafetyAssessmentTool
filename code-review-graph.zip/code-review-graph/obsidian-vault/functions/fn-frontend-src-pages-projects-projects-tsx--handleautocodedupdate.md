---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/Projects/projects.tsx::handleAutocodedUpdate", "handleAutocodedUpdate"]
tags: [function, tsx]
file: "frontend/src/pages/Projects/projects.tsx"
lines: "127-144"
---

# handleAutocodedUpdate

**Kind:** Function
**File:** [[file-frontend-src-pages-projects-projects-tsx|projects.tsx]]  `frontend/src/pages/Projects/projects.tsx`
**Lines:** 127-144
**Community:** [[com-projects-tag|projects-tag]]
**Signature:** `def handleAutocodedUpdate((event: CustomEvent))`

## Source

```tsx
    const handleAutocodedUpdate = (event: CustomEvent) => {
      const { projectName, autocodedSegmentCount } = event.detail;

      // Update the project list directly
      setProjectList((prev) => {
        if (!prev) return prev;
        return {
          projects: prev.projects.map((p) => {
            if (p.name === projectName) {
              if (autocodedSegmentCount !== undefined) {
                return { ...p, autocoded_segment_count: autocodedSegmentCount };
              }
            }
            return p;
          }),
        };
      });
    };
```

## External / unresolved calls (2)
- `setProjectList`
- `map`
