---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/sidebar/components/ImageUploadModal.tsx::handleDragOver", "handleDragOver"]
tags: [function, tsx]
file: "frontend/src/pages/sidebar/components/ImageUploadModal.tsx"
lines: "62-65"
---

# handleDragOver

**Kind:** Function
**File:** [[file-frontend-src-pages-sidebar-components-imageuploadmodal-tsx|ImageUploadModal.tsx]]  `frontend/src/pages/sidebar/components/ImageUploadModal.tsx`
**Lines:** 62-65
**Community:** [[com-components-handle-6|components-handle]]
**Signature:** `def handleDragOver((e: React.DragEvent))`

## Source

```tsx
  function handleDragOver(e: React.DragEvent) {
    e.preventDefault();
    e.stopPropagation();
  }
```

## External / unresolved calls (2)
- `preventDefault`
- `stopPropagation`
