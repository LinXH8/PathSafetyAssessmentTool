---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/project_manager.py::Project.by_date", "by_date"]
tags: [function, python]
file: "backend/app/services/project_manager.py"
lines: "216-220"
---

# by_date

**Kind:** Function
**File:** [[file-backend-app-services-project-manager-py|project_manager.py]]  `backend/app/services/project_manager.py`
**Lines:** 216-220
**Community:** [[com-services-project|services-project]]
**Signature:** `def by_date((self, yyyymmdd: str)) -> ProjectVersion`

## Source

```python
    def by_date(self, yyyymmdd: str) -> ProjectVersion:
        for v in self.versions:
            if v.path.name == yyyymmdd:
                return v
        raise ValueError(f"{yyyymmdd} not found in {self.project_path}")
```

## External / unresolved calls (1)
- `ValueError`
