---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/AttributesDropdown.tsx::attr", "attr"]
tags: [function, tsx]
file: "frontend/src/pages/PathAnalysisPage/components/AttributesDropdown.tsx"
lines: "878-878"
---

# attr

**Kind:** Function
**File:** [[file-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx|AttributesDropdown.tsx]]  `frontend/src/pages/PathAnalysisPage/components/AttributesDropdown.tsx`
**Lines:** 878-878
**Community:** [[com-components-handle|components-handle]]
**Signature:** `def attr()`

## Source

```tsx
  const hasAnyFilter = selectedAttributes.some(attr => attr !== null);
```
