---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/scoreband/colorConstants.ts::getRiskBandLabel", "getRiskBandLabel"]
tags: [function, typescript]
file: "frontend/src/components/visualization/scoreband/colorConstants.ts"
lines: "39-44"
---

# getRiskBandLabel

**Kind:** Function
**File:** [[file-frontend-src-components-visualization-scoreband-colorconstants-ts|colorConstants.ts]]  `frontend/src/components/visualization/scoreband/colorConstants.ts`
**Lines:** 39-44
**Community:** [[com-scoreband-risk|scoreband-risk]]
**Signature:** `def getRiskBandLabel((score: number)) -> : 'Low' | 'Medium' | 'High' | 'Extreme'`

## Description

> Get risk band label based on score
> Thresholds: Low (<10), Medium (10-25), High (25-60), Extreme (>60)

## Source

```typescript
export function getRiskBandLabel(score: number): 'Low' | 'Medium' | 'High' | 'Extreme' {
  if (score < 10) return 'Low';
  if (score <= 25) return 'Medium';
  if (score <= 60) return 'High';
  return 'Extreme';
}
```
