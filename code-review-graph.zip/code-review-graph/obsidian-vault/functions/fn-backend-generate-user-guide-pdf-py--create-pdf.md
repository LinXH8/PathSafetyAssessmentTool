---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/generate_user_guide_pdf.py::create_pdf", "create_pdf"]
tags: [function, python]
file: "backend/generate_user_guide_pdf.py"
lines: "43-73"
---

# create_pdf

**Kind:** Function
**File:** [[file-backend-generate-user-guide-pdf-py|generate_user_guide_pdf.py]]  `backend/generate_user_guide_pdf.py`
**Lines:** 43-73
**Community:** [[com-backend-pdf|backend-pdf]]
**Signature:** `def create_pdf(())`

## Source

```python
def create_pdf():
    pdf = PDF()
    pdf.add_page()
    
    # Intro
    pdf.set_font('helvetica', '', 11)
    pdf.multi_cell(0, 6, "Welcome to the Path Safety Assessment Tool (PSAT). This tool allows you to evaluate active mobility paths using the CycleRAP model.")
    pdf.ln(5)

    # Section 1
    pdf.section_title("1. Getting Started")
    pdf.print_bullet("Start a Project:", "From the Home page, click \"New Project\" to import your shapefiles, mapping data, and street-level imagery.")
    pdf.print_bullet("Project Settings:", "Ensure your project name is correctly set. You can manage multiple projects simultaneously from the Projects listing.")
    pdf.ln(5)

    # Section 2
    pdf.section_title("2. Coding Page")
    pdf.print_bullet("Auto-coding:", "Use the \"Auto-code image\" button to leverage AI models that automatically identify risk factors from the image.")
    pdf.print_bullet("GIS Coding:", "Our GIS backend automatically evaluates contextual data such as proximity to MRT exits, bus stops, and road intersections.")
    pdf.print_bullet("Manual Review:", "You can meticulously review and override the attributes predicted by the AI directly on the panel.")
    pdf.ln(5)

    # Section 3
    pdf.section_title("3. Map View & Analysis")
    pdf.print_bullet("GIS Layers:", "Toggle the map layers to visualize Footpaths, Cycling Paths, and Road Crossings.")
    pdf.print_bullet("Risk Bands:", "Segments are color-coded based on overall risk logic.")
    pdf.print_bullet("Editing:", "You can add or delete segment points directly on the Map preview using the cursor tools.")

    output_path = os.path.join("..", "frontend", "public", "Path_Safety_Assessment_Tool_User_Guide.pdf")
    pdf.output(output_path)
    print(f"PDF successfully created at {output_path}")
```

## Callees (3)
- [[cls-backend-generate-user-guide-pdf-py--pdf|PDF]]
- [[fn-backend-generate-user-guide-pdf-py--section-title|section_title]]
- [[fn-backend-generate-user-guide-pdf-py--print-bullet|print_bullet]]

## External / unresolved calls (7)
- `ln` ×3
- `add_page`
- `set_font`
- `multi_cell`
- `join`
- `output`
- `print`
