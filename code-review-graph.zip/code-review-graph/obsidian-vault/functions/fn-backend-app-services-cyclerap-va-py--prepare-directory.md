---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/cycleRAP_VA.py::prepare_directory", "prepare_directory"]
tags: [function, python]
file: "backend/app/services/cycleRAP_VA.py"
lines: "104-109"
---

# prepare_directory

**Kind:** Function
**File:** [[file-backend-app-services-cyclerap-va-py|cycleRAP_VA.py]]  `backend/app/services/cycleRAP_VA.py`
**Lines:** 104-109
**Community:** [[com-services-distance|services-distance]]
**Signature:** `def prepare_directory((output_dir_name, output_path = None)) -> str`

## Source

```python
def prepare_directory(output_dir_name, output_path = None) -> str:
    if output_path is None: full_path = get_full_path(output_dir_name)
    else: full_path = os.path.join(output_path, output_dir_name)
    if os.path.exists(full_path): shutil.rmtree(full_path)
    os.makedirs(full_path)
    return full_path
```

## Callers (2)
- [[fn-backend-app-services-cyclerap-va-py--extract-images-distance|extract_images_distance]]
- [[fn-backend-app-services-cyclerap-va-py--extract-images-interval|extract_images_interval]]

## Callees (1)
- [[fn-backend-app-services-cyclerap-va-py--get-full-path|get_full_path]]

## External / unresolved calls (4)
- `join`
- `exists`
- `rmtree`
- `makedirs`
