---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/gis_mapping.py::GIS._near", "_near"]
tags: [function, python]
file: "backend/app/services/gis_mapping.py"
lines: "167-173"
---

# _near

**Kind:** Function
**File:** [[file-backend-app-services-gis-mapping-py|gis_mapping.py]]  `backend/app/services/gis_mapping.py`
**Lines:** 167-173
**Community:** [[com-services-width|services-width]]
**Signature:** `def _near((self, layer, pt, dist))`

## Source

```python
    def _near(self, layer, pt, dist):
        gdf = self.store.get(layer)
        idx = gdf.sindex.query(pt.buffer(dist))
        if not len(idx):
            return False
        d = gdf.iloc[idx].distance(pt).min()
        return d <= dist
```

## Callers (5)
- [[fn-backend-app-services-gis-mapping-py--is-mrt|is_mrt]]
- [[fn-backend-app-services-gis-mapping-py--is-bus-lane|is_bus_lane]]
- [[fn-backend-app-services-gis-mapping-py--is-bus-stop|is_bus_stop]]
- [[fn-backend-app-services-gis-mapping-py--is-road-crossing|is_road_crossing]]
- [[fn-backend-app-services-gis-mapping-py--is-parking|is_parking]]

## Callees (1)
- [[fn-backend-app-services-gis-mapping-py--get|get]]

## External / unresolved calls (5)
- `query`
- `buffer`
- `len`
- `min`
- `distance`
