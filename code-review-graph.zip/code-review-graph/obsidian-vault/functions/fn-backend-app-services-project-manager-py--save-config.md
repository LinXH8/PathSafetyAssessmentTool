---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/project_manager.py::project_manager.save_config", "save_config"]
tags: [function, python]
file: "backend/app/services/project_manager.py"
lines: "994-996"
---

# save_config

**Kind:** Function
**File:** [[file-backend-app-services-project-manager-py|project_manager.py]]  `backend/app/services/project_manager.py`
**Lines:** 994-996
**Community:** [[com-services-project|services-project]]
**Signature:** `def save_config((self, config))`

## Source

```python
    def save_config(self, config):
        with open(get_config_path(), "w") as json_file:
            json.dump(config, json_file, indent=4)
```

## Callers (2)
- [[fn-backend-app-services-project-manager-py--initialise|_initialise]]
- [[fn-backend-app-services-project-manager-py--write-config|write_config]]

## Callees (1)
- [[fn-backend-app-services-project-manager-py--get-config-path|get_config_path]]

## External / unresolved calls (2)
- `open`
- `dump`
