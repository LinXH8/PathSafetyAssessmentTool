---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/run_attribute_inference.py::analyze_obstacle", "analyze_obstacle"]
tags: [function, python]
file: "run_attribute_inference.py"
lines: "235-260"
---

# analyze_obstacle

**Kind:** Function
**File:** [[file-run-attribute-inference-py|run_attribute_inference.py]]  `run_attribute_inference.py`
**Lines:** 235-260
**Community:** [[com-pathsafetyassessmenttool-compute|pathsafetyassessmenttool-compute]]
**Signature:** `def analyze_obstacle((obstacle_box, path_mask, threshold=0.1))`

## Description

> Return (is_blocking, ratio, path_center_x, obstacle_center_x).
>
> Measures path width at the bottom edge of the obstacle bounding box using
> the 5th–95th percentile of path-pixel x-coordinates (same technique as
> obstacle-visualizer/backend/logic.py:analyze_obstacle).

## Source

```python
def analyze_obstacle(obstacle_box, path_mask, threshold=0.1):
    """Return (is_blocking, ratio, path_center_x, obstacle_center_x).

    Measures path width at the bottom edge of the obstacle bounding box using
    the 5th–95th percentile of path-pixel x-coordinates (same technique as
    obstacle-visualizer/backend/logic.py:analyze_obstacle).
    """
    x_min, y_min, x_max, y_max = map(int, obstacle_box)
    obstacle_center_x = int((x_min + x_max) / 2)
    bottom_y = min(y_max, path_mask.shape[0] - 1)

    path_row = path_mask[bottom_y, :]
    if not np.any(path_row):
        return False, 0.0, 0, 0  # obstacle not on path

    path_pixels_x = np.where(path_row > 0)[0]
    path_center_x = int(np.median(path_pixels_x))
    path_width = np.percentile(path_pixels_x, 95) - np.percentile(path_pixels_x, 5)

    if path_width < 10:
        return False, 0.0, 0, 0  # path too narrow to reliably analyse

    deviation = abs(path_center_x - obstacle_center_x)
    ratio = deviation / path_width
    is_blocking = ratio < threshold
    return is_blocking, ratio, path_center_x, obstacle_center_x
```

## Callers (2)
- [[fn-run-attribute-inference-py--compute-width-restriction|compute_width_restriction]]
- [[fn-run-attribute-inference-py--annotate-image|annotate_image]]

## External / unresolved calls (8)
- `int` ×2
- `map`
- `min`
- `any`
- `where`
- `median`
- `percentile`
- `abs`
