---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/serializer.py::data_loader.getTrafficSpeedBands_df", "getTrafficSpeedBands_df"]
tags: [function, python]
file: "backend/app/services/serializer.py"
lines: "490-508"
---

# getTrafficSpeedBands_df

**Kind:** Function
**File:** [[file-backend-app-services-serializer-py|serializer.py]]  `backend/app/services/serializer.py`
**Lines:** 490-508
**Community:** [[com-services-fields|services-fields]]
**Signature:** `def getTrafficSpeedBands_df((cls)) -> pd.DataFrame | dict`

## Source

```python
    def getTrafficSpeedBands_df(cls) -> pd.DataFrame | dict:
        today = datetime.today().strftime('%Y-%m-%d')
        cache_path = os.path.join(cls.cache_dir, f"{today}_TrafficSpeedBands.json")
        
        if os.path.exists(cache_path):
            print("--------------------------------------------------------")
            print("NEW DATA")
            with open(cache_path, 'r') as f:
                data = json.load(f)
                cls.TrafficSpeedBands_df = pd.json_normalize(data)
        else:
            print("--------------------------------------------------------")
            print("CLEAR OLD DATA")
            cls.clean_old_cache("TrafficSpeedBands")
            cls.TrafficSpeedBands_df = cls.APIcall(cls.TrafficSpeedBands_URL)
            with open(cache_path, 'w') as f:
                json.dump(cls.TrafficSpeedBands_df.to_dict(orient="records"), f)

        return cls.TrafficSpeedBands_df
```

## Callees (3)
- [[fn-backend-app-services-serializer-py--clean-old-cache|clean_old_cache]]
- [[fn-backend-app-services-serializer-py--apicall|APIcall]]
- [[fn-backend-app-services-serializer-py--to-dict|to_dict]]

## External / unresolved calls (9)
- `print` ×4
- `open` ×2
- `strftime`
- `today`
- `join`
- `exists`
- `load`
- `json_normalize`
- `dump`
