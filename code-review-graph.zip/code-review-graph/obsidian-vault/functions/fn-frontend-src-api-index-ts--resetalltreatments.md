---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/api/index.ts::resetAllTreatments", "resetAllTreatments"]
tags: [function, typescript]
file: "frontend/src/api/index.ts"
lines: "795-807"
---

# resetAllTreatments

**Kind:** Function
**File:** [[file-frontend-src-api-index-ts|index.ts]]  `frontend/src/api/index.ts`
**Lines:** 795-807
**Community:** [[com-api-project|api-project]]
**Signature:** `def resetAllTreatments((
  project: string
)) -> : Promise<ResetAllTreatmentsResult>`

## Source

```typescript
export async function resetAllTreatments(
  project: string
): Promise<ResetAllTreatmentsResult> {
  const res = await fetch(
    `/api/projects/${encodeURIComponent(project)}/treatments/reset-all`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
    }
  );
  if (!res.ok) throw new Error(await readError(res));
  return res.json();
}
```

## Callers (1)
- [[fn-frontend-src-pages-sidebar-sidebar-tsx--sidebar|Sidebar]]

## Callees (1)
- [[fn-frontend-src-api-index-ts--readerror|readError]]

## External / unresolved calls (3)
- `fetch`
- `encodeURIComponent`
- `json`
