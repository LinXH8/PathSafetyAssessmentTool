---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/cycleRAP_interface.py::cycleRAP_interface.__init__", "__init__"]
tags: [function, python]
file: "backend/app/services/cycleRAP_interface.py"
lines: "26-27"
---

# __init__

**Kind:** Function
**File:** [[file-backend-app-services-cyclerap-interface-py|cycleRAP_interface.py]]  `backend/app/services/cycleRAP_interface.py`
**Lines:** 26-27
**Community:** [[com-services-cycle|services-cycle]]
**Signature:** `def __init__((self))`

## Source

```python
    def __init__(self):
        raise RuntimeError("Cannot create class instance, use the class methods instead")
```

## External / unresolved calls (1)
- `RuntimeError`
