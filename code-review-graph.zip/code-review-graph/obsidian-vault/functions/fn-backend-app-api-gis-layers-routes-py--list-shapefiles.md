---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/gis_layers/routes.py::list_shapefiles", "list_shapefiles"]
tags: [function, python]
file: "backend/app/api/gis_layers/routes.py"
lines: "171-183"
---

# list_shapefiles

**Kind:** Function
**File:** [[file-backend-app-api-gis-layers-routes-py|routes.py]]  `backend/app/api/gis_layers/routes.py`
**Lines:** 171-183
**Community:** [[com-gis-layers-shapefiles|gis-layers-shapefiles]]
**Signature:** `def list_shapefiles(())`

## Description

> Return metadata for every .shp file found under backend/shapefiles/.

## Source

```python
def list_shapefiles():
    """Return metadata for every .shp file found under backend/shapefiles/."""
    root = _shp_root()
    if not root.exists():
        return jsonify([])

    results = [
        _file_info(p, root)
        for p in sorted(root.rglob("*.shp"))
        if not any(part.startswith("temp") for part in p.parts)
        and not p.name.startswith("._")   # macOS AppleDouble metadata files
    ]
    return jsonify(results)
```

## Callees (2)
- [[fn-backend-app-api-gis-layers-routes-py--shp-root|_shp_root]]
- [[fn-backend-app-api-gis-layers-routes-py--file-info|_file_info]]

## External / unresolved calls (6)
- `jsonify` ×2
- `startswith` ×2
- `exists`
- `sorted`
- `rglob`
- `any`
