---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx::point", "point"]
tags: [function, tsx]
file: "frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx"
lines: "1434-1445"
---

# point

**Kind:** Function
**File:** [[file-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx|PathAnalysisMapView.tsx]]  `frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx`
**Lines:** 1434-1445
**Community:** [[com-components-handle-2|components-handle]]
**Signature:** `def point()`

## Source

```tsx
      sortedData.forEach(point => {
        const projectName = point.projectName;
        const imageRef = point.f.properties?.["Image Reference"];

        // Skip if no image reference or placeholder
        if (projectName && imageRef && imageRef !== "-" && imageRef !== "None" && imageRef !== "") {
          if (!projectImages[projectName]) {
            projectImages[projectName] = [];
          }
          projectImages[projectName].push(imageRef);
        }
      });
```

## Callees (1)
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--getcolumnvalue|getColumnValue]]

## External / unresolved calls (6)
- `startsWith` ×2
- `some`
- `toLowerCase`
- `includes`
- `map`
- `push`
