---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/CodingPage/components/AttributesPanel.tsx::isManuallyEdited", "isManuallyEdited"]
tags: [function, tsx]
file: "frontend/src/pages/CodingPage/components/AttributesPanel.tsx"
lines: "249-283"
---

# isManuallyEdited

**Kind:** Function
**File:** [[file-frontend-src-pages-codingpage-components-attributespanel-tsx|AttributesPanel.tsx]]  `frontend/src/pages/CodingPage/components/AttributesPanel.tsx`
**Lines:** 249-283
**Community:** [[com-components-group|components-group]]
**Signature:** `def isManuallyEdited((key: string, currentValue: any)) -> : boolean`

## Source

```tsx
  const isManuallyEdited = (key: string, currentValue: any): boolean => {
    if (!originalRow) return false;
    const originalValue = originalRow[key];

    // Handle null/undefined as equivalent
    if (currentValue === null || currentValue === undefined) {
      return originalValue !== null && originalValue !== undefined;
    }
    if (originalValue === null || originalValue === undefined) {
      return currentValue !== null && currentValue !== undefined;
    }

    // Strict comparison first (same type, same value)
    if (currentValue === originalValue) {
      return false;
    }

    // Type-aware comparison for numeric values
    // If one is a number and one is a string, try numeric comparison
    if (typeof currentValue === 'number' && typeof originalValue === 'string') {
      const parsedOriginal = Number(originalValue);
      if (!Number.isNaN(parsedOriginal) && currentValue === parsedOriginal) {
        return false;
      }
    }
    if (typeof currentValue === 'string' && typeof originalValue === 'number') {
      const parsedCurrent = Number(currentValue);
      if (!Number.isNaN(parsedCurrent) && parsedCurrent === originalValue) {
        return false;
      }
    }

    // If we get here, values are genuinely different
    return true;
  };
```

## Callers (1)
- [[fn-frontend-src-pages-codingpage-components-attributespanel-tsx--attributespanel|AttributesPanel]]

## External / unresolved calls (2)
- `Number` ×2
- `isNaN` ×2
