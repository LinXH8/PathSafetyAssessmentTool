---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/serializer.py::BaseTable", "BaseTable"]
tags: [class, python]
file: "backend/app/services/serializer.py"
lines: "64-142"
---

# BaseTable

**Kind:** Class
**File:** [[file-backend-app-services-serializer-py|serializer.py]]  `backend/app/services/serializer.py`
**Lines:** 64-142
**Community:** [[com-services-fields|services-fields]]
**Signature:** `class BaseTable`

## Source

```python
class BaseTable:
    def __init__(self, field_class, size=0, values=None):
        self.Fields = field_class
        self.fields = [
            v for k, v in field_class.__dict__.items()
            if isinstance(v, str) and k.endswith('_STR')
        ]
    
        if values is not None:
            self._df = pd.DataFrame([values] * size, columns=self.fields)
        elif size > 0:
            self._df = pd.DataFrame([{f: None for f in self.fields} for _ in range(size)])
        else:
            self._df = pd.DataFrame(columns=self.fields)

        self.df_dirty = False
        self.loc = LocWrapper(self)

    @property
    def df(self) -> pd.DataFrame:
        return self._df

    @df.setter
    def df(self, value : pd.DataFrame):
        if not isinstance(value, pd.DataFrame):
            raise TypeError("Value is not a pd.Dataframe")
        self._df = value
        self.df_dirty = True   

    def serialize(self, file_path: Path):
        file_path.parent.mkdir(parents=True, exist_ok=True)
        ext = file_path.suffix.lower()
        df = self.df if getattr(self, "df", None) is not None else pd.DataFrame()
        if ext == ".csv":
            df.to_csv(file_path, index=False)
        elif ext == ".xlsx":
            df.to_excel(file_path, index=False)
        elif ext == ".json":
            df.to_json(file_path, orient="records")
        else:
            raise ValueError(f"Unsupported file type: {ext}")
        self.df_dirty = False

    def parse(self, file_path: Path):
        """从磁盘读取表；文件不存在或为空时，初始化空表并标记 dirty。"""
        # 1) 不存在 / 空文件：初始化空 df
        if not file_path.exists() or file_path.stat().st_size == 0:  # ← 关键：为空文件直接兜底
            self.df = pd.DataFrame()
            self.df_dirty = True
            return

        ext = file_path.suffix.lower()
        if ext == ".csv":
            try:
                self.df = pd.read_csv(file_path, encoding="utf-8")
            except UnicodeDecodeError:
                self.df = pd.read_csv(file_path, encoding="latin1")
            except EmptyDataError:  # ← 关键：即便遇到空内容也兜底
                self.df = pd.DataFrame()
                self.df_dirty = True
                return
        elif ext == ".xlsx":
            self.df = pd.read_excel(file_path)
        elif ext == ".json":
            self.df = pd.read_json(file_path)
        else:
            raise ValueError(f"Unsupported file type: {ext}")

        # Add missing columns defined in the schema (e.g. for backward compatibility)
        if hasattr(self, 'fields') and self.fields:
            for count, col in enumerate(self.fields):
                if col not in self.df.columns:
                    # Insert missing column at the schema-defined index if possible
                    try:
                        self.df.insert(count, col, None)
                    except ValueError:
                        self.df[col] = None

        self.df_dirty = False
```
