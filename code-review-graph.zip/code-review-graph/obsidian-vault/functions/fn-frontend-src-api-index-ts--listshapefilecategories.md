---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/api/index.ts::listShapefileCategories", "listShapefileCategories"]
tags: [function, typescript]
file: "frontend/src/api/index.ts"
lines: "542-546"
---

# listShapefileCategories

**Kind:** Function
**File:** [[file-frontend-src-api-index-ts|index.ts]]  `frontend/src/api/index.ts`
**Lines:** 542-546
**Community:** [[com-api-project|api-project]]
**Signature:** `def listShapefileCategories(()) -> : Promise<ShapefileCategoryInfo[]>`

## Description

> List all shapefile categories (subdirectories)

## Source

```typescript
export async function listShapefileCategories(): Promise<ShapefileCategoryInfo[]> {
  const res = await fetch("/api/shapefiles/categories");
  if (!res.ok) throw new Error(await readError(res));
  return res.json();
}
```

## Callees (1)
- [[fn-frontend-src-api-index-ts--readerror|readError]]

## External / unresolved calls (2)
- `fetch`
- `json`
