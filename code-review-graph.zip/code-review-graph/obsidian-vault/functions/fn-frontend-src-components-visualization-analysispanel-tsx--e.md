---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/AnalysisPanel.tsx::e", "e"]
tags: [function, tsx]
file: "frontend/src/components/visualization/AnalysisPanel.tsx"
lines: "124-124"
---

# e

**Kind:** Function
**File:** [[file-frontend-src-components-visualization-analysispanel-tsx|AnalysisPanel.tsx]]  `frontend/src/components/visualization/AnalysisPanel.tsx`
**Lines:** 124-124
**Community:** [[com-visualization-width|visualization-width]]
**Signature:** `def e()`

## Source

```tsx
      .catch(e => setCurvError(e instanceof Error ? e.message : 'Failed'))
```

## External / unresolved calls (2)
- `setWidthError`
- `setCurvError`
