---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/api/index.ts::autocodeAll", "autocodeAll"]
tags: [function, typescript]
file: "frontend/src/api/index.ts"
lines: "311-321"
---

# autocodeAll

**Kind:** Function
**File:** [[file-frontend-src-api-index-ts|index.ts]]  `frontend/src/api/index.ts`
**Lines:** 311-321
**Community:** [[com-api-project|api-project]]
**Signature:** `def autocodeAll((project: string, payload: AutoCodeAllPayload)) -> : Promise<AutoCodeAllResult>`

## Description

> Auto-code attributes using CV and GIS models
>
> Supports three modes:
> 1. Single image: { imageRef, coords, index? }
> 2. All images: { all: true, save?: false }
> 3. Selected images: { indices: [0,2,5], save?: false }
>
> Key behavior:
> - When save=false (recommended for bulk), changes are kept in memory only
> - Returns updated_attributes so UI can display changes without persisting
> - User must click Save button to persist changes to disk
>
> @param project - Project name
> @param payload - Request payload (see AutoCodeAllPayload types)
> @returns Response with updates and tracking data (see AutoCodeAllResult types)

## Source

```typescript
export async function autocodeAll(project: string, payload: AutoCodeAllPayload): Promise<AutoCodeAllResult> {
  const res = await fetch(`/api/projects/${encodeURIComponent(project)}/autocode/all`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    throw new Error(await readError(res));
  }
  return (await res.json()) as AutoCodeAllResult;
}
```

## Callers (1)
- [[fn-frontend-src-pages-codingpage-codingpage-tsx--handler|handler]]

## Callees (1)
- [[fn-frontend-src-api-index-ts--readerror|readError]]

## External / unresolved calls (4)
- `fetch`
- `encodeURIComponent`
- `stringify`
- `json`
