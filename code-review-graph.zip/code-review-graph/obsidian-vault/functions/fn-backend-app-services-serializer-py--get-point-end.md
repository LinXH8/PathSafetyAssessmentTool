---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/serializer.py::ProjectGeoData.get_point_end", "get_point_end"]
tags: [function, python]
file: "backend/app/services/serializer.py"
lines: "356-358"
---

# get_point_end

**Kind:** Function
**File:** [[file-backend-app-services-serializer-py|serializer.py]]  `backend/app/services/serializer.py`
**Lines:** 356-358
**Community:** [[com-services-fields|services-fields]]
**Signature:** `def get_point_end((self, index: int))`

## Source

```python
    def get_point_end(self, index: int):
        geom = self.df.at[index, self.Fields.LINESTRING_STR]
        return geom.coords[-1] if geom and not geom.is_empty else None
```
