---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/scoreband/SegmentScoresCard.tsx::getBandColor", "getBandColor"]
tags: [function, tsx]
file: "frontend/src/components/visualization/scoreband/SegmentScoresCard.tsx"
lines: "59-73"
---

# getBandColor

**Kind:** Function
**File:** [[file-frontend-src-components-visualization-scoreband-segmentscorescard-tsx|SegmentScoresCard.tsx]]  `frontend/src/components/visualization/scoreband/SegmentScoresCard.tsx`
**Lines:** 59-73
**Community:** [[com-scoreband-color|scoreband-color]]
**Signature:** `def getBandColor((score: number, type: string)) -> : string`

## Source

```tsx
const getBandColor = (score: number, type: string): string => {
  // BB, BP, SB use stricter thresholds
  if (['BB', 'BP', 'SB'].includes(type)) {
    if (score < 5) return RISK_BAND_COLORS.LOW;
    if (score <= 10) return RISK_BAND_COLORS.MEDIUM;
    if (score <= 20) return RISK_BAND_COLORS.HIGH;
    return RISK_BAND_COLORS.EXTREME;
  }

  // VB and others (default)
  if (score < 10) return RISK_BAND_COLORS.LOW;
  if (score <= 25) return RISK_BAND_COLORS.MEDIUM;
  if (score <= 60) return RISK_BAND_COLORS.HIGH;
  return RISK_BAND_COLORS.EXTREME;
};
```

## Callers (1)
- [[fn-frontend-src-components-visualization-scoreband-segmentscorescard-tsx--segmentscorescard|SegmentScoresCard]]

## External / unresolved calls (1)
- `includes`
