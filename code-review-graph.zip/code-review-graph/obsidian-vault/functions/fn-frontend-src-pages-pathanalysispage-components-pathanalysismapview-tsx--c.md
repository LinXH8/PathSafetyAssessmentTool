---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx::c", "c"]
tags: [function, tsx]
file: "frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx"
lines: "1992-1992"
---

# c

**Kind:** Function
**File:** [[file-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx|PathAnalysisMapView.tsx]]  `frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx`
**Lines:** 1992-1992
**Community:** [[com-components-handle-2|components-handle]]
**Signature:** `def c()`

## Source

```tsx
                            [subcatConfig.childAttr]: Object.fromEntries(allChildOpts.map(c => [c, true])),
```
