---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/cycle_rap_processing_gopro_footage.py::getBuffer", "getBuffer"]
tags: [function, python]
file: "backend/app/services/cycle_rap_processing_gopro_footage.py"
lines: "73-77"
---

# getBuffer

**Kind:** Function
**File:** [[file-backend-app-services-cycle-rap-processing-gopro-footage-py|cycle_rap_processing_gopro_footage.py]]  `backend/app/services/cycle_rap_processing_gopro_footage.py`
**Lines:** 73-77
**Community:** [[com-services-extract|services-extract]]
**Signature:** `def getBuffer((gdf, buffer))`

## Source

```python
def getBuffer(gdf, buffer):
    gdf_buffer = gdf.to_crs(3857)
    gdf_buffer['geometry'] = gdf_buffer['geometry'].buffer(distance = int(buffer))
    gdf_buffer = gdf_buffer.to_crs(4326)
    return(gdf_buffer)
```

## External / unresolved calls (3)
- `to_crs` ×2
- `buffer`
- `int`
