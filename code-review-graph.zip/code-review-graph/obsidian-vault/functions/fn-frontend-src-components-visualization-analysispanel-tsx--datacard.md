---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/AnalysisPanel.tsx::DataCard", "DataCard"]
tags: [function, tsx]
file: "frontend/src/components/visualization/AnalysisPanel.tsx"
lines: "72-86"
---

# DataCard

**Kind:** Function
**File:** [[file-frontend-src-components-visualization-analysispanel-tsx|AnalysisPanel.tsx]]  `frontend/src/components/visualization/AnalysisPanel.tsx`
**Lines:** 72-86
**Community:** [[com-visualization-width|visualization-width]]
**Signature:** `def DataCard(({ label, value, loading, error, accent }: DataCardProps))`

## Source

```tsx
function DataCard({ label, value, loading, error, accent }: DataCardProps) {
  return (
    <div className="analysis-card">
      <span className="analysis-card-label">{label}</span>
      <span
        className="analysis-card-value"
        style={accent ? { color: accent } : undefined}
      >
        {loading ? <span className="analysis-card-loading">…</span>
          : error  ? <span className="analysis-card-na">—</span>
          : value}
      </span>
    </div>
  );
}
```

## Callers (1)
- [[fn-frontend-src-components-visualization-analysispanel-tsx--analysispanel|AnalysisPanel]]
