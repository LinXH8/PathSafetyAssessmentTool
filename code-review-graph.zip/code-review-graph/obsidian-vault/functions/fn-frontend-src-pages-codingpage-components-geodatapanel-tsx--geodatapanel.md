---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/CodingPage/components/GeoDataPanel.tsx::GeoDataPanel", "GeoDataPanel"]
tags: [function, tsx]
file: "frontend/src/pages/CodingPage/components/GeoDataPanel.tsx"
lines: "284-1487"
---

# GeoDataPanel

**Kind:** Function
**File:** [[file-frontend-src-pages-codingpage-components-geodatapanel-tsx|GeoDataPanel.tsx]]  `frontend/src/pages/CodingPage/components/GeoDataPanel.tsx`
**Lines:** 284-1487
**Community:** [[com-components-bounds|components-bounds]]
**Signature:** `def GeoDataPanel(({ projectName, index, onJump, containerHeight = 650, scores: externalScores, subtitle, geoFeatures: externalGeoFeatures, startIndex = 0, onDataChange, panToBounds, panKey = 0 }: Props))`

## Source

```tsx
export default function GeoDataPanel({ projectName, index, onJump, containerHeight = 650, scores: externalScores, subtitle, geoFeatures: externalGeoFeatures, startIndex = 0, onDataChange, panToBounds, panKey = 0 }: Props) {
  const decodedName = useMemo(() => {
    if (!projectName) return null;
    try { return decodeURIComponent(projectName); } catch { return projectName; }
  }, [projectName]);

  const [fc, setFc] = useState<GJ | null>(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [isCollapsed, setIsCollapsed] = useState(false);

  // Use external geofeatures if provided (for multi-project display), otherwise use fetched data
  const hasExternalGeoFeatures = externalGeoFeatures !== undefined;

  // Internal scores state (fallback if externalScores not provided)
  const [internalScores, setInternalScores] = useState<ScoreRow[]>([]);

  // Derived active scores - prioritize external props for real-time updates
  const activeScores = useMemo(() => {
    return (externalScores && externalScores.length > 0) ? externalScores : internalScores;
  }, [externalScores, internalScores]);

  // Read initial toggle states from localStorage if available
  const cachedLayers = useMemo(() => {
    if (!projectName) return {};
    try {
      const stored = localStorage.getItem(`gisLayerToggles_${projectName}`);
      return stored ? JSON.parse(stored) : {};
    } catch {
      return {};
    }
  }, [projectName]);
  
  // GIS Layer toggles (matching curvature analysis colors)
  const [showFootpath, setShowFootpath] = useState(cachedLayers.showFootpath ?? false);  // Blue
  const [showCycling, setShowCycling] = useState(cachedLayers.showCycling ?? false);     // Red
  const [showShared, setShowShared] = useState(cachedLayers.showShared ?? false);       // Orange
  const [showRoadcrossing, setShowRoadcrossing] = useState(cachedLayers.showRoadcrossing ?? false);  // Red
  const [showMrtExit, setShowMrtExit] = useState(cachedLayers.showMrtExit ?? false);     // Cyan
  const [showBusStop, setShowBusStop] = useState(cachedLayers.showBusStop ?? false);     // Purple
  const [showBusLane, setShowBusLane] = useState(cachedLayers.showBusLane ?? false);     // Yellow
  const [showParkingLot, setShowParkingLot] = useState(cachedLayers.showParkingLot ?? false); // Gold
  const [showKerbLine, setShowKerbLine] = useState(cachedLayers.showKerbLine ?? false);   // Deep Pink

  // Update localStorage whenever these toggles change
  useEffect(() => {
    if (!projectName) return;
    localStorage.setItem(`gisLayerToggles_${projectName}`, JSON.stringify({
      showFootpath, showCycling, showShared, showRoadcrossing, showMrtExit, showBusStop, showBusLane, showParkingLot, showKerbLine
    }));
  }, [showFootpath, showCycling, showShared, showRoadcrossing, showMrtExit, showBusStop, showBusLane, showParkingLot, showKerbLine, projectName]);

// Sub-component to pan map to current selection.
// When panKey changes (project tab clicked), MapAutoCenter suppresses its setView
// for a 800ms window. This prevents async treatment-fetch callbacks from causing
// a re-render that overrides PanToBounds' fitBounds.
function MapAutoCenter({ center, anyLayerOn, panKey }: { center: [number, number] | null; anyLayerOn?: boolean; panKey?: number }) {
  const map = useMap();
  const prevCenterRef = useRef<[number, number] | null>(null);
  const prevPanKeyRef = useRef(panKey ?? 0);
  const suppressUntilRef = useRef(0);
  useEffect(() => {
    if (!center) return;
    const prevCenter = prevCenterRef.current;
    const centerChanged = !prevCenter || prevCenter[0] !== center[0] || prevCenter[1] !== center[1];
    prevCenterRef.current = center;

    // If panKey just changed, start a suppression window.
    const currentPanKey = panKey ?? 0;
    if (currentPanKey !== prevPanKeyRef.current) {
      prevPanKeyRef.current = currentPanKey;
      suppressUntilRef.current = Date.now() + 800;
      return;
    }

    // Still within the suppression window — let PanToBounds' fitBounds stand.
    if (Date.now() < suppressUntilRef.current) {
      return;
    }

    if (centerChanged) {
      // When navigating to a new segment, pan to it
      // If GIS layers are on, zoom in close enough to see them
      const targetZoom = anyLayerOn ? Math.max(map.getZoom(), 17) : map.getZoom();
      map.setView(center, targetZoom, { animate: true });
    }
  }, [center, anyLayerOn, map, panKey]);
  return null;
}


  // Delete Mode State
  const [isDeleteMode, setIsDeleteMode] = useState(false);
  const [isPointAddMode, setIsPointAddMode] = useState(false);
  const [isPolygonMode, setIsPolygonMode] = useState(false); // Polygon batch delete mode
  const [isPolygonAddMode, setIsPolygonAddMode] = useState(false); // Polygon batch copy mode
  const [polygonPoints, setPolygonPoints] = useState<[number, number][]>([]);
  const [deleteConfirmationOpen, setDeleteConfirmationOpen] = useState(false);
  const [isAddSegmentsDialogOpen, setIsAddSegmentsDialogOpen] = useState(false);
  const [segmentToDelete, setSegmentToDelete] = useState<number | null>(null);
  const [segmentToAdd, setSegmentToAdd] = useState<number | null>(null);
  const [segmentsToDelete, setSegmentsToDelete] = useState<number[]>([]); // For batch delete
  const cancelRef = useRef<HTMLButtonElement>(null);

  // Clear single selections when toggling point modes
  useEffect(() => {
    if (!isDeleteMode && !isPointAddMode) {
      setSegmentToDelete(null);
      setSegmentToAdd(null);
    }
  }, [isDeleteMode, isPointAddMode]);

  // Clear polygon points and close dialog when toggling polygon mode
  useEffect(() => {
    setPolygonPoints([]);
    setDeleteConfirmationOpen(false);
    setSegmentsToDelete([]);
  }, [isPolygonMode]);

  // GIS Layer data
  type GISLayerFeature = {
    coordinates: [number, number][];
    properties: { width?: number };
    geometry_type?: "line" | "point" | "polygon";
  };
  type GISLayers = {
    footpath: GISLayerFeature[];
    cycling: GISLayerFeature[];
    shared: GISLayerFeature[];
    roadcrossing: GISLayerFeature[];
    mrt_exit: GISLayerFeature[];
    bus_stop: GISLayerFeature[];
    bus_lane: GISLayerFeature[];
    parking_lot: GISLayerFeature[];
    kerb_line: GISLayerFeature[];
  };
  const [gisLayers, setGisLayers] = useState<GISLayers | null>(null);

  // 拉取整条 geodata（如果没有 external geofeatures）
  useEffect(() => {
    // Skip if we have external geofeatures provided by parent
    if (hasExternalGeoFeatures) {
      setFc({ type: "FeatureCollection", features: externalGeoFeatures });
      setLoading(false);
      return;
    }

    if (!decodedName) return;
    let aborted = false;
    (async () => {
      try {
        setLoading(true);
        setErr(null);
        const res = await fetch(`/api/projects/${encodeURIComponent(decodedName)}/geodata`);
        if (!res.ok) throw new Error(await res.text().catch(() => res.statusText));
        const data = (await res.json()) as GJ;
        if (!aborted) setFc(data);
      } catch (e: any) {
        if (!aborted) setErr(e?.message ?? "Failed to load geodata");
      } finally {
        if (!aborted) setLoading(false);
      }
    })();
    return () => { aborted = true; };
  }, [decodedName, hasExternalGeoFeatures, externalGeoFeatures]);

  // Helper function to fetch scores
  const fetchScores = useCallback(async () => {
    if (!decodedName) return;
    try {
      const res = await fetch(`/api/projects/${encodeURIComponent(decodedName)}/results`);
      if (!res.ok) {
        return;
      }
      const data = await res.json();
      if (data.ok && Array.isArray(data.result_rows)) {
        setInternalScores(data.result_rows);
      }
    } catch (e: any) {
    }
  }, [decodedName]);

  // Fetch Overall Risk Levels for color coding on component mount (fallback if no external scores)
  useEffect(() => {
    if (!decodedName) return;
    // Only fetch if we don't have external scores
    if (!externalScores || externalScores.length === 0) {
      fetchScores();
    }
  }, [decodedName, fetchScores, externalScores]);

  // Listen for score update events (triggered after Calculate Score button is clicked)
  // If we have external scores (from parent), don't fetch from API - let parent updates drive the scores
  // Only fetch from API if we're using the fallback mechanism (no external scores)
  useEffect(() => {
    const handleScoresUpdated = () => {
      // Only refetch from API if we don't have external scores
      if (!externalScores || externalScores.length === 0) {
        fetchScores();
      }
    };

    window.addEventListener("psat:scores:updated", handleScoresUpdated);
    return () => window.removeEventListener("psat:scores:updated", handleScoresUpdated);
  }, [fetchScores, externalScores]);

  // 取每条 LineString 的首点（转 4326），并保留原 feature
  // For multi-project display, localIdx is the index within geoFeatures,
  // and globalIdx is the index within the aggregated scores array
  const points = useMemo(() => {
    if (!fc) return [] as { localIdx: number; globalIdx: number; latlng: [number, number]; f: Feature<LineString, any> }[];
    const arr: { localIdx: number; globalIdx: number; latlng: [number, number]; f: Feature<LineString, any> }[] = [];
    fc.features.forEach((f, i) => {
      const g = f.geometry;
      if (g?.type === "LineString" && Array.isArray(g.coordinates) && g.coordinates.length > 0) {
        arr.push({ localIdx: i, globalIdx: startIndex + i, latlng: to4326(g.coordinates[0]), f });
      }
    });
    return arr;
  }, [fc, startIndex]);

  const allLatLngs = useMemo(() => points.map(p => p.latlng), [points]);

  // 当前高亮点 - use globalIdx to match the index prop (global index)
  const current = useMemo(() => points.find(p => p.globalIdx === index) ?? null, [points, index]);

  // GIS query point: starts at current segment, can be repositioned by clicking on the map
  // Stored as { lat, lon } primitives so React useEffect deps work reliably (no array reference issues)
  const currentLat = current?.latlng[0] ?? null;
  const currentLon = current?.latlng[1] ?? null;
  const [gisLat, setGisLat] = useState<number | null>(null);
  const [gisLon, setGisLon] = useState<number | null>(null);

  // When segment changes (user clicks a green dot → navigates to new segment),
  // reset the GIS query point to the new segment's first coordinate.
  useEffect(() => {
    if (currentLat !== null && currentLon !== null) {
      setGisLat(currentLat);
      setGisLon(currentLon);
    }
  }, [index, currentLat, currentLon]);

  // Active query point (primitives, reliable for useEffect deps)
  const activeGisLat = gisLat ?? currentLat;
  const activeGisLon = gisLon ?? currentLon;

  // Array form for rendering (buffer circle, zoom components)
  const activeQueryPoint: [number, number] | null =
    (activeGisLat !== null && activeGisLon !== null) ? [activeGisLat, activeGisLon] : null;

# … (truncated, 954 more lines — see source file)
```

## Callers (2)
- [[fn-frontend-src-pages-codingpage-codingpage-tsx--codingpage|CodingPage]]
- [[fn-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx--treatmentdetailpage|TreatmentDetailPage]]

## Callees (10)
- [[fn-frontend-src-pages-codingpage-components-geodatapanel-tsx--to4326|to4326]]
- [[fn-frontend-src-components-common-mapcursorcontroller-tsx--mapcursorcontroller|MapCursorController]]
- [[fn-frontend-src-components-common-themeawaretilelayer-tsx--themeawaretilelayer|ThemeAwareTileLayer]]
- [[fn-frontend-src-pages-codingpage-components-geodatapanel-tsx--fitbounds|FitBounds]]
- [[fn-frontend-src-pages-codingpage-components-geodatapanel-tsx--zoomtogis|ZoomToGIS]]
- [[fn-frontend-src-pages-codingpage-components-geodatapanel-tsx--mapautocenter|MapAutoCenter]]
- [[fn-frontend-src-pages-codingpage-components-geodatapanel-tsx--pantobounds|PanToBounds]]
- [[fn-frontend-src-pages-codingpage-components-geodatapanel-tsx--getsegmentcolor|getSegmentColor]]
- [[fn-frontend-src-pages-codingpage-components-geodatapanel-tsx--polygondrawingtool|PolygonDrawingTool]]
- [[fn-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx--addsegmentsdialog|AddSegmentsDialog]]

## External / unresolved calls (91)
- `useState` ×27
- `map` ×23
- `Text` ×14
- `setPolygonPoints` ×12
- `Flex` ×11
- `push` ×10
- `setDeleteConfirmationOpen` ×9
- `/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/ui/switch.tsx::Switch` ×9
- `useEffect` ×8
- `create` ×8
- `setIsDeleteMode` ×8
- `setIsPolygonMode` ×8
- `Polyline` ×8
- `Tooltip` ×8
- `useCallback` ×7
- `setIsPointAddMode` ×7
- `setIsPolygonAddMode` ×7
- `useMemo` ×6
- `fetch` ×5
- `encodeURIComponent` ×5
- `stopPropagation` ×5
- `setSegmentToAdd` ×4
- `catch` ×4
- `text` ×4
- `filter` ×4
- `Root` ×4
- `FaPlus` ×4
- `Item` ×4
- `Button` ×4
- `CircleMarker` ×4
- *... and 61 more.*
