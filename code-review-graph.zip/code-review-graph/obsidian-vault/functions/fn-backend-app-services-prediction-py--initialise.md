---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/prediction.py::CycleRAP_Coding_Helper.initialise", "initialise"]
tags: [function, python]
file: "backend/app/services/prediction.py"
lines: "33-87"
---

# initialise

**Kind:** Function
**File:** [[file-backend-app-services-prediction-py|prediction.py]]  `backend/app/services/prediction.py`
**Lines:** 33-87
**Community:** [[com-services-compute|services-compute]]
**Signature:** `def initialise((cls, model_dir: Path))`

## Source

```python
    def initialise(cls, model_dir: Path):
        from ultralytics import YOLO
        from ultralytics.nn import tasks as _ul_tasks
        from concurrent.futures import ThreadPoolExecutor, as_completed

        # Patch BaseModel.fuse() so older .pt files don't crash
        _orig_fuse = _ul_tasks.BaseModel.fuse
        def _safe_fuse(self, verbose=True):
            try:
                return _orig_fuse(self, verbose=verbose)
            except AttributeError:
                return self
        _ul_tasks.BaseModel.fuse = _safe_fuse

        models_to_load = {
            "path_segmentation_model": "path_segmentation.pt",
            "obstacle_detector_model": "obstacle_detector_ema.pt",
        }

        # Validate files exist
        for attr, filename in models_to_load.items():
            path = model_dir / filename
            if not path.exists():
                raise RuntimeError(f'"{path}" could not be found')

        def _load_one(attr: str, filename: str):
            import time
            path = model_dir / filename
            print(f"[Autocode] Loading {filename}...", flush=True)
            t0 = time.time()
            model = YOLO(str(path))
            elapsed = time.time() - t0
            print(f"[Autocode] Loaded  {filename} in {elapsed:.1f}s", flush=True)
            return attr, model

        results: dict = {}
        errors: list = []
        with ThreadPoolExecutor(max_workers=2, thread_name_prefix="model-load") as pool:
            futures = {pool.submit(_load_one, attr, fn): attr for attr, fn in models_to_load.items()}
            for future in as_completed(futures):
                try:
                    attr, model = future.result()
                    results[attr] = model
                except Exception as e:
                    errors.append(str(e))

        if errors:
            raise RuntimeError("Model loading failed:\n" + "\n".join(errors))

        for attr, model in results.items():
            setattr(cls, attr, model)

        # Cache class-ID sets from the segmentation model
        cls.class_sets = cls._build_class_sets(cls.path_segmentation_model)
        print(f"[Autocode] Class sets: { {k: {cls.path_segmentation_model.names[cid] for cid in v} for k, v in cls.class_sets.items()} }", flush=True)
```

## Callees (1)
- [[fn-backend-app-services-prediction-py--build-class-sets|_build_class_sets]]

## External / unresolved calls (12)
- `items` ×4
- `RuntimeError` ×2
- `exists`
- `ThreadPoolExecutor`
- `submit`
- `as_completed`
- `result`
- `append`
- `str`
- `join`
- `setattr`
- `print`
