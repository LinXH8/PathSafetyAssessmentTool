---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx::prev", "prev"]
tags: [function, tsx]
file: "frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx"
lines: "2402-2405"
---

# prev

**Kind:** Function
**File:** [[file-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx|PathAnalysisMapView.tsx]]  `frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx`
**Lines:** 2402-2405
**Community:** [[com-components-handle-2|components-handle]]
**Signature:** `def prev()`

## Source

```tsx
                                  setColumnFilters(prev => ({
                                    ...prev,
                                    [col.key]: e.target.value
                                  }));
```

## External / unresolved calls (6)
- `forEach` ×2
- `fromEntries` ×2
- `map` ×2
- `flat`
- `values`
- `filter`
