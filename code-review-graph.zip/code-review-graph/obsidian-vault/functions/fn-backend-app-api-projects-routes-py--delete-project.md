---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/projects/routes.py::delete_project", "delete_project"]
tags: [function, python]
file: "backend/app/api/projects/routes.py"
lines: "2351-2366"
---

# delete_project

**Kind:** Function
**File:** [[file-backend-app-api-projects-routes-py|routes.py]]  `backend/app/api/projects/routes.py`
**Lines:** 2351-2366
**Community:** [[com-projects-treatments|projects-treatments]]
**Signature:** `def delete_project((project_name: str))`

## Description

> Delete an entire project (in-memory list + on-disk directory):
> DELETE /api/projects/<project_name>

## Source

```python
def delete_project(project_name: str):
    """
    Delete an entire project (in-memory list + on-disk directory):
    DELETE /api/projects/<project_name>
    """
    ctx = get_ctx()
    pm = ctx["pm"]

    try:
        pm.delete_project(project_name)  # Calls Project._delete() to remove the directory and drop from the list
        return ok({"ok": True, "name": project_name})
    except KeyError:
        return fail("Project not found", 404)
    except Exception as e:
        traceback.print_exc()
        return fail(f"Delete failed: {e}", 500)
```

## Callers (1)
- [[fn-backend-app-api-projects-routes-py--delete-project|delete_project]]

## Callees (4)
- [[fn-backend-app-api-projects-routes-py--get-ctx|get_ctx]]
- [[fn-backend-app-api-projects-routes-py--delete-project|delete_project]]
- [[fn-backend-app-api-projects-routes-py--ok|ok]]
- [[fn-backend-app-api-projects-routes-py--fail|fail]]

## External / unresolved calls (1)
- `print_exc`
