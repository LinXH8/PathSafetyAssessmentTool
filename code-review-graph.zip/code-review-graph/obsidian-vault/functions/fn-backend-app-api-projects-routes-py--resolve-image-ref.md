---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/projects/routes.py::_resolve_image_ref", "_resolve_image_ref"]
tags: [function, python]
file: "backend/app/api/projects/routes.py"
lines: "3147-3186"
---

# _resolve_image_ref

**Kind:** Function
**File:** [[file-backend-app-api-projects-routes-py|routes.py]]  `backend/app/api/projects/routes.py`
**Lines:** 3147-3186
**Community:** [[com-projects-treatments|projects-treatments]]
**Signature:** `def _resolve_image_ref((idx: int)) -> str | None`

## Description

> Resolve the image filename for a given row index.
>
> This function looks for image references in the correct location:
> 1. Primary source: geo_data.df (where project_manager stores image refs during creation)
> 2. Fallback: attributes.df (in case user manually added it there)
>
> It also verifies that the referenced image file actually exists on disk.
>
> Args:
>     idx: Row index in the attributes/geo_data tables
>
> Returns:
>     str: Image filename if found and exists, None otherwise

## Source

```python
        def _resolve_image_ref(idx: int) -> str | None:
            """
            Resolve the image filename for a given row index.

            This function looks for image references in the correct location:
            1. Primary source: geo_data.df (where project_manager stores image refs during creation)
            2. Fallback: attributes.df (in case user manually added it there)

            It also verifies that the referenced image file actually exists on disk.

            Args:
                idx: Row index in the attributes/geo_data tables

            Returns:
                str: Image filename if found and exists, None otherwise
            """
            # Primary source: geo_data (where image references are stored during project creation)
            # See project_manager.py:453 where image_ref is stored in geo_tbl
            if 0 <= idx < len(proj.geo_data.df):
                geo_row = proj.geo_data.df.iloc[idx]
                # Try multiple possible column names for compatibility
                for key in ("Image Reference", "Image_Reference", "image", "img", "FILENAME"):
                    if key in geo_row and pd.notna(geo_row[key]) and str(geo_row[key]).strip():
                        img_ref = str(geo_row[key]).strip()
                        # Verify file exists before returning
                        img_path = (pm.des_path / project_name / global_var.PROJECT_IMAGES_FOLDER / img_ref).resolve()
                        if img_path.exists():
                            return img_ref

            # Fallback: attributes table (in case it was copied there)
            if 0 <= idx < len(ver.attributes.df):
                attr_row = ver.attributes.df.iloc[idx]
                for key in ("Image Reference", "Image_Reference", "image", "img", "FILENAME"):
                    if key in attr_row and pd.notna(attr_row[key]) and str(attr_row[key]).strip():
                        img_ref = str(attr_row[key]).strip()
                        # Verify file exists before returning
                        img_path = (pm.des_path / project_name / global_var.PROJECT_IMAGES_FOLDER / img_ref).resolve()
                        if img_path.exists():
                            return img_ref
            return None
```

## Callers (1)
- [[fn-backend-app-api-projects-routes-py--autocode-all|autocode_all]]

## External / unresolved calls (6)
- `strip` ×4
- `str` ×4
- `len` ×2
- `notna` ×2
- `resolve` ×2
- `exists` ×2
