---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/utils/path_width_curvature.py::load_layer", "load_layer"]
tags: [function, python]
file: "backend/app/utils/path_width_curvature.py"
lines: "85-132"
---

# load_layer

**Kind:** Function
**File:** [[file-backend-app-utils-path-width-curvature-py|path_width_curvature.py]]  `backend/app/utils/path_width_curvature.py`
**Lines:** 85-132
**Community:** [[com-utils-width|utils-width]]
**Signature:** `def load_layer((path: str, base_dir: Optional[str] = None)) -> Optional[gpd.GeoDataFrame]`

## Description

> Load a shapefile, reproject to EPSG:3414, drop Z, ensure 'WIDTH', and build sindex.
> Uses an in-memory cache keyed by (path, last_modified_time).
>
> Args:
>     path: Relative or absolute path to shapefile
>     base_dir: Optional base directory to prepend to relative paths

## Source

```python
def load_layer(path: str, base_dir: Optional[str] = None) -> Optional[gpd.GeoDataFrame]:
    """
    Load a shapefile, reproject to EPSG:3414, drop Z, ensure 'WIDTH', and build sindex.
    Uses an in-memory cache keyed by (path, last_modified_time).

    Args:
        path: Relative or absolute path to shapefile
        base_dir: Optional base directory to prepend to relative paths
    """
    # Handle base_dir
    if base_dir and not os.path.isabs(path):
        full_path = os.path.join(base_dir, path)
    else:
        full_path = path

    if not full_path or not full_path.endswith(".shp") or not os.path.exists(full_path):
        return None

    key = (full_path, os.path.getmtime(full_path))
    if key in _LAYER_CACHE:
        return _LAYER_CACHE[key]

    try:
        gdf = gpd.read_file(full_path)
        if gdf.empty:
            _LAYER_CACHE[key] = None
            return None

        target_crs = "EPSG:3414"
        if gdf.crs is None or gdf.crs.to_string() != target_crs:
            gdf = gdf.to_crs(target_crs)

        # Clean geometries
        gdf = gdf.assign(geometry=lambda df: df.geometry.apply(remove_z))
        gdf = gdf[gdf.geometry.notnull() & gdf.is_valid & ~gdf.is_empty]

        # Standardize width column
        gdf = standardize_width_column(gdf)

        # Build spatial index for fast queries
        _ = gdf.sindex

        _LAYER_CACHE[key] = gdf
        return gdf
    except Exception as e:
        print(f"[Error] load_layer {full_path}: {e}")
        _LAYER_CACHE[key] = None
        return None
```

## Callers (2)
- [[fn-backend-app-utils-path-width-curvature-py--get-radius-and-width-at-point|get_radius_and_width_at_point]]
- [[fn-backend-visualize-facility-width-py--analyze-width-at-point-detailed|analyze_width_at_point_detailed]]

## Callees (1)
- [[fn-backend-app-utils-path-width-curvature-py--standardize-width-column|standardize_width_column]]

## External / unresolved calls (12)
- `isabs`
- `join`
- `endswith`
- `exists`
- `getmtime`
- `read_file`
- `to_string`
- `to_crs`
- `assign`
- `apply`
- `notnull`
- `print`
