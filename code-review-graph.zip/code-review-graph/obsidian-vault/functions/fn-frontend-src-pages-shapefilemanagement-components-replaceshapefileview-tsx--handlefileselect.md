---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/ShapefileManagement/components/ReplaceShapefileView.tsx::handleFileSelect", "handleFileSelect"]
tags: [function, tsx]
file: "frontend/src/pages/ShapefileManagement/components/ReplaceShapefileView.tsx"
lines: "56-61"
---

# handleFileSelect

**Kind:** Function
**File:** [[file-frontend-src-pages-shapefilemanagement-components-replaceshapefileview-tsx|ReplaceShapefileView.tsx]]  `frontend/src/pages/ShapefileManagement/components/ReplaceShapefileView.tsx`
**Lines:** 56-61
**Community:** [[com-components-handle-4|components-handle]]
**Signature:** `def handleFileSelect((e: React.ChangeEvent<HTMLInputElement>))`

## Source

```tsx
  function handleFileSelect(e: React.ChangeEvent<HTMLInputElement>) {
    if (e.target.files) {
      const selectedFiles = Array.from(e.target.files);
      addFiles(selectedFiles);
    }
  }
```

## Callees (1)
- [[fn-frontend-src-pages-shapefilemanagement-components-replaceshapefileview-tsx--addfiles|addFiles]]

## External / unresolved calls (1)
- `from`
