---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/CreateProjectPage/createProjectPage.tsx::t", "t"]
tags: [function, tsx]
file: "frontend/src/pages/CreateProjectPage/createProjectPage.tsx"
lines: "215-219"
---

# t

**Kind:** Function
**File:** [[file-frontend-src-pages-createprojectpage-createprojectpage-tsx|createProjectPage.tsx]]  `frontend/src/pages/CreateProjectPage/createProjectPage.tsx`
**Lines:** 215-219
**Community:** [[com-createprojectpage-tag|createprojectpage-tag]]
**Signature:** `def t()`

## Source

```tsx
                          .map(t => (
                            <Combobox.Item key={t} item={{ label: t, value: t }}>
                              {t}
                            </Combobox.Item>
                          ))}
```

## External / unresolved calls (3)
- `includes` ×2
- `toLowerCase`
- `Item`
