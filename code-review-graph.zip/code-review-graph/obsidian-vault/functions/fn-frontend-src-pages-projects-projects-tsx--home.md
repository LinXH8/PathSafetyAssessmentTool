---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/Projects/projects.tsx::Home", "Home"]
tags: [function, tsx]
file: "frontend/src/pages/Projects/projects.tsx"
lines: "53-692"
---

# Home

**Kind:** Function
**File:** [[file-frontend-src-pages-projects-projects-tsx|projects.tsx]]  `frontend/src/pages/Projects/projects.tsx`
**Lines:** 53-692
**Community:** [[com-projects-tag|projects-tag]]
**Signature:** `def Home(())`

## Source

```tsx
export default function Home() {

  // Status
  const [, setStatus] = useState("checking...");
  const [, setError] = useState<string | null>(null);

  // Project List
  const [Projectlist, setProjectList] = useState<FileListResponse | null>(null);

  // Sorting
  type SortCriterion = { key: string; direction: 'asc' | 'desc' };
  const [sortConfig, setSortConfig] = useState<SortCriterion[]>([
    { key: 'last_updated', direction: 'desc' }, // Default to newest first
  ]);

  // Filter
  const [nameQuery, setNameQuery] = useState("");
  const [tagFilters, setTagFilters] = useState<string[]>([]);
  const [tagInputValue, setTagInputValue] = useState("");
  const [tagComboboxOpen, setTagComboboxOpen] = useState(false);

  // Selected Projects (multiple selection)
  const [selected, setSelected] = useState<Set<string>>(new Set());

  // Delete dialog state
  const [openDelete, setOpenDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);

  // Edit dialog state
  const [openEdit, setOpenEdit] = useState(false);
  const [editingProject, setEditingProject] = useState<ProjectListItem | null>(null);

  const navigate = useNavigate();


  // Use effect
  useEffect(() => {
    ping()
      .then((r) => setStatus(r.status))
      .catch(() => setStatus("offline"));

    fetchProjectList()
      .then((data) => setProjectList(data))
      .catch((e) => setError(String(e)));
  }, []);

  // Listen for project verified status changes from coding page
  useEffect(() => {
    const handleVerificationUpdate = (event: CustomEvent) => {
      const { projectName, verified, verifiedSegmentCount } = event.detail;

      // Update the project list directly
      setProjectList((prev) => {
        if (!prev) return prev;
        return {
          projects: prev.projects.map((p) => {
            if (p.name === projectName) {
              const updates: any = {};
              if (verified !== undefined) updates.verified = verified;
              if (verifiedSegmentCount !== undefined) updates.verified_segment_count = verifiedSegmentCount;
              return { ...p, ...updates };
            }
            return p;
          }),
        };
      });
    };

    window.addEventListener("psat:verified:updated", handleVerificationUpdate as EventListener);
    return () => window.removeEventListener("psat:verified:updated", handleVerificationUpdate as EventListener);
  }, []);

  // Listen for project autocoded status changes from coding page
  useEffect(() => {
    const handleAutocodedUpdate = (event: CustomEvent) => {
      const { projectName, autocodedSegmentCount } = event.detail;

      // Update the project list directly
      setProjectList((prev) => {
        if (!prev) return prev;
        return {
          projects: prev.projects.map((p) => {
            if (p.name === projectName) {
              if (autocodedSegmentCount !== undefined) {
                return { ...p, autocoded_segment_count: autocodedSegmentCount };
              }
            }
            return p;
          }),
        };
      });
    };

    window.addEventListener("psat:autocoded:updated", handleAutocodedUpdate as EventListener);
    return () => window.removeEventListener("psat:autocoded:updated", handleAutocodedUpdate as EventListener);
  }, []);

  // UseMemo projects
  const projects: ProjectListItem[] = useMemo(() => {
    if (!Projectlist?.projects) return [];

    return Projectlist.projects.slice().sort((a, b) => {
      for (const criterion of sortConfig) {
        let result = 0;

        if (criterion.key === 'last_updated') {
          const dateA = new Date(a.last_updated || 0).getTime();
          const dateB = new Date(b.last_updated || 0).getTime();
          result = dateA - dateB;
        } else if (criterion.key === 'verification_status') {
          const pctA = (a.total_segments || 0) > 0 ? (a.verified_segment_count || 0) / a.total_segments! : 0;
          const pctB = (b.total_segments || 0) > 0 ? (b.verified_segment_count || 0) / b.total_segments! : 0;
          result = pctA - pctB;
        } else if (criterion.key === 'distance_verified') {
          const distA = (a.verified_segment_count || 0) * 10;
          const distB = (b.verified_segment_count || 0) * 10;
          result = distA - distB;
        } else if (criterion.key === 'autocode_status') {
          const pctA = (a.total_segments || 0) > 0 ? (a.autocoded_segment_count || 0) / a.total_segments! : 0;
          const pctB = (b.total_segments || 0) > 0 ? (b.autocoded_segment_count || 0) / b.total_segments! : 0;
          result = pctA - pctB;
        }

        if (result !== 0) {
          return criterion.direction === 'asc' ? result : -result;
        }
      }
      return 0;
    });
  }, [Projectlist, sortConfig]);

  // Get all unique tags across all projects
  const allTags = useMemo(() => {
    const tagSet = new Set<string>();
    projects.forEach(p => {
      p.tags?.forEach(tag => tagSet.add(tag));
    });
    return Array.from(tagSet).sort();
  }, [projects]);

  // for Filters
  const filtered = useMemo(() => {
    const q = nameQuery.trim().toLowerCase();
    let list = projects;

    // Filter by name query - searches both project name and tags
    if (q) {
      list = list.filter((p) =>
        p.name.toLowerCase().includes(q) ||
        (p.tags && p.tags.some(tag => tag.toLowerCase().includes(q)))
      );
    }

    // Filter by selected tags - project must have ALL selected tags
    if (tagFilters.length > 0) {
      list = list.filter((p) =>
        tagFilters.every(selectedTag => p.tags?.includes(selectedTag))
      );
    }

    return list;
  }, [projects, nameQuery, tagFilters]);

  // Toggle project selection
  const onRowClick = (name: string) => {
    setSelected(prev => {
      const newSet = new Set(prev);
      if (newSet.has(name)) {
        newSet.delete(name);
      } else {
        newSet.add(name);
      }
      return newSet;
    });
  };

  // Toggle select all projects
  const toggleSelectAll = () => {
    if (selected.size === filtered.length && filtered.length > 0) {
      // All are selected, deselect all
      setSelected(new Set());
    } else {
      // Select all
      setSelected(new Set(filtered.map(p => p.name)));
    }
  };

  // Load selected projects
  const loadProject = async () => {
    if (selected.size === 0) return;
    // Convert set to array and encode as query params
    const projectNames = Array.from(selected);
    const encodedNames = projectNames.map(name => encodeURIComponent(name));
    navigate(`/coding/${encodedNames.join(',')}`);
  };

  // Load treatment application for selected projects
  const loadTreatment = async () => {
    if (selected.size === 0) return;
    // Pass all selected projects as comma-separated encoded names
    const projectNames = Array.from(selected);
    const encodedNames = projectNames.map(name => encodeURIComponent(name));
    navigate(`/treatment/${encodedNames.join(',')}`);
  };

  // Load path analysis for selected projects
  const loadPathAnalysis = () => {
    if (selected.size === 0) return;
    const projectNames = Array.from(selected);
    sessionStorage.setItem("pathAnalysis_selectedProjects", JSON.stringify(projectNames));
    sessionStorage.setItem("pathAnalysis_loadedProjects", JSON.stringify(projectNames));
    navigate("/analysis/path");
  };

  // Edit success callback
  const handleEditSuccess = (newName: string, newTags: string[]) => {
    if (!editingProject) return;

    const oldName = editingProject.name;

    // Update local list
    setProjectList((prev) => {
      if (!prev) return prev;
      return {
        projects: prev.projects.map((p) =>
          p.name === oldName ? { name: newName, tags: newTags } : p
        ),
      };
    });

    // If edited project is currently selected and name changed, update selection
    if (selected.has(oldName) && newName !== oldName) {
      setSelected(prev => {
        const newSet = new Set(prev);
        newSet.delete(oldName);
        newSet.add(newName);
        return newSet;
      });
    }
  };

  // Open delete confirmation dialog for first selected project
  const askDelete = () => {
    if (selected.size === 0) return;
    setOpenDelete(true);
  };

  // Delete selected projects
  const confirmDelete = async () => {
    if (selected.size === 0) return;
# … (truncated, 390 more lines — see source file)
```

## Callers (1)
- [[fn-frontend-src-app-tsx--app|App]]

## Callees (8)
- [[fn-frontend-src-api-index-ts--ping|ping]]
- [[fn-frontend-src-api-index-ts--fetchprojectlist|fetchProjectList]]
- [[fn-frontend-src-pages-projects-projects-tsx--gettagcolor|getTagColor]]
- [[fn-frontend-src-pages-projects-projects-tsx--removetagfilter|removeTagFilter]]
- [[fn-frontend-src-pages-projects-projects-tsx--createproject|createProject]]
- [[fn-frontend-src-pages-projects-projects-tsx--renderheader|renderHeader]]
- [[fn-frontend-src-pages-projects-projects-tsx--onrowclick|onRowClick]]
- [[fn-frontend-src-pages-projects-components-editprojectmodal-tsx--editprojectmodal|EditProjectModal]]

## External / unresolved calls (55)
- `useState` ×13
- `Button` ×7
- `map` ×6
- `toFixed` ×4
- `useEffect` ×3
- `useMemo` ×3
- `sort` ×3
- `filter` ×3
- `stopPropagation` ×3
- `catch` ×2
- `then` ×2
- `setStatus` ×2
- `addEventListener` ×2
- `removeEventListener` ×2
- `slice` ×2
- `getTime` ×2
- `from` ×2
- `toLowerCase` ×2
- `includes` ×2
- `Root` ×2
- `setTagInputValue` ×2
- `setTagComboboxOpen` ×2
- `Portal` ×2
- `Positioner` ×2
- `Content` ×2
- `setOpenEdit` ×2
- `useNavigate`
- `setProjectList`
- `setError`
- `String`
- *... and 25 more.*
