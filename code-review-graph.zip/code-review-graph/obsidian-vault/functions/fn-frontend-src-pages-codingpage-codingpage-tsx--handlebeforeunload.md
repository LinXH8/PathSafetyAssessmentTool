---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/CodingPage/codingPage.tsx::handleBeforeUnload", "handleBeforeUnload"]
tags: [function, tsx]
file: "frontend/src/pages/CodingPage/codingPage.tsx"
lines: "1361-1363"
---

# handleBeforeUnload

**Kind:** Function
**File:** [[file-frontend-src-pages-codingpage-codingpage-tsx|codingPage.tsx]]  `frontend/src/pages/CodingPage/codingPage.tsx`
**Lines:** 1361-1363
**Community:** [[com-codingpage-handle|codingpage-handle]]
**Signature:** `def handleBeforeUnload((event: BeforeUnloadEvent))`

## Source

```tsx
    const handleBeforeUnload = (event: BeforeUnloadEvent) => {
      event.preventDefault();
    };
```

## External / unresolved calls (1)
- `preventDefault`
