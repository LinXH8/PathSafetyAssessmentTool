---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/AddSegmentsDialog.tsx::n", "n"]
tags: [function, tsx]
file: "frontend/src/pages/PathAnalysisPage/components/AddSegmentsDialog.tsx"
lines: "86-86"
---

# n

**Kind:** Function
**File:** [[file-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx|AddSegmentsDialog.tsx]]  `frontend/src/pages/PathAnalysisPage/components/AddSegmentsDialog.tsx`
**Lines:** 86-86
**Community:** [[com-components-tag|components-tag]]
**Signature:** `def n()`

## Source

```tsx
                        .filter(n => !sourceProjectNames.includes(n)); // Exclude source projects from target list? Actually maybe allowed to copy to self? Usually not.
```

## External / unresolved calls (1)
- `includes`
