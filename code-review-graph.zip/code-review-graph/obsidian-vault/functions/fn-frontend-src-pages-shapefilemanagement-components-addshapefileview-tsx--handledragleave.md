---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/ShapefileManagement/components/AddShapefileView.tsx::handleDragLeave", "handleDragLeave"]
tags: [function, tsx]
file: "frontend/src/pages/ShapefileManagement/components/AddShapefileView.tsx"
lines: "25-29"
---

# handleDragLeave

**Kind:** Function
**File:** [[file-frontend-src-pages-shapefilemanagement-components-addshapefileview-tsx|AddShapefileView.tsx]]  `frontend/src/pages/ShapefileManagement/components/AddShapefileView.tsx`
**Lines:** 25-29
**Community:** [[com-components-handle-3|components-handle]]
**Signature:** `def handleDragLeave((e: React.DragEvent))`

## Source

```tsx
  function handleDragLeave(e: React.DragEvent) {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
  }
```

## External / unresolved calls (3)
- `preventDefault`
- `stopPropagation`
- `setDragActive`
