---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/TreatmentPage/components/AttributesDropdown.tsx::AttributesDropdown", "AttributesDropdown"]
tags: [function, tsx]
file: "frontend/src/pages/TreatmentPage/components/AttributesDropdown.tsx"
lines: "190-320"
---

# AttributesDropdown

**Kind:** Function
**File:** [[file-frontend-src-pages-treatmentpage-components-attributesdropdown-tsx|AttributesDropdown.tsx]]  `frontend/src/pages/TreatmentPage/components/AttributesDropdown.tsx`
**Lines:** 190-320
**Community:** [[com-components-handle-5|components-handle]]
**Signature:** `def AttributesDropdown(())`

## Source

```tsx
export default function AttributesDropdown() {
  // Initialize all attributes with "Not Selected"
  const [attributeValues, setAttributeValues] = useState<Record<string, string>>(
    Object.fromEntries(cyclerapAttributes.map((attr) => [attr.name, "Not Selected"]))
  );
  const [isExpanded, setIsExpanded] = useState(false);

  const handleAttributeChange = (fieldName: string, value: string) => {
    setAttributeValues((prev) => ({ ...prev, [fieldName]: value }));
  };

  // Reset all filters
  const handleResetFilters = () => {
    setAttributeValues(
      Object.fromEntries(cyclerapAttributes.map((attr) => [attr.name, "Not Selected"]))
    );
  };

  // Count how many filters are active (not "Not Selected")
  const activeFilterCount = Object.values(attributeValues).filter(
    (value) => value !== "Not Selected"
  ).length;

  return (
    <Box
      borderWidth="1px"
      borderRadius="lg"
      p="6"
      bg="bg.panel"
    >
      {/* Header with Expand/Collapse Button */}
      <Flex justify="space-between" align="center" mb={isExpanded ? "4" : "0"}>
        <Flex align="center" gap="2">
          <Text fontSize="md" fontWeight="bold">
            Filter Segment by Attribute
          </Text>
          {activeFilterCount > 0 && (
            <Box
              px="2"
              py="0.5"
              borderRadius="full"
              bg="blue.subtle"
              fontSize="xs"
              fontWeight="semibold"
              color="blue.fg"
            >
              {activeFilterCount} active
            </Box>
          )}
        </Flex>
        <Flex gap="2">
          {activeFilterCount > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={handleResetFilters}
              colorPalette="red"
            >
              Reset All
            </Button>
          )}
          <Button
            variant="outline"
            size="sm"
            onClick={() => setIsExpanded(!isExpanded)}
          >
            {isExpanded ? "Hide" : "Show"} Fields
            <Box ml="2" display="inline">
              {isExpanded ? <FaChevronUp /> : <FaChevronDown />}
            </Box>
          </Button>
        </Flex>
      </Flex>

      {/* Collapsible Content */}
      <Collapsible.Root open={isExpanded}>
        <Collapsible.Content>
          <Box mb="4">
            <Text fontSize="sm" color="fg.muted" textAlign="center" mb="4">
              Select your desired filters to view segments of interest
            </Text>
          </Box>

          <Grid
            templateColumns={{
              base: "1fr",
              md: "repeat(3, 1fr)",
              lg: "repeat(4, 1fr)",
            }}
            gap="4"
          >
            {cyclerapAttributes.map((attribute) => {
              // Create collection for this specific attribute
              const optionCollection = createListCollection({
                items: attribute.options.map((opt) => ({
                  label: opt,
                  value: opt,
                })),
              });

              return (
                <GridItem key={attribute.name}>
                  <Text fontSize="xs" fontWeight="semibold" mb="1.5">
                    {attribute.name}
                  </Text>
                  <SelectRoot
                    collection={optionCollection}
                    size="sm"
                    value={[attributeValues[attribute.name]]}
                    onValueChange={(e) => handleAttributeChange(attribute.name, e.value[0])}
                  >
                    <SelectTrigger>
                      <SelectValueText placeholder="Select" />
                    </SelectTrigger>
                    <SelectContent maxH="250px" overflowY="auto">
                      {optionCollection.items.map((item) => (
                        <SelectItem key={item.value} item={item}>
                          {item.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </SelectRoot>
                </GridItem>
              );
            })}
          </Grid>
        </Collapsible.Content>
      </Collapsible.Root>
    </Box>
  );
}
```

## Callees (1)
- [[fn-frontend-src-pages-treatmentpage-components-attributesdropdown-tsx--handleattributechange|handleAttributeChange]]

## External / unresolved calls (22)
- `map` ×4
- `Box` ×4
- `Flex` ×3
- `Text` ×3
- `useState` ×2
- `Button` ×2
- `fromEntries`
- `filter`
- `values`
- `setIsExpanded`
- `FaChevronUp`
- `FaChevronDown`
- `Root`
- `Content`
- `Grid`
- `createListCollection`
- `GridItem`
- `SelectRoot`
- `SelectTrigger`
- `SelectValueText`
- `SelectContent`
- `SelectItem`
