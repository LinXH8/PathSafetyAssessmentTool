---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/cycleRAP_VA.py::extract_frames_to_path", "extract_frames_to_path"]
tags: [function, python]
file: "backend/app/services/cycleRAP_VA.py"
lines: "184-207"
---

# extract_frames_to_path

**Kind:** Function
**File:** [[file-backend-app-services-cyclerap-va-py|cycleRAP_VA.py]]  `backend/app/services/cycleRAP_VA.py`
**Lines:** 184-207
**Community:** [[com-services-distance|services-distance]]
**Signature:** `def extract_frames_to_path((video_file_path, frames_to_extract_df, path_to_save_images_to, enable_print = False))`

## Source

```python
def extract_frames_to_path(video_file_path, frames_to_extract_df, path_to_save_images_to, enable_print = False):
    video = cv2.VideoCapture(video_file_path)

    if enable_print is True: print(f"Total frames: {video.get(cv2.CAP_PROP_FRAME_COUNT)}")

    # Check if video was successfully opened
    if not video.isOpened():
        assert False, f"{video_file_path} cannot be loaded"
        print(f"Error: Could not open video file {video_filename}")
    elif enable_print: print(f"Video {video_file_path} successfully loaded.")

    success = False
    image_index = 1
    frame_number = 1
    frame_rate = video.get(cv2.CAP_PROP_FPS)

    for index, row in frames_to_extract_df.iloc[0:].iterrows():
        elapsed_time_in_seconds = row['ELAPSED_TIME']
        # Calculate the corresponding frame number
        frame_number = math.floor(elapsed_time_in_seconds * frame_rate) # Concern: may have very very small desync between image and geo data points due to rounding
        success, image_index = save_frame(video, frame_number, image_index, path_to_save_images_to, enable_print)
        if not success: break
    
    return success
```

## Callees (1)
- [[fn-backend-app-services-cyclerap-va-py--save-frame|save_frame]]

## External / unresolved calls (6)
- `print` ×3
- `get` ×2
- `VideoCapture`
- `isOpened`
- `iterrows`
- `floor`
