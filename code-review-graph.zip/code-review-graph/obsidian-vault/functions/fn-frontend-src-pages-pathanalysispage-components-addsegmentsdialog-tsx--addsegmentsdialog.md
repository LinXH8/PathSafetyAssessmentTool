---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/AddSegmentsDialog.tsx::AddSegmentsDialog", "AddSegmentsDialog"]
tags: [function, tsx]
file: "frontend/src/pages/PathAnalysisPage/components/AddSegmentsDialog.tsx"
lines: "50-432"
---

# AddSegmentsDialog

**Kind:** Function
**File:** [[file-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx|AddSegmentsDialog.tsx]]  `frontend/src/pages/PathAnalysisPage/components/AddSegmentsDialog.tsx`
**Lines:** 50-432
**Community:** [[com-components-tag|components-tag]]
**Signature:** `def AddSegmentsDialog(({
    isOpen,
    onClose,
    sources,
    onSuccess
}: AddSegmentsDialogProps))`

## Source

```tsx
export function AddSegmentsDialog({
    isOpen,
    onClose,
    sources,
    onSuccess
}: AddSegmentsDialogProps) {
    const [projectMode, setProjectMode] = useState<"existing" | "new">("existing");
    const [newProjectName, setNewProjectName] = useState("");
    const [existingProject, setExistingProject] = useState("");
    const [projects, setProjects] = useState<string[]>([]);
    const [submitting, setSubmitting] = useState(false);

    // Tag States for New Project
    const [tags, setTags] = useState<string[]>([]);
    const [tagInput, setTagInput] = useState("");
    const [existingTags, setExistingTags] = useState<string[]>([]);
    const [tagComboboxOpen, setTagComboboxOpen] = useState(false);

    // Project Combobox State
    const [existingProjectInput, setExistingProjectInput] = useState("");
    const [projectComboboxOpen, setProjectComboboxOpen] = useState(false);

    const [collisionConfirmOpen, setCollisionConfirmOpen] = useState(false);
    const [collisionCount, setCollisionCount] = useState(0);

    const totalSegments = sources.reduce((sum, s) => sum + s.indices.length, 0);
    const sourceProjectNames = sources.map(s => s.projectName);

    // Load available projects and tags
    useEffect(() => {
        if (isOpen) {
            fetchProjectList()
                .then((res) => {
                    // Projects list
                    const available = res.projects
                        .map(p => p.name)
                        .filter(n => !sourceProjectNames.includes(n)); // Exclude source projects from target list? Actually maybe allowed to copy to self? Usually not.
                    setProjects(available);
                    if (available.length > 0) {
                        setExistingProject(available[0]);
                        setProjectMode("existing");
                    } else {
                        setProjectMode("new");
                    }

                    // Extract unique tags
                    const tagSet = new Set<string>();
                    res.projects.forEach(p => {
                        p.tags?.forEach(tag => tagSet.add(tag));
                    });
                    setExistingTags(Array.from(tagSet).sort());
                })
                .catch(console.error);
        }
    }, [isOpen]);

    // Tag Handlers
    const handleTagInputKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
        if (e.key === "," || e.key === "Enter") {
            e.preventDefault();
            const trimmedTag = tagInput.trim();
            if (trimmedTag && !tags.includes(trimmedTag)) {
                setTags([...tags, trimmedTag]);
            }
            setTagInput("");
        } else if (e.key === "Backspace" && tagInput === "" && tags.length > 0) {
            setTags(tags.slice(0, -1));
        }
    };

    const removeTag = (tagToRemove: string) => {
        setTags(tags.filter((t) => t !== tagToRemove));
    };

    const performCopy = async (replace: boolean) => {
        const isNew = projectMode === "new";
        const target = isNew ? newProjectName : existingProject;

        try {
            setSubmitting(true);

            // Loop through sources and copy sequentially
            for (const source of sources) {
                await copySegments(
                    source.projectName,
                    target,
                    source.indices,
                    isNew && source === sources[0], // Only create new project for the first source, subsequent are appends
                    replace,
                    isNew ? tags : [] // Pass tags only if new project (only applied on creation)
                );
            }

            toaster.create({
                title: "Success",
                description: `Successfully copied ${totalSegments} segments to ${target}.`,
                type: "success"
            });
            onSuccess();
            onClose();
            setCollisionConfirmOpen(false);
        } catch (e: any) {
            toaster.create({
                title: "Error",
                description: e.message || "Failed to copy segments.",
                type: "error"
            });
        } finally {
            setSubmitting(false);
        }
    };

    const handleSubmit = async () => {
        const target = projectMode === "new" ? newProjectName : existingProject;

        if (!target) {
            toaster.create({ title: "Validation Error", description: "Please specify a project name.", type: "error" });
            return;
        }

        if (projectMode === "new" && target.includes("_")) {
            toaster.create({ title: "Validation Error", description: "Project name cannot contain underscores (_).", type: "error" });
            return;
        }

        try {
            setSubmitting(true);

            // Check for collisions ONLY if copying to existing project
            if (projectMode === "existing") {
                let totalCollisions = 0;

                // Check collisions for each source
                for (const source of sources) {
                    const checkRes = await checkCollisions(source.projectName, target, source.indices);
                    if (checkRes.collisions) {
                        totalCollisions += checkRes.collisions.length;
                    }
                }

                if (totalCollisions > 0) {
                    setCollisionCount(totalCollisions);
                    setCollisionConfirmOpen(true);
                    setSubmitting(false); // Stop loading, wait for user confirmation
                    return;
                }
            }

            // No collisions or new project, proceed directly
            await performCopy(false);

        } catch (e: any) {
            toaster.create({
                title: "Error",
                description: e.message || "Failed to check for collisions.",
                type: "error"
            });
            setSubmitting(false);
        }
    };

    const handleConfirmReplace = async () => {
        await performCopy(true);
    };

    const filteredProjects = projects.filter(p =>
        p.toLowerCase().includes(existingProjectInput.toLowerCase())
    );
    const projectCollection = createListCollection({ items: filteredProjects.map(p => ({ label: p, value: p })) });
    const tagCollection = createListCollection({ items: existingTags.map(t => ({ label: t, value: t })) });

    return (
        <>
            <Dialog.Root open={isOpen} onOpenChange={(e) => !e.open && onClose()}>
                <Portal>
                    <Dialog.Backdrop />
                    <Dialog.Positioner>
                        <Dialog.Content>
                            <Dialog.Header>
                                <Dialog.Title>Add Segments to Project</Dialog.Title>
                            </Dialog.Header>
                            <Dialog.Body>
                                <VStack gap="4" align="stretch">
                                    <Text fontSize="sm" color="gray.600">
                                        You are about to copy <b>{totalSegments}</b> segments from <b>{sources.length}</b> {sources.length === 1 ? 'project' : 'projects'}:
                                    </Text>
                                    <Box maxH="100px" overflowY="auto" pl="2" borderLeft="2px solid" borderColor="gray.200">
                                        {sources.map(s => (
                                            <Text fontSize="xs" key={s.projectName}>
                                                • <b>{s.projectName}</b>: {s.indices.length} segments
                                            </Text>
                                        ))}
                                    </Box>

                                    <Tabs.Root
                                        value={projectMode}
                                        onValueChange={(e) => setProjectMode(e.value as "existing" | "new")}
                                        variant="line"
                                    >
                                        <Tabs.List>
                                            <Tabs.Trigger value="existing" disabled={projects.length === 0}>
                                                Existing Project
                                            </Tabs.Trigger>
                                            <Tabs.Trigger value="new">
                                                New Project
                                            </Tabs.Trigger>
                                        </Tabs.List>

                                        <Tabs.Content value="existing" pt="4">
                                            <Field.Root>
                                                <Field.Label>Select Project</Field.Label>
                                                <Combobox.Root
                                                    collection={projectCollection}
                                                    value={existingProject ? [existingProject] : []}
                                                    onValueChange={(e) => {
                                                        setExistingProject(e.value[0]);
                                                        if (e.value[0]) setExistingProjectInput(e.value[0]);
                                                    }}
                                                    inputValue={existingProjectInput}
                                                    onInputValueChange={(e) => setExistingProjectInput(e.inputValue)}
                                                    open={projectComboboxOpen}
                                                    onOpenChange={(details) => setProjectComboboxOpen(details.open)}
                                                >
                                                    <Combobox.Control onClick={() => setProjectComboboxOpen(true)}>
                                                        <Combobox.Input placeholder="Select or type project name" />
                                                        <Combobox.IndicatorGroup>
                                                            <Combobox.Trigger />
                                                        </Combobox.IndicatorGroup>
                                                    </Combobox.Control>
                                                    <Portal>
                                                        <Combobox.Positioner>
                                                            <Combobox.Content zIndex={2000} maxH="300px" overflowY="auto">
                                                                <Combobox.Empty>No projects found</Combobox.Empty>
                                                                {projectCollection.items.map((item) => (
                                                                    <Combobox.Item item={item} key={item.value}>
                                                                        {item.label}
                                                                    </Combobox.Item>
                                                                ))}
                                                            </Combobox.Content>
                                                        </Combobox.Positioner>
                                                    </Portal>
                                                </Combobox.Root>
                                            </Field.Root>
                                        </Tabs.Content>

                                        <Tabs.Content value="new" pt="4">
                                            <VStack gap="4" align="stretch">
                                                <Field.Root>
                                                    <Field.Label>New Project Name</Field.Label>
                                                    <Input
# … (truncated, 133 more lines — see source file)
```

## Callers (2)
- [[fn-frontend-src-pages-codingpage-components-geodatapanel-tsx--geodatapanel|GeoDataPanel]]
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--attributeanalysismapview|AttributeAnalysisMapView]]

## Callees (3)
- [[fn-frontend-src-api-index-ts--fetchprojectlist|fetchProjectList]]
- [[fn-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx--gettagcolor|getTagColor]]
- [[fn-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx--removetag|removeTag]]

## External / unresolved calls (45)
- `useState` ×13
- `map` ×8
- `Root` ×8
- `Content` ×6
- `Portal` ×4
- `Positioner` ×4
- `Text` ×4
- `Box` ×4
- `Button` ×4
- `filter` ×3
- `setProjectMode` ×3
- `Trigger` ×3
- `Label` ×3
- `Input` ×3
- `setTagComboboxOpen` ×3
- `setExistingProject` ×2
- `createListCollection` ×2
- `Backdrop` ×2
- `Header` ×2
- `Title` ×2
- `Body` ×2
- `VStack` ×2
- `setExistingProjectInput` ×2
- `setProjectComboboxOpen` ×2
- `Control` ×2
- `setTagInput` ×2
- `Footer` ×2
- `setCollisionConfirmOpen` ×2
- `reduce`
- `useEffect`
- *... and 15 more.*
