---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/TreatmentPage/treatmentDetailPage.tsx::handleTreatAllCompleted", "handleTreatAllCompleted"]
tags: [function, tsx]
file: "frontend/src/pages/TreatmentPage/treatmentDetailPage.tsx"
lines: "745-785"
---

# handleTreatAllCompleted

**Kind:** Function
**File:** [[file-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx|treatmentDetailPage.tsx]]  `frontend/src/pages/TreatmentPage/treatmentDetailPage.tsx`
**Lines:** 745-785
**Community:** [[com-treatmentpage-treatment|treatmentpage-treatment]]
**Signature:** `def handleTreatAllCompleted((event: Event))`

## Source

```tsx
    const handleTreatAllCompleted = (event: Event) => {
      const customEvent = event as CustomEvent;
      const details = customEvent.detail; // Array of treatment details (now with projectName)

      if (details && Array.isArray(details)) {
        // Map treatment details to global indices based on projectMap
        setTreatmentState((prevState) => {
          const newState = { ...prevState };

          details.forEach((detail: any) => {
            const projectName = detail.projectName;
            const localIndex = detail.segment_index;
            const afterScores = detail.after_scores;

            // Find the project in projectMap to get the start index
            const project = projectMap.find(p => p.name === projectName);
            if (project) {
              const globalIndex = project.startIndex + localIndex;
              newState[globalIndex] = {
                applied: true,
                treatment_ids: detail.treatments_applied || detail.treatment_ids || [],
                after_scores: afterScores ? {
                  BB: afterScores.BB,
                  BP: afterScores.BP,
                  SB: afterScores.SB,
                  VB: afterScores.VB,
                  total: afterScores["Overall Risk Level"],
                } : null,
              };
            }
          });

          return newState;
        });

        setRefreshTrigger(prev => prev + 1);
      } else {
        setRefreshTrigger(prev => prev + 1);
        setTreatmentState({});
      }
    };
```

## External / unresolved calls (5)
- `setTreatmentState` ×2
- `setRefreshTrigger` ×2
- `isArray`
- `forEach`
- `find`
