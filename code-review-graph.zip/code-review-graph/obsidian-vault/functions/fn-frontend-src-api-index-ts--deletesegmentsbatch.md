---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/api/index.ts::deleteSegmentsBatch", "deleteSegmentsBatch"]
tags: [function, typescript]
file: "frontend/src/api/index.ts"
lines: "153-161"
---

# deleteSegmentsBatch

**Kind:** Function
**File:** [[file-frontend-src-api-index-ts|index.ts]]  `frontend/src/api/index.ts`
**Lines:** 153-161
**Community:** [[com-api-project|api-project]]
**Signature:** `def deleteSegmentsBatch((project: string, indices: number[]))`

## Source

```typescript
export async function deleteSegmentsBatch(project: string, indices: number[]) {
  const res = await fetch(`/api/projects/${encodeURIComponent(project)}/segments/delete-batch`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ indices }),
  });
  if (!res.ok) throw new Error(await readError(res));
  return res.json();
}
```

## Callers (1)
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--handlebatchdelete|handleBatchDelete]]

## Callees (1)
- [[fn-frontend-src-api-index-ts--readerror|readError]]

## External / unresolved calls (4)
- `fetch`
- `encodeURIComponent`
- `stringify`
- `json`
