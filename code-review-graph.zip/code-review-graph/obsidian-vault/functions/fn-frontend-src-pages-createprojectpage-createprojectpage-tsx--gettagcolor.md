---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/CreateProjectPage/createProjectPage.tsx::getTagColor", "getTagColor"]
tags: [function, tsx]
file: "frontend/src/pages/CreateProjectPage/createProjectPage.tsx"
lines: "21-38"
---

# getTagColor

**Kind:** Function
**File:** [[file-frontend-src-pages-createprojectpage-createprojectpage-tsx|createProjectPage.tsx]]  `frontend/src/pages/CreateProjectPage/createProjectPage.tsx`
**Lines:** 21-38
**Community:** [[com-createprojectpage-tag|createprojectpage-tag]]
**Signature:** `def getTagColor((tag: string)) -> : string`

## Source

```tsx
function getTagColor(tag: string): string {
  let hash = 0;
  for (let i = 0; i < tag.length; i++) {
    hash = tag.charCodeAt(i) + ((hash << 5) - hash);
  }

  const hash2 = Math.abs(hash >> 16);
  const hash3 = Math.abs(hash << 3);

  let hue = Math.abs(hash % 360);
  if (hue >= 40 && hue <= 60) hue = (hue + 30) % 360;
  if (hue >= 160 && hue <= 180) hue = (hue + 30) % 360;

  const saturation = 75 + (hash2 % 21);
  const lightness = 65 + (hash3 % 16);

  return `hsl(${hue}, ${saturation}%, ${lightness}%)`;
}
```

## Callers (1)
- [[fn-frontend-src-pages-createprojectpage-createprojectpage-tsx--createprojectpage|CreateProjectPage]]

## External / unresolved calls (2)
- `abs` ×3
- `charCodeAt`
