---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/cycle_rap_processing_gopro_footage.py::snap_to_nearest", "snap_to_nearest"]
tags: [function, python]
file: "backend/app/services/cycle_rap_processing_gopro_footage.py"
lines: "128-133"
---

# snap_to_nearest

**Kind:** Function
**File:** [[file-backend-app-services-cycle-rap-processing-gopro-footage-py|cycle_rap_processing_gopro_footage.py]]  `backend/app/services/cycle_rap_processing_gopro_footage.py`
**Lines:** 128-133
**Community:** [[com-services-extract|services-extract]]
**Signature:** `def snap_to_nearest((point))`

## Source

```python
    def snap_to_nearest(point):
        nearest_line = link.geometry.distance(point).idxmin()
        nearest_geom = link.geometry.iloc[nearest_line]
        snapped_point = nearest_points(point, nearest_geom)[1]

        return snapped_point if point.distance(snapped_point) <= t else point
```

## External / unresolved calls (3)
- `distance` ×2
- `idxmin`
- `nearest_points`
