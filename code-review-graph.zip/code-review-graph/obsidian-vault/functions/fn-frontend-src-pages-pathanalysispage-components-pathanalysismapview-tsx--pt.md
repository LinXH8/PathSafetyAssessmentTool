---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx::pt", "pt"]
tags: [function, tsx]
file: "frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx"
lines: "1890-1890"
---

# pt

**Kind:** Function
**File:** [[file-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx|PathAnalysisMapView.tsx]]  `frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx`
**Lines:** 1890-1890
**Community:** [[com-components-handle-2|components-handle]]
**Signature:** `def pt()`

## Source

```tsx
                      allPoints.filter(pt => isPointInPolygon(pt.latlng, polygonPoints)).length
```

## Callees (1)
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--ispointinpolygon|isPointInPolygon]]
