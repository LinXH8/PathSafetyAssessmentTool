---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/AttributeDistributionChart.tsx::c", "c"]
tags: [function, tsx]
file: "frontend/src/pages/PathAnalysisPage/components/AttributeDistributionChart.tsx"
lines: "93-93"
---

# c

**Kind:** Function
**File:** [[file-frontend-src-pages-pathanalysispage-components-attributedistributionchart-tsx|AttributeDistributionChart.tsx]]  `frontend/src/pages/PathAnalysisPage/components/AttributeDistributionChart.tsx`
**Lines:** 93-93
**Community:** [[com-components-attribute|components-attribute]]
**Signature:** `def c()`

## Source

```tsx
    acc + group.categories.filter(c => c.isActive).length, 0);
```
