---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/CodingPage/codingPage.tsx::timeout", "timeout"]
tags: [function, tsx]
file: "frontend/src/pages/CodingPage/codingPage.tsx"
lines: "312-316"
---

# timeout

**Kind:** Function
**File:** [[file-frontend-src-pages-codingpage-codingpage-tsx|codingPage.tsx]]  `frontend/src/pages/CodingPage/codingPage.tsx`
**Lines:** 312-316
**Community:** [[com-codingpage-handle|codingpage-handle]]
**Signature:** `def timeout()`

## Source

```tsx
      Object.values(scoreDebounceRef.current).forEach(timeout => {
        if (timeout !== undefined) {
          clearTimeout(timeout);
        }
      });
```

## External / unresolved calls (1)
- `clearTimeout`
