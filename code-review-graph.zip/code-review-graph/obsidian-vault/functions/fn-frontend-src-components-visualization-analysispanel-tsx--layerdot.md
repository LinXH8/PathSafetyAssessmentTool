---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/AnalysisPanel.tsx::LayerDot", "LayerDot"]
tags: [function, tsx]
file: "frontend/src/components/visualization/AnalysisPanel.tsx"
lines: "46-60"
---

# LayerDot

**Kind:** Function
**File:** [[file-frontend-src-components-visualization-analysispanel-tsx|AnalysisPanel.tsx]]  `frontend/src/components/visualization/AnalysisPanel.tsx`
**Lines:** 46-60
**Community:** [[com-visualization-width|visualization-width]]
**Signature:** `def LayerDot(({ layer }: { layer: string }))`

## Source

```tsx
function LayerDot({ layer }: { layer: string }) {
  return (
    <span
      style={{
        display: 'inline-block',
        width: 10,
        height: 10,
        borderRadius: '50%',
        background: getLayerColor(layer),
        marginLeft: 6,
        verticalAlign: 'middle',
      }}
    />
  );
}
```

## Callers (1)
- [[fn-frontend-src-components-visualization-analysispanel-tsx--analysispanel|AnalysisPanel]]

## Callees (1)
- [[fn-frontend-src-components-visualization-analysispanel-tsx--getlayercolor|getLayerColor]]
