---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/gis_mapping.py::GIS.__init__", "__init__"]
tags: [function, python]
file: "backend/app/services/gis_mapping.py"
lines: "164-165"
---

# __init__

**Kind:** Function
**File:** [[file-backend-app-services-gis-mapping-py|gis_mapping.py]]  `backend/app/services/gis_mapping.py`
**Lines:** 164-165
**Community:** [[com-services-width|services-width]]
**Signature:** `def __init__((self, store: LayerStore))`

## Source

```python
    def __init__(self, store: LayerStore):
        self.store = store
```
