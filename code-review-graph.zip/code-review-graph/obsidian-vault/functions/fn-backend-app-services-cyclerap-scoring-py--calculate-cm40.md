---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/cyclerap_scoring.py::calculate_cm40", "calculate_cm40"]
tags: [function, python]
file: "backend/app/services/cyclerap_scoring.py"
lines: "252-288"
---

# calculate_cm40

**Kind:** Function
**File:** [[file-backend-app-services-cyclerap-scoring-py|cyclerap_scoring.py]]  `backend/app/services/cyclerap_scoring.py`
**Lines:** 252-288
**Community:** [[com-services-calculate|services-calculate]]
**Signature:** `def calculate_cm40((row: pd.Series)) -> float`

## Description

> Calculate CM40 component (vehicle interaction)

## Source

```python
def calculate_cm40(row: pd.Series) -> float:
    """Calculate CM40 component (vehicle interaction)"""
    facility_vb_cond = LOOKUP_TABLES['facility_type'].get(row.get(FACILITY_TYPE, 1), {}).get('vb_cond', 0)

    cq40_triggers = [
        get_cond('intersection_crossing', row.get(INTERSECTION_CROSSING, 2)),
        get_cond('property_access', row.get(PROPERTY_ACCESS, 2)),
        get_cond('adjacent_road_0_1m', row.get(ADJACENT_ROAD_0_1M, 2)),
        get_cond('adjacent_road_1_3m', row.get(ADJACENT_ROAD_1_3M, 2)),
        facility_vb_cond,
        get_cond('intersection_approach', row.get(INTERSECTION_APPROACH, 2)),
        get_cond('line_of_sight', row.get(LINE_OF_SIGHT, 1)),
    ]
    cq_sum = sum(cq40_triggers)
    if cq_sum == 0:
        return 0

    facility_vb_sev = LOOKUP_TABLES['facility_type'].get(row.get(FACILITY_TYPE, 1), {}).get('vb_sev', 1.0)

    cu40_factors = [
        get_risk('crossing_facility', row.get(CROSSING_FACILITY, 1)),
        get_risk('flow_direction', row.get(FLOW_DIRECTION, 1)),
        get_risk('adjacent_parking_0_1m', row.get(ADJACENT_PARKING_0_1M, 2)),
        get_risk('adjacent_parking_1_3m', row.get(ADJACENT_PARKING_1_3M, 2)),
        get_risk('street_lighting', row.get(STREET_LIGHTING, 1)),
        get_risk('num_lanes_adjacent', row.get(NUM_LANES_ADJACENT, 1)),
        get_risk('num_lanes_intersecting', row.get(NUM_LANES_INTERSECTING, 1)),
        get_aadt_risk_factor(float(row.get(ROAD_AADT, 5000) or 5000)),
        get_risk('heavy_vehicle', row.get(HEAVY_VEHICLE, 1)),
        get_risk('delineation', row.get(DELINEATION, 2)),
        get_risk('light_segregation', row.get(LIGHT_SEGREGATION, 2)),
        facility_vb_sev,
        # Line of Sight: inadequate visibility directly increases vehicle-bicyclist conflict risk
        get_risk('line_of_sight', row.get(LINE_OF_SIGHT, 1)),
    ]
    cu40_product = np.prod(cu40_factors)
    return cu40_product ** (1 + cq_sum * 0.1)
```

## Callers (1)
- [[fn-backend-app-services-cyclerap-scoring-py--calculate-cyclerap-score-native|calculate_cyclerap_score_native]]

## Callees (3)
- [[fn-backend-app-services-cyclerap-scoring-py--get-cond|get_cond]]
- [[fn-backend-app-services-cyclerap-scoring-py--get-risk|get_risk]]
- [[fn-backend-app-services-cyclerap-scoring-py--get-aadt-risk-factor|get_aadt_risk_factor]]

## External / unresolved calls (4)
- `get` ×20
- `sum`
- `float`
- `prod`
