---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/scoreband/ScoreBandDistributionPanel.tsx::handleScoresUpdated", "handleScoresUpdated"]
tags: [function, tsx]
file: "frontend/src/components/visualization/scoreband/ScoreBandDistributionPanel.tsx"
lines: "123-126"
---

# handleScoresUpdated

**Kind:** Function
**File:** [[file-frontend-src-components-visualization-scoreband-scorebanddistributionpanel-tsx|ScoreBandDistributionPanel.tsx]]  `frontend/src/components/visualization/scoreband/ScoreBandDistributionPanel.tsx`
**Lines:** 123-126
**Community:** [[com-scoreband-score|scoreband-score]]
**Signature:** `def handleScoresUpdated(())`

## Source

```tsx
    const handleScoresUpdated = () => {
      
      fetchResults();
    };
```

## External / unresolved calls (1)
- `fetchResults`
