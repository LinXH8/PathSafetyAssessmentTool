---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/project_manager.py::Project.metadata", "metadata"]
tags: [function, python]
file: "backend/app/services/project_manager.py"
lines: "714-718"
---

# metadata

**Kind:** Function
**File:** [[file-backend-app-services-project-manager-py|project_manager.py]]  `backend/app/services/project_manager.py`
**Lines:** 714-718
**Community:** [[com-services-project|services-project]]
**Signature:** `def metadata((self, value: serializer.ProjectMetadata))`

## Source

```python
    def metadata(self, value: serializer.ProjectMetadata):
        if not isinstance(value, serializer.ProjectMetadata):
            raise TypeError("metadata must be serializer.ProjectMetadata")
        self._metadata = value
        self._meta_dirty = True      
```

## External / unresolved calls (5)
- `ProjectMetadata`
- `parse`
- `print`
- `isinstance`
- `TypeError`
