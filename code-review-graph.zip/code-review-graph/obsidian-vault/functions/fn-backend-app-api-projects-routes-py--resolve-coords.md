---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/projects/routes.py::_resolve_coords", "_resolve_coords"]
tags: [function, python]
file: "backend/app/api/projects/routes.py"
lines: "3188-3194"
---

# _resolve_coords

**Kind:** Function
**File:** [[file-backend-app-api-projects-routes-py|routes.py]]  `backend/app/api/projects/routes.py`
**Lines:** 3188-3194
**Community:** [[com-projects-treatments|projects-treatments]]
**Signature:** `def _resolve_coords((idx: int))`

## Source

```python
        def _resolve_coords(idx: int):
            if 0 <= idx < len(proj.geo_data.df):
                geom = proj.geo_data.df.geometry.iloc[idx]
                if geom is not None and isinstance(geom, _LS) and not geom.is_empty:
                    # shapely coords -> [[lon,lat], ...]
                    return [list(c) for c in list(geom.coords)]
            return None
```

## Callers (1)
- [[fn-backend-app-api-projects-routes-py--autocode-all|autocode_all]]

## External / unresolved calls (3)
- `len`
- `isinstance`
- `list`
