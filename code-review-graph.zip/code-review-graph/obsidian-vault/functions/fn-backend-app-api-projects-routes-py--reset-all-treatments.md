---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/projects/routes.py::reset_all_treatments", "reset_all_treatments"]
tags: [function, python]
file: "backend/app/api/projects/routes.py"
lines: "1960-2028"
---

# reset_all_treatments

**Kind:** Function
**File:** [[file-backend-app-api-projects-routes-py|routes.py]]  `backend/app/api/projects/routes.py`
**Lines:** 1960-2028
**Community:** [[com-projects-treatments|projects-treatments]]
**Signature:** `def reset_all_treatments((project_name: str))`

## Description

> Clear all applied treatments for all segments in a project.
>
> Response:
>     {
>         "ok": true,
>         "total_segments": 50,
>         "segments_reset": 48,
>         "message": "All treatments have been reset"
>     }

## Source

```python
def reset_all_treatments(project_name: str):
    """
    Clear all applied treatments for all segments in a project.

    Response:
        {
            "ok": true,
            "total_segments": 50,
            "segments_reset": 48,
            "message": "All treatments have been reset"
        }
    """
    try:
        ctx = get_ctx()
        proj: Project = ctx["pm"].project(project_name)
        ver = proj.latest()

        # Load treatment dataframe
        treatment_df = ver.treatment.df.copy()

        # Ensure treatment dataframe has same number of rows as attributes dataframe
        attrs_df = ver.attributes.df
        if len(treatment_df) < len(attrs_df):
            # Expand treatment dataframe to match attributes size
            new_rows = [{}] * (len(attrs_df) - len(treatment_df))
            treatment_df = pd.concat([treatment_df, pd.DataFrame(new_rows)], ignore_index=True)

        # Count how many segments had treatments
        if "Treatments Applied" in treatment_df.columns:
            # fillna("") ensures NaNs become empty strings. astype(str) ensures everything is string.
            # str.strip() removes distinct whitespace.
            # Then we check if length > 0.
            # This handles: NaN, None, "", "   ".
            # It counts ANY row that has non-empty treatment string.
            applied_col = treatment_df["Treatments Applied"].fillna("").astype(str).str.strip()
            segments_reset = int((applied_col != "").sum())
        else:
            segments_reset = 0

        # Clear "Treatments Applied" column for all rows
        if "Treatments Applied" in treatment_df.columns:
            treatment_df["Treatments Applied"] = ""

        # Reset all attribute columns to original values from attributes.csv
        attrs_df = ver.attributes.df
        for col in treatment_df.columns:
            if col != "Treatments Applied" and col in attrs_df.columns:
                # Copy original attribute values from attributes.csv
                if col in attrs_df.columns:
                    treatment_df[col] = attrs_df[col].values

        # Mark treatment dataframe as dirty but don't save yet
        # User must click "Save" button to persist changes
        # Directly assign to the existing treatment object's df property
        # This sets df_dirty=True via the property setter
        ver.treatment.df = treatment_df
        # NOTE: NOT calling proj.save_all() here - changes will be saved only when user clicks Save

        return jsonify({
            "ok": True,
            "total_segments": int(len(treatment_df)),
            "segments_reset": segments_reset,
            "message": "All treatments have been reset"
        })

    except Exception as e:
        import traceback
        traceback.print_exc()
        return fail(f"Error resetting treatments: {str(e)}", 500)
```

## Callees (2)
- [[fn-backend-app-api-projects-routes-py--get-ctx|get_ctx]]
- [[fn-backend-app-api-projects-routes-py--fail|fail]]

## External / unresolved calls (14)
- `len` ×3
- `int` ×2
- `project`
- `latest`
- `copy`
- `concat`
- `DataFrame`
- `strip`
- `astype`
- `fillna`
- `sum`
- `jsonify`
- `print_exc`
- `str`
