---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/Projects/projects.tsx::toggleSelectAll", "toggleSelectAll"]
tags: [function, tsx]
file: "frontend/src/pages/Projects/projects.tsx"
lines: "230-238"
---

# toggleSelectAll

**Kind:** Function
**File:** [[file-frontend-src-pages-projects-projects-tsx|projects.tsx]]  `frontend/src/pages/Projects/projects.tsx`
**Lines:** 230-238
**Community:** [[com-projects-tag|projects-tag]]
**Signature:** `def toggleSelectAll(())`

## Source

```tsx
  const toggleSelectAll = () => {
    if (selected.size === filtered.length && filtered.length > 0) {
      // All are selected, deselect all
      setSelected(new Set());
    } else {
      // Select all
      setSelected(new Set(filtered.map(p => p.name)));
    }
  };
```

## External / unresolved calls (2)
- `setSelected` ×2
- `map`
