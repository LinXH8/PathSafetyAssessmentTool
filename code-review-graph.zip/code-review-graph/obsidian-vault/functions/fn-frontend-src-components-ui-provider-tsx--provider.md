---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/ui/provider.tsx::Provider", "Provider"]
tags: [function, tsx]
file: "frontend/src/components/ui/provider.tsx"
lines: "9-15"
---

# Provider

**Kind:** Function
**File:** [[file-frontend-src-components-ui-provider-tsx|provider.tsx]]  `frontend/src/components/ui/provider.tsx`
**Lines:** 9-15
**Community:** [[com-ui-provider|ui-provider]]
**Signature:** `def Provider((props: ColorModeProviderProps))`

## Source

```tsx
export function Provider(props: ColorModeProviderProps) {
  return (
    <ChakraProvider value={defaultSystem}>
      <ColorModeProvider {...props} />
    </ChakraProvider>
  )
}
```

## Callees (1)
- [[fn-frontend-src-components-ui-color-mode-tsx--colormodeprovider|ColorModeProvider]]

## External / unresolved calls (1)
- `ChakraProvider`
