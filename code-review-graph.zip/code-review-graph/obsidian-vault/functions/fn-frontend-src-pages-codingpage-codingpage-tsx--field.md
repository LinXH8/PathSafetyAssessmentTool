---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/CodingPage/codingPage.tsx::field", "field"]
tags: [function, tsx]
file: "frontend/src/pages/CodingPage/codingPage.tsx"
lines: "509-509"
---

# field

**Kind:** Function
**File:** [[file-frontend-src-pages-codingpage-codingpage-tsx|codingPage.tsx]]  `frontend/src/pages/CodingPage/codingPage.tsx`
**Lines:** 509-509
**Community:** [[com-codingpage-handle|codingpage-handle]]
**Signature:** `def field()`

## Source

```tsx
        gisChanged.forEach(field => { fieldSources[field] = "GIS"; });
```
