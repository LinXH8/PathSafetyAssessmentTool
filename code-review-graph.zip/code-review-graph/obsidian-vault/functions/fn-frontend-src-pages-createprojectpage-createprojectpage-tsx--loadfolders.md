---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/CreateProjectPage/createProjectPage.tsx::loadFolders", "loadFolders"]
tags: [function, tsx]
file: "frontend/src/pages/CreateProjectPage/createProjectPage.tsx"
lines: "55-76"
---

# loadFolders

**Kind:** Function
**File:** [[file-frontend-src-pages-createprojectpage-createprojectpage-tsx|createProjectPage.tsx]]  `frontend/src/pages/CreateProjectPage/createProjectPage.tsx`
**Lines:** 55-76
**Community:** [[com-createprojectpage-tag|createprojectpage-tag]]
**Signature:** `def loadFolders((ctrl?: AbortController))`

## Source

```tsx
  const loadFolders = async (ctrl?: AbortController) => {
    try {
      setLoadingFolders(true);
      setErr(null);
      const [foldersData, projectsData] = await Promise.all([
        listSourceFolders({ signal: ctrl?.signal }),
        fetchProjectList()
      ]);
      setFolders(foldersData);

      // Extract all unique tags from existing projects
      const tagSet = new Set<string>();
      projectsData.projects.forEach(p => {
        p.tags?.forEach(tag => tagSet.add(tag));
      });
      setExistingTags(Array.from(tagSet).sort());
    } catch (e: any) {
      if (e?.name !== "AbortError") setErr(e?.message ?? "Failed to load folders");
    } finally {
      setLoadingFolders(false);
    }
  };
```

## Callers (1)
- [[fn-frontend-src-pages-createprojectpage-createprojectpage-tsx--createprojectpage|CreateProjectPage]]

## Callees (2)
- [[fn-frontend-src-api-index-ts--listsourcefolders|listSourceFolders]]
- [[fn-frontend-src-api-index-ts--fetchprojectlist|fetchProjectList]]

## External / unresolved calls (8)
- `setLoadingFolders` ×2
- `setErr` ×2
- `all`
- `setFolders`
- `forEach`
- `setExistingTags`
- `sort`
- `from`
