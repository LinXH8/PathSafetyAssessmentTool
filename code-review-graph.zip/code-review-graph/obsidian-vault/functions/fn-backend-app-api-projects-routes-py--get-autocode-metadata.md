---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/projects/routes.py::get_autocode_metadata", "get_autocode_metadata"]
tags: [function, python]
file: "backend/app/api/projects/routes.py"
lines: "3534-3570"
---

# get_autocode_metadata

**Kind:** Function
**File:** [[file-backend-app-api-projects-routes-py|routes.py]]  `backend/app/api/projects/routes.py`
**Lines:** 3534-3570
**Community:** [[com-projects-treatments|projects-treatments]]
**Signature:** `def get_autocode_metadata((project_name: str))`

## Description

> Get autocode metadata (changed fields and sources) as JSON.
>
> Response:
>     {
>         "ok": true,
>         "changedFieldsByRow": { "0": ["Field1"], ... },
>         "fieldSourcesByRow": { "0": {"Field1": "GIS"}, ... }
>     }

## Source

```python
def get_autocode_metadata(project_name: str):
    """
    Get autocode metadata (changed fields and sources) as JSON.
    
    Response:
        {
            "ok": true,
            "changedFieldsByRow": { "0": ["Field1"], ... },
            "fieldSourcesByRow": { "0": {"Field1": "GIS"}, ... }
        }
    """
    try:
        ctx = get_ctx()
        pm = ctx["pm"]
        proj = pm.project(project_name)
        
        # Use 'autocode' directory for metadata
        autocode_dir = proj.project_path / "autocode"
        metadata_path = autocode_dir / f"{project_name}_metadata.json"
        
        if not metadata_path.exists():
            return ok({
                "changedFieldsByRow": {},
                "fieldSourcesByRow": {}
            })
            
        import json
        with open(metadata_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            
        return ok(data)

    except KeyError:
        return fail("Project not found", 404)
    except Exception as e:
        traceback.print_exc()
        return fail(f"Error reading autocode metadata: {e}", 500)
```

## Callees (3)
- [[fn-backend-app-api-projects-routes-py--get-ctx|get_ctx]]
- [[fn-backend-app-api-projects-routes-py--ok|ok]]
- [[fn-backend-app-api-projects-routes-py--fail|fail]]

## External / unresolved calls (5)
- `project`
- `exists`
- `open`
- `load`
- `print_exc`
