---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/ShapefileManagement/ShapefileManagementPage.tsx::loadShapefiles", "loadShapefiles"]
tags: [function, tsx]
file: "frontend/src/pages/ShapefileManagement/ShapefileManagementPage.tsx"
lines: "21-34"
---

# loadShapefiles

**Kind:** Function
**File:** [[file-frontend-src-pages-shapefilemanagement-shapefilemanagementpage-tsx|ShapefileManagementPage.tsx]]  `frontend/src/pages/ShapefileManagement/ShapefileManagementPage.tsx`
**Lines:** 21-34
**Community:** [[com-shapefilemanagement-handle|shapefilemanagement-handle]]
**Signature:** `def loadShapefiles(())`

## Source

```tsx
  async function loadShapefiles() {
    try {
      setLoading(true);
      const data = await api.listShapefiles();
      setShapefiles(data);
    } catch (error) {
      toaster.create({
        description: `Failed to load shapefiles: ${error}`,
        type: "error",
      });
    } finally {
      setLoading(false);
    }
  }
```

## Callers (3)
- [[fn-frontend-src-pages-shapefilemanagement-shapefilemanagementpage-tsx--shapefilemanagementpage|ShapefileManagementPage]]
- [[fn-frontend-src-pages-shapefilemanagement-shapefilemanagementpage-tsx--handleuploadcomplete|handleUploadComplete]]
- [[fn-frontend-src-pages-shapefilemanagement-shapefilemanagementpage-tsx--handledelete|handleDelete]]

## External / unresolved calls (4)
- `setLoading` ×2
- `listShapefiles`
- `setShapefiles`
- `create`
