---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx::p", "p"]
tags: [function, tsx]
file: "frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx"
lines: "1716-1723"
---

# p

**Kind:** Function
**File:** [[file-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx|PathAnalysisMapView.tsx]]  `frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx`
**Lines:** 1716-1723
**Community:** [[com-components-handle-2|components-handle]]
**Signature:** `def p()`

## Source

```tsx
    allPoints.forEach(p => {
      if (isPointInPolygon(p.latlng, polygonPoints)) {
        if (!selectedMap.has(p.projectName)) {
          selectedMap.set(p.projectName, []);
        }
        selectedMap.get(p.projectName)?.push(p.idx);
      }
    });
```

## Callees (1)
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--ispointinpolygon|isPointInPolygon]]

## External / unresolved calls (6)
- `latLng`
- `add`
- `has`
- `set`
- `push`
- `get`
