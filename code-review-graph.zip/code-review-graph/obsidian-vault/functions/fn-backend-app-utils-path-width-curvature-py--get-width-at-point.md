---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/utils/path_width_curvature.py::get_width_at_point", "get_width_at_point"]
tags: [function, python]
file: "backend/app/utils/path_width_curvature.py"
lines: "388-401"
---

# get_width_at_point

**Kind:** Function
**File:** [[file-backend-app-utils-path-width-curvature-py|path_width_curvature.py]]  `backend/app/utils/path_width_curvature.py`
**Lines:** 388-401
**Community:** [[com-utils-width|utils-width]]
**Signature:** `def get_width_at_point((
    point: Point,
    start_radius: float = 1.0,
    max_radius: float = 5.0,
    step: float = 1.0,
    priority: Optional[List[str]] = None,
    base_dir: Optional[str] = None
)) -> Optional[float]`

## Description

> Backward-compatible API: returns only width W.
> If no width found, returns 0 to match previous behavior.

## Source

```python
def get_width_at_point(
    point: Point,
    start_radius: float = 1.0,
    max_radius: float = 5.0,
    step: float = 1.0,
    priority: Optional[List[str]] = None,
    base_dir: Optional[str] = None
) -> Optional[float]:
    """
    Backward-compatible API: returns only width W.
    If no width found, returns 0 to match previous behavior.
    """
    R, W = get_radius_and_width_at_point(point, start_radius, max_radius, step, priority, base_dir=base_dir)
    return 0 if W is None else W
```

## Callees (1)
- [[fn-backend-app-utils-path-width-curvature-py--get-radius-and-width-at-point|get_radius_and_width_at_point]]
