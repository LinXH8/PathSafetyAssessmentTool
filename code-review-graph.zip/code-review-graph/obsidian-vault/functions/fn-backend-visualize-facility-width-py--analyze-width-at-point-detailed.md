---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/visualize_facility_width.py::analyze_width_at_point_detailed", "analyze_width_at_point_detailed"]
tags: [function, python]
file: "backend/visualize_facility_width.py"
lines: "41-175"
---

# analyze_width_at_point_detailed

**Kind:** Function
**File:** [[file-backend-visualize-facility-width-py|visualize_facility_width.py]]  `backend/visualize_facility_width.py`
**Lines:** 41-175
**Community:** [[com-backend-width|backend-width]]
**Signature:** `def analyze_width_at_point_detailed((point, base_dir, start_radius=1.0, max_radius=10.0, step=1.0))`

## Description

> Perform detailed analysis of width calculation at a point.
>
> Returns diagnostic information about the search process.

## Source

```python
def analyze_width_at_point_detailed(point, base_dir, start_radius=1.0, max_radius=10.0, step=1.0):
    """
    Perform detailed analysis of width calculation at a point.

    Returns diagnostic information about the search process.
    """
    # Convert to metric if needed
    shp_dir = Path(base_dir)
    layer_store = gis.LayerStore.default(base_dir=str(shp_dir))
    _gis = gis.GIS(layer_store)
    pt = _gis.store.to_metric_point(point)

    # Load layers
    gdf_cycling = load_layer("path/CyclingpathCentreline.shp", base_dir=base_dir)
    gdf_foot = load_layer("path/Footpathcentreline.shp", base_dir=base_dir)
    gdf_share = load_layer("path/Sharedpathcentreline.shp", base_dir=base_dir)

    layers = {
        "cycling": gdf_cycling,
        "footpath": gdf_foot,
        "shared": gdf_share
    }

    # Check what's in each layer
    layer_info = {}
    for name, gdf in layers.items():
        if gdf is None or gdf.empty:
            layer_info[name] = {"status": "empty", "count": 0, "has_width": False}
        else:
            has_width = "WIDTH" in gdf.columns
            width_values = []
            if has_width:
                width_values = gdf["WIDTH"].dropna().tolist()

            layer_info[name] = {
                "status": "loaded",
                "count": len(gdf),
                "has_width": has_width,
                "width_range": (min(width_values), max(width_values)) if width_values else None,
                "width_values": width_values[:20]  # First 20 values
            }

    # Perform expanding ring search with diagnostics
    priority = ["cycling", "shared", "footpath"]
    search_diagnostics = []
    found_width = None
    found_layer = None
    found_radius = None

    for radius in np.arange(start_radius, max_radius + step, step):
        buf = pt.buffer(radius)

        for layer_name in priority:
            gdf = layers[layer_name]
            if gdf is None or gdf.empty:
                continue

            # Query spatial index
            try:
                idx = list(gdf.sindex.query(buf, predicate="intersects"))
            except:
                idx = []

            candidates_at_radius = len(idx)

            if idx and found_width is None:
                candidates = gdf.iloc[idx].copy()

                # Check for WIDTH values
                if "WIDTH" in candidates.columns:
                    candidates["_WIDTH_NUM"] = candidates["WIDTH"]
                    valid = candidates[candidates["_WIDTH_NUM"].notna()]

                    if not valid.empty:
                        # Calculate distances
                        dists = valid.geometry.distance(pt)
                        nearest_idx = dists.idxmin()
                        nearest_dist = dists.min()
                        found_width = float(valid.loc[nearest_idx, "_WIDTH_NUM"])
                        found_layer = layer_name
                        found_radius = radius

                        search_diagnostics.append({
                            "radius": radius,
                            "layer": layer_name,
                            "candidates": candidates_at_radius,
                            "valid_widths": len(valid),
                            "width_found": found_width,
                            "distance": nearest_dist,
                            "locked": True
                        })
                    else:
                        search_diagnostics.append({
                            "radius": radius,
                            "layer": layer_name,
                            "candidates": candidates_at_radius,
                            "valid_widths": 0,
                            "width_found": None,
                            "distance": None,
                            "locked": False
                        })
                else:
                    search_diagnostics.append({
                        "radius": radius,
                        "layer": layer_name,
                        "candidates": candidates_at_radius,
                        "valid_widths": 0,
                        "width_found": None,
                        "distance": None,
                        "locked": False,
                        "note": "No WIDTH column"
                    })
            elif idx:
                # Already locked, but show we found candidates
                search_diagnostics.append({
                    "radius": radius,
                    "layer": layer_name,
                    "candidates": candidates_at_radius,
                    "valid_widths": "?",
                    "width_found": found_width,
                    "distance": None,
                    "locked": "already_locked"
                })

    return {
        "point_wgs84": (point.x, point.y),
        "point_metric": (pt.x, pt.y),
        "layer_info": layer_info,
        "search_diagnostics": search_diagnostics,
        "final_width": found_width,
        "final_layer": found_layer,
        "final_radius": found_radius,
        "layers": layers,
        "priority": priority
    }
```

## Callers (1)
- [[fn-backend-visualize-facility-width-py--visualize-width-analysis|visualize_width_analysis]]

## Callees (1)
- [[fn-backend-app-utils-path-width-curvature-py--load-layer|load_layer]]

## External / unresolved calls (21)
- `append` ×4
- `len` ×3
- `min` ×2
- `Path`
- `default`
- `str`
- `GIS`
- `to_metric_point`
- `items`
- `tolist`
- `dropna`
- `max`
- `arange`
- `buffer`
- `list`
- `query`
- `copy`
- `notna`
- `distance`
- `idxmin`
- `float`
