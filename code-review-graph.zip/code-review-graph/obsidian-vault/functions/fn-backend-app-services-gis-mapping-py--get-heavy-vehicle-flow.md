---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/gis_mapping.py::GIS.get_heavy_vehicle_flow", "get_heavy_vehicle_flow"]
tags: [function, python]
file: "backend/app/services/gis_mapping.py"
lines: "532-602"
---

# get_heavy_vehicle_flow

**Kind:** Function
**File:** [[file-backend-app-services-gis-mapping-py|gis_mapping.py]]  `backend/app/services/gis_mapping.py`
**Lines:** 532-602
**Community:** [[com-services-width|services-width]]
**Signature:** `def get_heavy_vehicle_flow((self, point, buffer_dist=15, max_dist=15, default_value=1))`

## Description

> Get the heavy vehicle flow category for a point by checking proximity to bus lanes.
>
> Heavy Vehicle Flow indicates the level of heavy vehicle traffic (buses, trucks) on the road
> adjacent to the cycling facility. Locations near bus lanes are assumed to have higher heavy
> vehicle flow due to bus traffic.
>
> Args:
>     point: Shapely Point or (lon, lat) tuple in WGS84 or metric CRS
>     buffer_dist: Buffer distance in meters for initial spatial query (default: 15m)
>     max_dist: Maximum distance in meters to check for bus lanes (default: 15m)
>     default_value: Default category value (1 = Low) to return if no bus lane found
>
> Returns:
>     int: Heavy vehicle flow category
>          1 = 'Low' (default - no bus lane within 15m)
>          2 = 'Moderate to high' (bus lane within 15m)
>
> Implementation follows the specification:
> 1. Extract first coordinate from LineString geometry (or use provided point)
> 2. Create 15m buffer for spatial search
> 3. Query candidate bus lanes within buffer using spatial index
> 4. Calculate distance from point to each candidate bus lane
> 5. Find minimum distance to any bus lane
> 6. If minimum distance <= 15m, return 2 (Moderate to high)
> 7. Otherwise, return 1 (Low)

## Source

```python
    def get_heavy_vehicle_flow(self, point, buffer_dist=15, max_dist=15, default_value=1):
        """
        Get the heavy vehicle flow category for a point by checking proximity to bus lanes.

        Heavy Vehicle Flow indicates the level of heavy vehicle traffic (buses, trucks) on the road
        adjacent to the cycling facility. Locations near bus lanes are assumed to have higher heavy
        vehicle flow due to bus traffic.

        Args:
            point: Shapely Point or (lon, lat) tuple in WGS84 or metric CRS
            buffer_dist: Buffer distance in meters for initial spatial query (default: 15m)
            max_dist: Maximum distance in meters to check for bus lanes (default: 15m)
            default_value: Default category value (1 = Low) to return if no bus lane found

        Returns:
            int: Heavy vehicle flow category
                 1 = 'Low' (default - no bus lane within 15m)
                 2 = 'Moderate to high' (bus lane within 15m)

        Implementation follows the specification:
        1. Extract first coordinate from LineString geometry (or use provided point)
        2. Create 15m buffer for spatial search
        3. Query candidate bus lanes within buffer using spatial index
        4. Calculate distance from point to each candidate bus lane
        5. Find minimum distance to any bus lane
        6. If minimum distance <= 15m, return 2 (Moderate to high)
        7. Otherwise, return 1 (Low)
        """
        # Convert point to metric CRS (EPSG:3414)
        pt = self.store.to_metric_point(point)

        # Check if bus_lane shapefile is available
        try:
            bus_lane_gdf = self.store.get("bus_lane")
        except KeyError:
            print("Warning: bus_lane shapefile not registered")
            return default_value

        if bus_lane_gdf is None or bus_lane_gdf.empty:
            return default_value

        # Ensure bus lane data is in metric CRS (should already be from LayerStore.get)
        if bus_lane_gdf.crs.to_epsg() != 3414:
            bus_lane_gdf = bus_lane_gdf.to_crs("EPSG:3414")

        # Filter to only valid geometries
        bus_lane_gdf = bus_lane_gdf[bus_lane_gdf.geometry.notna()].copy()

        # Create buffer for spatial query
        buffer_geom = pt.buffer(buffer_dist)

        # Use spatial index to find candidate bus lanes
        candidate_indices = list(bus_lane_gdf.sindex.intersection(buffer_geom.bounds))

        if not candidate_indices:
            return default_value

        # Get candidate bus lanes
        candidates = bus_lane_gdf.iloc[candidate_indices].copy()

        # Calculate distances to point
        candidates['dist_to_pt'] = candidates.geometry.distance(pt)

        # Find the minimum distance to any bus lane
        min_distance = candidates['dist_to_pt'].min()

        # If minimum distance is within threshold, return "Moderate to high" (2)
        if min_distance <= max_dist:
            return 2  # Moderate to high
        else:
            return default_value  # Low (1)
```

## Callees (2)
- [[fn-backend-app-services-gis-mapping-py--to-metric-point|to_metric_point]]
- [[fn-backend-app-services-gis-mapping-py--get|get]]

## External / unresolved calls (10)
- `copy` ×2
- `print`
- `to_epsg`
- `to_crs`
- `notna`
- `buffer`
- `list`
- `intersection`
- `distance`
- `min`
