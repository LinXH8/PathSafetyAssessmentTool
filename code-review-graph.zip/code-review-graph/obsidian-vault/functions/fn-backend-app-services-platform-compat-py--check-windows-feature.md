---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/platform_compat.py::check_windows_feature", "check_windows_feature"]
tags: [function, python]
file: "backend/app/services/platform_compat.py"
lines: "31-51"
---

# check_windows_feature

**Kind:** Function
**File:** [[file-backend-app-services-platform-compat-py|platform_compat.py]]  `backend/app/services/platform_compat.py`
**Lines:** 31-51
**Community:** [[com-services-check|services-check]]
**Signature:** `def check_windows_feature((feature_name: str))`

## Description

> Check if Windows-specific features are available.
>
> Args:
>     feature_name: Name of the feature to check (for error messages)
>
> Raises:
>     RuntimeError: If the feature is not available on this platform

## Source

```python
def check_windows_feature(feature_name: str):
    """
    Check if Windows-specific features are available.

    Args:
        feature_name: Name of the feature to check (for error messages)

    Raises:
        RuntimeError: If the feature is not available on this platform
    """
    if not IS_WINDOWS:
        raise RuntimeError(
            f"{feature_name} requires Windows. "
            f"Current platform: {platform.system()}"
        )

    if not WINDOWS_MODULES_AVAILABLE:
        raise RuntimeError(
            f"{feature_name} requires pywin32 package. "
            f"Please install it with: pip install pywin32"
        )
```

## Callers (4)
- [[fn-backend-app-services-cyclerap-interface-py--calculate-cyclerap-score|calculate_cycleRAP_score]]
- [[fn-backend-app-services-cyclerap-interface-py--evaluate-treatment-suggestions|evaluate_treatment_suggestions]]
- [[fn-backend-app-services-platform-compat-py--get-excel-client|get_excel_client]]
- [[fn-backend-app-services-platform-compat-py--get-pythoncom|get_pythoncom]]

## External / unresolved calls (2)
- `RuntimeError` ×2
- `system`
