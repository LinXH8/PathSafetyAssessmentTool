---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/cycleRAP_VA.py::extract_images_distance", "extract_images_distance"]
tags: [function, python]
file: "backend/app/services/cycleRAP_VA.py"
lines: "213-301"
---

# extract_images_distance

**Kind:** Function
**File:** [[file-backend-app-services-cyclerap-va-py|cycleRAP_VA.py]]  `backend/app/services/cycleRAP_VA.py`
**Lines:** 213-301
**Community:** [[com-services-distance|services-distance]]
**Signature:** `def extract_images_distance((video_filename, telemetry_dataframe, distance_to_capture, directory_name = None, directory_path = None, enable_print = False))`

## Source

```python
def extract_images_distance(video_filename, telemetry_dataframe, distance_to_capture, directory_name = None, directory_path = None, enable_print = False):
    telemetry_dataframe = telemetry_dataframe.reset_index(drop=True)

    # Open the video file
    video_name = Path(video_filename).stem
    video = cv2.VideoCapture(video_filename)
    # Check if video was successfully opened
    if not video.isOpened():
        assert False, "Video cannot be loaded"
        print(f"Error: Could not open video file {video_filename}")
    elif enable_print: print(f"Video {video_filename} successfully loaded.")
    
    # Create folder to extract data (Will override existing directory)
    if directory_name is None: directory_name = video_name
    output_dir = prepare_directory(directory_name, directory_path)

    lat_df = telemetry_dataframe['geometry'].apply(lambda point: point.y)
    lon_df = telemetry_dataframe['geometry'].apply(lambda point: point.x)

    # Initialize variables
    last_lat = lat_df.iloc[0]
    last_lon = lon_df.iloc[0]
    accumulated_distance = 0
    image_index = 1
    frame_number = 1
    frame_rate = video.get(cv2.CAP_PROP_FPS)
    
    # Creating new list to hold corresponding telemetry data to captured images
    new_csv_data = []

    # print("SAVING FIRST FRAME")

    # Save first frame
    success, image_index = save_frame(video, frame_number, image_index, output_dir)
    if success: new_csv_data.append(telemetry_dataframe.iloc[0])
    else:
        if enable_print: print(f'Fail to save first frame, exiting...')
        return 0
    
    # print("FINISHED SAVING FIRST FRAME")
    # print("START ITERATION")

    # Iterate through telemetry data
    for index, row in telemetry_dataframe.iloc[1:].iterrows():
        # if row['GPS (2D) [m/s]'] < 0.1: continue # This line is to speed up the process by skipping entries where the cyclist isn't moving but can be removed for better accuracy
        # print(f"== ITERATION {index} ==")
        current_lon = lon_df.iloc[index]
        current_lat = lat_df.iloc[index]
        elapsed_time_in_seconds = row['ELAPSED_TIME']
        # print(f"Elapsed time in seconds: {elapsed_time_in_seconds}")
    
        # print("Begin distance calculation")
        # Calculate distance traveled since the last point
        distance = calculate_distance(last_lat, last_lon, current_lat, current_lon)
        # print(f"End distance calculation: {distance}")

        # print("Begin accumulated distance calc")
        # Acculumative distance traveled
        accumulated_distance += distance
        if accumulated_distance < distance_to_capture: 
            last_lat, last_lon = current_lat, current_lon
            continue
        # print(f"End accumulated distance calc: {accumulated_distance}")
        
        # Calculate the corresponding frame number
        frame_number = round(elapsed_time_in_seconds * frame_rate) # Concern: may have very very small desync between video and CSV file due to rounding

        success, image_index = save_frame(video, frame_number, image_index, output_dir)
        # print(f"SUCCESS IS {success}")
        if success: new_csv_data.append(row)
        else: 
            if enable_print: 
                print(f'Fail to append new row, exiting...')
            break
        
        # Reset the accumulated distance and set last location
        accumulated_distance -= distance_to_capture
        last_lat, last_lon = current_lat, current_lon
    # print("FINISH ITERATION")
    # Release the video
    video.release()
    
    # Creating the new CSV file
    new_csv_filename = os.path.join(directory_path, 'image_data.csv') # TODO change the string literal to a constant val
    new_csv_df = pd.DataFrame(new_csv_data)
    new_csv_df.to_csv(new_csv_filename, index = False)
    if enable_print: print(f'Image extraction complete, new CSV saved: \\{new_csv_filename}')

    return new_csv_df
```

## Callees (3)
- [[fn-backend-app-services-cyclerap-va-py--prepare-directory|prepare_directory]]
- [[fn-backend-app-services-cyclerap-va-py--save-frame|save_frame]]
- [[fn-backend-app-services-cyclerap-va-py--calculate-distance|calculate_distance]]

## External / unresolved calls (14)
- `print` ×5
- `apply` ×2
- `append` ×2
- `reset_index`
- `Path`
- `VideoCapture`
- `isOpened`
- `get`
- `iterrows`
- `round`
- `release`
- `join`
- `DataFrame`
- `to_csv`
