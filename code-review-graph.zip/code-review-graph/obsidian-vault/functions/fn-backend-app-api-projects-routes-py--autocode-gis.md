---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/projects/routes.py::autocode_gis", "autocode_gis"]
tags: [function, python]
file: "backend/app/api/projects/routes.py"
lines: "2585-2680"
---

# autocode_gis

**Kind:** Function
**File:** [[file-backend-app-api-projects-routes-py|routes.py]]  `backend/app/api/projects/routes.py`
**Lines:** 2585-2680
**Community:** [[com-projects-treatments|projects-treatments]]
**Signature:** `def autocode_gis((project_name: str))`

## Source

```python
def autocode_gis(project_name: str):
    try:
        payload = request.get_json(force=True, silent=True) or {}
        coords = payload.get("coords")  # [[lon, lat], ...]

        if not coords or not isinstance(coords, list) or not isinstance(coords[0], list):
            return fail("coords (LineString) is required", 400)

        # Segment starting point (WGS84) - first coordinate of the segment
        start_lon, start_lat = coords[0]
        from shapely.geometry import Point
        pt = Point(start_lon, start_lat)

        _gis = _get_gis()

        updates: dict[str, int | float] = {}

        # Rules
        if _gis.is_mrt(pt):
            updates["Peak pedestrian flow along or across facility"] = 3
        if _gis.is_bus_lane(pt):
            updates["Heavy vehicle flow"] = 2
        if _gis.is_parking(pt):
            updates["Adjacent Vehicle Parking 0-1m"] = 1
        if _gis.is_bus_stop(pt):
            # overrides 3 → 2
            updates["Peak pedestrian flow along or across facility"] = 2

        # Pedestrian Crossing Detection
        # Set to Present (1) if within 5m of bus stop OR road crossing
        if _gis.is_bus_stop(pt, dist=5) or _gis.is_road_crossing(pt, dist=5):
            updates["Pedestrian Crossing"] = 1  # 1 = Present

        area = _gis.get_area_type(pt)
        updates["Area type"] = int(area)

        updates["Road AADT"] = 6000

        res = _gis.get_peak_pedestrian_flow(pt, dist=10)
        bpks = (res or {}).get("before_peaks")
        spks = (res or {}).get("sensor_peaks")

        def apply_peak(peaks):
            if not peaks:
                return
            if int(peaks.get("MICROMOBILITY", 0)) > 50:
                updates["Peak bicycle/LV traffic flow"] = 2
            if int(peaks.get("OTHER", 0)) > 50:
                updates["Peak pedestrian flow along or across facility"] = 3

        if spks:
            apply_peak(spks)
        elif bpks:
            apply_peak(bpks)

        # Added for Road Operating Speed (mean)
        # Calculate road operating speed based on nearest road link
        road_speed = _gis.get_road_operating_speed(pt, buffer_dist=20, max_dist=30, default_speed=30.0)
        updates["Road operating speed (mean)"] = road_speed

        # Added for Road Speed Limit
        # Calculate road speed limit based on nearest speed limit segment
        speed_limit = _gis.get_road_speed_limit(pt, buffer_dist=20, max_dist=30, default_limit=10)
        updates["Road speed limit"] = speed_limit

        # Added for Heavy Vehicle Flow
        # Calculate heavy vehicle flow based on proximity to bus lanes
        heavy_vehicle_flow = _gis.get_heavy_vehicle_flow(pt, buffer_dist=15, max_dist=15, default_value=1)
        updates["Heavy vehicle flow"] = heavy_vehicle_flow

        # Added for Curvature
        # Calculate curvature using actual path centerline shapefiles
        # Uses two-stage process from original PathAssignmentTool:
        #   Stage 1: Expanding ring (1m→5m) to find nearest path
        #   Stage 2: Fixed 5m window to calculate curvature from that path
        curvature, curvature_subcat = _gis.get_curvature(pt, sharp_turn_threshold=10.0, default_value=2)
        updates["Curvature"] = curvature
        if curvature_subcat is not None:
            updates["Curvature Sub-category"] = curvature_subcat

        # Added for Facility Width per Direction
        # Calculate facility width using expanding ring search on path centerline shapefiles
        facility_width, width_subcat = _gis.get_facility_width(pt, start_radius=2.0, max_radius=10.0, step_size=2.0, default_value=2)
        updates["Facility Width per Direction"] = facility_width
        if width_subcat is not None:
            updates["Facility Width Sub-category"] = width_subcat

        # Return both updates and changed_fields for change tracking/highlighting in UI
        # changed_fields: list of field names that were updated by GIS rules
        return ok({"updates": updates, "changed_fields": list(updates.keys())})

    except ServiceUnavailable as e:
        return fail(str(e), 503)
    except Exception as e:
        traceback.print_exc()
        return fail(f"autocode_gis error: {e}", 500)
```

## Callers (1)
- [[fn-backend-app-api-projects-routes-py--call-autocode-pair|_call_autocode_pair]]

## Callees (4)
- [[fn-backend-app-api-projects-routes-py--fail|fail]]
- [[fn-backend-app-api-projects-routes-py--get-gis|_get_gis]]
- [[fn-backend-app-api-projects-routes-py--apply-peak|apply_peak]]
- [[fn-backend-app-api-projects-routes-py--ok|ok]]

## External / unresolved calls (21)
- `get` ×3
- `is_bus_stop` ×2
- `get_json`
- `isinstance`
- `Point`
- `is_mrt`
- `is_bus_lane`
- `is_parking`
- `is_road_crossing`
- `get_area_type`
- `int`
- `get_peak_pedestrian_flow`
- `get_road_operating_speed`
- `get_road_speed_limit`
- `get_heavy_vehicle_flow`
- `get_curvature`
- `get_facility_width`
- `list`
- `keys`
- `str`
- `print_exc`
