---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/Projects/projects.tsx::prev", "prev"]
tags: [function, tsx]
file: "frontend/src/pages/Projects/projects.tsx"
lines: "285-290"
---

# prev

**Kind:** Function
**File:** [[file-frontend-src-pages-projects-projects-tsx|projects.tsx]]  `frontend/src/pages/Projects/projects.tsx`
**Lines:** 285-290
**Community:** [[com-projects-tag|projects-tag]]
**Signature:** `def prev()`

## Source

```tsx
      setSelected(prev => {
        const newSet = new Set(prev);
        newSet.delete(oldName);
        newSet.add(newName);
        return newSet;
      });
```

## External / unresolved calls (3)
- `delete` ×2
- `add` ×2
- `has`
