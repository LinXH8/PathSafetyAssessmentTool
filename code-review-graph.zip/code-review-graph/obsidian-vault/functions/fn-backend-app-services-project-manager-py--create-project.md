---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/project_manager.py::project_manager.create_project", "create_project"]
tags: [function, python]
file: "backend/app/services/project_manager.py"
lines: "811-862"
---

# create_project

**Kind:** Function
**File:** [[file-backend-app-services-project-manager-py|project_manager.py]]  `backend/app/services/project_manager.py`
**Lines:** 811-862
**Community:** [[com-services-project|services-project]]
**Signature:** `def create_project((self, project_title, geo_data : gpd.geodataframe, dataset_name, tags=None))`

## Source

```python
    def create_project(self, project_title, geo_data : gpd.geodataframe, dataset_name, tags=None):
        proj_root = self.des_path / project_title

        prefix = str(project_title) + "_"
        rename_files_with_prefix(proj_root / global_var.PROJECT_IMAGES_FOLDER, prefix)

        # Get image reference
        image_ref = load_images_from_folder_cv(proj_root / global_var.PROJECT_IMAGES_FOLDER)
        size = len(image_ref)

        # Craft project metadata
        now_dt = datetime.datetime.now()
        project_metadata = serializer.ProjectMetadata()
        project_metadata.project_name   = project_title
        project_metadata.date_created   = now_dt
        project_metadata.last_updated   = now_dt
        project_metadata.created_by     = "default"
        project_metadata.dataset        = dataset_name
        project_metadata.progress       = []
        project_metadata.size           = size
        project_metadata.tags           = tags if tags is not None else []

        # Craft geo data csv
        geo_tbl = serializer.ProjectGeoData(size)
        geo_tbl.loc[:, serializer.ProjectGeoData.Fields.IMAGE_REFERENCE_STR] = image_ref[:size]
        geo_tbl.populate_linestring(geo_data)

        # Craft version 1 snapshot metadata
        snapshot_dataframe = serializer.SnapshotMetadata(size)


        # Craft default attributes 
        attribute_dataframe = serializer.Attributes(size, self.cyclerap_interface.attribute_default_values)
        
        # Create project
        new_project = Project(proj_root)
        new_project.create_new_version()

        # Initialise project var
        new_project.geo_data = geo_tbl
        new_project.metadata = project_metadata
        new_project.latest().attributes = attribute_dataframe
        new_project.latest().snapshot_metadata = snapshot_dataframe
        # Treatment and Results should remain empty
        new_project.latest().results = serializer.Results()
        new_project.latest().treatment = serializer.Treatment()

        # Write project to file
        new_project.save_all()
        new_project.metadata.serialize(new_project.project_path)

        self.projects.append(new_project)
```

## Callees (6)
- [[fn-backend-app-services-project-manager-py--rename-files-with-prefix|rename_files_with_prefix]]
- [[fn-backend-app-services-project-manager-py--load-images-from-folder-cv|load_images_from_folder_cv]]
- [[cls-backend-app-services-project-manager-py--project|Project]]
- [[fn-backend-app-services-project-manager-py--create-new-version|create_new_version]]
- [[fn-backend-app-services-project-manager-py--latest|latest]]
- [[fn-backend-app-services-project-manager-py--save-all|save_all]]

## External / unresolved calls (12)
- `str`
- `len`
- `now`
- `ProjectMetadata`
- `ProjectGeoData`
- `populate_linestring`
- `SnapshotMetadata`
- `Attributes`
- `Results`
- `Treatment`
- `serialize`
- `append`
