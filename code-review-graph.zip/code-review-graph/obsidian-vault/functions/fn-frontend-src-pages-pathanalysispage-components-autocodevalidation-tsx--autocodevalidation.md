---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/AutocodeValidation.tsx::AutocodeValidation", "AutocodeValidation"]
tags: [function, tsx]
file: "frontend/src/pages/PathAnalysisPage/components/AutocodeValidation.tsx"
lines: "157-450"
---

# AutocodeValidation

**Kind:** Function
**File:** [[file-frontend-src-pages-pathanalysispage-components-autocodevalidation-tsx|AutocodeValidation.tsx]]  `frontend/src/pages/PathAnalysisPage/components/AutocodeValidation.tsx`
**Lines:** 157-450
**Community:** [[com-components-algrade|components-algrade]]
**Signature:** `def AutocodeValidation(({
  projectName,
  attributes,
}: Props))`

## Source

```tsx
export default function AutocodeValidation({
  projectName,
  attributes,
}: Props) {
  const [validationStats, setValidationStats] = useState<Record<string, ValidationStats[]>>({});
  const [baselineRows, setBaselineRows] = useState<AttributeRow[]>([]);
  const [isExpanded, setIsExpanded] = useState(false);
  const [activeTab, setActiveTab] = useState<(typeof GROUP_ORDER)[number]>("Facility configuration");

  // Normalize attribute values to consistent types (convert numeric strings to numbers)
  const normalizeAttributeValues = (attrs: AttributeRow[]): AttributeRow[] => {
    return attrs.map(row => {
      const normalized: AttributeRow = {};
      for (const [key, value] of Object.entries(row)) {
        if (value === null || value === undefined) {
          normalized[key] = value;
        } else if (typeof value === 'string' && /^\d+(\.\d+)?$/.test(value)) {
          // Convert numeric strings to numbers
          normalized[key] = Number(value);
        } else {
          normalized[key] = value;
        }
      }
      return normalized;
    });
  };

  // Helper function to fetch baseline (extracted so it can be called from multiple places)
  const fetchBaseline = useCallback(async () => {
    if (!projectName) {
      setBaselineRows([]);
      return;
    }

    try {
      const response = await fetch(`/api/projects/${encodeURIComponent(projectName)}/baseline`);
      if (!response.ok) {
        setBaselineRows([]);
        return;
      }
      const data = await response.json();
      const rows = data.rows || [];
      setBaselineRows(rows);

      // If no baseline exists, create it from current attributes (version 0)
      if (rows.length === 0 && attributes && attributes.length > 0) {
        try {
          const normalized = normalizeAttributeValues(attributes);
          await fetch(`/api/projects/${encodeURIComponent(projectName)}/baseline`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ rows: normalized })
          });
          setBaselineRows(normalized);
        } catch {
        }
      }
    } catch {
      setBaselineRows([]);
    }
  }, [projectName, attributes]);

  // Fetch and cache baseline from server on project load (separate from stats calculation)
  useEffect(() => {
    if (!projectName) {
      setBaselineRows([]);
      return;
    }

    let cancelled = false;

    fetchBaseline().then(() => {
      if (!cancelled) {
        // Baseline fetched successfully
      }
    });

    return () => { cancelled = true; };
  }, [projectName, attributes.length, fetchBaseline]); // Re-fetch if project changes or attributes length changes

  // Calculate validation statistics (uses cached baseline)
  useEffect(() => {
    if (!attributes || attributes.length === 0) {
      setValidationStats({});
      return;
    }

    const newStats: Record<string, ValidationStats[]> = {};

    // Use cached baseline, or attributes if no baseline exists
    const valuesToCompare = baselineRows.length > 0 ? baselineRows : attributes;

    // Calculate stats for each attribute group
    for (const group of GROUP_ORDER) {
      const fieldList = GROUP_RULES[group];
      if (!fieldList) continue;

      const groupStats: ValidationStats[] = [];

      for (const displayName of fieldList) {
        const realKey = KEY_ALIASES[displayName] ?? displayName;

        // Count unchanged vs changed values
        let unchangedCount = 0;
        let changedCount = 0;

        for (let i = 0; i < attributes.length; i++) {
          const currentValue = attributes[i]?.[realKey];
          const originalValue = valuesToCompare[i]?.[realKey];

          // Determine if value has changed from original
          let isChanged = true;

          // Handle null/undefined as equivalent
          if ((currentValue === null || currentValue === undefined) &&
            (originalValue === null || originalValue === undefined)) {
            isChanged = false;
          }
          // Strict comparison first (same type, same value)
          else if (currentValue === originalValue) {
            isChanged = false;
          }
          // Type-aware comparison for numeric values
          else if (typeof currentValue === 'number' && typeof originalValue === 'string') {
            const parsedOriginal = Number(originalValue);
            if (!Number.isNaN(parsedOriginal) && currentValue === parsedOriginal) {
              isChanged = false;
            }
          }
          else if (typeof currentValue === 'string' && typeof originalValue === 'number') {
            const parsedCurrent = Number(currentValue);
            if (!Number.isNaN(parsedCurrent) && parsedCurrent === originalValue) {
              isChanged = false;
            }
          }

          if (isChanged) {
            changedCount++;
          } else {
            unchangedCount++;
          }
        }

        const totalCount = attributes.length;
        const correctnessPercentage = totalCount > 0 ? (unchangedCount / totalCount) * 100 : 0;

        groupStats.push({
          displayName,
          realKey,
          totalCount,
          unchangedCount,
          changedCount,
          correctnessPercentage,
        });
      }

      newStats[group] = groupStats;
    }

    setValidationStats(newStats);
  }, [attributes, baselineRows]); // Recalculate whenever attributes OR baseline changes

  // Listen for baseline updates from autocode operations
  useEffect(() => {
    const handleBaselineUpdate = () => {
      // Refetch baseline when it's updated by autocode
      fetchBaseline();
    };

    window.addEventListener("psat:baseline:updated", handleBaselineUpdate);

    return () => {
      window.removeEventListener("psat:baseline:updated", handleBaselineUpdate);
    };
  }, [fetchBaseline]);

  const groupsWithFields = useMemo(() => {
    return GROUP_ORDER.filter(g => (validationStats[g] ?? []).length > 0);
  }, [validationStats]);

  // Set activeTab to first group when it changes
  useEffect(() => {
    if (groupsWithFields.length > 0 && !groupsWithFields.includes(activeTab)) {
      setActiveTab(groupsWithFields[0]);
    }
  }, [groupsWithFields, activeTab]);

  if (!attributes || attributes.length === 0) {
    return (
      <div className="autocode-validation-panel">
        <div className="autocode-panel-header" onClick={() => setIsExpanded(!isExpanded)} style={{ cursor: 'pointer' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h3 style={{ margin: 0, fontSize: '16px', fontWeight: 'bold' }}>
              Autocode Validation {isExpanded ? '▼' : '▶'}
            </h3>
          </div>
        </div>
        {isExpanded && (
          <div className="autocode-panel-content">
            <p style={{ color: '#999', textAlign: 'center', padding: '1rem' }}>No data available.</p>
          </div>
        )}
      </div>
    );
  }

  const currentStats = validationStats[activeTab] ?? [];

  return (
    <div className="autocode-validation-panel">
      {/* Header */}
      <div className="autocode-panel-header" onClick={() => setIsExpanded(!isExpanded)} style={{ cursor: 'pointer', userSelect: 'none' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h3 style={{ margin: 0, fontSize: '16px', fontWeight: 'bold' }}>
            Autocode Validation {isExpanded ? '▼' : '▶'}
          </h3>
        </div>
      </div>

      {/* Content */}
      {isExpanded && (
        <div className="autocode-panel-content">
          {/* Tab Buttons */}
          <div className="autocode-tabs">
            {groupsWithFields.map((group) => (
              <button
                key={group}
                className={`autocode-tab-button ${activeTab === group ? 'active' : ''}`}
                onClick={() => setActiveTab(group)}
              >
                {group}
              </button>
            ))}
          </div>

          {/* Tab Content */}
          <div className="autocode-tab-content">
            <div className="autocode-grid">
              {currentStats.map((stat) => {
                const statusClass =
                  stat.correctnessPercentage >= 80
                    ? 'excellent'
                    : stat.correctnessPercentage >= 45
                      ? 'good'
                      : 'needs-review';

                return (
                  <div key={stat.realKey} className="autocode-card">
                    <div className="autocode-card-title">{stat.displayName}</div>

# … (truncated, 44 more lines — see source file)
```

## Callers (1)
- [[fn-frontend-src-pages-codingpage-codingpage-tsx--codingpage|CodingPage]]

## Callees (2)
- [[fn-frontend-src-pages-pathanalysispage-components-autocodevalidation-tsx--normalizeattributevalues|normalizeAttributeValues]]
- [[fn-frontend-src-pages-pathanalysispage-components-autocodevalidation-tsx--getalgrade|getALGrade]]

## External / unresolved calls (22)
- `setBaselineRows` ×6
- `useState` ×4
- `useEffect` ×4
- `map` ×3
- `fetch` ×2
- `encodeURIComponent` ×2
- `setValidationStats` ×2
- `Number` ×2
- `isNaN` ×2
- `setActiveTab` ×2
- `setIsExpanded` ×2
- `useCallback`
- `json`
- `stringify`
- `then`
- `fetchBaseline`
- `push`
- `addEventListener`
- `removeEventListener`
- `useMemo`
- `filter`
- `includes`
