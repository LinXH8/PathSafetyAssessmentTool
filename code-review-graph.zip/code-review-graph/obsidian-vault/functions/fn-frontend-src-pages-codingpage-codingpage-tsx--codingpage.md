---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/CodingPage/codingPage.tsx::CodingPage", "CodingPage"]
tags: [function, tsx]
file: "frontend/src/pages/CodingPage/codingPage.tsx"
lines: "89-1810"
---

# CodingPage

**Kind:** Function
**File:** [[file-frontend-src-pages-codingpage-codingpage-tsx|codingPage.tsx]]  `frontend/src/pages/CodingPage/codingPage.tsx`
**Lines:** 89-1810
**Community:** [[com-codingpage-handle|codingpage-handle]]
**Signature:** `def CodingPage(())`

## Source

```tsx
export default function CodingPage() {
  const { projectNames } = useParams<{ projectNames: string }>();

  // Parse multiple project names from URL
  const projectList = useMemo(() => {
    if (!projectNames) return [];
    try {
      return projectNames.split(',').map(name => {
        try {
          return decodeURIComponent(name);
        } catch {
          return name;
        }
      });
    } catch {
      return [];
    }
  }, [projectNames]);

  // Current active tab (project name or "coding-guide")
  const [activeTab, setActiveTab] = useState<string>(() => {
    if (projectNames) {
      try {
        const names = projectNames.split(',').map(name => {
          try {
            return decodeURIComponent(name);
          } catch {
            return name;
          }
        });
        return names[0] ?? "coding-guide";
      } catch {
        return "coding-guide";
      }
    }
    return "coding-guide";
  });
  const currentProjectName = activeTab === "coding-guide" ? null : activeTab;
  const isShowingCodingGuide = activeTab === "coding-guide";

  // State for each project: keyed by project name
  const [projectData, setProjectData] = useState<Record<string, ProjectDataState>>(projectDataCache);

  // Global state
  const [autoCoding, setAutoCoding] = useState(false);
  const [autoCodeMsg, setAutoCodeMsg] = useState<string>("");
  const [progress, setProgress] = useState<number>(0);
  const [projectProgress, setProjectProgress] = useState<Record<string, { processed: number; total: number }>>({});
  const [attrMappings, setAttrMappings] = useState<AttrMappings>({});

  // Image preloading state
  const [imagesLoaded, setImagesLoaded] = useState(false);
  const [imageLoadingProgress, setImageLoadingProgress] = useState(0);


  // Refs for cleanup
  const cleanupTimeoutRef = useRef<number | null>(null);
  const scoreDebounceRef = useRef<Record<number, number>>({});
  const autoCodingRef = useRef(false);

  // Handle query params for deep linking (e.g. ?segment=5)
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const initialSegment = queryParams.get("segment");
  const hasInitializedSegmentRef = useRef(false);

  // Save confirmation dialog state
  const [isSaveDialogOpen, setIsSaveDialogOpen] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (!initialSegment || !currentProjectName || hasInitializedSegmentRef.current) return;

    const segmentIdx = parseInt(initialSegment, 10);
    if (!isNaN(segmentIdx) && segmentIdx > 0) {
      // We can only set the page if we know the total length, or at least we trust the input.
      // The actual clamping happens in updateProjectData or valid rendering,
      // but here we just blindly set the currentPage if it seems valid.
      // We'll trust the component to clamp it if it's out of bounds once data is loaded.
      updateProjectData(currentProjectName, { currentPage: segmentIdx });
      hasInitializedSegmentRef.current = true;
    }
  }, [initialSegment, currentProjectName]);

  // Get current project data with defaults
  const currentData = useMemo<ProjectDataState>(() => {
    if (!currentProjectName) return defaultProjectData;
    return projectData[currentProjectName] || defaultProjectData;
  }, [projectData, currentProjectName]);

  // Shorthand accessors
  const {
    detail,
    attrs,
    geoFeatures,
    scores,
    currentPage,
    changedFieldsByRow,
    fieldSourcesByRow,
    loading,
    error,
    editedRow,
  } = currentData;

  // Helper to update a specific project's data
  const updateProjectData = (projectName: string, updates: Partial<ProjectDataState>) => {
    setProjectData(prev => {
      const newState = {
        ...prev,
        [projectName]: {
          ...prev[projectName] || defaultProjectData,
          ...updates,
        },
      };
      projectDataCache[projectName] = newState[projectName];
      return newState;
    });
  };

  const refreshCurrentProject = useCallback(async () => {
    if (!currentProjectName) return;

    updateProjectData(currentProjectName, { loading: true, error: null });

    try {
      const [d, a, gjson, metadata, autoMeta] = await Promise.all([
        fetchProjectDetail(currentProjectName),
        fetchProjectAttributes(currentProjectName) as Promise<AttributesResponse>,
        fetchProjectGeoJSON(currentProjectName) as Promise<FeatureCollection>,
        fetchProjectMetadata(currentProjectName).catch(() => null),
        fetch(`/api/projects/${encodeURIComponent(currentProjectName)}/autocode-metadata`).then(r => r.ok ? r.json() : null).catch(() => null),
      ]);

      const attributes = a?.rows ?? [];

      updateProjectData(currentProjectName, {
        detail: d ?? null,
        attrs: attributes,
        geoFeatures: gjson?.features ?? [],
        editedRow: null,
        verified: metadata?.verified ?? false,
        verifiedSegmentCount: metadata?.verified_segment_count ?? 0,
        autocodedSegmentCount: metadata?.autocoded_segment_count ?? 0,
        changedFieldsByRow: autoMeta?.changedFieldsByRow || {},
        fieldSourcesByRow: autoMeta?.fieldSourcesByRow || {},
        loading: false,
        isDirty: false,
      });

    } catch (e: any) {
      updateProjectData(currentProjectName, {
        error: e?.message ?? "Unknown error",
        loading: false,
      });
    }
  }, [currentProjectName]);


  // Update verified segment count for a project
  const updateVerifiedSegmentCount = async (projectName: string | null, count: number) => {
    if (!projectName) return;
    try {
      const totalSegments = projectData[projectName]?.attrs?.length ?? 0;
      // Clamp the count to be between 0 and total segments
      const clampedCount = Math.max(0, Math.min(count, totalSegments));

      await updateProject(projectName, { verified_segment_count: clampedCount });
      updateProjectData(projectName, { verifiedSegmentCount: clampedCount });
      // Notify other pages of the change with segment count
      window.dispatchEvent(new CustomEvent("psat:verified:updated", {
        detail: { projectName, verifiedSegmentCount: clampedCount }
      }));
    } catch (e: any) {
      toaster.create({
        title: "Failed to update",
        description: e?.message ?? "Failed to update verified segment count",
        type: "error",
      });
    }
  };

  // Update autocoded segment count for a project
  const updateAutocodedSegmentCount = async (projectName: string | null, count: number) => {
    if (!projectName) return;
    try {
      const totalSegments = projectData[projectName]?.attrs?.length ?? 0;
      // Clamp the count to be between 0 and total segments
      const clampedCount = Math.max(0, Math.min(count, totalSegments));

      await updateProject(projectName, { autocoded_segment_count: clampedCount });
      updateProjectData(projectName, { autocodedSegmentCount: clampedCount });
      // Notify other pages of the change with segment count
      window.dispatchEvent(new CustomEvent("psat:autocoded:updated", {
        detail: { projectName, autocodedSegmentCount: clampedCount }
      }));
    } catch (e: any) {
      toaster.create({
        title: "Failed to update",
        description: e?.message ?? "Failed to update autocoded segment count",
        type: "error",
      });
    }
  };

  // Helper function to clear auto-coding state
  const clearAutoCodingState = useCallback(() => {
    setAutoCoding(false);
    setAutoCodeMsg("");
    setProgress(0);
    setProjectProgress({});
    if (cleanupTimeoutRef.current !== null) {
      clearTimeout(cleanupTimeoutRef.current);
      cleanupTimeoutRef.current = null;
    }
  }, []);

  // Cleanup timeouts on unmount
  useEffect(() => {
    return () => {
      if (cleanupTimeoutRef.current !== null) {
        clearTimeout(cleanupTimeoutRef.current);
        cleanupTimeoutRef.current = null;
      }
      Object.values(scoreDebounceRef.current).forEach(timeout => {
        if (timeout !== undefined) {
          clearTimeout(timeout);
        }
      });
      scoreDebounceRef.current = {};
    };
  }, []);

  // Keep autoCodingRef in sync with autoCoding state
  useEffect(() => {
    autoCodingRef.current = autoCoding;
  }, [autoCoding]);

  const len = attrs.length;
  const [pageInput, setPageInput] = useState(String(currentPage));
  const [segmentInput, setSegmentInput] = useState(String(currentData.verifiedSegmentCount ?? 0));
  const [autocodedSegmentInput, setAutocodedSegmentInput] = useState(String(currentData.autocodedSegmentCount ?? 0));

  const currentIndex = useMemo(
    () => Math.max(0, Math.min(len - 1, currentPage - 1)),
    [currentPage, len]
  );

  const currentAttr = useMemo<AttributeRow | null>(
    () => (len > 0 ? attrs[currentIndex] : null),
    [attrs, currentIndex]
# … (truncated, 1472 more lines — see source file)
```

## Callers (1)
- [[fn-frontend-src-app-tsx--app|App]]

## Callees (17)
- [[fn-frontend-src-pages-codingpage-codingpage-tsx--updateprojectdata|updateProjectData]]
- [[fn-frontend-src-api-index-ts--fetchprojectdetail|fetchProjectDetail]]
- [[fn-frontend-src-api-index-ts--fetchprojectattributes|fetchProjectAttributes]]
- [[fn-frontend-src-api-index-ts--fetchprojectgeojson|fetchProjectGeoJSON]]
- [[fn-frontend-src-api-index-ts--fetchprojectmetadata|fetchProjectMetadata]]
- [[fn-frontend-src-pages-codingpage-codingpage-tsx--normalizeattributevalues|normalizeAttributeValues]]
- [[fn-frontend-src-api-index-ts--calculatescore|calculateScore]]
- [[fn-frontend-src-api-index-ts--fetchattributemappings|fetchAttributeMappings]]
- [[fn-frontend-src-pages-codingpage-codingpage-tsx--updateverifiedsegmentcount|updateVerifiedSegmentCount]]
- [[fn-frontend-src-pages-codingpage-codingpage-tsx--updateautocodedsegmentcount|updateAutocodedSegmentCount]]
- [[fn-frontend-src-pages-sidebar-components-exitconfirmationdialog-tsx--exitconfirmationdialog|ExitConfirmationDialog]]
- [[fn-frontend-src-components-visualization-scoreband-segmentscorescard-tsx--segmentscorescard|SegmentScoresCard]]
- [[fn-frontend-src-pages-codingpage-components-imagepanel-tsx--imagepanel|ImagePanel]]
- [[fn-frontend-src-pages-codingpage-components-attributespanel-tsx--attributespanel|AttributesPanel]]
- [[fn-frontend-src-components-visualization-analysispanel-tsx--analysispanel|AnalysisPanel]]
- [[fn-frontend-src-pages-codingpage-components-geodatapanel-tsx--geodatapanel|GeoDataPanel]]
- [[fn-frontend-src-pages-pathanalysispage-components-autocodevalidation-tsx--autocodevalidation|AutocodeValidation]]

## External / unresolved calls (77)
- `useEffect` ×21
- `useState` ×15
- `Text` ×14
- `Flex` ×14
- `Box` ×12
- `useCallback` ×11
- `fetch` ×9
- `encodeURIComponent` ×9
- `String` ×8
- `useMemo` ×7
- `map` ×7
- `forEach` ×7
- `Root` ×7
- `Button` ×7
- `addEventListener` ×6
- `removeEventListener` ×6
- `catch` ×5
- `clearTimeout` ×5
- `max` ×5
- `min` ×5
- `GridItem` ×5
- `useRef` ×4
- `json` ×4
- `create` ×4
- `gotoPage` ×4
- `setActiveTab` ×4
- `setIsSaveDialogOpen` ×4
- `all` ×3
- `then` ×3
- `stringify` ×3
- *... and 47 more.*
