---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/api/index.ts::previewTreatments", "previewTreatments"]
tags: [function, typescript]
file: "frontend/src/api/index.ts"
lines: "713-727"
---

# previewTreatments

**Kind:** Function
**File:** [[file-frontend-src-api-index-ts|index.ts]]  `frontend/src/api/index.ts`
**Lines:** 713-727
**Community:** [[com-api-project|api-project]]
**Signature:** `def previewTreatments((
  project: string,
  payload: PreviewTreatmentsPayload
)) -> : Promise<PreviewTreatmentsResult>`

## Description

> Preview treatments for a specific segment without saving
> @param project - Project name
> @param payload - Preview payload
> @returns Preview result with before/after scores

## Source

```typescript
export async function previewTreatments(
  project: string,
  payload: PreviewTreatmentsPayload
): Promise<PreviewTreatmentsResult> {
  const res = await fetch(
    `/api/projects/${encodeURIComponent(project)}/treatments/preview`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    }
  );
  if (!res.ok) throw new Error(await readError(res));
  return res.json();
}
```

## Callers (1)
- [[fn-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx--treatmentdetailpage|TreatmentDetailPage]]

## Callees (1)
- [[fn-frontend-src-api-index-ts--readerror|readError]]

## External / unresolved calls (4)
- `fetch`
- `encodeURIComponent`
- `stringify`
- `json`
