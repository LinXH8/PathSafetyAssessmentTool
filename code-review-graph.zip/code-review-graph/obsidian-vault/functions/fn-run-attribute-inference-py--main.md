---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/run_attribute_inference.py::main", "main"]
tags: [function, python]
file: "run_attribute_inference.py"
lines: "641-643"
---

# main

**Kind:** Function
**File:** [[file-run-attribute-inference-py|run_attribute_inference.py]]  `run_attribute_inference.py`
**Lines:** 641-643
**Community:** [[com-pathsafetyassessmenttool-compute|pathsafetyassessmenttool-compute]]
**Signature:** `def main(())`

## Source

```python
def main():
    args = parse_args()
    process_images(args)
```

## Callees (2)
- [[fn-run-attribute-inference-py--parse-args|parse_args]]
- [[fn-run-attribute-inference-py--process-images|process_images]]
