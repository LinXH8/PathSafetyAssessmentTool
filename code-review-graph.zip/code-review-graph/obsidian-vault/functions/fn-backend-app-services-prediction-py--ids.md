---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/prediction.py::CycleRAP_Coding_Helper._ids", "_ids"]
tags: [function, python]
file: "backend/app/services/prediction.py"
lines: "96-97"
---

# _ids

**Kind:** Function
**File:** [[file-backend-app-services-prediction-py|prediction.py]]  `backend/app/services/prediction.py`
**Lines:** 96-97
**Community:** [[com-services-compute|services-compute]]
**Signature:** `def _ids((*names))`

## Source

```python
        def _ids(*names):
            return {inv[n] for n in names if n in inv}
```

## Callers (1)
- [[fn-backend-app-services-prediction-py--build-class-sets|_build_class_sets]]
