---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/CodingPage/codingPage.tsx::prev", "prev"]
tags: [function, tsx]
file: "frontend/src/pages/CodingPage/codingPage.tsx"
lines: "761-764"
---

# prev

**Kind:** Function
**File:** [[file-frontend-src-pages-codingpage-codingpage-tsx|codingPage.tsx]]  `frontend/src/pages/CodingPage/codingPage.tsx`
**Lines:** 761-764
**Community:** [[com-codingpage-handle|codingpage-handle]]
**Signature:** `def prev()`

## Source

```tsx
                setProjectProgress(prev => ({
                  ...prev,
                  [projectName]: { processed: segmentIdx + 1, total: projectAttrsLength }
                }));
```

## External / unresolved calls (1)
- `map`
