---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/projects/routes.py::autocode_image", "autocode_image"]
tags: [function, python]
file: "backend/app/api/projects/routes.py"
lines: "2541-2581"
---

# autocode_image

**Kind:** Function
**File:** [[file-backend-app-api-projects-routes-py|routes.py]]  `backend/app/api/projects/routes.py`
**Lines:** 2541-2581
**Community:** [[com-projects-treatments|projects-treatments]]
**Signature:** `def autocode_image((project_name: str))`

## Source

```python
def autocode_image(project_name: str):
    print(f"[Autocode] >>> autocode_image called for project='{project_name}'", flush=True)
    try:
        _ensure_models_ready()

        ctx = get_ctx()
        pm = ctx["pm"]
        payload = request.get_json(force=True, silent=True) or {}
        image_ref = payload.get("imageRef")
        if not image_ref:
            return fail("imageRef is required", 400)

        img_path = (pm.des_path / project_name / global_var.PROJECT_IMAGES_FOLDER / image_ref).resolve()
        if not img_path.exists():
            return fail(f"image not found: {img_path.name}", 404)

        print(f"[Autocode] CV inference: {image_ref}", flush=True)
        global _INFERENCE_DEPTH
        _INFERENCE_DEPTH += 1
        try:
            updates = cv_pred.CycleRAP_Coding_Helper.autocode(img_path) or {}
        finally:
            _INFERENCE_DEPTH -= 1
        updates = {k: v for k, v in updates.items() if v is not None}
        print(f"[Autocode] CV done: {image_ref} → {len(updates)} field(s) set", flush=True)

        # Inject Grade from pre-computed LAZ gradient lookup (no-op if not available)
        gradient_pct = _inject_grade(image_ref, updates, project_name=project_name)

        # Return both updates and changed_fields for change tracking/highlighting in UI
        # changed_fields: list of field names that were updated by CV model
        resp: dict = {"updates": updates, "changed_fields": list(updates.keys())}
        if gradient_pct is not None:
            resp["gradient_pct"] = round(gradient_pct, 3)
        return ok(resp)

    except ServiceUnavailable as e:
        return fail(str(e), 503)
    except Exception as e:
        traceback.print_exc()
        return fail(f"autocode_image error: {e}", 500)
```

## Callers (1)
- [[fn-backend-app-api-projects-routes-py--call-autocode-pair|_call_autocode_pair]]

## Callees (5)
- [[fn-backend-app-api-projects-routes-py--ensure-models-ready|_ensure_models_ready]]
- [[fn-backend-app-api-projects-routes-py--get-ctx|get_ctx]]
- [[fn-backend-app-api-projects-routes-py--fail|fail]]
- [[fn-backend-app-api-projects-routes-py--inject-grade|_inject_grade]]
- [[fn-backend-app-api-projects-routes-py--ok|ok]]

## External / unresolved calls (13)
- `print` ×3
- `get_json`
- `get`
- `resolve`
- `exists`
- `autocode`
- `items`
- `len`
- `list`
- `keys`
- `round`
- `str`
- `print_exc`
