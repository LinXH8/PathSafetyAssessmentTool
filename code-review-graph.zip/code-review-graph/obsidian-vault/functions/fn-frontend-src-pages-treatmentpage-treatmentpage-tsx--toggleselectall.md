---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/TreatmentPage/treatmentPage.tsx::toggleSelectAll", "toggleSelectAll"]
tags: [function, tsx]
file: "frontend/src/pages/TreatmentPage/treatmentPage.tsx"
lines: "141-149"
---

# toggleSelectAll

**Kind:** Function
**File:** [[file-frontend-src-pages-treatmentpage-treatmentpage-tsx|treatmentPage.tsx]]  `frontend/src/pages/TreatmentPage/treatmentPage.tsx`
**Lines:** 141-149
**Community:** [[com-treatmentpage-tag|treatmentpage-tag]]
**Signature:** `def toggleSelectAll(())`

## Source

```tsx
  const toggleSelectAll = () => {
    if (selected.size === filtered.length && filtered.length > 0) {
      // All are selected, deselect all
      setSelected(new Set());
    } else {
      // Select all
      setSelected(new Set(filtered.map(p => p.name)));
    }
  };
```

## External / unresolved calls (2)
- `setSelected` ×2
- `map`
