---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/AutocodeValidation.tsx::normalizeAttributeValues", "normalizeAttributeValues"]
tags: [function, tsx]
file: "frontend/src/pages/PathAnalysisPage/components/AutocodeValidation.tsx"
lines: "167-182"
---

# normalizeAttributeValues

**Kind:** Function
**File:** [[file-frontend-src-pages-pathanalysispage-components-autocodevalidation-tsx|AutocodeValidation.tsx]]  `frontend/src/pages/PathAnalysisPage/components/AutocodeValidation.tsx`
**Lines:** 167-182
**Community:** [[com-components-algrade|components-algrade]]
**Signature:** `def normalizeAttributeValues((attrs: AttributeRow[])) -> : AttributeRow[]`

## Source

```tsx
  const normalizeAttributeValues = (attrs: AttributeRow[]): AttributeRow[] => {
    return attrs.map(row => {
      const normalized: AttributeRow = {};
      for (const [key, value] of Object.entries(row)) {
        if (value === null || value === undefined) {
          normalized[key] = value;
        } else if (typeof value === 'string' && /^\d+(\.\d+)?$/.test(value)) {
          // Convert numeric strings to numbers
          normalized[key] = Number(value);
        } else {
          normalized[key] = value;
        }
      }
      return normalized;
    });
  };
```

## Callers (1)
- [[fn-frontend-src-pages-pathanalysispage-components-autocodevalidation-tsx--autocodevalidation|AutocodeValidation]]

## External / unresolved calls (1)
- `map`
