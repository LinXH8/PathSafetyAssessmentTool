---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/project_manager.py::Project.map_labels_to_values", "map_labels_to_values"]
tags: [function, python]
file: "backend/app/services/project_manager.py"
lines: "634-639"
---

# map_labels_to_values

**Kind:** Function
**File:** [[file-backend-app-services-project-manager-py|project_manager.py]]  `backend/app/services/project_manager.py`
**Lines:** 634-639
**Community:** [[com-services-project|services-project]]
**Signature:** `def map_labels_to_values((labels, value_map))`

## Description

> Helper to normalize single/multi inputs and map to stored values.

## Source

```python
        def map_labels_to_values(labels, value_map):
            """Helper to normalize single/multi inputs and map to stored values."""
            if not labels:
                return []
            label_list = labels if isinstance(labels, list) else [labels]
            return [value_map[label] for label in label_list if label in value_map]
```

## Callers (1)
- [[fn-backend-app-services-project-manager-py--copy-segments|copy_segments]]

## External / unresolved calls (1)
- `isinstance`
