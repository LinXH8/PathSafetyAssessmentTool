---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/api/index.ts::copySegments", "copySegments"]
tags: [function, typescript]
file: "frontend/src/api/index.ts"
lines: "179-194"
---

# copySegments

**Kind:** Function
**File:** [[file-frontend-src-api-index-ts|index.ts]]  `frontend/src/api/index.ts`
**Lines:** 179-194
**Community:** [[com-api-project|api-project]]
**Signature:** `def copySegments((
  sourceProject: string,
  targetProject: string,
  indices: number[],
  createTarget: boolean,
  replace: boolean = false,
  tags: string[] = []
)) -> : Promise<{ ok: boolean; message: string; count: number; targetProject: string }>`

## Source

```typescript
export async function copySegments(
  sourceProject: string,
  targetProject: string,
  indices: number[],
  createTarget: boolean,
  replace: boolean = false,
  tags: string[] = []
): Promise<{ ok: boolean; message: string; count: number; targetProject: string }> {
  const res = await fetch("/api/projects/copy-segments", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ sourceProject, targetProject, indices, createTarget, replace, tags }),
  });
  if (!res.ok) throw new Error(await readError(res));
  return res.json();
}
```

## Callers (1)
- [[fn-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx--performcopy|performCopy]]

## Callees (1)
- [[fn-frontend-src-api-index-ts--readerror|readError]]

## External / unresolved calls (3)
- `fetch`
- `stringify`
- `json`
