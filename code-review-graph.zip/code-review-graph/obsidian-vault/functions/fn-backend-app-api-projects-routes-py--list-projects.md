---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/projects/routes.py::list_projects", "list_projects"]
tags: [function, python]
file: "backend/app/api/projects/routes.py"
lines: "545-595"
---

# list_projects

**Kind:** Function
**File:** [[file-backend-app-api-projects-routes-py|routes.py]]  `backend/app/api/projects/routes.py`
**Lines:** 545-595
**Community:** [[com-projects-treatments|projects-treatments]]
**Signature:** `def list_projects(())`

## Description

> List projects with metadata including tags, date_created, last_updated, and verification segment counts.

## Source

```python
def list_projects():
    """List projects with metadata including tags, date_created, last_updated, and verification segment counts."""
    ctx = get_ctx()
    pm = ctx["pm"]
    names = pm.list_names()

    # Build list with metadata
    projects = []
    for name in names:
        try:
            proj = pm.project(name)
            # Get total segment count from latest version's attributes
            ver = proj.latest()
            total_segments = 0
            if ver.attributes and hasattr(ver.attributes, 'df'):
                df = ver.attributes.df
                if df is not None and len(df) > 0:
                    total_segments = len(df)

            project_data = {
                "name": name,
                "tags": proj.metadata.tags or [],
                "verified": getattr(proj.metadata, 'verified', False),
                "verified_segment_count": getattr(proj.metadata, 'verified_segment_count', 0),
                "autocoded_segment_count": getattr(proj.metadata, 'autocoded_segment_count', 0),
                "total_segments": total_segments
            }

            # Add date_created if available
            if hasattr(proj.metadata, 'date_created') and proj.metadata.date_created:
                project_data["date_created"] = proj.metadata.date_created.isoformat()

            # Add last_updated if available
            if hasattr(proj.metadata, 'last_updated') and proj.metadata.last_updated:
                project_data["last_updated"] = proj.metadata.last_updated.isoformat()

            projects.append(project_data)
        except Exception as e:
            # If metadata fails to load, return project with empty tags and no dates
            import traceback
            traceback.print_exc()
            projects.append({
                "name": name,
                "tags": [],
                "verified": False,
                "verified_segment_count": 0,
                "autocoded_segment_count": 0,
                "total_segments": 0
            })

    return jsonify({"projects": projects})
```

## Callees (1)
- [[fn-backend-app-api-projects-routes-py--get-ctx|get_ctx]]

## External / unresolved calls (10)
- `hasattr` ×3
- `getattr` ×3
- `len` ×2
- `isoformat` ×2
- `append` ×2
- `list_names`
- `project`
- `latest`
- `print_exc`
- `jsonify`
