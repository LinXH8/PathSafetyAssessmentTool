---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/__init__.py::create_app", "create_app"]
tags: [function, python]
file: "backend/app/__init__.py"
lines: "6-19"
---

# create_app

**Kind:** Function
**File:** [[file-backend-app-init-py|__init__.py]]  `backend/app/__init__.py`
**Lines:** 6-19
**Community:** [[com-app-app|app-app]]
**Signature:** `def create_app((config_object=Config))`

## Source

```python
def create_app(config_object=Config):
    app = Flask(__name__)
    app.config.from_object(config_object)

    # Enable CORS for all routes
    CORS(app, resources={r"/api/*": {"origins": "*"}})

    register_blueprints(app)

    # Pre-load GIS shapefiles in background so layer toggles are instant
    from .api.projects.routes import warmup_gis
    warmup_gis()

    return app
```

## External / unresolved calls (5)
- `Flask`
- `from_object`
- `CORS`
- `register_blueprints`
- `warmup_gis`
