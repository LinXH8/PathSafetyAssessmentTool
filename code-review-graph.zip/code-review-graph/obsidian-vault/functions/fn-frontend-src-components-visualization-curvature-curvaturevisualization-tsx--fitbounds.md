---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/curvature/CurvatureVisualization.tsx::FitBounds", "FitBounds"]
tags: [function, tsx]
file: "frontend/src/components/visualization/curvature/CurvatureVisualization.tsx"
lines: "54-62"
---

# FitBounds

**Kind:** Function
**File:** [[file-frontend-src-components-visualization-curvature-curvaturevisualization-tsx|CurvatureVisualization.tsx]]  `frontend/src/components/visualization/curvature/CurvatureVisualization.tsx`
**Lines:** 54-62
**Community:** [[com-curvature-fit|curvature-fit]]
**Signature:** `def FitBounds(({ center }: { center: [number, number] }))`

## Source

```tsx
function FitBounds({ center }: { center: [number, number] }) {
  const map = useMap();

  useEffect(() => {
    map.setView(center, 22); // Maximum zoom
  }, [map, center]);

  return null;
}
```

## Callers (1)
- [[fn-frontend-src-components-visualization-curvature-curvaturevisualization-tsx--curvaturevisualization|CurvatureVisualization]]

## External / unresolved calls (3)
- `useMap`
- `useEffect`
- `setView`
