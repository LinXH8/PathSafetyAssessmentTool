---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/sidebar/components/ImageUploadModal.tsx::resetState", "resetState"]
tags: [function, tsx]
file: "frontend/src/pages/sidebar/components/ImageUploadModal.tsx"
lines: "33-39"
---

# resetState

**Kind:** Function
**File:** [[file-frontend-src-pages-sidebar-components-imageuploadmodal-tsx|ImageUploadModal.tsx]]  `frontend/src/pages/sidebar/components/ImageUploadModal.tsx`
**Lines:** 33-39
**Community:** [[com-components-handle-6|components-handle]]
**Signature:** `def resetState(())`

## Source

```tsx
  function resetState() {
    setStep("upload");
    setFolderName("");
    setUploadedFiles([]);
    setDragActive(false);
    setDisplayedCount(FILES_PER_PAGE);
  }
```

## Callers (2)
- [[fn-frontend-src-pages-sidebar-components-imageuploadmodal-tsx--imageuploadmodal|ImageUploadModal]]
- [[fn-frontend-src-pages-sidebar-components-imageuploadmodal-tsx--handleclose|handleClose]]

## External / unresolved calls (5)
- `setStep`
- `setFolderName`
- `setUploadedFiles`
- `setDragActive`
- `setDisplayedCount`
