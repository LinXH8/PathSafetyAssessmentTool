---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/Projects/projects.tsx::askDelete", "askDelete"]
tags: [function, tsx]
file: "frontend/src/pages/Projects/projects.tsx"
lines: "295-298"
---

# askDelete

**Kind:** Function
**File:** [[file-frontend-src-pages-projects-projects-tsx|projects.tsx]]  `frontend/src/pages/Projects/projects.tsx`
**Lines:** 295-298
**Community:** [[com-projects-tag|projects-tag]]
**Signature:** `def askDelete(())`

## Source

```tsx
  const askDelete = () => {
    if (selected.size === 0) return;
    setOpenDelete(true);
  };
```

## External / unresolved calls (1)
- `setOpenDelete`
