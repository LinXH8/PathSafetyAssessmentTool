---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/projects/routes.py::_load_gradient_lookup", "_load_gradient_lookup"]
tags: [function, python]
file: "backend/app/api/projects/routes.py"
lines: "460-494"
---

# _load_gradient_lookup

**Kind:** Function
**File:** [[file-backend-app-api-projects-routes-py|routes.py]]  `backend/app/api/projects/routes.py`
**Lines:** 460-494
**Community:** [[com-projects-treatments|projects-treatments]]
**Signature:** `def _load_gradient_lookup(()) -> dict`

## Description

> Load (and cache) the gradient lookup CSV. Returns {} if unavailable.

## Source

```python
def _load_gradient_lookup() -> dict:
    """Load (and cache) the gradient lookup CSV. Returns {} if unavailable."""
    global _GRADIENT_LOOKUP
    if _GRADIENT_LOOKUP is not None:
        return _GRADIENT_LOOKUP
    lookup_path = Path(__file__).resolve().parents[3] / "shapefiles" / "gradient_lookup.csv"
    if not lookup_path.exists():
        _GRADIENT_LOOKUP = {}
        return _GRADIENT_LOOKUP
    try:
        import csv as _csv
        result = {}
        with open(lookup_path, newline="", encoding="utf-8") as f:
            reader = _csv.DictReader(f)
            if "Image Reference" not in (reader.fieldnames or []):
                print("[Gradient] WARNING: gradient_lookup.csv missing 'Image Reference' column — skipping")
                _GRADIENT_LOOKUP = {}
                return _GRADIENT_LOOKUP
            for row in reader:
                try:
                    img = row.get("Image Reference", "").strip()
                    grade_pct_raw = row.get("gradient_pct", "").strip()
                    grade_coded_raw = row.get("Grade", "").strip()
                    if img and grade_coded_raw:
                        grade_coded = int(float(grade_coded_raw))
                        grade_pct = float(grade_pct_raw) if grade_pct_raw else float("nan")
                        result[img] = (grade_coded, grade_pct)
                except (ValueError, TypeError):
                    continue
        _GRADIENT_LOOKUP = result
        print(f"[Gradient] Loaded {len(_GRADIENT_LOOKUP)} entries from gradient_lookup.csv")
    except Exception as _e:
        print(f"[Gradient] WARNING: could not load gradient_lookup.csv: {_e} — Grade will not be set")
        _GRADIENT_LOOKUP = {}
    return _GRADIENT_LOOKUP
```

## Callers (1)
- [[fn-backend-app-api-projects-routes-py--inject-grade|_inject_grade]]

## External / unresolved calls (11)
- `print` ×3
- `strip` ×3
- `get` ×3
- `float` ×2
- `resolve`
- `Path`
- `exists`
- `open`
- `DictReader`
- `int`
- `len`
