---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/TreatmentPage/treatmentPage.tsx::tag", "tag"]
tags: [function, tsx]
file: "frontend/src/pages/TreatmentPage/treatmentPage.tsx"
lines: "326-326"
---

# tag

**Kind:** Function
**File:** [[file-frontend-src-pages-treatmentpage-treatmentpage-tsx|treatmentPage.tsx]]  `frontend/src/pages/TreatmentPage/treatmentPage.tsx`
**Lines:** 326-326
**Community:** [[com-treatmentpage-tag|treatmentpage-tag]]
**Signature:** `def tag()`

## Source

```tsx
                    const otherTags = p.tags?.filter(tag => tag !== "Pre" && tag !== "Post") || [];
```

## External / unresolved calls (3)
- `add`
- `includes`
- `toLowerCase`
