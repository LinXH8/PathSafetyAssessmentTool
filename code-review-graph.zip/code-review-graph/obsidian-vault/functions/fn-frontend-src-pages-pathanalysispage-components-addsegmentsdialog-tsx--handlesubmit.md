---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/AddSegmentsDialog.tsx::handleSubmit", "handleSubmit"]
tags: [function, tsx]
file: "frontend/src/pages/PathAnalysisPage/components/AddSegmentsDialog.tsx"
lines: "162-209"
---

# handleSubmit

**Kind:** Function
**File:** [[file-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx|AddSegmentsDialog.tsx]]  `frontend/src/pages/PathAnalysisPage/components/AddSegmentsDialog.tsx`
**Lines:** 162-209
**Community:** [[com-components-tag|components-tag]]
**Signature:** `def handleSubmit(())`

## Source

```tsx
    const handleSubmit = async () => {
        const target = projectMode === "new" ? newProjectName : existingProject;

        if (!target) {
            toaster.create({ title: "Validation Error", description: "Please specify a project name.", type: "error" });
            return;
        }

        if (projectMode === "new" && target.includes("_")) {
            toaster.create({ title: "Validation Error", description: "Project name cannot contain underscores (_).", type: "error" });
            return;
        }

        try {
            setSubmitting(true);

            // Check for collisions ONLY if copying to existing project
            if (projectMode === "existing") {
                let totalCollisions = 0;

                // Check collisions for each source
                for (const source of sources) {
                    const checkRes = await checkCollisions(source.projectName, target, source.indices);
                    if (checkRes.collisions) {
                        totalCollisions += checkRes.collisions.length;
                    }
                }

                if (totalCollisions > 0) {
                    setCollisionCount(totalCollisions);
                    setCollisionConfirmOpen(true);
                    setSubmitting(false); // Stop loading, wait for user confirmation
                    return;
                }
            }

            // No collisions or new project, proceed directly
            await performCopy(false);

        } catch (e: any) {
            toaster.create({
                title: "Error",
                description: e.message || "Failed to check for collisions.",
                type: "error"
            });
            setSubmitting(false);
        }
    };
```

## Callees (2)
- [[fn-frontend-src-api-index-ts--checkcollisions|checkCollisions]]
- [[fn-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx--performcopy|performCopy]]

## External / unresolved calls (5)
- `create` ×3
- `setSubmitting` ×3
- `includes`
- `setCollisionCount`
- `setCollisionConfirmOpen`
