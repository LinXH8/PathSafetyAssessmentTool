---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/sidebar/components/ShapefileModal.tsx::handleBackToChoice", "handleBackToChoice"]
tags: [function, tsx]
file: "frontend/src/pages/sidebar/components/ShapefileModal.tsx"
lines: "79-86"
---

# handleBackToChoice

**Kind:** Function
**File:** [[file-frontend-src-pages-sidebar-components-shapefilemodal-tsx|ShapefileModal.tsx]]  `frontend/src/pages/sidebar/components/ShapefileModal.tsx`
**Lines:** 79-86
**Community:** [[com-components-handle-7|components-handle]]
**Signature:** `def handleBackToChoice(())`

## Source

```tsx
  function handleBackToChoice() {
    setStep("choice");
    // Clear state
    setUploadFiles([]);
    setReplaceFiles([]);
    setSelectedReplaceCategory("");
    setSelectedTargetShapefile("");
  }
```

## External / unresolved calls (5)
- `setStep`
- `setUploadFiles`
- `setReplaceFiles`
- `setSelectedReplaceCategory`
- `setSelectedTargetShapefile`
