---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/projects/routes.py::get_width_visualization", "get_width_visualization"]
tags: [function, python]
file: "backend/app/api/projects/routes.py"
lines: "2775-2852"
---

# get_width_visualization

**Kind:** Function
**File:** [[file-backend-app-api-projects-routes-py|routes.py]]  `backend/app/api/projects/routes.py`
**Lines:** 2775-2852
**Community:** [[com-projects-treatments|projects-treatments]]
**Signature:** `def get_width_visualization((project_name: str))`

## Description

> Generate visualization data for facility width analysis at a specific segment.
>
> This endpoint returns all the data needed to display an interactive map showing:
> - The analysis point (segment starting location)
> - Expanding ring search pattern (1m to 10m radii)
> - Path centerlines within view (color-coded by type)
> - Which radius found the width value
> - Calculated width value and category
>
> Request body:
>     {
>         "coords": [[lon, lat], ...],  // Segment LineString coordinates
>         "index": 0  // Optional: segment index for reference
>     }
>
> Response:
>     {
>         "ok": true,
>         "point": {"lon": 103.8198, "lat": 1.3521},
>         "width": 2.5,  // Width in meters (null if not found)
>         "width_category": 2,  // 1=Very Narrow, 2=Narrow, 3=Wide
>         "search_info": {
>             "found_at_radius": 2.0,  // meters
>             "layer_used": "cycling",
>             "total_radii_checked": 5
>         },
>         "search_rings": [
>             {
>                 "radius": 2.0,
>                 "center": [lon, lat],
>                 "candidates_by_layer": {"cycling": 1, "shared": 0, "footpath": 0},
>                 "width_locked": true
>             },
>             ...
>         ],
>         "paths": [
>             {
>                 "type": "cycling",
>                 "color": [0, 180, 0],
>                 "coordinates": [[lon, lat], ...],
>                 "is_analysis_layer": true,
>                 "width_value": 2.5
>             },
>             ...
>         ],
>         "width_distribution": {
>             "cycling": {"min": 0.5, "max": 9.0, "count": 1437},
>             "shared": {"min": 0.4, "max": 11.3, "count": 4531},
>             "footpath": {"min": 0.04, "max": 33.3, "count": 179483}
>         }
>     }

## Source

```python
def get_width_visualization(project_name: str):
    """
    Generate visualization data for facility width analysis at a specific segment.

    This endpoint returns all the data needed to display an interactive map showing:
    - The analysis point (segment starting location)
    - Expanding ring search pattern (1m to 10m radii)
    - Path centerlines within view (color-coded by type)
    - Which radius found the width value
    - Calculated width value and category

    Request body:
        {
            "coords": [[lon, lat], ...],  // Segment LineString coordinates
            "index": 0  // Optional: segment index for reference
        }

    Response:
        {
            "ok": true,
            "point": {"lon": 103.8198, "lat": 1.3521},
            "width": 2.5,  // Width in meters (null if not found)
            "width_category": 2,  // 1=Very Narrow, 2=Narrow, 3=Wide
            "search_info": {
                "found_at_radius": 2.0,  // meters
                "layer_used": "cycling",
                "total_radii_checked": 5
            },
            "search_rings": [
                {
                    "radius": 2.0,
                    "center": [lon, lat],
                    "candidates_by_layer": {"cycling": 1, "shared": 0, "footpath": 0},
                    "width_locked": true
                },
                ...
            ],
            "paths": [
                {
                    "type": "cycling",
                    "color": [0, 180, 0],
                    "coordinates": [[lon, lat], ...],
                    "is_analysis_layer": true,
                    "width_value": 2.5
                },
                ...
            ],
            "width_distribution": {
                "cycling": {"min": 0.5, "max": 9.0, "count": 1437},
                "shared": {"min": 0.4, "max": 11.3, "count": 4531},
                "footpath": {"min": 0.04, "max": 33.3, "count": 179483}
            }
        }
    """
    try:
        payload = request.get_json(force=True, silent=True) or {}
        coords = payload.get("coords")  # [[lon, lat], ...]

        if not coords or not isinstance(coords, list) or not isinstance(coords[0], list):
            return fail("coords (LineString) is required", 400)

        # Segment starting point (WGS84)
        start_lon, start_lat = coords[0]
        pt = Point(start_lon, start_lat)

        _gis = _get_gis()

        # Generate visualization data
        viz_data = _gis.get_width_visualization(pt, start_radius=1.0, max_radius=10.0, step=1.0)

        viz_data["ok"] = True
        return ok(viz_data)

    except ServiceUnavailable as e:
        return fail(str(e), 503)
    except Exception as e:
        traceback.print_exc()
        return fail(f"width visualization error: {e}", 500)
```

## Callers (1)
- [[fn-backend-app-api-projects-routes-py--get-width-visualization|get_width_visualization]]

## Callees (4)
- [[fn-backend-app-api-projects-routes-py--fail|fail]]
- [[fn-backend-app-api-projects-routes-py--get-gis|_get_gis]]
- [[fn-backend-app-api-projects-routes-py--get-width-visualization|get_width_visualization]]
- [[fn-backend-app-api-projects-routes-py--ok|ok]]

## External / unresolved calls (6)
- `get_json`
- `get`
- `isinstance`
- `Point`
- `str`
- `print_exc`
