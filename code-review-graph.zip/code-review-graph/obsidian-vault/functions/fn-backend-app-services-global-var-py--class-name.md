---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/global_var.py::Map_index.class_name", "class_name"]
tags: [function, python]
file: "backend/app/services/global_var.py"
lines: "13-13"
---

# class_name

**Kind:** Function
**File:** [[file-backend-app-services-global-var-py|global_var.py]]  `backend/app/services/global_var.py`
**Lines:** 13-13
**Community:** [[com-services-class|services-class]]
**Signature:** `def class_name(())`

## Source

```python
    def class_name(): return "Map_index"
```
