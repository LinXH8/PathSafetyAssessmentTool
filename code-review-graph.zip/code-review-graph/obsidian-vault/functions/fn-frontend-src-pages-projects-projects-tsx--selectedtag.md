---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/Projects/projects.tsx::selectedTag", "selectedTag"]
tags: [function, tsx]
file: "frontend/src/pages/Projects/projects.tsx"
lines: "209-209"
---

# selectedTag

**Kind:** Function
**File:** [[file-frontend-src-pages-projects-projects-tsx|projects.tsx]]  `frontend/src/pages/Projects/projects.tsx`
**Lines:** 209-209
**Community:** [[com-projects-tag|projects-tag]]
**Signature:** `def selectedTag()`

## Source

```tsx
        tagFilters.every(selectedTag => p.tags?.includes(selectedTag))
```

## External / unresolved calls (1)
- `includes`
