---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/serializer.py::ProjectGeoData", "ProjectGeoData"]
tags: [class, python]
file: "backend/app/services/serializer.py"
lines: "306-373"
---

# ProjectGeoData

**Kind:** Class
**File:** [[file-backend-app-services-serializer-py|serializer.py]]  `backend/app/services/serializer.py`
**Lines:** 306-373
**Community:** [[com-services-fields|services-fields]]
**Signature:** `class ProjectGeoData`

## Source

```python
class ProjectGeoData:
    class Fields:
        IMAGE_REFERENCE_STR = "Image Reference"
        ROAD_NAME_STR       = "Road Name"
        DISTANCE_STR        = "Distance (Metres)"
        LINESTRING_STR      = "LineString"

    # === INIT ===

    def __init__(self, size : int = None, file_path : Path = None):
        self.df_dirty = False
        self.loc = LocWrapper(self)

        if file_path is None and size is None:
            return

        if file_path is not None:
            self.df : gpd.GeoDataFrame = None
            self.parse(file_path)
            return

        if size == 0:
            self.df = gpd.GeoDataFrame(columns=[
                self.Fields.IMAGE_REFERENCE_STR,
                self.Fields.ROAD_NAME_STR,
                self.Fields.DISTANCE_STR,
                self.Fields.LINESTRING_STR
            ], geometry=self.Fields.LINESTRING_STR, crs="EPSG:3414")
        else:
            self.df = gpd.GeoDataFrame([{
                self.Fields.IMAGE_REFERENCE_STR:    "",
                self.Fields.ROAD_NAME_STR:          "",
                self.Fields.DISTANCE_STR:           0,
                self.Fields.LINESTRING_STR:         None
            } for _ in range(size)], geometry=self.Fields.LINESTRING_STR, crs="EPSG:3414")

    # === UTILITY ===

    def populate_linestring(self, geometries: gpd.GeoSeries):
        if geometries.crs.to_epsg() != 3414:
            geometries = geometries.to_crs("EPSG:3414")

        self.df[self.Fields.LINESTRING_STR] = geometries["geometry"]
        per_segment_lengths = geometries.length
        self.df[self.Fields.DISTANCE_STR] = per_segment_lengths.cumsum()

    def get_point_start(self, index: int):
        geom = self.df.at[index, self.Fields.LINESTRING_STR]
        return geom.coords[0] if geom and not geom.is_empty else None

    def get_point_end(self, index: int):
        geom = self.df.at[index, self.Fields.LINESTRING_STR]
        return geom.coords[-1] if geom and not geom.is_empty else None

    # === SERIALIZATION ===

    def serialize(self, to_dir : Path):
        to_dir.mkdir(parents=True, exist_ok=True)
        file_path = to_dir / "geo_data.gpkg"
        self.df.to_file(file_path, driver="GPKG", index=False)

    def parse(self, project_path : Path):
        file_path = project_path / "geo_data.gpkg"
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        self.df = gpd.read_file(file_path)
        if self.df.crs.to_epsg() != 3414:
            raise Exception("Unexpected CRS: ", self.df.crs)
```
