---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/prediction.py::CycleRAP_Coding_Helper._build_masks", "_build_masks"]
tags: [function, python]
file: "backend/app/services/prediction.py"
lines: "115-145"
---

# _build_masks

**Kind:** Function
**File:** [[file-backend-app-services-prediction-py|prediction.py]]  `backend/app/services/prediction.py`
**Lines:** 115-145
**Community:** [[com-services-compute|services-compute]]
**Signature:** `def _build_masks((
        result,
        class_sets: dict[str, set[int]],
        img_h: int,
        img_w: int,
        conf_thresh: float,
    )) -> dict[str, np.ndarray]`

## Source

```python
    def _build_masks(
        result,
        class_sets: dict[str, set[int]],
        img_h: int,
        img_w: int,
        conf_thresh: float,
    ) -> dict[str, np.ndarray]:
        masks_out = {key: np.zeros((img_h, img_w), dtype=np.uint8) for key in class_sets}

        boxes = result.boxes
        seg_masks = result.masks
        if boxes is None or seg_masks is None:
            return masks_out

        class_ids = boxes.cls.int().tolist()
        confidences = boxes.conf.tolist()
        polygons = seg_masks.xy

        for i, (cid, conf) in enumerate(zip(class_ids, confidences)):
            if conf < conf_thresh or i >= len(polygons):
                continue
            poly = polygons[i]
            if len(poly) < 3:
                continue
            poly_int = np.array(poly, dtype=np.int32)
            for key, id_set in class_sets.items():
                if cid in id_set:
                    cv2.fillPoly(masks_out[key], [poly_int], 1)
                    break

        return masks_out
```

## Callers (1)
- [[fn-backend-app-services-prediction-py--autocode|autocode]]

## External / unresolved calls (9)
- `tolist` ×2
- `len` ×2
- `zeros`
- `int`
- `enumerate`
- `zip`
- `array`
- `items`
- `fillPoly`
