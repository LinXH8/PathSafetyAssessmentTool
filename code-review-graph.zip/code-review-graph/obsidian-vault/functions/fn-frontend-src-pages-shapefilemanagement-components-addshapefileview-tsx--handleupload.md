---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/ShapefileManagement/components/AddShapefileView.tsx::handleUpload", "handleUpload"]
tags: [function, tsx]
file: "frontend/src/pages/ShapefileManagement/components/AddShapefileView.tsx"
lines: "78-112"
---

# handleUpload

**Kind:** Function
**File:** [[file-frontend-src-pages-shapefilemanagement-components-addshapefileview-tsx|AddShapefileView.tsx]]  `frontend/src/pages/ShapefileManagement/components/AddShapefileView.tsx`
**Lines:** 78-112
**Community:** [[com-components-handle-3|components-handle]]
**Signature:** `def handleUpload(())`

## Source

```tsx
  async function handleUpload() {
    if (files.length === 0) {
      toaster.create({
        description: "Please select files to upload",
        type: "warning",
      });
      return;
    }

    try {
      setUploading(true);
      const result = await api.uploadShapefiles(files, category);

      if (result.errors.length > 0) {
        toaster.create({
          description: `Uploaded ${result.count} file(s) with ${result.errors.length} error(s)`,
          type: "warning",
        });
      } else {
        toaster.create({
          description: `Successfully uploaded ${result.count} shapefile(s)`,
          type: "success",
        });
      }

      onComplete();
    } catch (error) {
      toaster.create({
        description: `Upload failed: ${error}`,
        type: "error",
      });
    } finally {
      setUploading(false);
    }
  }
```

## External / unresolved calls (4)
- `create` ×4
- `setUploading` ×2
- `uploadShapefiles`
- `onComplete`
