---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/AddSegmentsDialog.tsx::s", "s"]
tags: [function, tsx]
file: "frontend/src/pages/PathAnalysisPage/components/AddSegmentsDialog.tsx"
lines: "237-241"
---

# s

**Kind:** Function
**File:** [[file-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx|AddSegmentsDialog.tsx]]  `frontend/src/pages/PathAnalysisPage/components/AddSegmentsDialog.tsx`
**Lines:** 237-241
**Community:** [[com-components-tag|components-tag]]
**Signature:** `def s()`

## Source

```tsx
                                        {sources.map(s => (
                                            <Text fontSize="xs" key={s.projectName}>
                                                • <b>{s.projectName}</b>: {s.indices.length} segments
                                            </Text>
                                        ))}
```

## External / unresolved calls (1)
- `Text`
