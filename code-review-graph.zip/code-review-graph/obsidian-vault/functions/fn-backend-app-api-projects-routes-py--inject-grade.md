---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/projects/routes.py::_inject_grade", "_inject_grade"]
tags: [function, python]
file: "backend/app/api/projects/routes.py"
lines: "497-535"
---

# _inject_grade

**Kind:** Function
**File:** [[file-backend-app-api-projects-routes-py|routes.py]]  `backend/app/api/projects/routes.py`
**Lines:** 497-535
**Community:** [[com-projects-treatments|projects-treatments]]
**Signature:** `def _inject_grade((image_ref: str, updates: dict, sources: "dict | None" = None,
                   project_name: str = "")) -> "float | None"`

## Description

> Inject Grade from the gradient lookup into *updates* (in-place).
> Returns grade_pct if found, else None.

## Source

```python
def _inject_grade(image_ref: str, updates: dict, sources: "dict | None" = None,
                   project_name: str = "") -> "float | None":
    """Inject Grade from the gradient lookup into *updates* (in-place).
    Returns grade_pct if found, else None.
    """
    try:
        lookup = _load_gradient_lookup()
        if not lookup:
            return None
        # Try exact match first, then strip project prefix, then suffix match
        key = image_ref
        if key not in lookup and project_name:
            prefix = project_name + "_"
            if key.startswith(prefix):
                key = key[len(prefix):]
        if key not in lookup:
            # Last resort: find any CSV entry whose key is a suffix of image_ref
            bare = image_ref.split("_", 1)[-1] if "_" in image_ref else image_ref
            for k in lookup:
                if image_ref.endswith(k) or k.endswith(bare):
                    key = k
                    break
        if key not in lookup:
            print(f"[Gradient] no entry for '{image_ref}' — skipping", flush=True)
            return None
        grade_coded, grade_pct = lookup[key]
        print(f"[Gradient] {image_ref}: {grade_pct:+.2f}% → Grade {grade_coded}", flush=True)
        if grade_coded not in (1, 2):
            print(f"[Gradient] WARNING: unexpected Grade value {grade_coded!r} for {image_ref} — skipping")
            return None
        updates["Grade"] = grade_coded
        updates["Gradient %"] = round(grade_pct, 2)
        if sources is not None:
            sources["Grade"] = "LAZ"
            sources["Gradient %"] = "LAZ"
        return grade_pct
    except Exception as _e:
        print(f"[Gradient] WARNING: error injecting Grade for {image_ref}: {_e}")
        return None
```

## Callers (2)
- [[fn-backend-app-api-projects-routes-py--autocode-image|autocode_image]]
- [[fn-backend-app-api-projects-routes-py--autocode-all|autocode_all]]

## Callees (1)
- [[fn-backend-app-api-projects-routes-py--load-gradient-lookup|_load_gradient_lookup]]

## External / unresolved calls (6)
- `print` ×4
- `startswith`
- `len`
- `split`
- `endswith`
- `round`
