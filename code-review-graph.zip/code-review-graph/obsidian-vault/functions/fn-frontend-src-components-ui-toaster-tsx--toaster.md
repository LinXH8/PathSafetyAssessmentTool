---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/ui/toaster.tsx::Toaster", "Toaster"]
tags: [function, tsx]
file: "frontend/src/components/ui/toaster.tsx"
lines: "17-43"
---

# Toaster

**Kind:** Function
**File:** [[file-frontend-src-components-ui-toaster-tsx|toaster.tsx]]  `frontend/src/components/ui/toaster.tsx`
**Lines:** 17-43
**Community:** [[com-ui-toaster|ui-toaster]]
**Signature:** `def Toaster(())`

## Source

```tsx
export const Toaster = () => {
  return (
    <Portal>
      <ChakraToaster toaster={toaster} insetInline={{ mdDown: "4" }}>
        {(toast) => (
          <Toast.Root width={{ md: "sm" }}>
            {toast.type === "loading" ? (
              <Spinner size="sm" color="blue.solid" />
            ) : (
              <Toast.Indicator />
            )}
            <Stack gap="1" flex="1" maxWidth="100%">
              {toast.title && <Toast.Title>{toast.title}</Toast.Title>}
              {toast.description && (
                <Toast.Description>{toast.description}</Toast.Description>
              )}
            </Stack>
            {toast.action && (
              <Toast.ActionTrigger>{toast.action.label}</Toast.ActionTrigger>
            )}
            {toast.closable && <Toast.CloseTrigger />}
          </Toast.Root>
        )}
      </ChakraToaster>
    </Portal>
  )
}
```

## External / unresolved calls (10)
- `Portal`
- `ChakraToaster`
- `Root`
- `Spinner`
- `Indicator`
- `Stack`
- `Title`
- `Description`
- `ActionTrigger`
- `CloseTrigger`
