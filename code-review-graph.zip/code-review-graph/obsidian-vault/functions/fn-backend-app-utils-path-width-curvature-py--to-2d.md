---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/utils/path_width_curvature.py::to_2d", "to_2d"]
tags: [function, python]
file: "backend/app/utils/path_width_curvature.py"
lines: "28-29"
---

# to_2d

**Kind:** Function
**File:** [[file-backend-app-utils-path-width-curvature-py|path_width_curvature.py]]  `backend/app/utils/path_width_curvature.py`
**Lines:** 28-29
**Community:** [[com-utils-width|utils-width]]
**Signature:** `def to_2d((coords))`

## Source

```python
    def to_2d(coords):
        return [(x, y) for x, y, *_ in coords]
```

## Callers (1)
- [[fn-backend-app-utils-path-width-curvature-py--remove-z|remove_z]]
