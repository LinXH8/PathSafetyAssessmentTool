---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/cycle_rap_processing_gopro_footage.py::gdfify", "gdfify"]
tags: [function, python]
file: "backend/app/services/cycle_rap_processing_gopro_footage.py"
lines: "26-32"
---

# gdfify

**Kind:** Function
**File:** [[file-backend-app-services-cycle-rap-processing-gopro-footage-py|cycle_rap_processing_gopro_footage.py]]  `backend/app/services/cycle_rap_processing_gopro_footage.py`
**Lines:** 26-32
**Community:** [[com-services-extract|services-extract]]
**Signature:** `def gdfify((gdf))`

## Source

```python
def gdfify(gdf):
    gdf = gpd.GeoDataFrame(gdf)
    try:
        gdf = gdf.to_crs(4326)
    except:
        gdf = gdf.set_crs(4326)
    return(gdf)
```

## External / unresolved calls (3)
- `GeoDataFrame`
- `to_crs`
- `set_crs`
