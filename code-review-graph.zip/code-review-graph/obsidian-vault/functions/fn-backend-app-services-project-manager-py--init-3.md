---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/project_manager.py::project_manager.__init__", "__init__"]
tags: [function, python]
file: "backend/app/services/project_manager.py"
lines: "751-766"
---

# __init__

**Kind:** Function
**File:** [[file-backend-app-services-project-manager-py|project_manager.py]]  `backend/app/services/project_manager.py`
**Lines:** 751-766
**Community:** [[com-services-project|services-project]]
**Signature:** `def __init__((self))`

## Source

```python
    def __init__(self):
        # Path variables
        self.des_path : Path            = None
        self.src_path : Path            = None
        self.in_path  : Path            = None
        self.cycleRAP_model_src : Path  = None

        # Application-level variables
        self.shapefile                                                  = None
        self.capture_freq                                               = None

        # NOTE: Variable deprecated but still kept for backwards compatibility, 
        # Use the cycleRAP_interface class methods instead
        self.cyclerap_interface : cycleRAP_interface.cycleRAP_interface = cycleRAP_interface.cycleRAP_interface

        self._initialise()
```

## Callees (1)
- [[fn-backend-app-services-project-manager-py--initialise|_initialise]]
