---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx::PanToBounds", "PanToBounds"]
tags: [function, tsx]
file: "frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx"
lines: "35-42"
---

# PanToBounds

**Kind:** Function
**File:** [[file-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx|PathAnalysisMapView.tsx]]  `frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx`
**Lines:** 35-42
**Community:** [[com-components-handle-2|components-handle]]
**Signature:** `def PanToBounds(({ bounds }: { bounds: L.LatLngBounds | null }))`

## Source

```tsx
function PanToBounds({ bounds }: { bounds: L.LatLngBounds | null }) {
  const map = useMap();
  useEffect(() => {
    if (!bounds) return;
    map.fitBounds(bounds, { padding: [24, 24] });
  }, [bounds, map]);
  return null;
}
```

## Callers (1)
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--attributeanalysismapview|AttributeAnalysisMapView]]

## External / unresolved calls (3)
- `useMap`
- `useEffect`
- `fitBounds`
