---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/Projects/components/EditProjectModal.tsx::handleTagInputKeyDown", "handleTagInputKeyDown"]
tags: [function, tsx]
file: "frontend/src/pages/Projects/components/EditProjectModal.tsx"
lines: "71-83"
---

# handleTagInputKeyDown

**Kind:** Function
**File:** [[file-frontend-src-pages-projects-components-editprojectmodal-tsx|EditProjectModal.tsx]]  `frontend/src/pages/Projects/components/EditProjectModal.tsx`
**Lines:** 71-83
**Community:** [[com-components-tag-2|components-tag]]
**Signature:** `def handleTagInputKeyDown((e: KeyboardEvent<HTMLInputElement>))`

## Source

```tsx
  function handleTagInputKeyDown(e: KeyboardEvent<HTMLInputElement>) {
    if (e.key === "," || e.key === "Enter") {
      e.preventDefault();
      const trimmedTag = tagInput.trim();
      if (trimmedTag && !tags.includes(trimmedTag)) {
        setTags([...tags, trimmedTag]);
      }
      setTagInput("");
    } else if (e.key === "Backspace" && tagInput === "" && tags.length > 0) {
      // Remove last tag on backspace if input is empty
      setTags(tags.slice(0, -1));
    }
  }
```

## External / unresolved calls (6)
- `setTags` ×2
- `preventDefault`
- `trim`
- `includes`
- `setTagInput`
- `slice`
