---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/sidebar/components/ImageUploadModal.tsx::addFiles", "addFiles"]
tags: [function, tsx]
file: "frontend/src/pages/sidebar/components/ImageUploadModal.tsx"
lines: "124-142"
---

# addFiles

**Kind:** Function
**File:** [[file-frontend-src-pages-sidebar-components-imageuploadmodal-tsx|ImageUploadModal.tsx]]  `frontend/src/pages/sidebar/components/ImageUploadModal.tsx`
**Lines:** 124-142
**Community:** [[com-components-handle-6|components-handle]]
**Signature:** `def addFiles((newFiles: File[]))`

## Source

```tsx
  function addFiles(newFiles: File[]) {
    // Accept common image formats
    const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.tiff', '.tif'];

    const validFiles = newFiles.filter((f) => {
      const fileName = f.name.toLowerCase();
      return imageExtensions.some(ext => fileName.endsWith(ext));
    });

    if (validFiles.length === 0) {
      toaster.create({
        description: "Please upload image files (.jpg, .png, .gif, etc.)",
        type: "warning",
      });
      return;
    }

    setUploadedFiles((prev) => [...prev, ...validFiles]);
  }
```

## Callers (2)
- [[fn-frontend-src-pages-sidebar-components-imageuploadmodal-tsx--handledrop|handleDrop]]
- [[fn-frontend-src-pages-sidebar-components-imageuploadmodal-tsx--handlefileselect|handleFileSelect]]

## External / unresolved calls (5)
- `filter`
- `toLowerCase`
- `some`
- `create`
- `setUploadedFiles`
