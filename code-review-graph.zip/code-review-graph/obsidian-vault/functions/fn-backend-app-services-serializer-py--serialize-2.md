---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/serializer.py::ProjectGeoData.serialize", "serialize"]
tags: [function, python]
file: "backend/app/services/serializer.py"
lines: "362-365"
---

# serialize

**Kind:** Function
**File:** [[file-backend-app-services-serializer-py|serializer.py]]  `backend/app/services/serializer.py`
**Lines:** 362-365
**Community:** [[com-services-fields|services-fields]]
**Signature:** `def serialize((self, to_dir : Path))`

## Source

```python
    def serialize(self, to_dir : Path):
        to_dir.mkdir(parents=True, exist_ok=True)
        file_path = to_dir / "geo_data.gpkg"
        self.df.to_file(file_path, driver="GPKG", index=False)
```

## External / unresolved calls (2)
- `mkdir`
- `to_file`
