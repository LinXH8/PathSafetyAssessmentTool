---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/api/curvatureVisualization.ts::fetchCurvatureVisualization", "fetchCurvatureVisualization"]
tags: [function, typescript]
file: "frontend/src/api/curvatureVisualization.ts"
lines: "103-125"
---

# fetchCurvatureVisualization

**Kind:** Function
**File:** [[file-frontend-src-api-curvaturevisualization-ts|curvatureVisualization.ts]]  `frontend/src/api/curvatureVisualization.ts`
**Lines:** 103-125
**Community:** [[com-api-fetch|api-fetch]]
**Signature:** `def fetchCurvatureVisualization((
  projectName: string,
  coords: [number, number][],
  index?: number
)) -> : Promise<CurvatureVisualizationResponse>`

## Description

> Fetch curvature visualization data for a segment
>
> @param projectName - Name of the project
> @param coords - LineString coordinates [[lon, lat], ...]
> @param index - Optional segment index
> @returns Visualization data including map layers, diagnostics, and calculations

## Source

```typescript
export async function fetchCurvatureVisualization(
  projectName: string,
  coords: [number, number][],
  index?: number
): Promise<CurvatureVisualizationResponse> {
  const response = await fetch(
    `${API_BASE_URL}/api/projects/${projectName}/curvature/visualize`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ coords, index }),
    }
  );

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Failed to fetch curvature visualization');
  }

  return await response.json();
}
```

## Callers (2)
- [[fn-frontend-src-components-visualization-analysispanel-tsx--analysispanel|AnalysisPanel]]
- [[fn-frontend-src-components-visualization-curvature-curvaturevisualizationpanel-tsx--loadvisualization|loadVisualization]]

## External / unresolved calls (3)
- `json` ×2
- `fetch`
- `stringify`
