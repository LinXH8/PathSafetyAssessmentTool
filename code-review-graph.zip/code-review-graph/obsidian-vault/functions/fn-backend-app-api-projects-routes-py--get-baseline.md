---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/projects/routes.py::get_baseline", "get_baseline"]
tags: [function, python]
file: "backend/app/api/projects/routes.py"
lines: "3448-3481"
---

# get_baseline

**Kind:** Function
**File:** [[file-backend-app-api-projects-routes-py|routes.py]]  `backend/app/api/projects/routes.py`
**Lines:** 3448-3481
**Community:** [[com-projects-treatments|projects-treatments]]
**Signature:** `def get_baseline((project_name: str))`

## Description

> Get baseline CSV as JSON array of row dictionaries.
>
> Response:
>     {
>         "ok": true,
>         "rows": [
>             {"Facility Type": 2, "Area type": 1, ...},
>             ...
>         ]
>     }

## Source

```python
def get_baseline(project_name: str):
    """
    Get baseline CSV as JSON array of row dictionaries.

    Response:
        {
            "ok": true,
            "rows": [
                {"Facility Type": 2, "Area type": 1, ...},
                ...
            ]
        }
    """
    try:
        ctx = get_ctx()
        pm = ctx["pm"]
        proj = pm.project(project_name)

        baseline_path = proj.project_path / "baseline" / f"{project_name}_baseline.csv"

        if not baseline_path.exists():
            return ok({"rows": []})  # No baseline yet

        # Read CSV and convert to JSON
        baseline_df = pd.read_csv(baseline_path)
        rows = df_to_records(baseline_df)

        return ok({"rows": rows})

    except KeyError:
        return fail("Project not found", 404)
    except Exception as e:
        traceback.print_exc()
        return fail(f"Error reading baseline: {e}", 500)
```

## Callees (4)
- [[fn-backend-app-api-projects-routes-py--get-ctx|get_ctx]]
- [[fn-backend-app-api-projects-routes-py--ok|ok]]
- [[fn-backend-app-api-projects-routes-py--df-to-records|df_to_records]]
- [[fn-backend-app-api-projects-routes-py--fail|fail]]

## External / unresolved calls (4)
- `project`
- `exists`
- `read_csv`
- `print_exc`
