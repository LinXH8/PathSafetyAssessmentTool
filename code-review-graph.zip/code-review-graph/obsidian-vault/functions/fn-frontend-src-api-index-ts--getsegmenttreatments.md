---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/api/index.ts::getSegmentTreatments", "getSegmentTreatments"]
tags: [function, typescript]
file: "frontend/src/api/index.ts"
lines: "631-640"
---

# getSegmentTreatments

**Kind:** Function
**File:** [[file-frontend-src-api-index-ts|index.ts]]  `frontend/src/api/index.ts`
**Lines:** 631-640
**Community:** [[com-api-project|api-project]]
**Signature:** `def getSegmentTreatments((
  project: string,
  segmentIndex: number
)) -> : Promise<SegmentTreatmentState>`

## Description

> Get treatment state for a specific segment
> @param project - Project name
> @param segmentIndex - Segment index
> @returns Treatment state including applied treatments and after scores

## Source

```typescript
export async function getSegmentTreatments(
  project: string,
  segmentIndex: number
): Promise<SegmentTreatmentState> {
  const res = await fetch(
    `/api/projects/${encodeURIComponent(project)}/treatments/segment/${segmentIndex}`
  );
  if (!res.ok) throw new Error(await readError(res));
  return res.json();
}
```

## Callers (1)
- [[fn-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx--treatmentdetailpage|TreatmentDetailPage]]

## Callees (1)
- [[fn-frontend-src-api-index-ts--readerror|readError]]

## External / unresolved calls (3)
- `fetch`
- `encodeURIComponent`
- `json`
