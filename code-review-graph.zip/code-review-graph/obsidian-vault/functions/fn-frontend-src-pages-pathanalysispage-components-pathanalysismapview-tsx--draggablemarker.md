---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx::DraggableMarker", "DraggableMarker"]
tags: [function, tsx]
file: "frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx"
lines: "87-115"
---

# DraggableMarker

**Kind:** Function
**File:** [[file-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx|PathAnalysisMapView.tsx]]  `frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx`
**Lines:** 87-115
**Community:** [[com-components-handle-2|components-handle]]
**Signature:** `def DraggableMarker(({ position, index, color, icon, onDrag, onDragEnd }: DraggableMarkerProps))`

## Source

```tsx
function DraggableMarker({ position, index, color, icon, onDrag, onDragEnd }: DraggableMarkerProps) {
  const eventHandlers = useMemo(
    () => ({
      drag: (e: L.LeafletEvent) => {
        const marker = e.target;
        const pos = marker.getLatLng();
        onDrag(index, pos);
      },
      dragend: (e: L.LeafletEvent) => {
        const marker = e.target;
        const pos = marker.getLatLng();
        onDragEnd(index, pos);
      },
      click: (e: L.LeafletEvent) => {
        L.DomEvent.stopPropagation(e as any);
      },
    }),
    [index, onDrag, onDragEnd]
  );

  return (
    <Marker
      position={position}
      draggable={true}
      icon={icon}
      eventHandlers={eventHandlers}
    />
  );
}
```

## Callers (1)
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--polygondrawingtool|PolygonDrawingTool]]

## External / unresolved calls (6)
- `getLatLng` ×2
- `useMemo`
- `onDrag`
- `onDragEnd`
- `stopPropagation`
- `Marker`
