---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/sidebar/Sidebar.tsx::s", "s"]
tags: [function, tsx]
file: "frontend/src/pages/sidebar/Sidebar.tsx"
lines: "246-246"
---

# s

**Kind:** Function
**File:** [[file-frontend-src-pages-sidebar-sidebar-tsx|Sidebar.tsx]]  `frontend/src/pages/sidebar/Sidebar.tsx`
**Lines:** 246-246
**Community:** [[com-sidebar-shapefile|sidebar-shapefile]]
**Signature:** `def s()`

## Source

```tsx
      const projects = projectName.split(',').map(s => s.trim()).filter(Boolean);
```

## External / unresolved calls (1)
- `trim` ×3
