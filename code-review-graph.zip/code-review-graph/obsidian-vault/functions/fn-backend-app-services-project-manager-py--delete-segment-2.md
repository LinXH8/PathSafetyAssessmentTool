---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/project_manager.py::Project.delete_segment", "delete_segment"]
tags: [function, python]
file: "backend/app/services/project_manager.py"
lines: "283-319"
---

# delete_segment

**Kind:** Function
**File:** [[file-backend-app-services-project-manager-py|project_manager.py]]  `backend/app/services/project_manager.py`
**Lines:** 283-319
**Community:** [[com-services-project|services-project]]
**Signature:** `def delete_segment((self, index: int))`

## Source

```python
    def delete_segment(self, index: int):
        # 0. Delete Associated Image (from Geo Data info)
        try:
            if self.geo_data.df is not None and index < len(self.geo_data.df):
                row = self.geo_data.df.iloc[index]
                # Try common column names for image reference
                img_ref = None
                for col in ["Image Reference", "image", "img"]:
                    if col in row:
                        img_ref = row[col]
                        break
                
                if img_ref and isinstance(img_ref, str):
                    image_path = self.project_path / global_var.PROJECT_IMAGES_FOLDER / img_ref
                    if image_path.exists() and image_path.is_file():
                        os.remove(image_path)
        except Exception as e:
            print(f"Error deleting image for segment {index}: {e}")

        # Delete from Geo Data
        # Delete from Geo Data
        if self.geo_data.df is not None and index < len(self.geo_data.df):
            self.geo_data.df = self.geo_data.df.drop(index).reset_index(drop=True)
            self.geo_data.df_dirty = True
        
        # Delete from latest version data
        self.latest().delete_segment(index)

        # Update Metadata
        if self.metadata.size is not None and self.metadata.size > 0:
            self.metadata.size -= 1
        
        # We can't easily know if the deleted segment was verified or autocoded without checking previous state
        # But we can re-calculate verified count if needed, or just decrement if we tracked indices
        # For now, let's just save.
        
        self.save_all()
```

## Callees (3)
- [[fn-backend-app-services-project-manager-py--delete-segment|delete_segment]]
- [[fn-backend-app-services-project-manager-py--latest|latest]]
- [[fn-backend-app-services-project-manager-py--save-all|save_all]]

## External / unresolved calls (8)
- `len` ×2
- `isinstance`
- `exists`
- `is_file`
- `remove`
- `print`
- `reset_index`
- `drop`
