---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/AttributesDropdown.tsx::handleAddFilter", "handleAddFilter"]
tags: [function, tsx]
file: "frontend/src/pages/PathAnalysisPage/components/AttributesDropdown.tsx"
lines: "749-756"
---

# handleAddFilter

**Kind:** Function
**File:** [[file-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx|AttributesDropdown.tsx]]  `frontend/src/pages/PathAnalysisPage/components/AttributesDropdown.tsx`
**Lines:** 749-756
**Community:** [[com-components-handle|components-handle]]
**Signature:** `def handleAddFilter(())`

## Source

```tsx
  const handleAddFilter = () => {
    if (selectedAttributes.length < 5) {
      onAttributeChange([...selectedAttributes, null]);
      setInputValues([...inputValues, ""]);
      setOpenComboboxes([...openComboboxes, false]);
      setFilterIds([...filterIds, Math.random().toString(36).substr(2, 9)]);
    }
  };
```

## External / unresolved calls (7)
- `onAttributeChange`
- `setInputValues`
- `setOpenComboboxes`
- `setFilterIds`
- `substr`
- `toString`
- `random`
