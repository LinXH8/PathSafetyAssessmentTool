---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/TreatmentPage/treatmentDetailPage.tsx::getApplicableTreatments", "getApplicableTreatments"]
tags: [function, tsx]
file: "frontend/src/pages/TreatmentPage/treatmentDetailPage.tsx"
lines: "304-306"
---

# getApplicableTreatments

**Kind:** Function
**File:** [[file-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx|treatmentDetailPage.tsx]]  `frontend/src/pages/TreatmentPage/treatmentDetailPage.tsx`
**Lines:** 304-306
**Community:** [[com-treatmentpage-treatment|treatmentpage-treatment]]
**Signature:** `def getApplicableTreatments((attrs: Record<string, any>)) -> : Treatment[]`

## Source

```tsx
const getApplicableTreatments = (attrs: Record<string, any>): Treatment[] => {
  return TREATMENTS.filter(t => isTreatmentApplicable(t, attrs));
};
```

## Callers (3)
- [[fn-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx--row|row]]
- [[fn-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx--t|t]]
- [[fn-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx--treatmentdetailpage|TreatmentDetailPage]]

## External / unresolved calls (1)
- `filter`
