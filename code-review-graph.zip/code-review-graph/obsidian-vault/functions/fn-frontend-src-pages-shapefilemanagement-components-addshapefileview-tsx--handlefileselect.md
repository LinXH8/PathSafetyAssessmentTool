---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/ShapefileManagement/components/AddShapefileView.tsx::handleFileSelect", "handleFileSelect"]
tags: [function, tsx]
file: "frontend/src/pages/ShapefileManagement/components/AddShapefileView.tsx"
lines: "45-50"
---

# handleFileSelect

**Kind:** Function
**File:** [[file-frontend-src-pages-shapefilemanagement-components-addshapefileview-tsx|AddShapefileView.tsx]]  `frontend/src/pages/ShapefileManagement/components/AddShapefileView.tsx`
**Lines:** 45-50
**Community:** [[com-components-handle-3|components-handle]]
**Signature:** `def handleFileSelect((e: React.ChangeEvent<HTMLInputElement>))`

## Source

```tsx
  function handleFileSelect(e: React.ChangeEvent<HTMLInputElement>) {
    if (e.target.files) {
      const selectedFiles = Array.from(e.target.files);
      addFiles(selectedFiles);
    }
  }
```

## Callees (1)
- [[fn-frontend-src-pages-shapefilemanagement-components-addshapefileview-tsx--addfiles|addFiles]]

## External / unresolved calls (1)
- `from`
