---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/CodingPage/components/GeoDataPanel.tsx::getSegmentColor", "getSegmentColor"]
tags: [function, tsx]
file: "frontend/src/pages/CodingPage/components/GeoDataPanel.tsx"
lines: "613-656"
---

# getSegmentColor

**Kind:** Function
**File:** [[file-frontend-src-pages-codingpage-components-geodatapanel-tsx|GeoDataPanel.tsx]]  `frontend/src/pages/CodingPage/components/GeoDataPanel.tsx`
**Lines:** 613-656
**Community:** [[com-components-bounds|components-bounds]]
**Signature:** `def getSegmentColor((segmentIndex: number)) -> : string`

## Source

```tsx
  const getSegmentColor = (segmentIndex: number): string => {
    if (!activeScores || segmentIndex >= activeScores.length) {
      return "#2563EB"; // Default blue if no scores
    }

    const segmentScores = activeScores[segmentIndex];
    if (!segmentScores) {
      return "#2563EB"; // Default blue if no score data for this segment
    }

    const crashTypes = ["BB", "BP", "SB", "VB"];

    let maxRiskLevel = 0; // 0: Low, 1: Med, 2: High, 3: Extreme

    // Find the crash type with the highest risk level
    crashTypes.forEach((crashType) => {
      const score = segmentScores[crashType] || 0;
      let riskLevel = 0;

      if (['BB', 'BP', 'SB'].includes(crashType)) {
        if (score > 20) riskLevel = 3;       // Extreme
        else if (score > 10) riskLevel = 2;  // High
        else if (score >= 5) riskLevel = 1;  // Medium
        else riskLevel = 0;                  // Low
      } else {
        // VB
        if (score > 60) riskLevel = 3;       // Extreme
        else if (score > 25) riskLevel = 2;  // High
        else if (score >= 10) riskLevel = 1; // Medium
        else riskLevel = 0;                  // Low
      }

      if (riskLevel > maxRiskLevel) {
        maxRiskLevel = riskLevel;
      }
    });

    switch (maxRiskLevel) {
      case 3: return RISK_BAND_COLORS.EXTREME;
      case 2: return RISK_BAND_COLORS.HIGH;
      case 1: return RISK_BAND_COLORS.MEDIUM;
      default: return RISK_BAND_COLORS.LOW;
    }
  };
```

## Callers (1)
- [[fn-frontend-src-pages-codingpage-components-geodatapanel-tsx--geodatapanel|GeoDataPanel]]

## External / unresolved calls (2)
- `forEach`
- `includes`
