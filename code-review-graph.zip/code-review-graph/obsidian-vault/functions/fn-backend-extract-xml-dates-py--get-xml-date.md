---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/extract_xml_dates.py::get_xml_date", "get_xml_date"]
tags: [function, python]
file: "backend/extract_xml_dates.py"
lines: "7-21"
---

# get_xml_date

**Kind:** Function
**File:** [[file-backend-extract-xml-dates-py|extract_xml_dates.py]]  `backend/extract_xml_dates.py`
**Lines:** 7-21
**Community:** [[com-backend-xml|backend-xml]]
**Signature:** `def get_xml_date((xml_path))`

## Source

```python
def get_xml_date(xml_path):
    try:
        tree = ET.parse(xml_path)
        root = tree.getroot()
        # Find CreaDate inside Esri tag
        crea_date = root.find('.//CreaDate')
        if crea_date is not None and crea_date.text:
            return crea_date.text
        # Fallback to ModDate
        mod_date = root.find('.//ModDate')
        if mod_date is not None and mod_date.text:
            return mod_date.text
    except Exception as e:
        return f"Error parsing: {e}"
    return None
```

## External / unresolved calls (3)
- `find` ×2
- `parse`
- `getroot`
