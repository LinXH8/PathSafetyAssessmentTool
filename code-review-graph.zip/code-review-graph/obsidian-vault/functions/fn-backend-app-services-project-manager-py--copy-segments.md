---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/project_manager.py::Project.copy_segments", "copy_segments"]
tags: [function, python]
file: "backend/app/services/project_manager.py"
lines: "423-697"
---

# copy_segments

**Kind:** Function
**File:** [[file-backend-app-services-project-manager-py|project_manager.py]]  `backend/app/services/project_manager.py`
**Lines:** 423-697
**Community:** [[com-services-project|services-project]]
**Signature:** `def copy_segments((self, indices: list[int], target_project: 'Project', replace: bool = False))`

## Description

> Copy segments (and their images) specified by indices from self (source) to target_project.

## Source

```python
    def copy_segments(self, indices: list[int], target_project: 'Project', replace: bool = False):
        """
        Copy segments (and their images) specified by indices from self (source) to target_project.
        """
        # 1. Get filtered data from source (latest version + geo_data)
        # We can reuse the logic from search/create_temporary_project but specific to indices
        
        source_geo = self.geo_data.df
        source_attr = self.latest().attributes.df
        source_res = self.latest().results.df
        source_treat = self.latest().treatment.df
        source_imgs = []

        # Validate indices
        valid_indices = [i for i in indices if i < len(source_geo)]
        if not valid_indices:
            return 0

        # Extract rows
        # Extract rows
        # Use reindex instead of iloc to handle cases where other DFs might be shorter than geo_df
        # This aligns everything to valid_indices (based on geo_df), filling missing with NaN
        subset_geo = source_geo.iloc[valid_indices].copy().reset_index(drop=True)
        subset_attr = source_attr.reindex(valid_indices).copy().reset_index(drop=True)
        subset_res = source_res.reindex(valid_indices).copy().reset_index(drop=True)
        
        subset_treat = pd.DataFrame()
        if not source_treat.empty:
             subset_treat = source_treat.reindex(valid_indices).copy().reset_index(drop=True)

        # 1.5 Handle Replacement
        if replace and target_project.geo_data.df is not None and not target_project.geo_data.df.empty:
            target_geo = target_project.geo_data.df
            target_geo = target_project.geo_data.df
            # Update: We need to predict the new image names FIRST because we are going to rename them.
            # Logic: If source image matches "SourceProject_...", rename to "TargetProject_..."
            # Then check if THAT new name exists in target.

            source_name = self.metadata.project_name
            target_name = target_project.metadata.project_name
            
            # Helper to predict name
            def predict_name(img_ref):
                if pd.isna(img_ref): return None
                s_ref = str(img_ref).strip()
                if not s_ref or s_ref.lower() == 'nan': return None
                
                # If starts with source project name (case-insensitive check), replace it
                # Otherwise, PREPEND target project name to enforce convention
                
                # Check 1: Exact match start
                if s_ref.startswith(source_name):
                    return s_ref.replace(source_name, target_name, 1)
                
                # Check 2: Case-insensitive match start
                if s_ref.lower().startswith(source_name.lower()):
                    # Retrieve the actual prefix length and slice
                    old_len = len(source_name)
                    suffix = s_ref[old_len:]
                    # If there was a separator (e.g. _) make sure we don't double it or lose it
                    # But simple concatenation is safest: TargetName + suffix
                    return f"{target_name}{suffix}"

                # Check 3: Force Prepend (if not already starting with target name)
                # If the image doesn't have the source prefix, the user wants it renamed to the new project.
                # e.g. "Cam1.jpg" -> "TargetProject_Cam1.jpg"
                if not s_ref.startswith(target_name):
                     return f"{target_name}_{s_ref}"

                return s_ref


            if "Image Reference" in target_geo.columns:
                # Identify images to replace (using PREDICTED names)
                img_refs_to_replace = set()
                for _, row in subset_geo.iterrows():
                    ref = row.get("Image Reference")
                    predicted = predict_name(ref)
                    if predicted:
                        img_refs_to_replace.add(predicted)
                
                if img_refs_to_replace:
                    # Find indices in target that match these images
                    # We iterate to find indices. 
                    # Note: target_geo index should be RangeIndex 0..N usually
                    # Safe boolean mask: convert target column to string, but handle NaNs carefully
                    # We only care about rows where Image Ref is in our set. 
                    
                    # 1. Ensure target column is treated as string for comparison, but keep index alignment
                    target_refs = target_geo["Image Reference"].astype(str)
                    
                    # 2. Check membership
                    mask = target_refs.isin(img_refs_to_replace)
                    indices_to_delete = target_geo[mask].index.tolist()
                    
                    if indices_to_delete:
                        # Batch delete them from target
                        target_project.delete_segments(indices_to_delete)
                        # Reload target_geo as it has changed
                        # Actually delete_segments modifies df in place (or reassigns it)
                        # But we should rely on the object state update.

        # 2. Copy Images
        # Target Image Directory
        target_img_dir = target_project.project_path / global_var.PROJECT_IMAGES_FOLDER
        if not target_img_dir.exists():
            target_img_dir.mkdir(parents=True, exist_ok=True)

        source_name = self.metadata.project_name
        target_name = target_project.metadata.project_name

        for idx, row in subset_geo.iterrows():
            img_ref = None
            col_name_found = None
            for col in ["Image Reference", "image", "img"]:
                if col in row and pd.notna(row[col]):
                    val = str(row[col]).strip()
                    if val and val.lower() != 'nan':
                        img_ref = val
                        col_name_found = col
                        break
            
            if img_ref:
                # Calculate new name using robust logic
                new_img_ref = img_ref
                
                # Check 1: Exact
                if img_ref.startswith(source_name):
                    new_img_ref = img_ref.replace(source_name, target_name, 1)
                # Check 2: Case insensitive
                elif img_ref.lower().startswith(source_name.lower()):
                    old_len = len(source_name)
                    suffix = img_ref[old_len:]
                    new_img_ref = f"{target_name}{suffix}"
                # Check 3: Force Prepend (if not already starting with target name)
                elif not img_ref.startswith(target_name):
                     new_img_ref = f"{target_name}_{img_ref}"

                # Update the dataframe (subset_geo) with the new name
                # This ensures when we append below, it has the correct reference
                subset_geo.at[idx, col_name_found] = new_img_ref
                # Also update treatment/results if they have the column? 
                # (Treatment has ImageReference, Results usually only lat/lon/scores)
                
                # Check treatment df
                if not subset_treat.empty and idx < len(subset_treat) and "Image Reference" in subset_treat.columns:
                     subset_treat.at[idx, "Image Reference"] = new_img_ref

                source_img_path = self.project_path / global_var.PROJECT_IMAGES_FOLDER / img_ref
                if source_img_path.exists():
                    target_img_path = target_img_dir / new_img_ref
                    shutil.copy2(source_img_path, target_img_path)


        # 3. Append to Target Project
        # Append GeoData
        if target_project.geo_data.df is None or target_project.geo_data.df.empty:
             target_project.geo_data.df = subset_geo
        else:
             target_project.geo_data.df = pd.concat([target_project.geo_data.df, subset_geo], ignore_index=True)
        target_project.geo_data.df_dirty = True

        # Append Attributes
        if target_project.latest().attributes.df is None or target_project.latest().attributes.df.empty:
            target_project.latest().attributes.df = subset_attr
        else:
            target_project.latest().attributes.df = pd.concat([target_project.latest().attributes.df, subset_attr], ignore_index=True)
        target_project.latest().attributes.df_dirty = True

        # Append Results
        if target_project.latest().results.df is None or target_project.latest().results.df.empty:
            target_project.latest().results.df = subset_res
        else:
            target_project.latest().results.df = pd.concat([target_project.latest().results.df, subset_res], ignore_index=True)
        target_project.latest().results.df_dirty = True

        # Append Treatment
        if target_project.latest().treatment.df is None or target_project.latest().treatment.df.empty:
            target_project.latest().treatment.df = subset_treat
        else:
            target_project.latest().treatment.df = pd.concat([target_project.latest().treatment.df, subset_treat], ignore_index=True)
        target_project.latest().treatment.df_dirty = True

        # 4. Update Target Metadata
        count_added = len(valid_indices)
        if target_project.metadata.size is None:
             target_project.metadata.size = 0
        target_project.metadata.size += count_added
        target_project.metadata.last_updated = datetime.datetime.now()
        
        # Save Target
        target_project.save_all()
        target_project.metadata.serialize(target_project.project_path)
        return count_added
        # ================================
        # Get dataframes to filter
        # ================================
        attr_df = self.latest().attributes.df
        treatment_df = self.latest().treatment.df
        results_df = self.latest().results.df
        geo_df = self.geo_data.df

        # ================================
        # Apply filters (AND logic between groups)
        # ================================

        # Start with all True masks
        attr_mask = pd.Series([True] * len(attr_df))
        treat_mask = pd.Series([True] * len(treatment_df))
        result_mask = pd.Series([True] * len(results_df))

        def map_labels_to_values(labels, value_map):
            """Helper to normalize single/multi inputs and map to stored values."""
            if not labels:
                return []
            label_list = labels if isinstance(labels, list) else [labels]
            return [value_map[label] for label in label_list if label in value_map]

        # === Filter attributes (OR per field) ===
        for field, labels in filter_attributes.items():
            if labels:
                value_map = serializer.Attributes.CHOICES.get(field, {})
                mapped_values = map_labels_to_values(labels, value_map)
                attr_mask &= attr_df[field].isin(mapped_values)

        # === TODO Filter treatment ===
        for field_key, values in filter_treatment.items():
            field_name = getattr(serializer.Treatment.Fields, field_key, None)
            if field_name and values:
                treat_mask &= treatment_df[field_name].isin(values)

        # === Filter results ===
        for field, labels in filter_results.items():
            if labels:
                if field in serializer.Results.FIELDS_META:
                    value_map = serializer.Results.FIELDS_META[field]
                    mapped_values = map_labels_to_values(labels, value_map)
                else:
                    mapped_values = labels if isinstance(labels, list) else [labels]

                result_mask &= results_df[field].isin(mapped_values)

        # ================================
        # Combine masks with AND across datasets
        # ================================
        combined_mask = attr_mask & result_mask
        selected_indexes = combined_mask[combined_mask].index

        # ================================
        # Package filtered data
# … (truncated, 25 more lines — see source file)
```

## Callees (6)
- [[fn-backend-app-services-project-manager-py--latest|latest]]
- [[fn-backend-app-services-project-manager-py--predict-name|predict_name]]
- [[fn-backend-app-services-project-manager-py--delete-segments|delete_segments]]
- [[fn-backend-app-services-project-manager-py--save-all|save_all]]
- [[fn-backend-app-services-project-manager-py--map-labels-to-values|map_labels_to_values]]
- [[cls-backend-app-services-project-manager-py--project|Project]]

## External / unresolved calls (33)
- `len` ×7
- `reset_index` ×7
- `copy` ×4
- `isin` ×4
- `concat` ×4
- `reindex` ×3
- `startswith` ×3
- `Series` ×3
- `items` ×3
- `iterrows` ×2
- `get` ×2
- `exists` ×2
- `lower` ×2
- `DataFrame`
- `set`
- `add`
- `astype`
- `tolist`
- `mkdir`
- `notna`
- `strip`
- `str`
- `replace`
- `copy2`
- `now`
- `serialize`
- `getattr`
- `isinstance`
- `Attributes`
- `Treatment`
- *... and 3 more.*
