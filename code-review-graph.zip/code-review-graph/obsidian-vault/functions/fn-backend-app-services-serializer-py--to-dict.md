---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/serializer.py::ProjectMetadata.to_dict", "to_dict"]
tags: [function, python]
file: "backend/app/services/serializer.py"
lines: "418-431"
---

# to_dict

**Kind:** Function
**File:** [[file-backend-app-services-serializer-py|serializer.py]]  `backend/app/services/serializer.py`
**Lines:** 418-431
**Community:** [[com-services-fields|services-fields]]
**Signature:** `def to_dict((self))`

## Source

```python
    def to_dict(self):
        return {
            "project_name": self.project_name,
            "date_created": self.date_created.isoformat() if self.date_created else None,
            "last_updated": self.last_updated.isoformat() if self.last_updated else None,
            "created_by": self.created_by,
            "dataset": self.dataset,
            "progress": self.progress,
            "size": self.size,
            "tags": self.tags,
            "verified": self.verified,
            "verified_segment_count": self.verified_segment_count,
            "autocoded_segment_count": self.autocoded_segment_count
        }
```

## Callers (2)
- [[fn-backend-app-services-serializer-py--serialize-3|serialize]]
- [[fn-backend-app-services-serializer-py--gettrafficspeedbands-df|getTrafficSpeedBands_df]]

## External / unresolved calls (1)
- `isoformat` ×2
