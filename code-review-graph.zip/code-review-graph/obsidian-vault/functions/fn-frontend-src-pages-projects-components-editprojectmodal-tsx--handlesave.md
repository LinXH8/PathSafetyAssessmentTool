---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/Projects/components/EditProjectModal.tsx::handleSave", "handleSave"]
tags: [function, tsx]
file: "frontend/src/pages/Projects/components/EditProjectModal.tsx"
lines: "89-140"
---

# handleSave

**Kind:** Function
**File:** [[file-frontend-src-pages-projects-components-editprojectmodal-tsx|EditProjectModal.tsx]]  `frontend/src/pages/Projects/components/EditProjectModal.tsx`
**Lines:** 89-140
**Community:** [[com-components-tag-2|components-tag]]
**Signature:** `def handleSave(())`

## Source

```tsx
  async function handleSave() {
    if (!newName.trim()) {
      toaster.create({
        title: "Validation Error",
        description: "Project name cannot be empty",
        type: "error",
      });
      return;
    }

    try {
      setSaving(true);
      const updates: { new_name?: string; tags?: string[] } = {};

      // Only send changed fields
      if (newName !== projectName) {
        updates.new_name = newName;
      }
      if (JSON.stringify(tags) !== JSON.stringify(projectTags)) {
        updates.tags = tags;
      }

      if (Object.keys(updates).length === 0) {
        toaster.create({
          title: "No Changes",
          description: "No changes to save",
          type: "info",
        });
        handleClose();
        return;
      }

      const result = await api.updateProject(projectName, updates);

      toaster.create({
        title: "Success",
        description: "Project updated successfully",
        type: "success",
      });

      onSuccess(result.name || newName, result.tags || tags);
      handleClose();
    } catch (error: any) {
      toaster.create({
        title: "Update Failed",
        description: error?.message || "Failed to update project",
        type: "error",
      });
    } finally {
      setSaving(false);
    }
  }
```

## Callees (1)
- [[fn-frontend-src-pages-projects-components-editprojectmodal-tsx--handleclose|handleClose]]

## External / unresolved calls (7)
- `create` ×4
- `setSaving` ×2
- `trim`
- `stringify`
- `keys`
- `updateProject`
- `onSuccess`
