---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/platform_compat.py::get_excel_client", "get_excel_client"]
tags: [function, python]
file: "backend/app/services/platform_compat.py"
lines: "54-65"
---

# get_excel_client

**Kind:** Function
**File:** [[file-backend-app-services-platform-compat-py|platform_compat.py]]  `backend/app/services/platform_compat.py`
**Lines:** 54-65
**Community:** [[com-services-check|services-check]]
**Signature:** `def get_excel_client(())`

## Description

> Get the Excel COM client if available.
>
> Returns:
>     win32com.client module or None
>
> Raises:
>     RuntimeError: If Excel COM is not available on this platform

## Source

```python
def get_excel_client():
    """
    Get the Excel COM client if available.

    Returns:
        win32com.client module or None

    Raises:
        RuntimeError: If Excel COM is not available on this platform
    """
    check_windows_feature("Excel COM automation")
    return win32
```

## Callers (2)
- [[fn-backend-app-services-cyclerap-interface-py--calculate-cyclerap-score|calculate_cycleRAP_score]]
- [[fn-backend-app-services-cyclerap-interface-py--evaluate-treatment-suggestions|evaluate_treatment_suggestions]]

## Callees (1)
- [[fn-backend-app-services-platform-compat-py--check-windows-feature|check_windows_feature]]
