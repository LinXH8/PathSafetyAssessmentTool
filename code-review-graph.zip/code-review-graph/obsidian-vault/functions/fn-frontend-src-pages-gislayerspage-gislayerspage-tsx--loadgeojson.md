---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/GisLayersPage/GisLayersPage.tsx::loadGeoJson", "loadGeoJson"]
tags: [function, tsx]
file: "frontend/src/pages/GisLayersPage/GisLayersPage.tsx"
lines: "64-94"
---

# loadGeoJson

**Kind:** Function
**File:** [[file-frontend-src-pages-gislayerspage-gislayerspage-tsx|GisLayersPage.tsx]]  `frontend/src/pages/GisLayersPage/GisLayersPage.tsx`
**Lines:** 64-94
**Community:** [[com-gislayerspage-layers|gislayerspage-layers]]
**Signature:** `def loadGeoJson(())`

## Source

```tsx
    async function loadGeoJson() {
      try {
        setMapLoading(true);
        setMapError(null);
        
        const res = await fetch("/api/shapefiles/geojson", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ 
            path: selectedLayer!.path,
            max_features: 10000 
          })
        });
        
        if (!res.ok) {
          throw new Error(await res.text().catch(() => "Failed to load map data"));
        }
        
        const data = await res.json();
        if (data.error) throw new Error(data.error);
        
        if (!aborted) {
          setGeojsonData(data);
        }
      } catch (err: any) {
        console.error("Error loading geojson:", err);
        if (!aborted) setMapError(err.message || "Failed to parse shapefile geometry");
      } finally {
        if (!aborted) setMapLoading(false);
      }
    }
```

## Callers (1)
- [[fn-frontend-src-pages-gislayerspage-gislayerspage-tsx--gislayerspage|GisLayersPage]]

## External / unresolved calls (9)
- `setMapLoading` ×2
- `setMapError` ×2
- `fetch`
- `stringify`
- `catch`
- `text`
- `json`
- `setGeojsonData`
- `error`
