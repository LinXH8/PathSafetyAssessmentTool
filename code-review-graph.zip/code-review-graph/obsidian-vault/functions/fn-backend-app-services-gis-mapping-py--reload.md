---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/gis_mapping.py::LayerStore.reload", "reload"]
tags: [function, python]
file: "backend/app/services/gis_mapping.py"
lines: "94-106"
---

# reload

**Kind:** Function
**File:** [[file-backend-app-services-gis-mapping-py|gis_mapping.py]]  `backend/app/services/gis_mapping.py`
**Lines:** 94-106
**Community:** [[com-services-width|services-width]]
**Signature:** `def reload((self, name: str = None))`

## Description

> Force reload of one or all layers by clearing cache and reloading

## Source

```python
    def reload(self, name: str = None):
        """Force reload of one or all layers by clearing cache and reloading"""
        self.clear_cache(name)
        if name is not None:
            # Force reload by accessing the layer
            return self.get(name)
        else:
            # Reload all registered layers
            for layer_name in list(self.paths.keys()):
                try:
                    self.get(layer_name)
                except Exception as e:
                    print(f"Warning: Could not reload layer {layer_name}: {e}")
```

## Callees (2)
- [[fn-backend-app-services-gis-mapping-py--clear-cache|clear_cache]]
- [[fn-backend-app-services-gis-mapping-py--get|get]]

## External / unresolved calls (3)
- `list`
- `keys`
- `print`
