---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/shapefile_validator.py::ShapefileValidator.validate_replacement", "validate_replacement"]
tags: [function, python]
file: "backend/app/services/shapefile_validator.py"
lines: "20-133"
---

# validate_replacement

**Kind:** Function
**File:** [[file-backend-app-services-shapefile-validator-py|shapefile_validator.py]]  `backend/app/services/shapefile_validator.py`
**Lines:** 20-133
**Community:** [[com-services-validate|services-validate]]
**Signature:** `def validate_replacement((
        new_file_path: str,
        old_file_path: str,
        layer_name: Optional[str] = None,
    )) -> Dict`

## Description

> Validate that a new shapefile is compatible with the one being replaced.
>
> Args:
>     new_file_path: Path to new shapefile to validate
>     old_file_path: Path to existing shapefile being replaced
>     layer_name: Layer identifier (e.g., "cycling_path", optional)
>
> Returns:
>     {
>         'valid': bool,                          # True if no errors
>         'errors': List[str],                    # Fatal issues - don't replace
>         'warnings': List[str],                  # Non-fatal issues - warn user
>         'info': Dict,                           # Comparison data
>         'column_mapping': Dict[str, str],      # Mapping of required columns
>     }

## Source

```python
    def validate_replacement(
        new_file_path: str,
        old_file_path: str,
        layer_name: Optional[str] = None,
    ) -> Dict:
        """
        Validate that a new shapefile is compatible with the one being replaced.

        Args:
            new_file_path: Path to new shapefile to validate
            old_file_path: Path to existing shapefile being replaced
            layer_name: Layer identifier (e.g., "cycling_path", optional)

        Returns:
            {
                'valid': bool,                          # True if no errors
                'errors': List[str],                    # Fatal issues - don't replace
                'warnings': List[str],                  # Non-fatal issues - warn user
                'info': Dict,                           # Comparison data
                'column_mapping': Dict[str, str],      # Mapping of required columns
            }
        """
        result = {
            "valid": True,
            "errors": [],
            "warnings": [],
            "info": {},
            "column_mapping": {},
        }

        # Validate files exist
        new_path = Path(new_file_path)
        old_path = Path(old_file_path)

        if not new_path.exists():
            result["errors"].append(f"New file not found: {new_file_path}")
            result["valid"] = False
            return result

        if not old_path.exists():
            result["errors"].append(f"Original file not found: {old_file_path}")
            result["valid"] = False
            return result

        try:
            # Load both shapefiles
            new_gdf = gpd.read_file(new_file_path)
            old_gdf = gpd.read_file(old_file_path)
        except Exception as e:
            result["errors"].append(f"Failed to read shapefile: {str(e)}")
            result["valid"] = False
            return result

        # Get layer definition if available
        layer_def = get_layer_definition(layer_name) if layer_name else None

        # Check 1: CRS Compatibility
        result_crs = ShapefileValidator._validate_crs(new_gdf, old_gdf)
        if result_crs["error"]:
            result["errors"].append(result_crs["error"])
        if result_crs["warning"]:
            result["warnings"].append(result_crs["warning"])
        result["info"]["crs_new"] = str(new_gdf.crs) if new_gdf.crs else "None"
        result["info"]["crs_old"] = str(old_gdf.crs) if old_gdf.crs else "None"

        # Check 2: Geometry Type Compatibility
        result_geom = ShapefileValidator._validate_geometry_type(
            new_gdf, old_gdf, layer_def
        )
        if result_geom["error"]:
            result["errors"].append(result_geom["error"])
        if result_geom["warning"]:
            result["warnings"].append(result_geom["warning"])
        result["info"]["geometry_new"] = result_geom["geometry_type"]
        result["info"]["geometry_old"] = result_geom["geometry_type_old"]

        # Check 3: Required Columns (with alias resolution)
        result_cols = ShapefileValidator._validate_required_columns(
            new_gdf, layer_def
        )
        if result_cols["missing"]:
            result["errors"].append(
                f"Missing required columns: {', '.join(result_cols['missing'])}"
            )
        if result_cols["column_mapping"]:
            result["column_mapping"] = result_cols["column_mapping"]
        if result_cols["warnings"]:
            result["warnings"].extend(result_cols["warnings"])

        result["info"]["columns_new"] = list(new_gdf.columns)
        result["info"]["columns_old"] = list(old_gdf.columns)

        # Check 4: Feature Count
        result_count = ShapefileValidator._validate_feature_count(new_gdf, old_gdf)
        if result_count["warning"]:
            result["warnings"].append(result_count["warning"])
        result["info"]["feature_count_new"] = len(new_gdf)
        result["info"]["feature_count_old"] = len(old_gdf)

        # Check 5: Empty Geometries
        result_empty = ShapefileValidator._validate_empty_geometries(new_gdf)
        if result_empty["warning"]:
            result["warnings"].append(result_empty["warning"])
        result["info"]["empty_geometries_count"] = result_empty["count"]

        # Check 6: Spatial Bounds
        result_bounds = ShapefileValidator._validate_spatial_bounds(new_gdf, old_gdf)
        if result_bounds["warning"]:
            result["warnings"].append(result_bounds["warning"])

        # Determine validity
        result["valid"] = len(result["errors"]) == 0

        return result
```

## Callees (6)
- [[fn-backend-app-services-shapefile-validator-py--validate-crs|_validate_crs]]
- [[fn-backend-app-services-shapefile-validator-py--validate-geometry-type|_validate_geometry_type]]
- [[fn-backend-app-services-shapefile-validator-py--validate-required-columns|_validate_required_columns]]
- [[fn-backend-app-services-shapefile-validator-py--validate-feature-count|_validate_feature_count]]
- [[fn-backend-app-services-shapefile-validator-py--validate-empty-geometries|_validate_empty_geometries]]
- [[fn-backend-app-services-shapefile-validator-py--validate-spatial-bounds|_validate_spatial_bounds]]

## External / unresolved calls (10)
- `append` ×11
- `str` ×3
- `len` ×3
- `Path` ×2
- `exists` ×2
- `read_file` ×2
- `list` ×2
- `get_layer_definition`
- `join`
- `extend`
