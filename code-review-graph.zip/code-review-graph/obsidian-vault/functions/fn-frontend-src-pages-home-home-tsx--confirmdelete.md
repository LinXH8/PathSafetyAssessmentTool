---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/Home/home.tsx::confirmDelete", "confirmDelete"]
tags: [function, tsx]
file: "frontend/src/pages/Home/home.tsx"
lines: "95-114"
---

# confirmDelete

**Kind:** Function
**File:** [[file-frontend-src-pages-home-home-tsx|home.tsx]]  `frontend/src/pages/Home/home.tsx`
**Lines:** 95-114
**Community:** [[com-home-home|home-home]]
**Signature:** `def confirmDelete(())`

## Source

```tsx
  const confirmDelete = async () => {
    if (!selected) return;
    try {
      setDeleting(true);
      setDeleteErr(null);
      await apiDeleteProject(selected);
      // 本地把它从列表移除
      setProjectList((prev) =>
        prev
          ? { projects: prev.projects.filter((n) => n !== selected) }
          : prev
      );
      setSelected(null);
      setOpenDelete(false);
    } catch (e: any) {
      setDeleteErr(e?.message ?? "Delete failed");
    } finally {
      setDeleting(false);
    }
  };
```

## External / unresolved calls (7)
- `setDeleting` ×2
- `setDeleteErr` ×2
- `/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/api/index.ts::apiDeleteProject`
- `setProjectList`
- `filter`
- `setSelected`
- `setOpenDelete`
