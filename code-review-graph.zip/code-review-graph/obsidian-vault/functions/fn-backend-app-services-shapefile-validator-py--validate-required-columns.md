---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/shapefile_validator.py::ShapefileValidator._validate_required_columns", "_validate_required_columns"]
tags: [function, python]
file: "backend/app/services/shapefile_validator.py"
lines: "206-234"
---

# _validate_required_columns

**Kind:** Function
**File:** [[file-backend-app-services-shapefile-validator-py|shapefile_validator.py]]  `backend/app/services/shapefile_validator.py`
**Lines:** 206-234
**Community:** [[com-services-validate|services-validate]]
**Signature:** `def _validate_required_columns((
        gdf: gpd.GeoDataFrame, layer_def: Optional[LayerDefinition]
    )) -> Dict`

## Description

> Check for required columns with alias resolution

## Source

```python
    def _validate_required_columns(
        gdf: gpd.GeoDataFrame, layer_def: Optional[LayerDefinition]
    ) -> Dict:
        """Check for required columns with alias resolution"""
        result = {"missing": [], "column_mapping": {}, "warnings": []}

        if not layer_def or not layer_def.required_columns:
            return result

        gdf_cols = list(gdf.columns)
        gdf_cols_upper = {col.upper(): col for col in gdf_cols}

        for req_col in layer_def.required_columns:
            actual_col = layer_def.get_column_name(req_col, gdf_cols)

            if actual_col:
                # Found the column (either exact match or alias)
                result["column_mapping"][req_col] = actual_col

                if actual_col != req_col:
                    # Column alias was used
                    result["warnings"].append(
                        f"Column '{req_col}' resolved to '{actual_col}' in new file"
                    )
            else:
                # Column not found
                result["missing"].append(req_col)

        return result
```

## Callers (1)
- [[fn-backend-app-services-shapefile-validator-py--validate-replacement|validate_replacement]]

## External / unresolved calls (4)
- `append` ×2
- `list`
- `upper`
- `get_column_name`
