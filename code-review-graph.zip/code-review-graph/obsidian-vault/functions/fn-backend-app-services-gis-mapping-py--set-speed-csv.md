---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/gis_mapping.py::LayerStore.set_speed_csv", "set_speed_csv"]
tags: [function, python]
file: "backend/app/services/gis_mapping.py"
lines: "59-74"
---

# set_speed_csv

**Kind:** Function
**File:** [[file-backend-app-services-gis-mapping-py|gis_mapping.py]]  `backend/app/services/gis_mapping.py`
**Lines:** 59-74
**Community:** [[com-services-width|services-width]]
**Signature:** `def set_speed_csv((self, csv_path: str | Path))`

## Description

> Load and cache the speed CSV data for Road Operating Speed (mean)

## Source

```python
    def set_speed_csv(self, csv_path: str | Path):
        """Load and cache the speed CSV data for Road Operating Speed (mean)"""
        csv_path = Path(csv_path)
        if not csv_path.exists():
            raise FileNotFoundError(f"Speed CSV not found: {csv_path}")

        # Read CSV - first row contains headers
        df = pd.read_csv(csv_path)

        # Convert LINKID to string for matching
        if 'LINKID' in df.columns:
            df['LINKID'] = df['LINKID'].astype(str)
            # Index by LINKID for quick lookup
            self.speed_data = df.set_index('LINKID')
        else:
            raise ValueError(f"Speed CSV missing LINKID column. Found columns: {df.columns.tolist()}")
```

## Callers (1)
- [[fn-backend-app-services-gis-mapping-py--default|default]]

## External / unresolved calls (8)
- `Path`
- `exists`
- `FileNotFoundError`
- `read_csv`
- `astype`
- `set_index`
- `ValueError`
- `tolist`
