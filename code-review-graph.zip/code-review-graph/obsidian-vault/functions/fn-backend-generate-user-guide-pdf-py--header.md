---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/generate_user_guide_pdf.py::PDF.header", "header"]
tags: [function, python]
file: "backend/generate_user_guide_pdf.py"
lines: "5-10"
---

# header

**Kind:** Function
**File:** [[file-backend-generate-user-guide-pdf-py|generate_user_guide_pdf.py]]  `backend/generate_user_guide_pdf.py`
**Lines:** 5-10
**Community:** [[com-backend-pdf|backend-pdf]]
**Signature:** `def header((self))`

## Source

```python
    def header(self):
        self.set_font('helvetica', 'B', 15)
        self.cell(0, 10, 'Path Safety Assessment Tool (PSAT)', ln=True, align='C')
        self.set_font('helvetica', 'I', 11)
        self.cell(0, 10, 'User Guide', ln=True, align='C')
        self.ln(10)
```

## External / unresolved calls (3)
- `set_font` ×2
- `cell` ×2
- `ln`
