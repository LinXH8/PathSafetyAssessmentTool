---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/prediction.py::CycleRAP_Coding_Helper._safe_fuse", "_safe_fuse"]
tags: [function, python]
file: "backend/app/services/prediction.py"
lines: "40-44"
---

# _safe_fuse

**Kind:** Function
**File:** [[file-backend-app-services-prediction-py|prediction.py]]  `backend/app/services/prediction.py`
**Lines:** 40-44
**Community:** [[com-services-compute|services-compute]]
**Signature:** `def _safe_fuse((self, verbose=True))`

## Source

```python
        def _safe_fuse(self, verbose=True):
            try:
                return _orig_fuse(self, verbose=verbose)
            except AttributeError:
                return self
```

## External / unresolved calls (1)
- `_orig_fuse`
