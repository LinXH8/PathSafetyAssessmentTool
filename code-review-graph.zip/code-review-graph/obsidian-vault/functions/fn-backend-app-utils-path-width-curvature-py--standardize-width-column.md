---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/utils/path_width_curvature.py::standardize_width_column", "standardize_width_column"]
tags: [function, python]
file: "backend/app/utils/path_width_curvature.py"
lines: "47-78"
---

# standardize_width_column

**Kind:** Function
**File:** [[file-backend-app-utils-path-width-curvature-py|path_width_curvature.py]]  `backend/app/utils/path_width_curvature.py`
**Lines:** 47-78
**Community:** [[com-utils-width|utils-width]]
**Signature:** `def standardize_width_column((gdf: gpd.GeoDataFrame)) -> gpd.GeoDataFrame`

## Description

> Normalize any column representing width into 'WIDTH' (float).
> If none found, create 'WIDTH' with NaN.

## Source

```python
def standardize_width_column(gdf: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    """
    Normalize any column representing width into 'WIDTH' (float).
    If none found, create 'WIDTH' with NaN.
    """
    if gdf is None or gdf.empty:
        return gdf

    candidates = [
        "WIDTH", "width", "Width",
        "PATH_WIDTH", "path_width", "Path_Width",
        "L_WIDTH", "R_WIDTH", "AVG_WIDTH", "avg_width",
        "Wdth", "WID", "Width_m", "WIDTH_M"
    ]

    found = None
    lower_cols = {c.lower(): c for c in gdf.columns}
    for c in candidates:
        if c in gdf.columns:
            found = c
            break
        if c.lower() in lower_cols:
            found = lower_cols[c.lower()]
            break

    if found is None:
        gdf["WIDTH"] = np.nan
    else:
        if found != "WIDTH":
            gdf = gdf.rename(columns={found: "WIDTH"})
        gdf["WIDTH"] = pd.to_numeric(gdf["WIDTH"], errors="coerce")
    return gdf
```

## Callers (1)
- [[fn-backend-app-utils-path-width-curvature-py--load-layer|load_layer]]

## External / unresolved calls (3)
- `lower` ×3
- `rename`
- `to_numeric`
