---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/ShapefileManagement/components/ReplaceShapefileView.tsx::handleDragLeave", "handleDragLeave"]
tags: [function, tsx]
file: "frontend/src/pages/ShapefileManagement/components/ReplaceShapefileView.tsx"
lines: "36-40"
---

# handleDragLeave

**Kind:** Function
**File:** [[file-frontend-src-pages-shapefilemanagement-components-replaceshapefileview-tsx|ReplaceShapefileView.tsx]]  `frontend/src/pages/ShapefileManagement/components/ReplaceShapefileView.tsx`
**Lines:** 36-40
**Community:** [[com-components-handle-4|components-handle]]
**Signature:** `def handleDragLeave((e: React.DragEvent))`

## Source

```tsx
  function handleDragLeave(e: React.DragEvent) {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
  }
```

## External / unresolved calls (3)
- `preventDefault`
- `stopPropagation`
- `setDragActive`
