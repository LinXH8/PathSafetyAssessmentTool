---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/AnalysisPage/components/MapView.tsx::SetViewOnLoad", "SetViewOnLoad"]
tags: [function, tsx]
file: "frontend/src/pages/AnalysisPage/components/MapView.tsx"
lines: "12-20"
---

# SetViewOnLoad

**Kind:** Function
**File:** [[file-frontend-src-pages-analysispage-components-mapview-tsx|MapView.tsx]]  `frontend/src/pages/AnalysisPage/components/MapView.tsx`
**Lines:** 12-20
**Community:** [[com-components-view|components-view]]
**Signature:** `def SetViewOnLoad(())`

## Source

```tsx
function SetViewOnLoad() {
  const map = useMap();

  useEffect(() => {
    map.setView(SINGAPORE_CENTER, DEFAULT_ZOOM);
  }, [map]);

  return null;
}
```

## Callers (1)
- [[fn-frontend-src-pages-analysispage-components-mapview-tsx--mapview|MapView]]

## External / unresolved calls (3)
- `useMap`
- `useEffect`
- `setView`
