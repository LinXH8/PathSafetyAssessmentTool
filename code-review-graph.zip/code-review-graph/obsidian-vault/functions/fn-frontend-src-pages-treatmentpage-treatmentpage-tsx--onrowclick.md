---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/TreatmentPage/treatmentPage.tsx::onRowClick", "onRowClick"]
tags: [function, tsx]
file: "frontend/src/pages/TreatmentPage/treatmentPage.tsx"
lines: "127-138"
---

# onRowClick

**Kind:** Function
**File:** [[file-frontend-src-pages-treatmentpage-treatmentpage-tsx|treatmentPage.tsx]]  `frontend/src/pages/TreatmentPage/treatmentPage.tsx`
**Lines:** 127-138
**Community:** [[com-treatmentpage-tag|treatmentpage-tag]]
**Signature:** `def onRowClick((name: string))`

## Source

```tsx
  const onRowClick = (name: string) => {
    setSelected(prev => {
      const newSet = new Set(prev);
      if (newSet.has(name)) {
        newSet.delete(name);
      } else {
        newSet.add(name);
      }

      return newSet;
    });
  };
```

## Callers (1)
- [[fn-frontend-src-pages-treatmentpage-treatmentpage-tsx--treatmentpage|TreatmentPage]]

## External / unresolved calls (1)
- `setSelected`
