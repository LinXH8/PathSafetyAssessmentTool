---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx::handlePolygonPoint", "handlePolygonPoint"]
tags: [function, tsx]
file: "frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx"
lines: "346-348"
---

# handlePolygonPoint

**Kind:** Function
**File:** [[file-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx|PathAnalysisMapView.tsx]]  `frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx`
**Lines:** 346-348
**Community:** [[com-components-handle-2|components-handle]]
**Signature:** `def handlePolygonPoint((latlng: L.LatLng))`

## Source

```tsx
  const handlePolygonPoint = (latlng: L.LatLng) => {
    setPolygonPoints((prev) => [...prev, [latlng.lat, latlng.lng]]);
  };
```

## Callers (1)
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--attributeanalysismapview|AttributeAnalysisMapView]]

## External / unresolved calls (1)
- `setPolygonPoints`
