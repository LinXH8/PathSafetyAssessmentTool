---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/utils/path_width_curvature.py::get_radius_and_width_at_point", "get_radius_and_width_at_point"]
tags: [function, python]
file: "backend/app/utils/path_width_curvature.py"
lines: "357-385"
---

# get_radius_and_width_at_point

**Kind:** Function
**File:** [[file-backend-app-utils-path-width-curvature-py|path_width_curvature.py]]  `backend/app/utils/path_width_curvature.py`
**Lines:** 357-385
**Community:** [[com-utils-width|utils-width]]
**Signature:** `def get_radius_and_width_at_point((
    point: Point,
    start_radius: float = 1.0,
    max_radius: float = 5.0,
    step: float = 1.0,
    priority: Optional[List[str]] = None,
    collect_radius: float = 5.0,   # local window for curvature (meters)
    sample_half_window: float = 1.0, # used here as densify_step (meters); set 0 to disable
    base_dir: Optional[str] = None  # base directory for shapefiles
)) -> tuple[Optional[float], Optional[float]]`

## Description

> Returns (R, W):
> - W is the first-found width by priority while scanning rings.
> - R is the **minimum** radius (sharpest turn) computed only from the layer that gave W,
>   using only features within `collect_radius` meters of the point.
> - `sample_half_window` is used as densify step; 0 disables densify.
> - `base_dir` is the base directory for shapefile paths (optional).

## Source

```python
def get_radius_and_width_at_point(
    point: Point,
    start_radius: float = 1.0,
    max_radius: float = 5.0,
    step: float = 1.0,
    priority: Optional[List[str]] = None,
    collect_radius: float = 5.0,   # local window for curvature (meters)
    sample_half_window: float = 1.0, # used here as densify_step (meters); set 0 to disable
    base_dir: Optional[str] = None  # base directory for shapefiles
) -> tuple[Optional[float], Optional[float]]:
    """
    Returns (R, W):
    - W is the first-found width by priority while scanning rings.
    - R is the **minimum** radius (sharpest turn) computed only from the layer that gave W,
      using only features within `collect_radius` meters of the point.
    - `sample_half_window` is used as densify step; 0 disables densify.
    - `base_dir` is the base directory for shapefile paths (optional).
    """
    gdf_cycling = load_layer("path/CyclingpathCentreline.shp", base_dir=base_dir)
    gdf_foot    = load_layer("path/Footpathcentreline.shp", base_dir=base_dir)
    gdf_share   = load_layer("path/Sharedpathcentreline.shp", base_dir=base_dir)
    layers = {"cycling": gdf_cycling, "footpath": gdf_foot, "shared": gdf_share}

    return _nearest_radius_and_width_with_priority(
        point, layers, start_radius, max_radius, step,
        priority=priority,
        collect_radius=collect_radius,
        sample_half_window=sample_half_window,
    )
```

## Callers (4)
- [[fn-backend-app-services-gis-mapping-py--get-curvature|get_curvature]]
- [[fn-backend-app-services-gis-mapping-py--get-curvature-visualization|get_curvature_visualization]]
- [[fn-backend-app-services-gis-mapping-py--get-facility-width|get_facility_width]]
- [[fn-backend-app-utils-path-width-curvature-py--get-width-at-point|get_width_at_point]]

## Callees (2)
- [[fn-backend-app-utils-path-width-curvature-py--load-layer|load_layer]]
- [[fn-backend-app-utils-path-width-curvature-py--nearest-radius-and-width-with-priority|_nearest_radius_and_width_with_priority]]
