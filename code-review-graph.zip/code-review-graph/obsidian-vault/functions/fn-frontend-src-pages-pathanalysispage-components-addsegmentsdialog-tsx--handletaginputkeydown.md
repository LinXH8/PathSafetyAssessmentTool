---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/AddSegmentsDialog.tsx::handleTagInputKeyDown", "handleTagInputKeyDown"]
tags: [function, tsx]
file: "frontend/src/pages/PathAnalysisPage/components/AddSegmentsDialog.tsx"
lines: "107-118"
---

# handleTagInputKeyDown

**Kind:** Function
**File:** [[file-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx|AddSegmentsDialog.tsx]]  `frontend/src/pages/PathAnalysisPage/components/AddSegmentsDialog.tsx`
**Lines:** 107-118
**Community:** [[com-components-tag|components-tag]]
**Signature:** `def handleTagInputKeyDown((e: KeyboardEvent<HTMLInputElement>))`

## Source

```tsx
    const handleTagInputKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
        if (e.key === "," || e.key === "Enter") {
            e.preventDefault();
            const trimmedTag = tagInput.trim();
            if (trimmedTag && !tags.includes(trimmedTag)) {
                setTags([...tags, trimmedTag]);
            }
            setTagInput("");
        } else if (e.key === "Backspace" && tagInput === "" && tags.length > 0) {
            setTags(tags.slice(0, -1));
        }
    };
```

## External / unresolved calls (6)
- `setTags` ×2
- `preventDefault`
- `trim`
- `includes`
- `setTagInput`
- `slice`
