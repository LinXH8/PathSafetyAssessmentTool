---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/projects/routes.py::get_All_Img_Folder", "get_All_Img_Folder"]
tags: [function, python]
file: "backend/app/api/projects/routes.py"
lines: "2168-2193"
---

# get_All_Img_Folder

**Kind:** Function
**File:** [[file-backend-app-api-projects-routes-py|routes.py]]  `backend/app/api/projects/routes.py`
**Lines:** 2168-2193
**Community:** [[com-projects-treatments|projects-treatments]]
**Signature:** `def get_All_Img_Folder((folder_path, filename_df, imagePath))`

## Description

> folder_path:      Source folder containing the .jpg files to copy
> filename_df:      DataFrame containing a FILENAME column
> imagePath:        Destination path to save; will be created if not present

## Source

```python
def get_All_Img_Folder(folder_path, filename_df, imagePath):
    """
    folder_path:      Source folder containing the .jpg files to copy
    filename_df:      DataFrame containing a FILENAME column
    imagePath:        Destination path to save; will be created if not present
    """
    # 1. Validate source folder
    if not os.path.isdir(folder_path):
        raise FileNotFoundError(f"The folder at {folder_path} does not exist or is not a directory.")
    
    # 2. Ensure destination folder exists
    os.makedirs(imagePath, exist_ok=True)
    
    # 3. Copy by names in the FILENAME column
    for img_name in filename_df['FILENAME']:
        src = os.path.join(folder_path, img_name)
        dst = os.path.join(imagePath, img_name)
        
        if os.path.isfile(src):
            shutil.copy2(src, dst)
        else:
            # Similar to the Zip version: record missing files
            print(f"Image {img_name} not found in folder {folder_path}.")
    
    # 4. Return the original DataFrame for downstream use
    return filename_df
```

## Callers (1)
- [[fn-backend-app-api-projects-routes-py--create-project-from-folder|create_project_from_folder]]

## External / unresolved calls (7)
- `join` ×2
- `isdir`
- `FileNotFoundError`
- `makedirs`
- `isfile`
- `copy2`
- `print`
