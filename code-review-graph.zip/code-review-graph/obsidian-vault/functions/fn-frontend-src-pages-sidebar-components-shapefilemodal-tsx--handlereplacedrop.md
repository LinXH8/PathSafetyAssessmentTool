---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/sidebar/components/ShapefileModal.tsx::handleReplaceDrop", "handleReplaceDrop"]
tags: [function, tsx]
file: "frontend/src/pages/sidebar/components/ShapefileModal.tsx"
lines: "220-229"
---

# handleReplaceDrop

**Kind:** Function
**File:** [[file-frontend-src-pages-sidebar-components-shapefilemodal-tsx|ShapefileModal.tsx]]  `frontend/src/pages/sidebar/components/ShapefileModal.tsx`
**Lines:** 220-229
**Community:** [[com-components-handle-7|components-handle]]
**Signature:** `def handleReplaceDrop((e: React.DragEvent))`

## Source

```tsx
  function handleReplaceDrop(e: React.DragEvent) {
    e.preventDefault();
    e.stopPropagation();
    setReplaceDragActive(false);

    const droppedFiles = Array.from(e.dataTransfer.files);
    if (droppedFiles.length > 0) {
      validateAndSetReplaceFiles(droppedFiles);
    }
  }
```

## Callees (1)
- [[fn-frontend-src-pages-sidebar-components-shapefilemodal-tsx--validateandsetreplacefiles|validateAndSetReplaceFiles]]

## External / unresolved calls (4)
- `preventDefault`
- `stopPropagation`
- `setReplaceDragActive`
- `from`
