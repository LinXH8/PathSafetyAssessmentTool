---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/projects/routes.py::apply_treatments", "apply_treatments"]
tags: [function, python]
file: "backend/app/api/projects/routes.py"
lines: "1210-1349"
---

# apply_treatments

**Kind:** Function
**File:** [[file-backend-app-api-projects-routes-py|routes.py]]  `backend/app/api/projects/routes.py`
**Lines:** 1210-1349
**Community:** [[com-projects-treatments|projects-treatments]]
**Signature:** `def apply_treatments((project_name: str))`

## Description

> Apply selected treatments to a specific segment.
>
> Request body:
>     {
>         "segment_index": 5,
>         "treatment_ids": [1, 9, 14],
>         "image_ref": "FERNVALE_001.jpg"  // Optional, for tracking
>     }
>
> Response:
>     {
>         "ok": true,
>         "segment_index": 5,
>         "treatments_applied": "1,9,14",
>         "modified_attributes": { "Facility Type": 4, ... },
>         "before_scores": { "BB": 2.5, "BP": 1.2, "SB": 3.1, "VB": 5.8, "Overall Risk Level": 12.6 },
>         "after_scores": { "BB": 1.8, "BP": 0.9, "SB": 2.2, "VB": 3.5, "Overall Risk Level": 8.4 }
>     }

## Source

```python
def apply_treatments(project_name: str):
    """
    Apply selected treatments to a specific segment.

    Request body:
        {
            "segment_index": 5,
            "treatment_ids": [1, 9, 14],
            "image_ref": "FERNVALE_001.jpg"  // Optional, for tracking
        }

    Response:
        {
            "ok": true,
            "segment_index": 5,
            "treatments_applied": "1,9,14",
            "modified_attributes": { "Facility Type": 4, ... },
            "before_scores": { "BB": 2.5, "BP": 1.2, "SB": 3.1, "VB": 5.8, "Overall Risk Level": 12.6 },
            "after_scores": { "BB": 1.8, "BP": 0.9, "SB": 2.2, "VB": 3.5, "Overall Risk Level": 8.4 }
        }
    """
    try:
        ctx = get_ctx()
        proj: Project = ctx["pm"].project(project_name)
        ver = proj.latest()

        data = request.get_json(silent=True) or {}
        segment_index = data.get("segment_index")
        treatment_ids = data.get("treatment_ids", [])
        image_ref = data.get("image_ref", "")

        if segment_index is None:
            return fail("Missing segment_index", 400)

        if not isinstance(treatment_ids, list):
            return fail("treatment_ids must be a list", 400)

        # Load original attributes
        attrs_df = ver.attributes.df
        if segment_index >= len(attrs_df):
            return fail(f"Segment index {segment_index} out of range", 400)

        original_row = dict(attrs_df.iloc[segment_index])

        # Apply treatment effects
        modified_row = original_row.copy()
        for treatment_id in treatment_ids:
            if not (1 <= treatment_id <= 25):
                return fail(f"Invalid treatment ID: {treatment_id}", 400)
            treatment = TREATMENTS[treatment_id - 1]  # Convert 1-based to 0-based
            for attr_name, new_value in treatment['effects'].items():
                modified_row[attr_name] = new_value

        # Calculate before scores (from original attributes)
        original_df = pd.DataFrame([original_row])
        before_scores_df = calculate_cyclerap_score_native(original_df)
        before_scores = {
            "BB": float(before_scores_df["BB"].iloc[0]),
            "BP": float(before_scores_df["BP"].iloc[0]),
            "SB": float(before_scores_df["SB"].iloc[0]),
            "VB": float(before_scores_df["VB"].iloc[0]),
            "Overall Risk Level": float(before_scores_df["Overall Risk Level"].iloc[0])
        }

        # Calculate after scores (from modified attributes)
        modified_df = pd.DataFrame([modified_row])
        after_scores_df = calculate_cyclerap_score_native(modified_df)
        after_scores = {
            "BB": float(after_scores_df["BB"].iloc[0]),
            "BP": float(after_scores_df["BP"].iloc[0]),
            "SB": float(after_scores_df["SB"].iloc[0]),
            "VB": float(after_scores_df["VB"].iloc[0]),
            "Overall Risk Level": float(after_scores_df["Overall Risk Level"].iloc[0])
        }

        # Convert modified_row values to JSON-serializable types
        serializable_modified_row = {}
        for col, val in modified_row.items():
            if pd.notna(val):
                try:
                    if hasattr(val, 'item'):  # numpy/pandas scalar
                        serializable_modified_row[col] = val.item()
                    else:
                        serializable_modified_row[col] = val
                except (ValueError, TypeError):
                    serializable_modified_row[col] = None
            else:
                serializable_modified_row[col] = None

        # Update or create treatment.csv
        treatment_df = ver.treatment.df

        # Ensure treatment dataframe has all attribute columns
        for col in attrs_df.columns:
            if col not in treatment_df.columns:
                treatment_df[col] = ""

        # Ensure the treatment.csv has enough rows
        if len(treatment_df) <= segment_index:
            # Need to expand the dataframe
            new_rows = [treatment_df.iloc[0].copy() if len(treatment_df) > 0 else {}] * (segment_index - len(treatment_df) + 1)
            treatment_df = pd.concat([treatment_df, pd.DataFrame(new_rows)], ignore_index=True)

        # Update the row with modified attributes
        for col in modified_row.keys():
            if col in treatment_df.columns:
                treatment_df.at[segment_index, col] = modified_row[col]

        # Update "Treatments Applied" column
        if "Treatments Applied" not in treatment_df.columns:
            treatment_df.insert(0, "Treatments Applied", "")

        if treatment_ids:
            treatment_df.at[segment_index, "Treatments Applied"] = ",".join(str(tid) for tid in treatment_ids)
        else:
            treatment_df.at[segment_index, "Treatments Applied"] = ""

        # Save updated treatment.csv
        ver._treatment = serializer.Treatment()
        ver.treatment.df = treatment_df
        ver.treatment.df_dirty = True
        proj.save_all()

        # Update last_updated
        proj.metadata.last_updated = datetime.datetime.now()
        proj.metadata.serialize(proj.project_path)

        return jsonify({
            "ok": True,
            "segment_index": segment_index,
            "treatments_applied": ",".join(str(tid) for tid in treatment_ids),
            "modified_attributes": serializable_modified_row,
            "before_scores": before_scores,
            "after_scores": after_scores
        })

    except Exception as e:
        import traceback
        traceback.print_exc()
        return fail(f"Error applying treatments: {str(e)}", 500)
```

## Callees (3)
- [[fn-backend-app-api-projects-routes-py--get-ctx|get_ctx]]
- [[fn-backend-app-api-projects-routes-py--fail|fail]]
- [[fn-backend-app-services-cyclerap-scoring-py--calculate-cyclerap-score-native|calculate_cyclerap_score_native]]

## External / unresolved calls (25)
- `float` ×10
- `get` ×3
- `len` ×3
- `DataFrame` ×3
- `str` ×3
- `copy` ×2
- `items` ×2
- `join` ×2
- `project`
- `latest`
- `get_json`
- `isinstance`
- `dict`
- `notna`
- `hasattr`
- `item`
- `concat`
- `keys`
- `insert`
- `Treatment`
- `save_all`
- `now`
- `serialize`
- `jsonify`
- `print_exc`
