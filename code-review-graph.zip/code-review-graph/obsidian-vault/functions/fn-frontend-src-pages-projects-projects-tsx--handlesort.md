---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/Projects/projects.tsx::handleSort", "handleSort"]
tags: [function, tsx]
file: "frontend/src/pages/Projects/projects.tsx"
lines: "328-358"
---

# handleSort

**Kind:** Function
**File:** [[file-frontend-src-pages-projects-projects-tsx|projects.tsx]]  `frontend/src/pages/Projects/projects.tsx`
**Lines:** 328-358
**Community:** [[com-projects-tag|projects-tag]]
**Signature:** `def handleSort((key: string, event: React.MouseEvent))`

## Source

```tsx
  const handleSort = (key: string, event: React.MouseEvent) => {
    setSortConfig(current => {
      const isShift = event.shiftKey;
      const existingIndex = current.findIndex(c => c.key === key);

      // If user holds Shift, we are doing multi-column sort
      if (isShift) {
        // If sorting by this key already exists
        if (existingIndex !== -1) {
          // Toggle direction
          const newConfig = [...current];
          newConfig[existingIndex] = {
            ...newConfig[existingIndex],
            direction: newConfig[existingIndex].direction === 'asc' ? 'desc' : 'asc'
          };
          return newConfig;
        } else {
          // Add new sort criterion to the end
          return [...current, { key, direction: 'desc' }];
        }
      } else {
        // Single column sort (replace everything)
        // If clicking the same column that is currently primary, toggle it
        if (current.length > 0 && current[0].key === key) {
          return [{ key, direction: current[0].direction === 'asc' ? 'desc' : 'asc' }];
        }
        // Otherwise start fresh with this column descending
        return [{ key, direction: 'desc' }];
      }
    });
  };
```

## Callers (1)
- [[fn-frontend-src-pages-projects-projects-tsx--renderheader|renderHeader]]

## External / unresolved calls (1)
- `setSortConfig`
