---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/prediction.py::CycleRAP_Coding_Helper._convert_to_coded", "_convert_to_coded"]
tags: [function, python]
file: "backend/app/services/prediction.py"
lines: "421-471"
---

# _convert_to_coded

**Kind:** Function
**File:** [[file-backend-app-services-prediction-py|prediction.py]]  `backend/app/services/prediction.py`
**Lines:** 421-471
**Community:** [[com-services-compute|services-compute]]
**Signature:** `def _convert_to_coded((attrs: dict[str, str])) -> dict[str, int | None]`

## Source

```python
    def _convert_to_coded(attrs: dict[str, str]) -> dict[str, int | None]:
        F = serializer.Attributes.Fields

        # Map from assign_attributes keys → serializer field constants
        field_map = {
            "Facility Type":                    F.FACILITY_TYPE_STR,
            "Light Segregation":                F.LIGHT_SEGREGATION_STR,
            "Delineation":                      F.DELINEATION_STR,
            "Adjacent Road Lane 0-1m":          F.ADJ_ROAD_LANE_01M_STR,
            "Adjacent Road Lane 1-3m":          F.ADJ_ROAD_LANE_13M_STR,
            "Adjacent Object/Level Change 0-1m": F.ADJ_OBJ_LVL_CHGE_01M_STR,
            "Adjacent Object/Level Change 1-3m": F.ADJ_OBJ_LVL_CHGE_13M_STR,
            "Adjacent Sidewalk 0-1m":           F.ADJ_SIDEWALK_01M_STR,
            "Crossing Facility":                F.CROSS_FACILITY_STR,
            "Crossing Type":                    F.CROSSING_TYPE_STR,
            "Width Restriction":               F.WIDTH_RESTRICTION_STR,
            "Peak Pedestrian Flow":            F.PEAK_PED_FLOW_STR,
            "Intersection/Road Crossing":       F.INTERSECT_ROAD_CROSS_STR,
            "No of Lanes on Intersecting Road": F.NOL_INTERSECT_ROAD_STR,
            "Fixed Obstacles":                 F.FIXED_OBSTACLE_STR,
            "Non-Fixed Obstacles":             F.NON_FIXED_OBSTACLE_STR,
            "FO Type":                         F.FIXED_OBSTACLE_TYPE_STR,
            "NFO Type":                        F.NON_FIXED_OBSTACLE_TYPE_STR,
        }

        # Value converters per field
        nol_map = {
            "1 per direction":  serializer.NoL_mapping["1 per Direction/NA"],
            ">1 per direction": serializer.NoL_mapping["> 1 per Direction"],
        }

        coded = dict.fromkeys(serializer.Attributes.Fields.values(), None)

        for raw_key, field_key in field_map.items():
            value = attrs.get(raw_key)
            if value is None:
                continue

            if field_key == F.FACILITY_TYPE_STR:
                coded[field_key] = serializer.facility_type_mapping.get(value)
            elif field_key == F.PEAK_PED_FLOW_STR:
                coded[field_key] = serializer.none_low_modhigh_mapping.get(value)
            elif field_key == F.NOL_INTERSECT_ROAD_STR:
                coded[field_key] = nol_map.get(value)
            elif field_key in [F.FIXED_OBSTACLE_TYPE_STR, F.NON_FIXED_OBSTACLE_TYPE_STR, F.CROSSING_TYPE_STR]:
                coded[field_key] = value
            else:
                # All remaining fields use presence_mapping
                coded[field_key] = serializer.presence_mapping.get(value)

        return coded
```

## Callers (1)
- [[fn-backend-app-services-prediction-py--autocode|autocode]]

## External / unresolved calls (4)
- `get` ×5
- `fromkeys`
- `values`
- `items`
