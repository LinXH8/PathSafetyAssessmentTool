---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/AnalysisPanel.tsx::v", "v"]
tags: [function, tsx]
file: "frontend/src/components/visualization/AnalysisPanel.tsx"
lines: "297-297"
---

# v

**Kind:** Function
**File:** [[file-frontend-src-components-visualization-analysispanel-tsx|AnalysisPanel.tsx]]  `frontend/src/components/visualization/AnalysisPanel.tsx`
**Lines:** 297-297
**Community:** [[com-visualization-width|visualization-width]]
**Signature:** `def v()`

## Source

```tsx
              onClick={() => setShowDiag(v => !v)}
```
