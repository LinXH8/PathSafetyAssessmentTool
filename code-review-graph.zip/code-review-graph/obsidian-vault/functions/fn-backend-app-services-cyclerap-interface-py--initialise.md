---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/cycleRAP_interface.py::cycleRAP_interface.initialise", "initialise"]
tags: [function, python]
file: "backend/app/services/cycleRAP_interface.py"
lines: "30-39"
---

# initialise

**Kind:** Function
**File:** [[file-backend-app-services-cyclerap-interface-py|cycleRAP_interface.py]]  `backend/app/services/cycleRAP_interface.py`
**Lines:** 30-39
**Community:** [[com-services-cycle|services-cycle]]
**Signature:** `def initialise((cls, source_dir : Path))`

## Source

```python
    def initialise(cls, source_dir : Path):
        cls.source_dir : Path = source_dir

        cls.attribute_default_values : dict[str, int] = None
        cls.treatment_solutions : pd.DataFrame = None

        path = cls.source_dir / DEFAULT_VALUES_SOURCE
        if not path.exists():
            cls._write_default_config(path)
        cls._parse(path)
```

## Callees (2)
- [[fn-backend-app-services-cyclerap-interface-py--write-default-config|_write_default_config]]
- [[fn-backend-app-services-cyclerap-interface-py--parse|_parse]]

## External / unresolved calls (1)
- `exists`
