---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/sidebar/components/ShapefileModal.tsx::handleAddUpload", "handleAddUpload"]
tags: [function, tsx]
file: "frontend/src/pages/sidebar/components/ShapefileModal.tsx"
lines: "151-199"
---

# handleAddUpload

**Kind:** Function
**File:** [[file-frontend-src-pages-sidebar-components-shapefilemodal-tsx|ShapefileModal.tsx]]  `frontend/src/pages/sidebar/components/ShapefileModal.tsx`
**Lines:** 151-199
**Community:** [[com-components-handle-7|components-handle]]
**Signature:** `def handleAddUpload(())`

## Source

```tsx
  async function handleAddUpload() {
    const categoryToUse = selectedCategory === "__new__" ? newCategoryName : selectedCategory;

    if (!categoryToUse) {
      toaster.create({
        description: "Please select or enter a category",
        type: "warning",
      });
      return;
    }

    if (uploadFiles.length === 0) {
      toaster.create({
        description: "Please select files to upload",
        type: "warning",
      });
      return;
    }

    try {
      setUploading(true);
      const result = await api.uploadShapefiles(uploadFiles, categoryToUse);

      if (result.errors.length > 0) {
        toaster.create({
          description: `Uploaded ${result.count} file(s) with ${result.errors.length} error(s)`,
          type: "warning",
        });
      } else {
        toaster.create({
          description: `Successfully uploaded ${result.count} shapefile(s)`,
          type: "success",
        });
      }

      // Clear files and reload data
      setUploadFiles([]);
      await loadCategories();
      await loadAllShapefiles();
      setStep("success");
    } catch (error) {
      toaster.create({
        description: `Upload failed: ${error}`,
        type: "error",
      });
    } finally {
      setUploading(false);
    }
  }
```

## Callees (2)
- [[fn-frontend-src-pages-sidebar-components-shapefilemodal-tsx--loadcategories|loadCategories]]
- [[fn-frontend-src-pages-sidebar-components-shapefilemodal-tsx--loadallshapefiles|loadAllShapefiles]]

## External / unresolved calls (5)
- `create` ×5
- `setUploading` ×2
- `uploadShapefiles`
- `setUploadFiles`
- `setStep`
