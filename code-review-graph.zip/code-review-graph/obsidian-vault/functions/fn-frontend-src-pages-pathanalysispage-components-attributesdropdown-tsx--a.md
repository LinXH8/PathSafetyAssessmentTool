---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/AttributesDropdown.tsx::a", "a"]
tags: [function, tsx]
file: "frontend/src/pages/PathAnalysisPage/components/AttributesDropdown.tsx"
lines: "453-455"
---

# a

**Kind:** Function
**File:** [[file-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx|AttributesDropdown.tsx]]  `frontend/src/pages/PathAnalysisPage/components/AttributesDropdown.tsx`
**Lines:** 453-455
**Community:** [[com-components-handle|components-handle]]
**Signature:** `def a()`

## Source

```tsx
safetyScoreAttributes.forEach(a => {
  ATTRIBUTE_OPTIONS[a.name] = a.options.filter(o => o !== "Not Selected");
});
```

## External / unresolved calls (1)
- `filter` ×2
