---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/serializer.py::ProjectGeoData.parse", "parse"]
tags: [function, python]
file: "backend/app/services/serializer.py"
lines: "367-373"
---

# parse

**Kind:** Function
**File:** [[file-backend-app-services-serializer-py|serializer.py]]  `backend/app/services/serializer.py`
**Lines:** 367-373
**Community:** [[com-services-fields|services-fields]]
**Signature:** `def parse((self, project_path : Path))`

## Source

```python
    def parse(self, project_path : Path):
        file_path = project_path / "geo_data.gpkg"
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        self.df = gpd.read_file(file_path)
        if self.df.crs.to_epsg() != 3414:
            raise Exception("Unexpected CRS: ", self.df.crs)
```

## External / unresolved calls (5)
- `exists`
- `FileNotFoundError`
- `read_file`
- `to_epsg`
- `Exception`
