---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/cyclerap_scoring.py::calculate_cm3", "calculate_cm3"]
tags: [function, python]
file: "backend/app/services/cyclerap_scoring.py"
lines: "168-202"
---

# calculate_cm3

**Kind:** Function
**File:** [[file-backend-app-services-cyclerap-scoring-py|cyclerap_scoring.py]]  `backend/app/services/cyclerap_scoring.py`
**Lines:** 168-202
**Community:** [[com-services-calculate|services-calculate]]
**Signature:** `def calculate_cm3((row: pd.Series)) -> float`

## Description

> Calculate CM3 component (main cycling environment risk)

## Source

```python
def calculate_cm3(row: pd.Series) -> float:
    """Calculate CM3 component (main cycling environment risk)"""
    cu_factors = [
        get_risk('loose_surface', row.get(LOOSE_SURFACE, 2)),
        get_risk('delineation', row.get(DELINEATION, 2)),
        get_risk('facility_width', row.get(FACILITY_WIDTH, 3)),
        get_risk('flow_direction', row.get(FLOW_DIRECTION, 1)),
        get_risk('width_restriction', row.get(WIDTH_RESTRICTION, 2)),
        get_risk('grade', row.get(GRADE, 1)),
        get_risk('cargo_bikes', row.get(CARGO_BIKES, 1)),
        get_risk('pedestrian_flow', row.get(PEDESTRIAN_FLOW, 1)),
        get_risk('bicycle_flow', row.get(BICYCLE_FLOW, 1)),
        get_risk('speed_differential', row.get(SPEED_DIFFERENTIAL, 1)),
        get_risk('curvature', row.get(CURVATURE, 2)),
        get_risk('street_lighting', row.get(STREET_LIGHTING, 1)),
        # Line of Sight: inadequate visibility raises general conflict risk
        get_risk('line_of_sight', row.get(LINE_OF_SIGHT, 1)),
    ]

    cq_triggers = [
        get_cond('surface_deformation', row.get(SURFACE_DEFORMATION, 2)),
        get_cond('fixed_obstacle', row.get(FIXED_OBSTACLE, 2)),
        get_cond('non_fixed_obstacle', row.get(NON_FIXED_OBSTACLE, 2)),
        get_cond('adjacent_parking_0_1m', row.get(ADJACENT_PARKING_0_1M, 2)),
        get_cond('intersection_crossing', row.get(INTERSECTION_CROSSING, 2)),
        get_cond('property_access', row.get(PROPERTY_ACCESS, 2)),
        get_cond('intersecting_facility', row.get(INTERSECTING_FACILITY, 2)),
        get_cond('pedestrian_crossing', row.get(PEDESTRIAN_CROSSING, 2)),
        # Line of Sight: inadequate LOS is a condition trigger — compounds all BB/BP/SB risks
        get_cond('line_of_sight', row.get(LINE_OF_SIGHT, 1)),
    ]

    cu_product = np.prod(cu_factors)
    cq_sum = sum(cq_triggers)
    return cu_product ** (1 + cq_sum * 0.1)
```

## Callers (1)
- [[fn-backend-app-services-cyclerap-scoring-py--calculate-cyclerap-score-native|calculate_cyclerap_score_native]]

## Callees (2)
- [[fn-backend-app-services-cyclerap-scoring-py--get-risk|get_risk]]
- [[fn-backend-app-services-cyclerap-scoring-py--get-cond|get_cond]]

## External / unresolved calls (3)
- `get` ×22
- `prod`
- `sum`
