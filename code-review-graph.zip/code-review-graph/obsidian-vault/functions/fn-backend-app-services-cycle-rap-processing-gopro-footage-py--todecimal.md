---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/cycle_rap_processing_gopro_footage.py::toDecimal", "toDecimal"]
tags: [function, python]
file: "backend/app/services/cycle_rap_processing_gopro_footage.py"
lines: "34-45"
---

# toDecimal

**Kind:** Function
**File:** [[file-backend-app-services-cycle-rap-processing-gopro-footage-py|cycle_rap_processing_gopro_footage.py]]  `backend/app/services/cycle_rap_processing_gopro_footage.py`
**Lines:** 34-45
**Community:** [[com-services-extract|services-extract]]
**Signature:** `def toDecimal((dms))`

## Source

```python
def toDecimal(dms):
    match = re.match(r'(\d+) deg (\d+)\s*\'\s*(\d+\.\d*)\s*\"\s*([NSEW])', dms)
    if not match:
        raise ValueError(f"Invalid DMS format: {dms}")
    degrees = float(match.group(1))
    minutes = float(match.group(2))
    seconds = float(match.group(3))
    direction = match.group(4)
    decimal_degrees = degrees + minutes / 60 + seconds / 3600
    if direction in ['S', 'W']:
        decimal_degrees *= -1
    return(decimal_degrees)
```

## Callers (1)
- [[fn-backend-app-services-cycle-rap-processing-gopro-footage-py--extractgps|extractGPS]]

## External / unresolved calls (4)
- `group` ×4
- `float` ×3
- `match`
- `ValueError`
