---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/test_routes_with_gpd.py::_read_shapefile_as_geojson", "_read_shapefile_as_geojson"]
tags: [function, python]
file: "backend/test_routes_with_gpd.py"
lines: "6-44"
---

# _read_shapefile_as_geojson

**Kind:** Function
**File:** [[file-backend-test-routes-with-gpd-py|test_routes_with_gpd.py]]  `backend/test_routes_with_gpd.py`
**Lines:** 6-44
**Community:** [[com-backend-read-2|backend-read]]
**Signature:** `def _read_shapefile_as_geojson((full_path, max_features=5000))`

## Source

```python
def _read_shapefile_as_geojson(full_path, max_features=5000):
    features = []
    with fiona.open(full_path) as src:
        src_crs = CRS(src.crs) if src.crs else None
        transformer = None
        if src_crs and src_crs.to_epsg() != 4326:
            transformer = Transformer.from_crs(src_crs, CRS.from_epsg(4326), always_xy=True)

        count = 0
        for feat in src:
            if count >= max_features:
                break
            geom = shape(feat["geometry"])
            if transformer:
                from shapely.ops import transform
                geom = transform(transformer.transform, geom)

            props = {}
            for k, v in (feat.get("properties") or {}).items():
                if v is None:
                    props[k] = None
                elif isinstance(v, (int, float, str, bool)):
                    if isinstance(v, float) and (v != v or v == float("inf") or v == float("-inf")):
                        props[k] = None
                    else:
                        props[k] = v
                else:
                    props[k] = str(v)

            features.append({
                "type": "Feature",
                "geometry": mapping(geom),
                "properties": props,
            })
            count += 1
    return {
        "type": "FeatureCollection",
        "features": features,
    }
```

## External / unresolved calls (14)
- `isinstance` ×2
- `open`
- `CRS`
- `to_epsg`
- `from_crs`
- `from_epsg`
- `shape`
- `transform`
- `items`
- `get`
- `float`
- `str`
- `append`
- `mapping`
