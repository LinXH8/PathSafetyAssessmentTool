---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/GisLayersPage/GisLayersPage.tsx::renderTooltip", "renderTooltip"]
tags: [function, tsx]
file: "frontend/src/pages/GisLayersPage/GisLayersPage.tsx"
lines: "179-187"
---

# renderTooltip

**Kind:** Function
**File:** [[file-frontend-src-pages-gislayerspage-gislayerspage-tsx|GisLayersPage.tsx]]  `frontend/src/pages/GisLayersPage/GisLayersPage.tsx`
**Lines:** 179-187
**Community:** [[com-gislayerspage-layers|gislayerspage-layers]]
**Signature:** `def renderTooltip((props: any))`

## Source

```tsx
  const renderTooltip = (props: any) => (
    <Tooltip sticky>
      <Box p={1}>
        {Object.entries(props).slice(0, 5).map(([k, v]) => (
          <Text key={k} fontSize="xs"><strong>{k}:</strong> {String(v)}</Text>
        ))}
      </Box>
    </Tooltip>
  );
```

## Callers (1)
- [[fn-frontend-src-pages-gislayerspage-gislayerspage-tsx--gislayerspage|GisLayersPage]]

## External / unresolved calls (7)
- `Tooltip`
- `Box`
- `map`
- `slice`
- `entries`
- `Text`
- `String`
