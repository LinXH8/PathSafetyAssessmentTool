---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/gis_layers/routes.py::validate_replacement", "validate_replacement"]
tags: [function, python]
file: "backend/app/api/gis_layers/routes.py"
lines: "355-381"
---

# validate_replacement

**Kind:** Function
**File:** [[file-backend-app-api-gis-layers-routes-py|routes.py]]  `backend/app/api/gis_layers/routes.py`
**Lines:** 355-381
**Community:** [[com-gis-layers-shapefiles|gis-layers-shapefiles]]
**Signature:** `def validate_replacement(())`

## Description

> Check whether an uploaded shapefile is compatible with the one it would replace.
>
> Body: { "new_file_path": "...", "target_file_path": "...", "layer_name": "..." }
> Paths are relative to backend/shapefiles/.

## Source

```python
def validate_replacement():
    """
    Check whether an uploaded shapefile is compatible with the one it would replace.

    Body: { "new_file_path": "...", "target_file_path": "...", "layer_name": "..." }
    Paths are relative to backend/shapefiles/.
    """
    body = request.get_json(force=True, silent=True) or {}
    new_rel = body.get("new_file_path", "")
    target_rel = body.get("target_file_path", "")
    layer_name = body.get("layer_name")

    if not new_rel or not target_rel:
        return jsonify({"valid": False, "errors": ["new_file_path and target_file_path are required"]}), 400

    new_abs = _safe_relative(new_rel)
    target_abs = _safe_relative(target_rel)

    if new_abs is None or not new_abs.exists():
        return jsonify({"valid": False, "errors": [f"New file not found: {new_rel}"]}), 404
    if target_abs is None or not target_abs.exists():
        return jsonify({"valid": False, "errors": [f"Target file not found: {target_rel}"]}), 404

    result = ShapefileValidator.validate_replacement(
        str(new_abs), str(target_abs), layer_name
    )
    return jsonify(result)
```

## Callers (1)
- [[fn-backend-app-api-gis-layers-routes-py--validate-replacement|validate_replacement]]

## Callees (2)
- [[fn-backend-app-api-gis-layers-routes-py--safe-relative|_safe_relative]]
- [[fn-backend-app-api-gis-layers-routes-py--validate-replacement|validate_replacement]]

## External / unresolved calls (5)
- `jsonify` ×4
- `get` ×3
- `exists` ×2
- `get_json`
- `str`
