---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/gis_mapping.py::GIS.get_radius_and_width_at_point", "get_radius_and_width_at_point"]
tags: [function, python]
file: "backend/app/services/gis_mapping.py"
lines: "604-909"
---

# get_radius_and_width_at_point

**Kind:** Function
**File:** [[file-backend-app-services-gis-mapping-py|gis_mapping.py]]  `backend/app/services/gis_mapping.py`
**Lines:** 604-909
**Community:** [[com-services-width|services-width]]
**Signature:** `def get_radius_and_width_at_point((
        self,
        point,
        start_radius=1.0,
        max_radius=5.0,
        step=1.0,
        collect_radius=5.0,
        sample_half_window=1.0,
        epsilon=1e-6
    ))`

## Description

> Calculate the minimum curvature radius and facility width at a given point using a
> TWO-STAGE process that matches the original PathAssignmentTool implementation.
>
> This method implements the exact algorithm from the original Streamlit app:
> - STAGE 1: Expanding ring search (1m→5m) to find WIDTH from the nearest path
> - STAGE 2: Fixed window search (5m) to calculate CURVATURE from the same layer
>
> Args:
>     point: Shapely Point or (lon, lat) tuple in WGS84
>     start_radius: Initial ring radius for width search (default: 1.0m)
>     max_radius: Maximum ring radius for width search (default: 5.0m)
>     step: Ring increment size (default: 1.0m)
>     collect_radius: Fixed window radius for curvature calculation (default: 5.0m, extended to 5.5m internally)
>     sample_half_window: Legacy parameter (not used - densification now uses 0.25m fixed step and preserves original vertices)
>     epsilon: Minimum threshold for distance/area calculations (default: 1e-6)
>
> Returns:
>     tuple: (min_radius, width)
>            - min_radius (float or None): Minimum circumradius in meters (sharpest curve)
>            - width (float or None): Facility width in meters from the nearest path feature
>
> Algorithm (Two-Stage Process):
>
> STAGE 1 - WIDTH SEARCH (Expanding Ring):
> 1. For each radius in [start_radius, start_radius+step, ..., max_radius]:
>    a. Create circular buffer at current radius
>    b. For each layer in priority order [cycling, shared, footpath]:
>       - Find features intersecting this ring
>       - If width not yet locked AND features found with valid WIDTH:
>         * Lock the width from the nearest feature
>         * Remember which layer provided it
>    c. Increment radius and continue (width stays locked)
>
> STAGE 2 - CURVATURE CALCULATION (Fixed Window):
> 1. Use ONLY the layer that provided the width
> 2. Query features within collect_radius (5.5m extended) of the point
> 3. Merge connectable line segments using shapely's linemerge/unary_union
> 4. Clip merged geometry to the circular buffer
> 5. IMPROVED DENSIFICATION: Preserve original vertices + add points at 0.25m intervals
> 6. Calculate minimum circumradius using sliding triplet window on ALL points
> 7. Return (min_radius, width)
>
> Key Characteristics:
> - Width and curvature come from THE SAME LAYER
> - Width uses EXPANDING RING (tries closer features first)
> - Curvature uses FIXED WINDOW (always collect_radius, not expanding)
> - Width locks at first match (never changes after first valid value)
> - Curvature calculated AFTER width search completes

## Source

```python
    def get_radius_and_width_at_point(
        self,
        point,
        start_radius=1.0,
        max_radius=5.0,
        step=1.0,
        collect_radius=5.0,
        sample_half_window=1.0,
        epsilon=1e-6
    ):
        """
        Calculate the minimum curvature radius and facility width at a given point using a
        TWO-STAGE process that matches the original PathAssignmentTool implementation.

        This method implements the exact algorithm from the original Streamlit app:
        - STAGE 1: Expanding ring search (1m→5m) to find WIDTH from the nearest path
        - STAGE 2: Fixed window search (5m) to calculate CURVATURE from the same layer

        Args:
            point: Shapely Point or (lon, lat) tuple in WGS84
            start_radius: Initial ring radius for width search (default: 1.0m)
            max_radius: Maximum ring radius for width search (default: 5.0m)
            step: Ring increment size (default: 1.0m)
            collect_radius: Fixed window radius for curvature calculation (default: 5.0m, extended to 5.5m internally)
            sample_half_window: Legacy parameter (not used - densification now uses 0.25m fixed step and preserves original vertices)
            epsilon: Minimum threshold for distance/area calculations (default: 1e-6)

        Returns:
            tuple: (min_radius, width)
                   - min_radius (float or None): Minimum circumradius in meters (sharpest curve)
                   - width (float or None): Facility width in meters from the nearest path feature

        Algorithm (Two-Stage Process):

        STAGE 1 - WIDTH SEARCH (Expanding Ring):
        1. For each radius in [start_radius, start_radius+step, ..., max_radius]:
           a. Create circular buffer at current radius
           b. For each layer in priority order [cycling, shared, footpath]:
              - Find features intersecting this ring
              - If width not yet locked AND features found with valid WIDTH:
                * Lock the width from the nearest feature
                * Remember which layer provided it
           c. Increment radius and continue (width stays locked)

        STAGE 2 - CURVATURE CALCULATION (Fixed Window):
        1. Use ONLY the layer that provided the width
        2. Query features within collect_radius (5.5m extended) of the point
        3. Merge connectable line segments using shapely's linemerge/unary_union
        4. Clip merged geometry to the circular buffer
        5. IMPROVED DENSIFICATION: Preserve original vertices + add points at 0.25m intervals
        6. Calculate minimum circumradius using sliding triplet window on ALL points
        7. Return (min_radius, width)

        Key Characteristics:
        - Width and curvature come from THE SAME LAYER
        - Width uses EXPANDING RING (tries closer features first)
        - Curvature uses FIXED WINDOW (always collect_radius, not expanding)
        - Width locks at first match (never changes after first valid value)
        - Curvature calculated AFTER width search completes
        """
        # Convert point to metric CRS (EPSG:3414)
        pt = self.store.to_metric_point(point)

        # Priority order: cycling paths first, then shared, then footpaths
        priority = ["cycling", "shared", "footpath"]
        layer_names = {
            "cycling": "cycling_path",
            "shared": "shared_path",
            "footpath": "footpath"
        }

        # ========================================================================
        # STAGE 1: EXPANDING RING SEARCH FOR WIDTH
        # ========================================================================
        found_layer = None       # layer that gave us a valid width
        found_width = None
        curvature_layer = None   # layer to use for curvature (first geometric hit,
                                 # even if it has no WIDTH attribute)

        # Expand search radius from start_radius to max_radius in steps
        current_radius = start_radius
        while current_radius <= max_radius:
            buffer_ring = pt.buffer(current_radius)

            for layer_key in priority:
                try:
                    gdf = self.store.get(layer_names[layer_key])
                    if gdf is None or gdf.empty:
                        continue

                    # Ensure metric CRS
                    if gdf.crs.to_epsg() != 3414:
                        gdf = gdf.to_crs("EPSG:3414")

                    # Remove Z-coordinates if present
                    if len(gdf) > 0 and gdf.geometry.iloc[0].has_z:
                        gdf.geometry = gdf.geometry.apply(
                            lambda geom: self._remove_z_coordinate(geom) if geom is not None else None
                        )

                    # Filter to valid geometries
                    gdf = gdf[gdf.geometry.notna() & gdf.geometry.is_valid].copy()
                    if gdf.empty:
                        continue

                    # Spatial query using index
                    candidate_indices = list(gdf.sindex.intersection(buffer_ring.bounds))
                    if not candidate_indices:
                        continue

                    candidates = gdf.iloc[candidate_indices]

                    # Find features that actually intersect the buffer
                    intersecting = candidates[candidates.intersects(buffer_ring)]
                    if intersecting.empty:
                        continue

                    # Record the first layer found geometrically for curvature use
                    if curvature_layer is None:
                        curvature_layer = layer_key

                    # Lock width if not yet set
                    if found_width is None:
                        # Standardize WIDTH column
                        intersecting_std = self._standardize_width_column(intersecting)
                        if 'WIDTH' in intersecting_std.columns:
                            # Get width from the nearest feature
                            distances = intersecting_std.geometry.distance(pt)
                            nearest_idx = distances.idxmin()
                            width_value = intersecting_std.loc[nearest_idx, 'WIDTH']
                            if pd.notna(width_value):
                                found_width = float(width_value)
                                found_layer = layer_key  # Remember which layer provided it

                except KeyError:
                    continue
                except Exception as e:
                    print(f"Warning: Error processing {layer_key} for width search: {e}")
                    continue

            # Increment radius for next ring
            current_radius += step

        # Curvature uses the width layer when available, otherwise the first geometric hit
        effective_curvature_layer = found_layer if found_layer is not None else curvature_layer

        # ========================================================================
        # STAGE 2: CURVATURE CALCULATION (Fixed Window)
        # ========================================================================
        # Calculate curvature from the best available layer
        min_radius = None

        if effective_curvature_layer is not None:
            # Temporarily swap found_layer so the existing Stage 2 block works unchanged
            found_layer = effective_curvature_layer
        if found_layer is not None:
            try:
                gdf = self.store.get(layer_names[found_layer])
                if gdf is not None and not gdf.empty:
                    # Ensure metric CRS
                    if gdf.crs.to_epsg() != 3414:
                        gdf = gdf.to_crs("EPSG:3414")

                    # Remove Z-coordinates if present
                    if len(gdf) > 0 and gdf.geometry.iloc[0].has_z:
                        gdf.geometry = gdf.geometry.apply(
                            lambda geom: self._remove_z_coordinate(geom) if geom is not None else None
                        )

                    # Filter to valid geometries
                    gdf = gdf[gdf.geometry.notna() & gdf.geometry.is_valid].copy()

                    if not gdf.empty:
                        # Create FIXED window buffer for curvature (extended slightly for better edge detection)
                        # Use 5.5m instead of 5.0m to ensure sharp bends at the edge are fully captured
                        buffer_curv = pt.buffer(collect_radius + 0.5)

                        # Spatial query using index
                        candidate_indices = list(gdf.sindex.intersection(buffer_curv.bounds))
                        if candidate_indices:
                            candidates = gdf.iloc[candidate_indices]

                            # Find features that actually intersect the buffer
                            intersecting_curv = candidates[candidates.intersects(buffer_curv)]
                            if not intersecting_curv.empty:
                                # Merge all intersecting geometries
                                from shapely.ops import linemerge, unary_union
                                merged_geom = unary_union(intersecting_curv.geometry.tolist())

                                # Apply linemerge to connect segments if possible
                                if merged_geom.geom_type == 'MultiLineString':
                                    merged_geom = linemerge(merged_geom)

                                # IMPORTANT: Process UNCLIPPED geometry to preserve sharp vertices
                                # Clipping can alter vertex angles at the boundary
                                # We'll filter individual vertices by distance instead
                                from shapely.geometry import LineString, MultiLineString
                                lines_to_process = []

                                if merged_geom.geom_type == 'LineString':
                                    lines_to_process = [merged_geom]
                                elif merged_geom.geom_type == 'MultiLineString':
                                    lines_to_process = list(merged_geom.geoms)
                                elif merged_geom.geom_type == 'GeometryCollection':
                                    lines_to_process = [g for g in merged_geom.geoms if g.geom_type == 'LineString']

                                # Calculate radius for each line segment
                                for line in lines_to_process:
                                    if line.is_empty:
                                        continue

                                    # IMPROVED DENSIFICATION: Preserve original vertices + add interpolated points
                                    # This ensures we capture sharp bends encoded as vertices in the shapefile
                                    original_coords = list(line.coords)

                                    if len(original_coords) < 2:
                                        continue

                                    # Use finer densification step (0.25m instead of 1.0m)
                                    fine_step = 0.25

                                    # Build combined coordinate list: original vertices + interpolated points
                                    combined_coords = []

                                    for i in range(len(original_coords) - 1):
                                        # Always add the original vertex (this preserves sharp angles)
                                        combined_coords.append(original_coords[i])

                                        # Calculate segment between this vertex and next
                                        segment = LineString([original_coords[i], original_coords[i+1]])
                                        segment_length = segment.length

                                        # Add densified points between vertices
                                        if segment_length > fine_step:
                                            num_intermediate = int(segment_length / fine_step)
                                            for j in range(1, num_intermediate + 1):
                                                dist = j * fine_step
                                                if dist < segment_length:
                                                    pt_interp = segment.interpolate(dist)
                                                    combined_coords.append((pt_interp.x, pt_interp.y))

                                    # Add the final original vertex
                                    combined_coords.append(original_coords[-1])

                                    # Remove duplicate consecutive points (within epsilon tolerance)
                                    deduped_coords = [combined_coords[0]]
                                    for coord in combined_coords[1:]:
                                        prev = deduped_coords[-1]
                                        dist_sq = (coord[0] - prev[0])**2 + (coord[1] - prev[1])**2
                                        if dist_sq > epsilon * epsilon:
# … (truncated, 56 more lines — see source file)
```

## Callees (4)
- [[fn-backend-app-services-gis-mapping-py--to-metric-point|to_metric_point]]
- [[fn-backend-app-services-gis-mapping-py--get|get]]
- [[fn-backend-app-services-gis-mapping-py--remove-z-coordinate|_remove_z_coordinate]]
- [[fn-backend-app-services-gis-mapping-py--standardize-width-column|_standardize_width_column]]

## External / unresolved calls (24)
- `len` ×5
- `append` ×5
- `list` ×4
- `distance` ×4
- `notna` ×3
- `float` ×3
- `range` ×3
- `Point` ×3
- `buffer` ×2
- `to_epsg` ×2
- `to_crs` ×2
- `apply` ×2
- `copy` ×2
- `intersection` ×2
- `intersects` ×2
- `print` ×2
- `idxmin`
- `unary_union`
- `tolist`
- `linemerge`
- `LineString`
- `int`
- `interpolate`
- `min`
