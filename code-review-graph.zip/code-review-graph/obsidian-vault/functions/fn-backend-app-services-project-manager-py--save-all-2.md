---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/project_manager.py::Project.save_all", "save_all"]
tags: [function, python]
file: "backend/app/services/project_manager.py"
lines: "263-277"
---

# save_all

**Kind:** Function
**File:** [[file-backend-app-services-project-manager-py|project_manager.py]]  `backend/app/services/project_manager.py`
**Lines:** 263-277
**Community:** [[com-services-project|services-project]]
**Signature:** `def save_all((self))`

## Source

```python
    def save_all(self):
        yyyymmdd = datetime.datetime.now().strftime("%Y%m%d")
        today_ver_path = self.project_path / "versions" / yyyymmdd
        if not today_ver_path.exists():
            # 只有在今天目录真的不存在时，才创建新版本
            self.create_new_version(self.latest())

        # NOTE: metadata is NOT serialized here intentionally.
        # Callers are responsible for setting last_updated and calling
        # metadata.serialize() explicitly, so only the intended project
        # gets its timestamp updated.
        if self.geo_data.df_dirty is True:
            self.geo_data.serialize(self.project_path)
        self.latest().save_all()
        return self.project_path
```

## Callees (3)
- [[fn-backend-app-services-project-manager-py--create-new-version|create_new_version]]
- [[fn-backend-app-services-project-manager-py--latest|latest]]
- [[fn-backend-app-services-project-manager-py--save-all|save_all]]

## External / unresolved calls (4)
- `strftime`
- `now`
- `exists`
- `serialize`
