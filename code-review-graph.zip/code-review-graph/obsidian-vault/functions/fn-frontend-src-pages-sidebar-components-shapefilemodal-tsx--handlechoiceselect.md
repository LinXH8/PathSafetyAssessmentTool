---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/sidebar/components/ShapefileModal.tsx::handleChoiceSelect", "handleChoiceSelect"]
tags: [function, tsx]
file: "frontend/src/pages/sidebar/components/ShapefileModal.tsx"
lines: "75-77"
---

# handleChoiceSelect

**Kind:** Function
**File:** [[file-frontend-src-pages-sidebar-components-shapefilemodal-tsx|ShapefileModal.tsx]]  `frontend/src/pages/sidebar/components/ShapefileModal.tsx`
**Lines:** 75-77
**Community:** [[com-components-handle-7|components-handle]]
**Signature:** `def handleChoiceSelect((choice: "add" | "replace"))`

## Source

```tsx
  function handleChoiceSelect(choice: "add" | "replace") {
    setStep(choice);
  }
```

## Callers (1)
- [[fn-frontend-src-pages-sidebar-components-shapefilemodal-tsx--shapefilemodal|ShapefileModal]]

## External / unresolved calls (1)
- `setStep`
