---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/prediction.py::CycleRAP_Coding_Helper.__init__", "__init__"]
tags: [function, python]
file: "backend/app/services/prediction.py"
lines: "26-27"
---

# __init__

**Kind:** Function
**File:** [[file-backend-app-services-prediction-py|prediction.py]]  `backend/app/services/prediction.py`
**Lines:** 26-27
**Community:** [[com-services-compute|services-compute]]
**Signature:** `def __init__((self))`

## Source

```python
    def __init__(self):
        raise RuntimeError("Do not create class instance, use the class methods instead")
```

## External / unresolved calls (1)
- `RuntimeError`
