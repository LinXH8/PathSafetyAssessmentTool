---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/prediction.py::CycleRAP_Coding_Helper._analyze_obstacle", "_analyze_obstacle"]
tags: [function, python]
file: "backend/app/services/prediction.py"
lines: "205-224"
---

# _analyze_obstacle

**Kind:** Function
**File:** [[file-backend-app-services-prediction-py|prediction.py]]  `backend/app/services/prediction.py`
**Lines:** 205-224
**Community:** [[com-services-compute|services-compute]]
**Signature:** `def _analyze_obstacle((obstacle_box, path_mask, threshold=0.1))`

## Source

```python
    def _analyze_obstacle(obstacle_box, path_mask, threshold=0.1):
        x_min, y_min, x_max, y_max = map(int, obstacle_box)
        obstacle_center_x = int((x_min + x_max) / 2)
        bottom_y = min(y_max, path_mask.shape[0] - 1)

        path_row = path_mask[bottom_y, :]
        if not np.any(path_row):
            return False, 0.0, 0, 0

        path_pixels_x = np.where(path_row > 0)[0]
        path_center_x = int(np.median(path_pixels_x))
        path_width = np.percentile(path_pixels_x, 95) - np.percentile(path_pixels_x, 5)

        if path_width < 10:
            return False, 0.0, 0, 0

        deviation = abs(path_center_x - obstacle_center_x)
        ratio = deviation / path_width
        is_blocking = ratio < threshold
        return is_blocking, ratio, path_center_x, obstacle_center_x
```

## Callers (1)
- [[fn-backend-app-services-prediction-py--compute-width-restriction|_compute_width_restriction]]

## External / unresolved calls (8)
- `int` ×2
- `map`
- `min`
- `any`
- `where`
- `median`
- `percentile`
- `abs`
