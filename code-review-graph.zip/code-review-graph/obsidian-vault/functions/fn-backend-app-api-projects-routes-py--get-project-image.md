---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/projects/routes.py::get_project_image", "get_project_image"]
tags: [function, python]
file: "backend/app/api/projects/routes.py"
lines: "864-896"
---

# get_project_image

**Kind:** Function
**File:** [[file-backend-app-api-projects-routes-py|routes.py]]  `backend/app/api/projects/routes.py`
**Lines:** 864-896
**Community:** [[com-projects-treatments|projects-treatments]]
**Signature:** `def get_project_image((project_name: str, filename: str))`

## Description

> Return an image file under the project's images directory:
> GET /api/projects/<project_name>/images/<filename>

## Source

```python
def get_project_image(project_name: str, filename: str):
    """
    Return an image file under the project's images directory:
    GET /api/projects/<project_name>/images/<filename>
    """
    ctx = get_ctx()
    pm = ctx["pm"]

    # Compute {data}/{project}/images directory
    images_dir: Path = (pm.des_path / project_name / global_var.PROJECT_IMAGES_FOLDER).resolve()

    # Directory existence check
    if not images_dir.exists() or not images_dir.is_dir():
        abort(404, description="Images folder not found")

    # Use safe_join to prevent directory traversal
    safe_path = safe_join(str(images_dir), filename)
    if safe_path is None:
        abort(400, description="Invalid image path")

    file_path = Path(safe_path).resolve()
    # Double-check: must be under images_dir
    if not str(file_path).startswith(str(images_dir)):
        abort(400, description="Invalid image path")

    if not file_path.exists() or not file_path.is_file():
        abort(404, description="Image not found")

    # Return via send_from_directory with conditional caching
    resp = send_from_directory(images_dir, file_path.name, conditional=True)
    # Optional: add Cache-Control (adjust as needed for your deployment)
    resp.headers["Cache-Control"] = "public, max-age=86400"
    return resp
```

## Callees (1)
- [[fn-backend-app-api-projects-routes-py--get-ctx|get_ctx]]

## External / unresolved calls (10)
- `abort` ×4
- `resolve` ×2
- `exists` ×2
- `str` ×2
- `is_dir`
- `safe_join`
- `Path`
- `startswith`
- `is_file`
- `send_from_directory`
