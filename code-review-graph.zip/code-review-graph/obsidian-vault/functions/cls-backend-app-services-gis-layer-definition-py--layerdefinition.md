---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/gis_layer_definition.py::LayerDefinition", "LayerDefinition"]
tags: [class, python]
file: "backend/app/services/gis_layer_definition.py"
lines: "11-49"
---

# LayerDefinition

**Kind:** Class
**File:** [[file-backend-app-services-gis-layer-definition-py|gis_layer_definition.py]]  `backend/app/services/gis_layer_definition.py`
**Lines:** 11-49
**Community:** [[com-services-layer|services-layer]]
**Signature:** `class LayerDefinition`

## Description

> Defines how a GIS layer is used in autocoding.
> Separates structure (what columns/geometry it needs)
> from logic (how it's used in calculations).

## Source

```python
class LayerDefinition:
    """
    Defines how a GIS layer is used in autocoding.
    Separates structure (what columns/geometry it needs)
    from logic (how it's used in calculations).
    """
    name: str                                    # e.g., "cycling_path"
    geometry_types: List[str]                    # ["LineString", "MultiLineString"]
    required_columns: List[str]                  # Columns that MUST be present
    query_type: str                              # "near", "poly", "buffer", "nearest_with_lookup"
    description: str = ""
    default_buffer_m: float = 20.0
    column_aliases: Dict[str, List[str]] = field(default_factory=dict)  # Alternative column names

    def get_column_name(self, required_col: str, gdf_columns: List[str]) -> Optional[str]:
        """
        Find the actual column name in a geodataframe for a required column.
        Handles aliases like WIDTH → PATH_WIDTH, width, W_WIDTH, etc.

        Args:
            required_col: Required column (e.g., "WIDTH")
            gdf_columns: Available columns in the geodataframe

        Returns:
            Actual column name if found, else None
        """
        gdf_cols_upper = {col.upper(): col for col in gdf_columns}

        # Check exact match first
        if required_col.upper() in gdf_cols_upper:
            return gdf_cols_upper[required_col.upper()]

        # Check aliases
        if required_col in self.column_aliases:
            for alias in self.column_aliases[required_col]:
                if alias.upper() in gdf_cols_upper:
                    return gdf_cols_upper[alias.upper()]

        return None
```
