---
aliases: ["treatmentpage-treatment"]
tags: [community, tsx]
size: 20
cohesion: 0.1205
---

# Community · treatmentpage-treatment

**Size:** 20 &nbsp; **Cohesion:** 0.1205 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/TreatmentPage/treatmentDetailPage.tsx

## Members (20)
- [[file-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx|treatmentDetailPage.tsx]] — *File* `1-1625`
- [[fn-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx--to4326|to4326]] — *Function* `27-33`
- [[fn-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx--istreatmentapplicable|isTreatmentApplicable]] — *Function* `289-301`
- [[fn-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx--set|set]] — *Function* `292-299`
- [[fn-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx--getapplicabletreatments|getApplicableTreatments]] — *Function* `304-306`
- [[fn-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx--applytreatmenteffects|applyTreatmentEffects]] — *Function* `309-329`
- [[fn-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx--calculatebandfromscore|calculateBandFromScore]] — *Function* `336-350`
- [[fn-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx--calculatebanddistributions|calculateBandDistributions]] — *Function* `353-390`
- [[fn-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx--treatmentdetailpage|TreatmentDetailPage]] — *Function* `392-1624`
- [[fn-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx--name|name]] — *Function* `399-405`
- [[fn-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx--row|row]] — *Function* `425-433`
- [[fn-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx--x|x]] — *Function* `474-474`
- [[fn-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx--res|res]] — *Function* `654-655`
- [[fn-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx--handletreatallcompleted|handleTreatAllCompleted]] — *Function* `745-785`
- [[fn-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx--p|p]] — *Function* `760-760`
- [[fn-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx--handleresetallcompleted|handleResetAllCompleted]] — *Function* `787-793`
- [[fn-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx--prev|prev]] — *Function* `789-789`
- [[fn-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx--handleconfirmapplytoall|handleConfirmApplyToAll]] — *Function* `899-927`
- [[fn-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx--k|k]] — *Function* `1081-1081`
- [[fn-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx--t|t]] — *Function* `1369-1369`
