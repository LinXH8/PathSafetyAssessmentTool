---
aliases: ["sidebar-shapefile"]
tags: [community, tsx]
size: 6
cohesion: 0.0496
---

# Community · sidebar-shapefile

**Size:** 6 &nbsp; **Cohesion:** 0.0496 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/sidebar/Sidebar.tsx

## Members (6)
- [[file-frontend-src-pages-sidebar-sidebar-tsx|Sidebar.tsx]] — *File* `1-405`
- [[fn-frontend-src-pages-sidebar-sidebar-tsx--sidebar|Sidebar]] — *Function* `20-404`
- [[fn-frontend-src-pages-sidebar-sidebar-tsx--openshapefilemodal|openShapefileModal]] — *Function* `30-32`
- [[fn-frontend-src-pages-sidebar-sidebar-tsx--closeshapefilemodal|closeShapefileModal]] — *Function* `34-36`
- [[fn-frontend-src-pages-sidebar-sidebar-tsx--onsave|onSave]] — *Function* `180-189`
- [[fn-frontend-src-pages-sidebar-sidebar-tsx--s|s]] — *Function* `246-246`
