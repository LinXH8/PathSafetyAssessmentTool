---
aliases: ["scoreband-color"]
tags: [community, tsx]
size: 6
cohesion: 0.1233
---

# Community · scoreband-color

**Size:** 6 &nbsp; **Cohesion:** 0.1233 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/scoreband/SegmentScoresCard.tsx

## Members (6)
- [[file-frontend-src-components-visualization-scoreband-segmentscorescard-tsx|SegmentScoresCard.tsx]] — *File* `1-331`
- [[fn-frontend-src-components-visualization-scoreband-segmentscorescard-tsx--getbandcolor|getBandColor]] — *Function* `59-73`
- [[fn-frontend-src-components-visualization-scoreband-segmentscorescard-tsx--getlightbgcolor|getLightBgColor]] — *Function* `75-87`
- [[fn-frontend-src-components-visualization-scoreband-segmentscorescard-tsx--getdarkbgcolor|getDarkBgColor]] — *Function* `89-101`
- [[fn-frontend-src-components-visualization-scoreband-segmentscorescard-tsx--getbandlabel|getBandLabel]] — *Function* `103-115`
- [[fn-frontend-src-components-visualization-scoreband-segmentscorescard-tsx--segmentscorescard|SegmentScoresCard]] — *Function* `117-330`
