---
aliases: ["services-width"]
tags: [community, python]
size: 38
cohesion: 0.2343
---

# Community · services-width

**Size:** 38 &nbsp; **Cohesion:** 0.2343 &nbsp; **Dominant language:** python

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/gis_mapping.py

## Members (38)
- [[file-backend-app-services-gis-mapping-py|gis_mapping.py]] — *File* `1-1930`
- [[fn-backend-app-services-gis-mapping-py--load-gdf-cached|_load_gdf_cached]] — *Function* `13-41`
- [[cls-backend-app-services-gis-mapping-py--layerstore|LayerStore]] — *Class* `46-159`
- [[fn-backend-app-services-gis-mapping-py--init|__init__]] — *Function* `48-53`
- [[fn-backend-app-services-gis-mapping-py--add-path|add_path]] — *Function* `55-56`
- [[fn-backend-app-services-gis-mapping-py--set-speed-csv|set_speed_csv]] — *Function* `59-74`
- [[fn-backend-app-services-gis-mapping-py--get|get]] — *Function* `76-85`
- [[fn-backend-app-services-gis-mapping-py--clear-cache|clear_cache]] — *Function* `87-92`
- [[fn-backend-app-services-gis-mapping-py--reload|reload]] — *Function* `94-106`
- [[fn-backend-app-services-gis-mapping-py--to-metric-point|to_metric_point]] — *Function* `108-122`
- [[fn-backend-app-services-gis-mapping-py--default|default]] — *Function* `125-159`
- [[cls-backend-app-services-gis-mapping-py--gis|GIS]] — *Class* `162-1930`
- [[fn-backend-app-services-gis-mapping-py--init-2|__init__]] — *Function* `164-165`
- [[fn-backend-app-services-gis-mapping-py--near|_near]] — *Function* `167-173`
- [[fn-backend-app-services-gis-mapping-py--poly|_poly]] — *Function* `175-177`
- [[fn-backend-app-services-gis-mapping-py--peak-hourly-by-group|_peak_hourly_by_group]] — *Function* `204-235`
- [[fn-backend-app-services-gis-mapping-py--is-mrt|is_mrt]] — *Function* `237-239`
- [[fn-backend-app-services-gis-mapping-py--is-bus-lane|is_bus_lane]] — *Function* `241-243`
- [[fn-backend-app-services-gis-mapping-py--is-bus-stop|is_bus_stop]] — *Function* `245-247`
- [[fn-backend-app-services-gis-mapping-py--is-road-crossing|is_road_crossing]] — *Function* `249-251`
- [[fn-backend-app-services-gis-mapping-py--is-parking|is_parking]] — *Function* `253-255`
- [[fn-backend-app-services-gis-mapping-py--get-area-type|get_area_type]] — *Function* `257-262`
- [[fn-backend-app-services-gis-mapping-py--get-peak-pedestrian-flow|get_peak_pedestrian_flow]] — *Function* `264-320`
- [[fn-backend-app-services-gis-mapping-py--get-number-of-lane|get_number_of_lane]] — *Function* `322-355`
- [[fn-backend-app-services-gis-mapping-py--get-road-operating-speed|get_road_operating_speed]] — *Function* `358-448`
- [[fn-backend-app-services-gis-mapping-py--get-road-speed-limit|get_road_speed_limit]] — *Function* `451-530`
- [[fn-backend-app-services-gis-mapping-py--get-heavy-vehicle-flow|get_heavy_vehicle_flow]] — *Function* `532-602`
- [[fn-backend-app-services-gis-mapping-py--get-radius-and-width-at-point|get_radius_and_width_at_point]] — *Function* `604-909`
- [[fn-backend-app-services-gis-mapping-py--calculate-min-radius-triplet|_calculate_min_radius_triplet]] — *Function* `911-1033`
- [[fn-backend-app-services-gis-mapping-py--format-calculation-steps|_format_calculation_steps]] — *Function* `1035-1076`
- [[fn-backend-app-services-gis-mapping-py--get-curvature|get_curvature]] — *Function* `1078-1139`
- [[fn-backend-app-services-gis-mapping-py--check-angle-curvature|_check_angle_curvature]] — *Function* `1141-1240`
- [[fn-backend-app-services-gis-mapping-py--deflection-angle|deflection_angle]] — *Function* `1214-1222`
- [[fn-backend-app-services-gis-mapping-py--get-curvature-visualization|get_curvature_visualization]] — *Function* `1242-1508`
- [[fn-backend-app-services-gis-mapping-py--get-facility-width|get_facility_width]] — *Function* `1510-1586`
- [[fn-backend-app-services-gis-mapping-py--get-width-visualization|get_width_visualization]] — *Function* `1588-1846`
- [[fn-backend-app-services-gis-mapping-py--remove-z-coordinate|_remove_z_coordinate]] — *Function* `1849-1880`
- [[fn-backend-app-services-gis-mapping-py--standardize-width-column|_standardize_width_column]] — *Function* `1883-1930`
