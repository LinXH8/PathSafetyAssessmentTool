---
aliases: ["services-validate"]
tags: [community, python]
size: 9
cohesion: 0.1892
---

# Community · services-validate

**Size:** 9 &nbsp; **Cohesion:** 0.1892 &nbsp; **Dominant language:** python

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/shapefile_validator.py

## Members (9)
- [[file-backend-app-services-shapefile-validator-py|shapefile_validator.py]] — *File* `1-308`
- [[cls-backend-app-services-shapefile-validator-py--shapefilevalidator|ShapefileValidator]] — *Class* `16-307`
- [[fn-backend-app-services-shapefile-validator-py--validate-replacement|validate_replacement]] — *Function* `20-133`
- [[fn-backend-app-services-shapefile-validator-py--validate-crs|_validate_crs]] — *Function* `136-164`
- [[fn-backend-app-services-shapefile-validator-py--validate-geometry-type|_validate_geometry_type]] — *Function* `167-203`
- [[fn-backend-app-services-shapefile-validator-py--validate-required-columns|_validate_required_columns]] — *Function* `206-234`
- [[fn-backend-app-services-shapefile-validator-py--validate-feature-count|_validate_feature_count]] — *Function* `237-256`
- [[fn-backend-app-services-shapefile-validator-py--validate-empty-geometries|_validate_empty_geometries]] — *Function* `259-274`
- [[fn-backend-app-services-shapefile-validator-py--validate-spatial-bounds|_validate_spatial_bounds]] — *Function* `277-307`
