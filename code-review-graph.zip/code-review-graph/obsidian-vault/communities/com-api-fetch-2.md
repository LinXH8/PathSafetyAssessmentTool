---
aliases: ["api-fetch"]
tags: [community, typescript]
size: 2
cohesion: 0.1667
---

# Community · api-fetch

**Size:** 2 &nbsp; **Cohesion:** 0.1667 &nbsp; **Dominant language:** typescript

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/api/widthVisualization.ts

## Members (2)
- [[file-frontend-src-api-widthvisualization-ts|widthVisualization.ts]] — *File* `1-90`
- [[fn-frontend-src-api-widthvisualization-ts--fetchwidthvisualization|fetchWidthVisualization]] — *Function* `63-85`
