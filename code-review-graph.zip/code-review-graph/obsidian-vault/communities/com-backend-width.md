---
aliases: ["backend-width"]
tags: [community, python]
size: 5
cohesion: 0.0483
---

# Community · backend-width

**Size:** 5 &nbsp; **Cohesion:** 0.0483 &nbsp; **Dominant language:** python

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/visualize_facility_width.py

## Members (5)
- [[file-backend-visualize-facility-width-py|visualize_facility_width.py]] — *File* `1-414`
- [[fn-backend-visualize-facility-width-py--analyze-width-at-point-detailed|analyze_width_at_point_detailed]] — *Function* `41-175`
- [[fn-backend-visualize-facility-width-py--visualize-width-analysis|visualize_width_analysis]] — *Function* `178-247`
- [[fn-backend-visualize-facility-width-py--create-width-visualization|create_width_visualization]] — *Function* `250-356`
- [[fn-backend-visualize-facility-width-py--main|main]] — *Function* `359-409`
