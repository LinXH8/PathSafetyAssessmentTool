---
aliases: ["treatmentpage-tag"]
tags: [community, tsx]
size: 13
cohesion: 0.1667
---

# Community · treatmentpage-tag

**Size:** 13 &nbsp; **Cohesion:** 0.1667 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/TreatmentPage/treatmentPage.tsx

## Members (13)
- [[file-frontend-src-pages-treatmentpage-treatmentpage-tsx|treatmentPage.tsx]] — *File* `1-410`
- [[fn-frontend-src-pages-treatmentpage-treatmentpage-tsx--gettagbordercolor|getTagBorderColor]] — *Function* `15-19`
- [[fn-frontend-src-pages-treatmentpage-treatmentpage-tsx--gettagcolor|getTagColor]] — *Function* `22-50`
- [[fn-frontend-src-pages-treatmentpage-treatmentpage-tsx--treatmentpage|TreatmentPage]] — *Function* `52-409`
- [[fn-frontend-src-pages-treatmentpage-treatmentpage-tsx--handleverificationupdate|handleVerificationUpdate]] — *Function* `81-94`
- [[fn-frontend-src-pages-treatmentpage-treatmentpage-tsx--onrowclick|onRowClick]] — *Function* `127-138`
- [[fn-frontend-src-pages-treatmentpage-treatmentpage-tsx--toggleselectall|toggleSelectAll]] — *Function* `141-149`
- [[fn-frontend-src-pages-treatmentpage-treatmentpage-tsx--loadproject|loadProject]] — *Function* `151-160`
- [[fn-frontend-src-pages-treatmentpage-treatmentpage-tsx--name|name]] — *Function* `158-158`
- [[fn-frontend-src-pages-treatmentpage-treatmentpage-tsx--handleeditsuccess|handleEditSuccess]] — *Function* `162-181`
- [[fn-frontend-src-pages-treatmentpage-treatmentpage-tsx--prev|prev]] — *Function* `174-179`
- [[fn-frontend-src-pages-treatmentpage-treatmentpage-tsx--p|p]] — *Function* `217-221`
- [[fn-frontend-src-pages-treatmentpage-treatmentpage-tsx--tag|tag]] — *Function* `326-326`
