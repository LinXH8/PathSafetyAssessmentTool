---
aliases: ["ui-toaster"]
tags: [community, tsx]
size: 2
cohesion: 0.0400
---

# Community · ui-toaster

**Size:** 2 &nbsp; **Cohesion:** 0.0400 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/ui/toaster.tsx

## Members (2)
- [[file-frontend-src-components-ui-toaster-tsx|toaster.tsx]] — *File* `1-44`
- [[fn-frontend-src-components-ui-toaster-tsx--toaster|Toaster]] — *Function* `17-43`
