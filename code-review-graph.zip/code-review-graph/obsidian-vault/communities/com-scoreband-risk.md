---
aliases: ["scoreband-risk"]
tags: [community, typescript]
size: 4
cohesion: 0.3750
---

# Community · scoreband-risk

**Size:** 4 &nbsp; **Cohesion:** 0.3750 &nbsp; **Dominant language:** typescript

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/scoreband/colorConstants.ts

## Members (4)
- [[file-frontend-src-components-visualization-scoreband-colorconstants-ts|colorConstants.ts]] — *File* `1-56`
- [[fn-frontend-src-components-visualization-scoreband-colorconstants-ts--getriskbandcolor|getRiskBandColor]] — *Function* `28-33`
- [[fn-frontend-src-components-visualization-scoreband-colorconstants-ts--getriskbandlabel|getRiskBandLabel]] — *Function* `39-44`
- [[fn-frontend-src-components-visualization-scoreband-colorconstants-ts--getriskbandindex|getRiskBandIndex]] — *Function* `50-55`
