---
aliases: ["createprojectpage-tag"]
tags: [community, tsx]
size: 11
cohesion: 0.1192
---

# Community · createprojectpage-tag

**Size:** 11 &nbsp; **Cohesion:** 0.1192 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/CreateProjectPage/createProjectPage.tsx

## Members (11)
- [[file-frontend-src-pages-createprojectpage-createprojectpage-tsx|createProjectPage.tsx]] — *File* `1-315`
- [[fn-frontend-src-pages-createprojectpage-createprojectpage-tsx--gettagcolor|getTagColor]] — *Function* `21-38`
- [[fn-frontend-src-pages-createprojectpage-createprojectpage-tsx--createprojectpage|CreateProjectPage]] — *Function* `40-314`
- [[fn-frontend-src-pages-createprojectpage-createprojectpage-tsx--loadfolders|loadFolders]] — *Function* `55-76`
- [[fn-frontend-src-pages-createprojectpage-createprojectpage-tsx--p|p]] — *Function* `67-69`
- [[fn-frontend-src-pages-createprojectpage-createprojectpage-tsx--tag|tag]] — *Function* `68-68`
- [[fn-frontend-src-pages-createprojectpage-createprojectpage-tsx--handletaginputkeydown|handleTagInputKeyDown]] — *Function* `91-103`
- [[fn-frontend-src-pages-createprojectpage-createprojectpage-tsx--removetag|removeTag]] — *Function* `105-107`
- [[fn-frontend-src-pages-createprojectpage-createprojectpage-tsx--oncreate|onCreate]] — *Function* `109-122`
- [[fn-frontend-src-pages-createprojectpage-createprojectpage-tsx--t|t]] — *Function* `215-219`
- [[fn-frontend-src-pages-createprojectpage-createprojectpage-tsx--f|f]] — *Function* `264-268`
