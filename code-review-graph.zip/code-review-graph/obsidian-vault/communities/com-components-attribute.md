---
aliases: ["components-attribute"]
tags: [community, tsx]
size: 4
cohesion: 0.0375
---

# Community · components-attribute

**Size:** 4 &nbsp; **Cohesion:** 0.0375 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/AttributeDistributionChart.tsx

## Members (4)
- [[file-frontend-src-pages-pathanalysispage-components-attributedistributionchart-tsx|AttributeDistributionChart.tsx]] — *File* `1-372`
- [[fn-frontend-src-pages-pathanalysispage-components-attributedistributionchart-tsx--attributedistributionchart|AttributeDistributionChart]] — *Function* `29-371`
- [[fn-frontend-src-pages-pathanalysispage-components-attributedistributionchart-tsx--rendercustomlabel|renderCustomLabel]] — *Function* `62-90`
- [[fn-frontend-src-pages-pathanalysispage-components-attributedistributionchart-tsx--c|c]] — *Function* `93-93`
