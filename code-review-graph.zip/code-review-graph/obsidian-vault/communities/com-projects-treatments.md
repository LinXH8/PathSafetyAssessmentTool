---
aliases: ["projects-treatments"]
tags: [community, python]
size: 67
cohesion: 0.2118
---

# Community · projects-treatments

**Size:** 67 &nbsp; **Cohesion:** 0.2118 &nbsp; **Dominant language:** python

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/projects/routes.py

## Members (67)
- [[file-backend-app-api-projects-routes-py|routes.py]] — *File* `1-3607`
- [[fn-backend-app-api-projects-routes-py--get-gis|_get_gis]] — *Function* `39-54`
- [[fn-backend-app-api-projects-routes-py--warmup-gis|warmup_gis]] — *Function* `57-77`
- [[fn-backend-app-api-projects-routes-py--warm|_warm]] — *Function* `67-74`
- [[fn-backend-app-api-projects-routes-py--ok|ok]] — *Function* `307-308`
- [[fn-backend-app-api-projects-routes-py--fail|fail]] — *Function* `310-311`
- [[fn-backend-app-api-projects-routes-py--df-to-records|df_to_records]] — *Function* `313-325`
- [[fn-backend-app-api-projects-routes-py--get-ctx|get_ctx]] — *Function* `332-349`
- [[fn-backend-app-api-projects-routes-py--ensure-models-ready|_ensure_models_ready]] — *Function* `353-404`
- [[fn-backend-app-api-projects-routes-py--warmup-models-in-background|_warmup_models_in_background]] — *Function* `407-445`
- [[fn-backend-app-api-projects-routes-py--load-one|_load_one]] — *Function* `427-430`
- [[fn-backend-app-api-projects-routes-py--load-gradient-lookup|_load_gradient_lookup]] — *Function* `460-494`
- [[fn-backend-app-api-projects-routes-py--inject-grade|_inject_grade]] — *Function* `497-535`
- [[fn-backend-app-api-projects-routes-py--log-incoming|_log_incoming]] — *Function* `541-542`
- [[fn-backend-app-api-projects-routes-py--list-projects|list_projects]] — *Function* `545-595`
- [[fn-backend-app-api-projects-routes-py--delete-segments-batch|delete_segments_batch]] — *Function* `598-631`
- [[fn-backend-app-api-projects-routes-py--check-collisions|check_collisions]] — *Function* `634-662`
- [[fn-backend-app-api-projects-routes-py--copy-segments|copy_segments]] — *Function* `666-763`
- [[fn-backend-app-api-projects-routes-py--delete-segment|delete_segment]] — *Function* `767-792`
- [[fn-backend-app-api-projects-routes-py--get-project|get_project]] — *Function* `795-804`
- [[fn-backend-app-api-projects-routes-py--get-project-metadata|get_project_metadata]] — *Function* `807-819`
- [[fn-backend-app-api-projects-routes-py--get-latest-attributes|get_latest_attributes]] — *Function* `822-849`
- [[fn-backend-app-api-projects-routes-py--get-geodata|get_geodata]] — *Function* `852-861`
- [[fn-backend-app-api-projects-routes-py--get-project-image|get_project_image]] — *Function* `864-896`
- [[fn-backend-app-api-projects-routes-py--download-images|download_images]] — *Function* `899-970`
- [[fn-backend-app-api-projects-routes-py--get-attribute-mappings|get_attribute_mappings]] — *Function* `973-990`
- [[fn-backend-app-api-projects-routes-py--convert-attribute-types|_convert_attribute_types]] — *Function* `992-1067`
- [[fn-backend-app-api-projects-routes-py--calculate-score|calculate_score]] — *Function* `1071-1158`
- [[fn-backend-app-api-projects-routes-py--get-results|get_results]] — *Function* `1161-1187`
- [[fn-backend-app-api-projects-routes-py--evaluate-treatments|evaluate_treatments]] — *Function* `1190-1206`
- [[fn-backend-app-api-projects-routes-py--apply-treatments|apply_treatments]] — *Function* `1210-1349`
- [[fn-backend-app-api-projects-routes-py--preview-treatments|preview_treatments]] — *Function* `1353-1450`
- [[fn-backend-app-api-projects-routes-py--get-all-treatments|get_all_treatments]] — *Function* `1454-1538`
- [[fn-backend-app-api-projects-routes-py--get-segment-treatments|get_segment_treatments]] — *Function* `1542-1651`
- [[fn-backend-app-api-projects-routes-py--apply-all-treatments|apply_all_treatments]] — *Function* `1655-1813`
- [[fn-backend-app-api-projects-routes-py--get-applicable-treatments|get_applicable_treatments]] — *Function* `1701-1719`
- [[fn-backend-app-api-projects-routes-py--apply-specific-treatment|apply_specific_treatment]] — *Function* `1817-1956`
- [[fn-backend-app-api-projects-routes-py--is-treatment-applicable|is_treatment_applicable]] — *Function* `1854-1866`
- [[fn-backend-app-api-projects-routes-py--reset-all-treatments|reset_all_treatments]] — *Function* `1960-2028`
- [[fn-backend-app-api-projects-routes-py--save-treatments|save_treatments]] — *Function* `2032-2062`
- [[fn-backend-app-api-projects-routes-py--update-attributes|update_attributes]] — *Function* `2066-2128`
- [[fn-backend-app-api-projects-routes-py--dms-to-decimal|dms_to_decimal]] — *Function* `2132-2137`
- [[fn-backend-app-api-projects-routes-py--get-image-folder-geo|get_image_folder_geo]] — *Function* `2139-2166`
- [[fn-backend-app-api-projects-routes-py--get-all-img-folder|get_All_Img_Folder]] — *Function* `2168-2193`
- [[fn-backend-app-api-projects-routes-py--list-input-folders|list_input_folders]] — *Function* `2196-2211`
- [[fn-backend-app-api-projects-routes-py--create-project-from-folder|create_project_from_folder]] — *Function* `2214-2274`
- [[fn-backend-app-api-projects-routes-py--upload-images-to-source-folder|upload_images_to_source_folder]] — *Function* `2277-2348`
- [[fn-backend-app-api-projects-routes-py--delete-project|delete_project]] — *Function* `2351-2366`
- [[fn-backend-app-api-projects-routes-py--update-project-metadata|update_project_metadata]] — *Function* `2369-2538`
- [[fn-backend-app-api-projects-routes-py--update-image-ref-in-df|update_image_ref_in_df]] — *Function* `2476-2493`
- [[fn-backend-app-api-projects-routes-py--update-ref|_update_ref]] — *Function* `2480-2488`
- [[fn-backend-app-api-projects-routes-py--autocode-image|autocode_image]] — *Function* `2541-2581`
- [[fn-backend-app-api-projects-routes-py--autocode-gis|autocode_gis]] — *Function* `2585-2680`
- [[fn-backend-app-api-projects-routes-py--apply-peak|apply_peak]] — *Function* `2627-2633`
- [[fn-backend-app-api-projects-routes-py--get-curvature-visualization|get_curvature_visualization]] — *Function* `2684-2771`
- [[fn-backend-app-api-projects-routes-py--get-width-visualization|get_width_visualization]] — *Function* `2775-2852`
- [[fn-backend-app-api-projects-routes-py--get-gis-layers|get_gis_layers]] — *Function* `2856-3053`
- [[fn-backend-app-api-projects-routes-py--detect-nearby-gis|detect_nearby_gis]] — *Function* `3056-3103`
- [[fn-backend-app-api-projects-routes-py--autocode-all|autocode_all]] — *Function* `3107-3423`
- [[fn-backend-app-api-projects-routes-py--resolve-image-ref|_resolve_image_ref]] — *Function* `3147-3186`
- [[fn-backend-app-api-projects-routes-py--resolve-coords|_resolve_coords]] — *Function* `3188-3194`
- [[fn-backend-app-api-projects-routes-py--call-autocode-pair|_call_autocode_pair]] — *Function* `3196-3245`
- [[fn-backend-app-api-projects-routes-py--baseline-exists|baseline_exists]] — *Function* `3429-3444`
- [[fn-backend-app-api-projects-routes-py--get-baseline|get_baseline]] — *Function* `3448-3481`
- [[fn-backend-app-api-projects-routes-py--save-baseline|save_baseline]] — *Function* `3485-3529`
- [[fn-backend-app-api-projects-routes-py--get-autocode-metadata|get_autocode_metadata]] — *Function* `3534-3570`
- [[fn-backend-app-api-projects-routes-py--save-autocode-metadata|save_autocode_metadata]] — *Function* `3573-3606`
