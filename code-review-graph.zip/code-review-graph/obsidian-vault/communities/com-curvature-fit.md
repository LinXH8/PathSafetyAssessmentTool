---
aliases: ["curvature-fit"]
tags: [community, tsx]
size: 3
cohesion: 0.1000
---

# Community · curvature-fit

**Size:** 3 &nbsp; **Cohesion:** 0.1000 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/curvature/CurvatureVisualization.tsx

## Members (3)
- [[file-frontend-src-components-visualization-curvature-curvaturevisualization-tsx|CurvatureVisualization.tsx]] — *File* `1-170`
- [[fn-frontend-src-components-visualization-curvature-curvaturevisualization-tsx--fitbounds|FitBounds]] — *Function* `54-62`
- [[fn-frontend-src-components-visualization-curvature-curvaturevisualization-tsx--curvaturevisualization|CurvatureVisualization]] — *Function* `64-167`
