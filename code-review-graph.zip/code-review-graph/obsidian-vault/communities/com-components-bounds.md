---
aliases: ["components-bounds"]
tags: [community, tsx]
size: 17
cohesion: 0.0889
---

# Community · components-bounds

**Size:** 17 &nbsp; **Cohesion:** 0.0889 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/CodingPage/components/GeoDataPanel.tsx

## Members (17)
- [[file-frontend-src-pages-codingpage-components-geodatapanel-tsx|GeoDataPanel.tsx]] — *File* `1-1488`
- [[fn-frontend-src-pages-codingpage-components-geodatapanel-tsx--to4326|to4326]] — *Function* `50-63`
- [[fn-frontend-src-pages-codingpage-components-geodatapanel-tsx--fitbounds|FitBounds]] — *Function* `66-76`
- [[fn-frontend-src-pages-codingpage-components-geodatapanel-tsx--pantobounds|PanToBounds]] — *Function* `84-99`
- [[fn-frontend-src-pages-codingpage-components-geodatapanel-tsx--zoomtogis|ZoomToGIS]] — *Function* `102-117`
- [[fn-frontend-src-pages-codingpage-components-geodatapanel-tsx--createcustomicon|createCustomIcon]] — *Function* `121-136`
- [[fn-frontend-src-pages-codingpage-components-geodatapanel-tsx--draggablemarker|DraggableMarker]] — *Function* `147-175`
- [[fn-frontend-src-pages-codingpage-components-geodatapanel-tsx--polygondrawingtool|PolygonDrawingTool]] — *Function* `178-261`
- [[fn-frontend-src-pages-codingpage-components-geodatapanel-tsx--click|click]] — *Function* `201-205`
- [[fn-frontend-src-pages-codingpage-components-geodatapanel-tsx--ispointinpolygon|isPointInPolygon]] — *Function* `264-279`
- [[fn-frontend-src-pages-codingpage-components-geodatapanel-tsx--geodatapanel|GeoDataPanel]] — *Function* `284-1487`
- [[fn-frontend-src-pages-codingpage-components-geodatapanel-tsx--mapautocenter|MapAutoCenter]] — *Function* `340-372`
- [[fn-frontend-src-pages-codingpage-components-geodatapanel-tsx--handlescoresupdated|handleScoresUpdated]] — *Function* `479-484`
- [[fn-frontend-src-pages-codingpage-components-geodatapanel-tsx--getsegmentcolor|getSegmentColor]] — *Function* `613-656`
- [[fn-frontend-src-pages-codingpage-components-geodatapanel-tsx--prev|prev]] — *Function* `713-717`
- [[fn-frontend-src-pages-codingpage-components-geodatapanel-tsx--c|c]] — *Function* `1248-1248`
- [[fn-frontend-src-pages-codingpage-components-geodatapanel-tsx--p|p]] — *Function* `1474-1474`
