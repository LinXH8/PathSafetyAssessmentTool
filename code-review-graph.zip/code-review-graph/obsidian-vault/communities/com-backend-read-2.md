---
aliases: ["backend-read"]
tags: [community, python]
size: 2
cohesion: 0.0476
---

# Community · backend-read

**Size:** 2 &nbsp; **Cohesion:** 0.0476 &nbsp; **Dominant language:** python

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/test_routes_with_gpd.py

## Members (2)
- [[file-backend-test-routes-with-gpd-py|test_routes_with_gpd.py]] — *File* `1-54`
- [[fn-backend-test-routes-with-gpd-py--read-shapefile-as-geojson|_read_shapefile_as_geojson]] — *Function* `6-44`
