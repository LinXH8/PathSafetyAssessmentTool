---
aliases: ["shapefilemanagement-handle"]
tags: [community, tsx]
size: 10
cohesion: 0.1667
---

# Community · shapefilemanagement-handle

**Size:** 10 &nbsp; **Cohesion:** 0.1667 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/ShapefileManagement/ShapefileManagementPage.tsx

## Members (10)
- [[file-frontend-src-pages-shapefilemanagement-shapefilemanagementpage-tsx|ShapefileManagementPage.tsx]] — *File* `1-231`
- [[fn-frontend-src-pages-shapefilemanagement-shapefilemanagementpage-tsx--shapefilemanagementpage|ShapefileManagementPage]] — *Function* `9-230`
- [[fn-frontend-src-pages-shapefilemanagement-shapefilemanagementpage-tsx--loadshapefiles|loadShapefiles]] — *Function* `21-34`
- [[fn-frontend-src-pages-shapefilemanagement-shapefilemanagementpage-tsx--loadcategories|loadCategories]] — *Function* `36-42`
- [[fn-frontend-src-pages-shapefilemanagement-shapefilemanagementpage-tsx--handleopenmodal|handleOpenModal]] — *Function* `44-47`
- [[fn-frontend-src-pages-shapefilemanagement-shapefilemanagementpage-tsx--handleclosemodal|handleCloseModal]] — *Function* `49-52`
- [[fn-frontend-src-pages-shapefilemanagement-shapefilemanagementpage-tsx--handlemodeselect|handleModeSelect]] — *Function* `54-56`
- [[fn-frontend-src-pages-shapefilemanagement-shapefilemanagementpage-tsx--handleuploadcomplete|handleUploadComplete]] — *Function* `58-62`
- [[fn-frontend-src-pages-shapefilemanagement-shapefilemanagementpage-tsx--handledelete|handleDelete]] — *Function* `64-83`
- [[fn-frontend-src-pages-shapefilemanagement-shapefilemanagementpage-tsx--formatbytes|formatBytes]] — *Function* `85-91`
