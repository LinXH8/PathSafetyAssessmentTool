---
aliases: ["backend-read"]
tags: [community, python]
size: 2
cohesion: 0.0476
---

# Community · backend-read

**Size:** 2 &nbsp; **Cohesion:** 0.0476 &nbsp; **Dominant language:** python

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/test_routes2.py

## Members (2)
- [[file-backend-test-routes2-py|test_routes2.py]] — *File* `1-53`
- [[fn-backend-test-routes2-py--read-shapefile-as-geojson|_read_shapefile_as_geojson]] — *Function* `5-43`
