---
aliases: ["services-layer"]
tags: [community, python]
size: 5
cohesion: 0.3077
---

# Community · services-layer

**Size:** 5 &nbsp; **Cohesion:** 0.3077 &nbsp; **Dominant language:** python

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/gis_layer_definition.py

## Members (5)
- [[file-backend-app-services-gis-layer-definition-py|gis_layer_definition.py]] — *File* `1-211`
- [[cls-backend-app-services-gis-layer-definition-py--layerdefinition|LayerDefinition]] — *Class* `11-49`
- [[fn-backend-app-services-gis-layer-definition-py--get-column-name|get_column_name]] — *Function* `25-49`
- [[fn-backend-app-services-gis-layer-definition-py--get-layer-definition|get_layer_definition]] — *Function* `203-205`
- [[fn-backend-app-services-gis-layer-definition-py--list-layer-definitions|list_layer_definitions]] — *Function* `208-210`
