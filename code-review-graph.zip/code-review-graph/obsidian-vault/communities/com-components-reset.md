---
aliases: ["components-reset"]
tags: [community, tsx]
size: 2
cohesion: 0.0400
---

# Community · components-reset

**Size:** 2 &nbsp; **Cohesion:** 0.0400 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/sidebar/components/ResetConfirmationDialog.tsx

## Members (2)
- [[file-frontend-src-pages-sidebar-components-resetconfirmationdialog-tsx|ResetConfirmationDialog.tsx]] — *File* `1-65`
- [[fn-frontend-src-pages-sidebar-components-resetconfirmationdialog-tsx--resetconfirmationdialog|ResetConfirmationDialog]] — *Function* `11-64`
