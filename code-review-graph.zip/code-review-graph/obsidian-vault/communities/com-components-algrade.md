---
aliases: ["components-algrade"]
tags: [community, tsx]
size: 7
cohesion: 0.1333
---

# Community · components-algrade

**Size:** 7 &nbsp; **Cohesion:** 0.1333 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/AutocodeValidation.tsx

## Members (7)
- [[file-frontend-src-pages-pathanalysispage-components-autocodevalidation-tsx|AutocodeValidation.tsx]] — *File* `1-451`
- [[fn-frontend-src-pages-pathanalysispage-components-autocodevalidation-tsx--getalgrade|getALGrade]] — *Function* `5-14`
- [[fn-frontend-src-pages-pathanalysispage-components-autocodevalidation-tsx--autocodevalidation|AutocodeValidation]] — *Function* `157-450`
- [[fn-frontend-src-pages-pathanalysispage-components-autocodevalidation-tsx--normalizeattributevalues|normalizeAttributeValues]] — *Function* `167-182`
- [[fn-frontend-src-pages-pathanalysispage-components-autocodevalidation-tsx--row|row]] — *Function* `168-181`
- [[fn-frontend-src-pages-pathanalysispage-components-autocodevalidation-tsx--handlebaselineupdate|handleBaselineUpdate]] — *Function* `321-324`
- [[fn-frontend-src-pages-pathanalysispage-components-autocodevalidation-tsx--g|g]] — *Function* `334-334`
