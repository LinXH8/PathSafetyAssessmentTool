---
aliases: ["components-filter"]
tags: [community, tsx]
size: 7
cohesion: 0.1579
---

# Community · components-filter

**Size:** 7 &nbsp; **Cohesion:** 0.1579 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/FilterPanel.tsx

## Members (7)
- [[file-frontend-src-pages-pathanalysispage-components-filterpanel-tsx|FilterPanel.tsx]] — *File* `1-167`
- [[fn-frontend-src-pages-pathanalysispage-components-filterpanel-tsx--filterpanel|FilterPanel]] — *Function* `23-167`
- [[fn-frontend-src-pages-pathanalysispage-components-filterpanel-tsx--toggle|toggle]] — *Function* `26-32`
- [[fn-frontend-src-pages-pathanalysispage-components-filterpanel-tsx--f|f]] — *Function* `28-28`
- [[fn-frontend-src-pages-pathanalysispage-components-filterpanel-tsx--a|a]] — *Function* `100-100`
- [[fn-frontend-src-pages-pathanalysispage-components-filterpanel-tsx--group|group]] — *Function* `115-161`
- [[fn-frontend-src-pages-pathanalysispage-components-filterpanel-tsx--attr|attr]] — *Function* `118-158`
