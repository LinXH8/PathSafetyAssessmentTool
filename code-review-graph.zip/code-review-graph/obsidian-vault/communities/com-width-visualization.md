---
aliases: ["width-visualization"]
tags: [community, tsx]
size: 6
cohesion: 0.3667
---

# Community · width-visualization

**Size:** 6 &nbsp; **Cohesion:** 0.3667 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/width/WidthVisualizationPanel.tsx

## Members (6)
- [[file-frontend-src-components-visualization-width-widthvisualizationpanel-tsx|WidthVisualizationPanel.tsx]] — *File* `1-179`
- [[fn-frontend-src-components-visualization-width-widthvisualizationpanel-tsx--widthvisualizationpanel|WidthVisualizationPanel]] — *Function* `11-167`
- [[fn-frontend-src-components-visualization-width-widthvisualizationpanel-tsx--loadvisualization|loadVisualization]] — *Function* `22-34`
- [[fn-frontend-src-components-visualization-width-widthvisualizationpanel-tsx--getcategorycolor|getCategoryColor]] — *Function* `62-69`
- [[fn-frontend-src-components-visualization-width-widthvisualizationpanel-tsx--getcategoryicon|getCategoryIcon]] — *Function* `71-78`
- [[fn-frontend-src-components-visualization-width-widthvisualizationpanel-tsx--getlayercolor|getLayerColor]] — *Function* `169-176`
