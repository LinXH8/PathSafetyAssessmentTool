---
aliases: ["backend-inspect"]
tags: [community, python]
size: 2
cohesion: 0.0385
---

# Community · backend-inspect

**Size:** 2 &nbsp; **Cohesion:** 0.0385 &nbsp; **Dominant language:** python

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/inspect_data.py

## Members (2)
- [[file-backend-inspect-data-py|inspect_data.py]] — *File* `1-54`
- [[fn-backend-inspect-data-py--inspect-project|inspect_project]] — *Function* `10-50`
