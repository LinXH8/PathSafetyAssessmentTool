---
aliases: ["projects-tag"]
tags: [community, tsx]
size: 25
cohesion: 0.1974
---

# Community · projects-tag

**Size:** 25 &nbsp; **Cohesion:** 0.1974 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/Projects/projects.tsx

## Members (25)
- [[file-frontend-src-pages-projects-projects-tsx|projects.tsx]] — *File* `1-692`
- [[fn-frontend-src-pages-projects-projects-tsx--createproject|createProject]] — *Function* `18-20`
- [[fn-frontend-src-pages-projects-projects-tsx--gettagcolor|getTagColor]] — *Function* `27-51`
- [[fn-frontend-src-pages-projects-projects-tsx--home|Home]] — *Function* `53-692`
- [[fn-frontend-src-pages-projects-projects-tsx--handleverificationupdate|handleVerificationUpdate]] — *Function* `101-119`
- [[fn-frontend-src-pages-projects-projects-tsx--handleautocodedupdate|handleAutocodedUpdate]] — *Function* `127-144`
- [[fn-frontend-src-pages-projects-projects-tsx--selectedtag|selectedTag]] — *Function* `209-209`
- [[fn-frontend-src-pages-projects-projects-tsx--onrowclick|onRowClick]] — *Function* `217-227`
- [[fn-frontend-src-pages-projects-projects-tsx--toggleselectall|toggleSelectAll]] — *Function* `230-238`
- [[fn-frontend-src-pages-projects-projects-tsx--p|p]] — *Function* `236-236`
- [[fn-frontend-src-pages-projects-projects-tsx--loadproject|loadProject]] — *Function* `241-247`
- [[fn-frontend-src-pages-projects-projects-tsx--loadtreatment|loadTreatment]] — *Function* `250-256`
- [[fn-frontend-src-pages-projects-projects-tsx--loadpathanalysis|loadPathAnalysis]] — *Function* `259-265`
- [[fn-frontend-src-pages-projects-projects-tsx--handleeditsuccess|handleEditSuccess]] — *Function* `268-292`
- [[fn-frontend-src-pages-projects-projects-tsx--prev|prev]] — *Function* `285-290`
- [[fn-frontend-src-pages-projects-projects-tsx--askdelete|askDelete]] — *Function* `295-298`
- [[fn-frontend-src-pages-projects-projects-tsx--confirmdelete|confirmDelete]] — *Function* `301-319`
- [[fn-frontend-src-pages-projects-projects-tsx--removetagfilter|removeTagFilter]] — *Function* `322-324`
- [[fn-frontend-src-pages-projects-projects-tsx--handlesort|handleSort]] — *Function* `328-358`
- [[fn-frontend-src-pages-projects-projects-tsx--current|current]] — *Function* `329-357`
- [[fn-frontend-src-pages-projects-projects-tsx--getsortmeta|getSortMeta]] — *Function* `361-368`
- [[fn-frontend-src-pages-projects-projects-tsx--c|c]] — *Function* `362-362`
- [[fn-frontend-src-pages-projects-projects-tsx--renderheader|renderHeader]] — *Function* `370-394`
- [[fn-frontend-src-pages-projects-projects-tsx--tag|tag]] — *Function* `460-462`
- [[fn-frontend-src-pages-projects-projects-tsx--name|name]] — *Function* `663-665`
