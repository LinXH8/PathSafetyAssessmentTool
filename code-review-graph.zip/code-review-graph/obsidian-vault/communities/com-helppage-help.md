---
aliases: ["helppage-help"]
tags: [community, tsx]
size: 4
cohesion: 0.2174
---

# Community · helppage-help

**Size:** 4 &nbsp; **Cohesion:** 0.2174 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/HelpPage/helpPage.tsx

## Members (4)
- [[file-frontend-src-pages-helppage-helppage-tsx|helpPage.tsx]] — *File* `1-174`
- [[fn-frontend-src-pages-helppage-helppage-tsx--helppage|HelpPage]] — *Function* `8-97`
- [[fn-frontend-src-pages-helppage-helppage-tsx--adminguide|AdminGuide]] — *Function* `99-155`
- [[fn-frontend-src-pages-helppage-helppage-tsx--code|Code]] — *Function* `157-173`
