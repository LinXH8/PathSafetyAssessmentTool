---
aliases: ["services-calculate"]
tags: [community, python]
size: 12
cohesion: 0.4407
---

# Community · services-calculate

**Size:** 12 &nbsp; **Cohesion:** 0.4407 &nbsp; **Dominant language:** python

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/cyclerap_scoring.py

## Members (12)
- [[file-backend-app-services-cyclerap-scoring-py|cyclerap_scoring.py]] — *File* `1-519`
- [[fn-backend-app-services-cyclerap-scoring-py--get-risk|get_risk]] — *Function* `115-117`
- [[fn-backend-app-services-cyclerap-scoring-py--get-cond|get_cond]] — *Function* `120-122`
- [[fn-backend-app-services-cyclerap-scoring-py--get-aadt-risk-factor|get_aadt_risk_factor]] — *Function* `147-155`
- [[fn-backend-app-services-cyclerap-scoring-py--get-road-speed-risk-factor|get_road_speed_risk_factor]] — *Function* `158-164`
- [[fn-backend-app-services-cyclerap-scoring-py--calculate-cm3|calculate_cm3]] — *Function* `168-202`
- [[fn-backend-app-services-cyclerap-scoring-py--calculate-cm16|calculate_cm16]] — *Function* `205-227`
- [[fn-backend-app-services-cyclerap-scoring-py--calculate-cm25|calculate_cm25]] — *Function* `230-249`
- [[fn-backend-app-services-cyclerap-scoring-py--calculate-cm40|calculate_cm40]] — *Function* `252-288`
- [[fn-backend-app-services-cyclerap-scoring-py--calculate-cyclerap-score|calculate_cyclerap_score]] — *Function* `291-424`
- [[fn-backend-app-services-cyclerap-scoring-py--calculate-risk-band-for-type|calculate_risk_band_for_type]] — *Function* `428-463`
- [[fn-backend-app-services-cyclerap-scoring-py--calculate-cyclerap-score-native|calculate_cyclerap_score_native]] — *Function* `466-518`
