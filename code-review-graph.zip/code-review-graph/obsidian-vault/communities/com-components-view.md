---
aliases: ["components-view"]
tags: [community, tsx]
size: 3
cohesion: 0.2143
---

# Community · components-view

**Size:** 3 &nbsp; **Cohesion:** 0.2143 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/AnalysisPage/components/MapView.tsx

## Members (3)
- [[file-frontend-src-pages-analysispage-components-mapview-tsx|MapView.tsx]] — *File* `1-47`
- [[fn-frontend-src-pages-analysispage-components-mapview-tsx--setviewonload|SetViewOnLoad]] — *Function* `12-20`
- [[fn-frontend-src-pages-analysispage-components-mapview-tsx--mapview|MapView]] — *Function* `22-46`
