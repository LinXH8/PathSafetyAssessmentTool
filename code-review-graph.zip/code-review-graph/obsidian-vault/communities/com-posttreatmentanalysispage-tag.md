---
aliases: ["posttreatmentanalysispage-tag"]
tags: [community, tsx]
size: 8
cohesion: 0.2000
---

# Community · posttreatmentanalysispage-tag

**Size:** 8 &nbsp; **Cohesion:** 0.2000 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PostTreatmentAnalysisPage/postTreatmentAnalysisPage.tsx

## Members (8)
- [[file-frontend-src-pages-posttreatmentanalysispage-posttreatmentanalysispage-tsx|postTreatmentAnalysisPage.tsx]] — *File* `1-243`
- [[fn-frontend-src-pages-posttreatmentanalysispage-posttreatmentanalysispage-tsx--gettagbordercolor|getTagBorderColor]] — *Function* `11-15`
- [[fn-frontend-src-pages-posttreatmentanalysispage-posttreatmentanalysispage-tsx--gettagcolor|getTagColor]] — *Function* `17-45`
- [[fn-frontend-src-pages-posttreatmentanalysispage-posttreatmentanalysispage-tsx--posttreatmentanalysispage|PostTreatmentAnalysisPage]] — *Function* `47-242`
- [[fn-frontend-src-pages-posttreatmentanalysispage-posttreatmentanalysispage-tsx--onrowclick|onRowClick]] — *Function* `79-79`
- [[fn-frontend-src-pages-posttreatmentanalysispage-posttreatmentanalysispage-tsx--analyzeproject|analyzeProject]] — *Function* `81-84`
- [[fn-frontend-src-pages-posttreatmentanalysispage-posttreatmentanalysispage-tsx--compareprojects|compareProjects]] — *Function* `86-89`
- [[fn-frontend-src-pages-posttreatmentanalysispage-posttreatmentanalysispage-tsx--tag|tag]] — *Function* `160-160`
