---
aliases: ["utils-width"]
tags: [community, python]
size: 13
cohesion: 0.2437
---

# Community · utils-width

**Size:** 13 &nbsp; **Cohesion:** 0.2437 &nbsp; **Dominant language:** python

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/utils/path_width_curvature.py

## Members (13)
- [[file-backend-app-utils-path-width-curvature-py|path_width_curvature.py]] — *File* `1-402`
- [[fn-backend-app-utils-path-width-curvature-py--remove-z|remove_z]] — *Function* `20-44`
- [[fn-backend-app-utils-path-width-curvature-py--to-2d|to_2d]] — *Function* `28-29`
- [[fn-backend-app-utils-path-width-curvature-py--standardize-width-column|standardize_width_column]] — *Function* `47-78`
- [[fn-backend-app-utils-path-width-curvature-py--load-layer|load_layer]] — *Function* `85-132`
- [[fn-backend-app-utils-path-width-curvature-py--densify-linestring|_densify_linestring]] — *Function* `139-150`
- [[fn-backend-app-utils-path-width-curvature-py--min-triplet-radius-from-linestring|_min_triplet_radius_from_linestring]] — *Function* `153-182`
- [[fn-backend-app-utils-path-width-curvature-py--merge-connectable-lines|_merge_connectable_lines]] — *Function* `185-208`
- [[fn-backend-app-utils-path-width-curvature-py--extract-lines|_extract_lines]] — *Function* `211-227`
- [[fn-backend-app-utils-path-width-curvature-py--min-radius-within-window-for-layer|_min_radius_within_window_for_layer]] — *Function* `230-281`
- [[fn-backend-app-utils-path-width-curvature-py--nearest-radius-and-width-with-priority|_nearest_radius_and_width_with_priority]] — *Function* `288-350`
- [[fn-backend-app-utils-path-width-curvature-py--get-radius-and-width-at-point|get_radius_and_width_at_point]] — *Function* `357-385`
- [[fn-backend-app-utils-path-width-curvature-py--get-width-at-point|get_width_at_point]] — *Function* `388-401`
