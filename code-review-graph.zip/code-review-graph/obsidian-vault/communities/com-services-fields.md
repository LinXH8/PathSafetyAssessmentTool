---
aliases: ["services-fields"]
tags: [community, python]
size: 44
cohesion: 0.3135
---

# Community · services-fields

**Size:** 44 &nbsp; **Cohesion:** 0.3135 &nbsp; **Dominant language:** python

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/serializer.py

## Members (44)
- [[file-backend-app-services-serializer-py|serializer.py]] — *File* `1-521`
- [[cls-backend-app-services-serializer-py--locwrapper|LocWrapper]] — *Class* `53-62`
- [[fn-backend-app-services-serializer-py--init|__init__]] — *Function* `54-55`
- [[fn-backend-app-services-serializer-py--getitem|__getitem__]] — *Function* `57-58`
- [[fn-backend-app-services-serializer-py--setitem|__setitem__]] — *Function* `60-62`
- [[cls-backend-app-services-serializer-py--basetable|BaseTable]] — *Class* `64-142`
- [[fn-backend-app-services-serializer-py--init-2|__init__]] — *Function* `65-80`
- [[fn-backend-app-services-serializer-py--df|df]] — *Function* `87-91`
- [[fn-backend-app-services-serializer-py--serialize|serialize]] — *Function* `93-105`
- [[fn-backend-app-services-serializer-py--parse|parse]] — *Function* `107-142`
- [[cls-backend-app-services-serializer-py--attributes|Attributes]] — *Class* `144-253`
- [[cls-backend-app-services-serializer-py--fields|Fields]] — *Class* `145-199`
- [[fn-backend-app-services-serializer-py--values|values]] — *Function* `198-199`
- [[fn-backend-app-services-serializer-py--init-3|__init__]] — *Function* `252-253`
- [[cls-backend-app-services-serializer-py--results|Results]] — *Class* `255-277`
- [[cls-backend-app-services-serializer-py--fields-2|Fields]] — *Class* `256-266`
- [[fn-backend-app-services-serializer-py--init-4|__init__]] — *Function* `276-277`
- [[cls-backend-app-services-serializer-py--snapshotmetadata|SnapshotMetadata]] — *Class* `279-288`
- [[cls-backend-app-services-serializer-py--fields-3|Fields]] — *Class* `280-284`
- [[fn-backend-app-services-serializer-py--init-5|__init__]] — *Function* `286-288`
- [[cls-backend-app-services-serializer-py--treatment|Treatment]] — *Class* `290-304`
- [[cls-backend-app-services-serializer-py--fields-4|Fields]] — *Class* `291-301`
- [[fn-backend-app-services-serializer-py--init-6|__init__]] — *Function* `303-304`
- [[cls-backend-app-services-serializer-py--projectgeodata|ProjectGeoData]] — *Class* `306-373`
- [[cls-backend-app-services-serializer-py--fields-5|Fields]] — *Class* `307-311`
- [[fn-backend-app-services-serializer-py--init-7|__init__]] — *Function* `315-340`
- [[fn-backend-app-services-serializer-py--populate-linestring|populate_linestring]] — *Function* `344-350`
- [[fn-backend-app-services-serializer-py--get-point-start|get_point_start]] — *Function* `352-354`
- [[fn-backend-app-services-serializer-py--get-point-end|get_point_end]] — *Function* `356-358`
- [[fn-backend-app-services-serializer-py--serialize-2|serialize]] — *Function* `362-365`
- [[fn-backend-app-services-serializer-py--parse-2|parse]] — *Function* `367-373`
- [[cls-backend-app-services-serializer-py--projectmetadata|ProjectMetadata]] — *Class* `375-437`
- [[fn-backend-app-services-serializer-py--init-8|__init__]] — *Function* `378-389`
- [[fn-backend-app-services-serializer-py--parse-3|parse]] — *Function* `393-416`
- [[fn-backend-app-services-serializer-py--parse-datetime|parse_datetime]] — *Function* `399-405`
- [[fn-backend-app-services-serializer-py--to-dict|to_dict]] — *Function* `418-431`
- [[fn-backend-app-services-serializer-py--serialize-3|serialize]] — *Function* `433-437`
- [[cls-backend-app-services-serializer-py--data-loader|data_loader]] — *Class* `441-520`
- [[cls-backend-app-services-serializer-py--fields-6|Fields]] — *Class* `449-451`
- [[fn-backend-app-services-serializer-py--initialise|initialise]] — *Function* `454-459`
- [[fn-backend-app-services-serializer-py--clean-old-cache|clean_old_cache]] — *Function* `462-466`
- [[fn-backend-app-services-serializer-py--gettrafficflow-df|getTrafficFlow_df]] — *Function* `469-487`
- [[fn-backend-app-services-serializer-py--gettrafficspeedbands-df|getTrafficSpeedBands_df]] — *Function* `490-508`
- [[fn-backend-app-services-serializer-py--apicall|APIcall]] — *Function* `511-520`
