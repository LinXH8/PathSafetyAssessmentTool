---
aliases: ["backend-pdf"]
tags: [community, python]
size: 8
cohesion: 0.3455
---

# Community · backend-pdf

**Size:** 8 &nbsp; **Cohesion:** 0.3455 &nbsp; **Dominant language:** python

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/generate_user_guide_pdf.py

## Members (8)
- [[file-backend-generate-user-guide-pdf-py|generate_user_guide_pdf.py]] — *File* `1-77`
- [[cls-backend-generate-user-guide-pdf-py--pdf|PDF]] — *Class* `4-41`
- [[fn-backend-generate-user-guide-pdf-py--header|header]] — *Function* `5-10`
- [[fn-backend-generate-user-guide-pdf-py--footer|footer]] — *Function* `12-15`
- [[fn-backend-generate-user-guide-pdf-py--section-title|section_title]] — *Function* `17-21`
- [[fn-backend-generate-user-guide-pdf-py--section-body|section_body]] — *Function* `23-26`
- [[fn-backend-generate-user-guide-pdf-py--print-bullet|print_bullet]] — *Function* `28-41`
- [[fn-backend-generate-user-guide-pdf-py--create-pdf|create_pdf]] — *Function* `43-73`
