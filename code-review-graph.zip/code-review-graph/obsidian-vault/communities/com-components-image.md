---
aliases: ["components-image"]
tags: [community, tsx]
size: 2
cohesion: 0.0476
---

# Community · components-image

**Size:** 2 &nbsp; **Cohesion:** 0.0476 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/CodingPage/components/ImagePanel.tsx

## Members (2)
- [[file-frontend-src-pages-codingpage-components-imagepanel-tsx|ImagePanel.tsx]] — *File* `1-64`
- [[fn-frontend-src-pages-codingpage-components-imagepanel-tsx--imagepanel|ImagePanel]] — *Function* `11-63`
