---
aliases: ["landingpage-landing"]
tags: [community, tsx]
size: 3
cohesion: 0.1818
---

# Community · landingpage-landing

**Size:** 3 &nbsp; **Cohesion:** 0.1818 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/LandingPage/landingPage.tsx

## Members (3)
- [[file-frontend-src-pages-landingpage-landingpage-tsx|landingPage.tsx]] — *File* `1-54`
- [[fn-frontend-src-pages-landingpage-landingpage-tsx--landingpage|LandingPage]] — *Function* `8-53`
- [[fn-frontend-src-pages-landingpage-landingpage-tsx--startpsat|startPSAT]] — *Function* `10-10`
