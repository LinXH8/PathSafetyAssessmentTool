---
aliases: ["curvature-visualization"]
tags: [community, tsx]
size: 4
cohesion: 0.2000
---

# Community · curvature-visualization

**Size:** 4 &nbsp; **Cohesion:** 0.2000 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/curvature/CurvatureVisualizationPanel.tsx

## Members (4)
- [[file-frontend-src-components-visualization-curvature-curvaturevisualizationpanel-tsx|CurvatureVisualizationPanel.tsx]] — *File* `1-188`
- [[fn-frontend-src-components-visualization-curvature-curvaturevisualizationpanel-tsx--curvaturevisualizationpanel|CurvatureVisualizationPanel]] — *Function* `12-176`
- [[fn-frontend-src-components-visualization-curvature-curvaturevisualizationpanel-tsx--loadvisualization|loadVisualization]] — *Function* `23-35`
- [[fn-frontend-src-components-visualization-curvature-curvaturevisualizationpanel-tsx--getlayercolor|getLayerColor]] — *Function* `178-185`
