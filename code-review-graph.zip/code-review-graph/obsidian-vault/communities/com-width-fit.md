---
aliases: ["width-fit"]
tags: [community, tsx]
size: 3
cohesion: 0.1154
---

# Community · width-fit

**Size:** 3 &nbsp; **Cohesion:** 0.1154 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/width/WidthVisualization.tsx

## Members (3)
- [[file-frontend-src-components-visualization-width-widthvisualization-tsx|WidthVisualization.tsx]] — *File* `1-138`
- [[fn-frontend-src-components-visualization-width-widthvisualization-tsx--fitbounds|FitBounds]] — *Function* `12-20`
- [[fn-frontend-src-components-visualization-width-widthvisualization-tsx--widthvisualization|WidthVisualization]] — *Function* `22-135`
