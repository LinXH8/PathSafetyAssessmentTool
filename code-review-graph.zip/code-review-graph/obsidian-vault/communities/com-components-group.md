---
aliases: ["components-group"]
tags: [community, tsx]
size: 6
cohesion: 0.0860
---

# Community · components-group

**Size:** 6 &nbsp; **Cohesion:** 0.0860 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/CodingPage/components/AttributesPanel.tsx

## Members (6)
- [[file-frontend-src-pages-codingpage-components-attributespanel-tsx|AttributesPanel.tsx]] — *File* `1-539`
- [[fn-frontend-src-pages-codingpage-components-attributespanel-tsx--groupentries|groupEntries]] — *Function* `163-209`
- [[fn-frontend-src-pages-codingpage-components-attributespanel-tsx--todisplaystring|toDisplayString]] — *Function* `211-215`
- [[fn-frontend-src-pages-codingpage-components-attributespanel-tsx--attributespanel|AttributesPanel]] — *Function* `218-538`
- [[fn-frontend-src-pages-codingpage-components-attributespanel-tsx--ismanuallyedited|isManuallyEdited]] — *Function* `249-283`
- [[fn-frontend-src-pages-codingpage-components-attributespanel-tsx--code|code]] — *Function* `473-480`
