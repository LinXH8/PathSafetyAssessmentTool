---
aliases: ["common-help"]
tags: [community, tsx]
size: 2
cohesion: 0.1667
---

# Community · common-help

**Size:** 2 &nbsp; **Cohesion:** 0.1667 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/common/HelpButton.tsx

## Members (2)
- [[file-frontend-src-components-common-helpbutton-tsx|HelpButton.tsx]] — *File* `1-44`
- [[fn-frontend-src-components-common-helpbutton-tsx--helpbutton|HelpButton]] — *Function* `3-43`
