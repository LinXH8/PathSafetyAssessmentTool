---
aliases: ["services-ema"]
tags: [community, python]
size: 4
cohesion: 0.1000
---

# Community · services-ema

**Size:** 4 &nbsp; **Cohesion:** 0.1000 &nbsp; **Dominant language:** python

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/ema.py

## Members (4)
- [[file-backend-app-services-ema-py|ema.py]] — *File* `1-33`
- [[cls-backend-app-services-ema-py--ema|EMA]] — *Class* `5-32`
- [[fn-backend-app-services-ema-py--init|__init__]] — *Function* `6-16`
- [[fn-backend-app-services-ema-py--forward|forward]] — *Function* `18-32`
