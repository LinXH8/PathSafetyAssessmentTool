---
aliases: ["components-treatment"]
tags: [community, tsx]
size: 2
cohesion: 0.0714
---

# Community · components-treatment

**Size:** 2 &nbsp; **Cohesion:** 0.0714 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/sidebar/components/TreatmentSidebar.tsx

## Members (2)
- [[file-frontend-src-pages-sidebar-components-treatmentsidebar-tsx|TreatmentSidebar.tsx]] — *File* `1-82`
- [[fn-frontend-src-pages-sidebar-components-treatmentsidebar-tsx--treatmentsidebar|TreatmentSidebar]] — *Function* `10-81`
