---
aliases: ["common-theme"]
tags: [community, tsx]
size: 2
cohesion: 0.0526
---

# Community · common-theme

**Size:** 2 &nbsp; **Cohesion:** 0.0526 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/common/ThemeAwareTileLayer.tsx

## Members (2)
- [[file-frontend-src-components-common-themeawaretilelayer-tsx|ThemeAwareTileLayer.tsx]] — *File* `1-19`
- [[fn-frontend-src-components-common-themeawaretilelayer-tsx--themeawaretilelayer|ThemeAwareTileLayer]] — *Function* `4-18`
