---
aliases: ["components-attributes"]
tags: [community, tsx]
size: 3
cohesion: 0.0882
---

# Community · components-attributes

**Size:** 3 &nbsp; **Cohesion:** 0.0882 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/AnalysisPage/components/AttributesDropdown.tsx

## Members (3)
- [[file-frontend-src-pages-analysispage-components-attributesdropdown-tsx|AttributesDropdown.tsx]] — *File* `1-195`
- [[fn-frontend-src-pages-analysispage-components-attributesdropdown-tsx--attributesdropdown|AttributesDropdown]] — *Function* `114-194`
- [[fn-frontend-src-pages-analysispage-components-attributesdropdown-tsx--handleattributechange|handleAttributeChange]] — *Function* `120-123`
