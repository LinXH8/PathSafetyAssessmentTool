---
aliases: ["components-upload"]
tags: [community, tsx]
size: 3
cohesion: 0.0625
---

# Community · components-upload

**Size:** 3 &nbsp; **Cohesion:** 0.0625 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/ShapefileManagement/components/UploadModal.tsx

## Members (3)
- [[file-frontend-src-pages-shapefilemanagement-components-uploadmodal-tsx|UploadModal.tsx]] — *File* `1-111`
- [[fn-frontend-src-pages-shapefilemanagement-components-uploadmodal-tsx--uploadmodal|UploadModal]] — *Function* `16-110`
- [[fn-frontend-src-pages-shapefilemanagement-components-uploadmodal-tsx--handleback|handleBack]] — *Function* `24-26`
