---
aliases: ["layouts-app"]
tags: [community, tsx]
size: 2
cohesion: 0.1250
---

# Community · layouts-app

**Size:** 2 &nbsp; **Cohesion:** 0.1250 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/layouts/AppLayout.tsx

## Members (2)
- [[file-frontend-src-layouts-applayout-tsx|AppLayout.tsx]] — *File* `1-15`
- [[fn-frontend-src-layouts-applayout-tsx--applayout|AppLayout]] — *Function* `5-14`
