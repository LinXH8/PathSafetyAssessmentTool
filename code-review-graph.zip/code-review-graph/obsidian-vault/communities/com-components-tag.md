---
aliases: ["components-tag"]
tags: [community, tsx]
size: 13
cohesion: 0.1164
---

# Community · components-tag

**Size:** 13 &nbsp; **Cohesion:** 0.1164 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/AddSegmentsDialog.tsx

## Members (13)
- [[file-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx|AddSegmentsDialog.tsx]] — *File* `1-433`
- [[fn-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx--gettagcolor|getTagColor]] — *Function* `20-36`
- [[fn-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx--addsegmentsdialog|AddSegmentsDialog]] — *Function* `50-432`
- [[fn-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx--n|n]] — *Function* `86-86`
- [[fn-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx--tag|tag]] — *Function* `98-98`
- [[fn-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx--handletaginputkeydown|handleTagInputKeyDown]] — *Function* `107-118`
- [[fn-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx--removetag|removeTag]] — *Function* `120-122`
- [[fn-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx--performcopy|performCopy]] — *Function* `124-160`
- [[fn-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx--handlesubmit|handleSubmit]] — *Function* `162-209`
- [[fn-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx--handleconfirmreplace|handleConfirmReplace]] — *Function* `211-213`
- [[fn-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx--p|p]] — *Function* `218-218`
- [[fn-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx--s|s]] — *Function* `237-241`
- [[fn-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx--t|t]] — *Function* `363-367`
