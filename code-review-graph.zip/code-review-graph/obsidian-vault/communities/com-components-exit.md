---
aliases: ["components-exit"]
tags: [community, tsx]
size: 2
cohesion: 0.0345
---

# Community · components-exit

**Size:** 2 &nbsp; **Cohesion:** 0.0345 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/sidebar/components/ExitConfirmationDialog.tsx

## Members (2)
- [[file-frontend-src-pages-sidebar-components-exitconfirmationdialog-tsx|ExitConfirmationDialog.tsx]] — *File* `1-75`
- [[fn-frontend-src-pages-sidebar-components-exitconfirmationdialog-tsx--exitconfirmationdialog|ExitConfirmationDialog]] — *Function* `12-74`
