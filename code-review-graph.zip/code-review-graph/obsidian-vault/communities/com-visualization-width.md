---
aliases: ["visualization-width"]
tags: [community, tsx]
size: 9
cohesion: 0.3514
---

# Community · visualization-width

**Size:** 9 &nbsp; **Cohesion:** 0.3514 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/AnalysisPanel.tsx

## Members (9)
- [[file-frontend-src-components-visualization-analysispanel-tsx|AnalysisPanel.tsx]] — *File* `1-334`
- [[fn-frontend-src-components-visualization-analysispanel-tsx--getwidthcategorycolor|getWidthCategoryColor]] — *Function* `19-26`
- [[fn-frontend-src-components-visualization-analysispanel-tsx--getwidthcategoryicon|getWidthCategoryIcon]] — *Function* `28-35`
- [[fn-frontend-src-components-visualization-analysispanel-tsx--getlayercolor|getLayerColor]] — *Function* `37-44`
- [[fn-frontend-src-components-visualization-analysispanel-tsx--layerdot|LayerDot]] — *Function* `46-60`
- [[fn-frontend-src-components-visualization-analysispanel-tsx--datacard|DataCard]] — *Function* `72-86`
- [[fn-frontend-src-components-visualization-analysispanel-tsx--analysispanel|AnalysisPanel]] — *Function* `90-331`
- [[fn-frontend-src-components-visualization-analysispanel-tsx--e|e]] — *Function* `124-124`
- [[fn-frontend-src-components-visualization-analysispanel-tsx--v|v]] — *Function* `297-297`
