---
aliases: ["components-coding"]
tags: [community, tsx]
size: 2
cohesion: 0.0625
---

# Community · components-coding

**Size:** 2 &nbsp; **Cohesion:** 0.0625 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/sidebar/components/CodingSidebar.tsx

## Members (2)
- [[file-frontend-src-pages-sidebar-components-codingsidebar-tsx|CodingSidebar.tsx]] — *File* `1-73`
- [[fn-frontend-src-pages-sidebar-components-codingsidebar-tsx--codingsidebar|CodingSidebar]] — *Function* `14-72`
