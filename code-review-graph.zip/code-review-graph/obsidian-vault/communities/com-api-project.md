---
aliases: ["api-project"]
tags: [community, typescript]
size: 41
cohesion: 0.2241
---

# Community · api-project

**Size:** 41 &nbsp; **Cohesion:** 0.2241 &nbsp; **Dominant language:** typescript

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/api/index.ts

## Members (41)
- [[file-frontend-src-api-index-ts|index.ts]] — *File* `1-878`
- [[fn-frontend-src-api-index-ts--ping|ping]] — *Function* `4-8`
- [[fn-frontend-src-api-index-ts--fetchprojectlist|fetchProjectList]] — *Function* `26-30`
- [[fn-frontend-src-api-index-ts--fetchprojectdetail|fetchProjectDetail]] — *Function* `39-43`
- [[fn-frontend-src-api-index-ts--fetchprojectmetadata|fetchProjectMetadata]] — *Function* `46-50`
- [[fn-frontend-src-api-index-ts--fetchprojectattributes|fetchProjectAttributes]] — *Function* `56-62`
- [[fn-frontend-src-api-index-ts--fetchprojectgeojson|fetchProjectGeoJSON]] — *Function* `66-72`
- [[fn-frontend-src-api-index-ts--fetchattributemappings|fetchAttributeMappings]] — *Function* `78-82`
- [[fn-frontend-src-api-index-ts--saveattributes|saveAttributes]] — *Function* `84-92`
- [[fn-frontend-src-api-index-ts--listsourcefolders|listSourceFolders]] — *Function* `94-99`
- [[fn-frontend-src-api-index-ts--createprojectfromfolder|createProjectFromFolder]] — *Function* `101-110`
- [[fn-frontend-src-api-index-ts--deleteproject|deleteProject]] — *Function* `113-124`
- [[fn-frontend-src-api-index-ts--updateproject|updateProject]] — *Function* `127-141`
- [[fn-frontend-src-api-index-ts--deletesegment|deleteSegment]] — *Function* `144-150`
- [[fn-frontend-src-api-index-ts--deletesegmentsbatch|deleteSegmentsBatch]] — *Function* `153-161`
- [[fn-frontend-src-api-index-ts--checkcollisions|checkCollisions]] — *Function* `164-176`
- [[fn-frontend-src-api-index-ts--copysegments|copySegments]] — *Function* `179-194`
- [[fn-frontend-src-api-index-ts--autocodeimage|autocodeImage]] — *Function* `196-208`
- [[fn-frontend-src-api-index-ts--autocodegis|autocodeGIS]] — *Function* `210-222`
- [[fn-frontend-src-api-index-ts--readerror|readError]] — *Function* `282-290`
- [[fn-frontend-src-api-index-ts--autocodeall|autocodeAll]] — *Function* `311-321`
- [[fn-frontend-src-api-index-ts--calculatescore|calculateScore]] — *Function* `336-345`
- [[fn-frontend-src-api-index-ts--calculatescoreforrow|calculateScoreForRow]] — *Function* `354-365`
- [[fn-frontend-src-api-index-ts--listshapefiles|listShapefiles]] — *Function* `445-449`
- [[fn-frontend-src-api-index-ts--uploadshapefiles|uploadShapefiles]] — *Function* `456-469`
- [[fn-frontend-src-api-index-ts--replaceshapefiles|replaceShapefiles]] — *Function* `475-485`
- [[fn-frontend-src-api-index-ts--deleteshapefile|deleteShapefile]] — *Function* `491-497`
- [[fn-frontend-src-api-index-ts--validateshapefile|validateShapefile]] — *Function* `503-513`
- [[fn-frontend-src-api-index-ts--validateshapefilereplacement|validateShapefileReplacement]] — *Function* `521-537`
- [[fn-frontend-src-api-index-ts--listshapefilecategories|listShapefileCategories]] — *Function* `542-546`
- [[fn-frontend-src-api-index-ts--applytreatments|applyTreatments]] — *Function* `609-623`
- [[fn-frontend-src-api-index-ts--getsegmenttreatments|getSegmentTreatments]] — *Function* `631-640`
- [[fn-frontend-src-api-index-ts--getalltreatments|getAllTreatments]] — *Function* `659-667`
- [[fn-frontend-src-api-index-ts--previewtreatments|previewTreatments]] — *Function* `713-727`
- [[fn-frontend-src-api-index-ts--applyalltreatments|applyAllTreatments]] — *Function* `747-759`
- [[fn-frontend-src-api-index-ts--applyspecifictreatment|applySpecificTreatment]] — *Function* `767-781`
- [[fn-frontend-src-api-index-ts--resetalltreatments|resetAllTreatments]] — *Function* `795-807`
- [[fn-frontend-src-api-index-ts--savetreatments|saveTreatments]] — *Function* `819-831`
- [[fn-frontend-src-api-index-ts--uploadimagestosourcefolder|uploadImagesToSourceFolder]] — *Function* `838-858`
- [[fn-frontend-src-api-index-ts--file|file]] — *Function* `845-850`
- [[fn-frontend-src-api-index-ts--downloadfilteredimages|downloadFilteredImages]] — *Function* `864-877`
