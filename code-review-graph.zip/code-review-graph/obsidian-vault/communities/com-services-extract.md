---
aliases: ["services-extract"]
tags: [community, python]
size: 13
cohesion: 0.1308
---

# Community · services-extract

**Size:** 13 &nbsp; **Cohesion:** 0.1308 &nbsp; **Dominant language:** python

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/cycle_rap_processing_gopro_footage.py

## Members (13)
- [[file-backend-app-services-cycle-rap-processing-gopro-footage-py|cycle_rap_processing_gopro_footage.py]] — *File* `1-211`
- [[fn-backend-app-services-cycle-rap-processing-gopro-footage-py--gdfify|gdfify]] — *Function* `26-32`
- [[fn-backend-app-services-cycle-rap-processing-gopro-footage-py--todecimal|toDecimal]] — *Function* `34-45`
- [[fn-backend-app-services-cycle-rap-processing-gopro-footage-py--geocode|geoCode]] — *Function* `47-49`
- [[fn-backend-app-services-cycle-rap-processing-gopro-footage-py--extractgps|extractGPS]] — *Function* `51-71`
- [[fn-backend-app-services-cycle-rap-processing-gopro-footage-py--getbuffer|getBuffer]] — *Function* `73-77`
- [[fn-backend-app-services-cycle-rap-processing-gopro-footage-py--snaptolink|snaptoLink]] — *Function* `83-140`
- [[fn-backend-app-services-cycle-rap-processing-gopro-footage-py--snap-to-nearest|snap_to_nearest]] — *Function* `128-133`
- [[fn-backend-app-services-cycle-rap-processing-gopro-footage-py--getduration|getDuration]] — *Function* `143-154`
- [[fn-backend-app-services-cycle-rap-processing-gopro-footage-py--gettimestamp|getTimestamp]] — *Function* `156-167`
- [[fn-backend-app-services-cycle-rap-processing-gopro-footage-py--calculate-average-time-difference|calculate_average_time_difference]] — *Function* `169-185`
- [[fn-backend-app-services-cycle-rap-processing-gopro-footage-py--extractspeed|extractSpeed]] — *Function* `187-197`
- [[fn-backend-app-services-cycle-rap-processing-gopro-footage-py--makelinestrings|makeLineStrings]] — *Function* `199-211`
