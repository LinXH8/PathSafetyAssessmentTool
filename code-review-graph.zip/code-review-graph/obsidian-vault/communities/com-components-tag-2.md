---
aliases: ["components-tag"]
tags: [community, tsx]
size: 7
cohesion: 0.1325
---

# Community · components-tag

**Size:** 7 &nbsp; **Cohesion:** 0.1325 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/Projects/components/EditProjectModal.tsx

## Members (7)
- [[file-frontend-src-pages-projects-components-editprojectmodal-tsx|EditProjectModal.tsx]] — *File* `1-229`
- [[fn-frontend-src-pages-projects-components-editprojectmodal-tsx--gettagcolor|getTagColor]] — *Function* `24-41`
- [[fn-frontend-src-pages-projects-components-editprojectmodal-tsx--editprojectmodal|EditProjectModal]] — *Function* `43-228`
- [[fn-frontend-src-pages-projects-components-editprojectmodal-tsx--handleclose|handleClose]] — *Function* `64-69`
- [[fn-frontend-src-pages-projects-components-editprojectmodal-tsx--handletaginputkeydown|handleTagInputKeyDown]] — *Function* `71-83`
- [[fn-frontend-src-pages-projects-components-editprojectmodal-tsx--removetag|removeTag]] — *Function* `85-87`
- [[fn-frontend-src-pages-projects-components-editprojectmodal-tsx--handlesave|handleSave]] — *Function* `89-140`
