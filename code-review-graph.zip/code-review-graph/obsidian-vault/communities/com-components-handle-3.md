---
aliases: ["components-handle"]
tags: [community, tsx]
size: 11
cohesion: 0.1647
---

# Community · components-handle

**Size:** 11 &nbsp; **Cohesion:** 0.1647 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/ShapefileManagement/components/AddShapefileView.tsx

## Members (11)
- [[file-frontend-src-pages-shapefilemanagement-components-addshapefileview-tsx|AddShapefileView.tsx]] — *File* `1-226`
- [[fn-frontend-src-pages-shapefilemanagement-components-addshapefileview-tsx--addshapefileview|AddShapefileView]] — *Function* `12-225`
- [[fn-frontend-src-pages-shapefilemanagement-components-addshapefileview-tsx--handledragenter|handleDragEnter]] — *Function* `19-23`
- [[fn-frontend-src-pages-shapefilemanagement-components-addshapefileview-tsx--handledragleave|handleDragLeave]] — *Function* `25-29`
- [[fn-frontend-src-pages-shapefilemanagement-components-addshapefileview-tsx--handledragover|handleDragOver]] — *Function* `31-34`
- [[fn-frontend-src-pages-shapefilemanagement-components-addshapefileview-tsx--handledrop|handleDrop]] — *Function* `36-43`
- [[fn-frontend-src-pages-shapefilemanagement-components-addshapefileview-tsx--handlefileselect|handleFileSelect]] — *Function* `45-50`
- [[fn-frontend-src-pages-shapefilemanagement-components-addshapefileview-tsx--addfiles|addFiles]] — *Function* `52-72`
- [[fn-frontend-src-pages-shapefilemanagement-components-addshapefileview-tsx--removefile|removeFile]] — *Function* `74-76`
- [[fn-frontend-src-pages-shapefilemanagement-components-addshapefileview-tsx--handleupload|handleUpload]] — *Function* `78-112`
- [[fn-frontend-src-pages-shapefilemanagement-components-addshapefileview-tsx--formatbytes|formatBytes]] — *Function* `114-120`
