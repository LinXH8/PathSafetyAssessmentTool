---
aliases: ["projects-layer"]
tags: [community, python]
size: 4
cohesion: 0.0735
---

# Community · projects-layer

**Size:** 4 &nbsp; **Cohesion:** 0.0735 &nbsp; **Dominant language:** python

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/projects/width_visualization.py

## Members (4)
- [[file-backend-app-api-projects-width-visualization-py|width_visualization.py]] — *File* `1-286`
- [[fn-backend-app-api-projects-width-visualization-py--get-layer-color|get_layer_color]] — *Function* `22-29`
- [[fn-backend-app-api-projects-width-visualization-py--get-gis-instance|_get_gis_instance]] — *Function* `32-35`
- [[fn-backend-app-api-projects-width-visualization-py--visualize-width|visualize_width]] — *Function* `39-285`
