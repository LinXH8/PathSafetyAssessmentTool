---
aliases: ["ui-provider"]
tags: [community, tsx]
size: 2
cohesion: 0.1667
---

# Community · ui-provider

**Size:** 2 &nbsp; **Cohesion:** 0.1667 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/ui/provider.tsx

## Members (2)
- [[file-frontend-src-components-ui-provider-tsx|provider.tsx]] — *File* `1-16`
- [[fn-frontend-src-components-ui-provider-tsx--provider|Provider]] — *Function* `9-15`
