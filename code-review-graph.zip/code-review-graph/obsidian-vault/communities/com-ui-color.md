---
aliases: ["ui-color"]
tags: [community, tsx]
size: 6
cohesion: 0.2500
---

# Community · ui-color

**Size:** 6 &nbsp; **Cohesion:** 0.2500 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/ui/color-mode.tsx

## Members (6)
- [[file-frontend-src-components-ui-color-mode-tsx|color-mode.tsx]] — *File* `1-115`
- [[fn-frontend-src-components-ui-color-mode-tsx--colormodeprovider|ColorModeProvider]] — *Function* `12-22`
- [[fn-frontend-src-components-ui-color-mode-tsx--usecolormode|useColorMode]] — *Function* `32-43`
- [[fn-frontend-src-components-ui-color-mode-tsx--togglecolormode|toggleColorMode]] — *Function* `35-37`
- [[fn-frontend-src-components-ui-color-mode-tsx--usecolormodevalue|useColorModeValue]] — *Function* `45-48`
- [[fn-frontend-src-components-ui-color-mode-tsx--colormodeicon|ColorModeIcon]] — *Function* `50-53`
