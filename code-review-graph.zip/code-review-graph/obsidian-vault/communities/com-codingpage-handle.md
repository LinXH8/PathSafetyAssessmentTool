---
aliases: ["codingpage-handle"]
tags: [community, tsx]
size: 22
cohesion: 0.1176
---

# Community · codingpage-handle

**Size:** 22 &nbsp; **Cohesion:** 0.1176 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/CodingPage/codingPage.tsx

## Members (22)
- [[file-frontend-src-pages-codingpage-codingpage-tsx|codingPage.tsx]] — *File* `1-1811`
- [[fn-frontend-src-pages-codingpage-codingpage-tsx--codingpage|CodingPage]] — *Function* `89-1810`
- [[fn-frontend-src-pages-codingpage-codingpage-tsx--updateprojectdata|updateProjectData]] — *Function* `194-206`
- [[fn-frontend-src-pages-codingpage-codingpage-tsx--updateverifiedsegmentcount|updateVerifiedSegmentCount]] — *Function* `248-268`
- [[fn-frontend-src-pages-codingpage-codingpage-tsx--updateautocodedsegmentcount|updateAutocodedSegmentCount]] — *Function* `271-291`
- [[fn-frontend-src-pages-codingpage-codingpage-tsx--timeout|timeout]] — *Function* `312-316`
- [[fn-frontend-src-pages-codingpage-codingpage-tsx--idx|idx]] — *Function* `373-396`
- [[fn-frontend-src-pages-codingpage-codingpage-tsx--normalizeattributevalues|normalizeAttributeValues]] — *Function* `421-436`
- [[fn-frontend-src-pages-codingpage-codingpage-tsx--e|e]] — *Function* `467-467`
- [[fn-frontend-src-pages-codingpage-codingpage-tsx--field|field]] — *Function* `509-509`
- [[fn-frontend-src-pages-codingpage-codingpage-tsx--handler|handler]] — *Function* `704-873`
- [[fn-frontend-src-pages-codingpage-codingpage-tsx--name|name]] — *Function* `721-728`
- [[fn-frontend-src-pages-codingpage-codingpage-tsx--prev|prev]] — *Function* `761-764`
- [[fn-frontend-src-pages-codingpage-codingpage-tsx--r|r]] — *Function* `900-900`
- [[fn-frontend-src-pages-codingpage-codingpage-tsx--row|row]] — *Function* `944-948`
- [[fn-frontend-src-pages-codingpage-codingpage-tsx--ref|ref]] — *Function* `966-981`
- [[fn-frontend-src-pages-codingpage-codingpage-tsx--onfinish|onFinish]] — *Function* `970-977`
- [[fn-frontend-src-pages-codingpage-codingpage-tsx--handlebaselineupdate|handleBaselineUpdate]] — *Function* `1040-1053`
- [[fn-frontend-src-pages-codingpage-codingpage-tsx--projname|projName]] — *Function* `1188-1198`
- [[fn-frontend-src-pages-codingpage-codingpage-tsx--handlesaveevent|handleSaveEvent]] — *Function* `1221-1223`
- [[fn-frontend-src-pages-codingpage-codingpage-tsx--editcurrentattr|editCurrentAttr]] — *Function* `1248-1289`
- [[fn-frontend-src-pages-codingpage-codingpage-tsx--handlebeforeunload|handleBeforeUnload]] — *Function* `1361-1363`
