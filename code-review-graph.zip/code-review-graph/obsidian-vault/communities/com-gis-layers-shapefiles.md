---
aliases: ["gis-layers-shapefiles"]
tags: [community, python]
size: 16
cohesion: 0.1522
---

# Community · gis-layers-shapefiles

**Size:** 16 &nbsp; **Cohesion:** 0.1522 &nbsp; **Dominant language:** python

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/gis_layers/routes.py

## Members (16)
- [[file-backend-app-api-gis-layers-routes-py|routes.py]] — *File* `1-514`
- [[fn-backend-app-api-gis-layers-routes-py--shp-root|_shp_root]] — *Function* `49-51`
- [[fn-backend-app-api-gis-layers-routes-py--extract-xml-yearstr|_extract_xml_yearStr]] — *Function* `77-93`
- [[fn-backend-app-api-gis-layers-routes-py--temp-root|_temp_root]] — *Function* `97-101`
- [[fn-backend-app-api-gis-layers-routes-py--safe-relative|_safe_relative]] — *Function* `104-116`
- [[fn-backend-app-api-gis-layers-routes-py--companion-extensions|_companion_extensions]] — *Function* `119-122`
- [[fn-backend-app-api-gis-layers-routes-py--file-info|_file_info]] — *Function* `125-163`
- [[fn-backend-app-api-gis-layers-routes-py--list-shapefiles|list_shapefiles]] — *Function* `171-183`
- [[fn-backend-app-api-gis-layers-routes-py--list-categories|list_categories]] — *Function* `191-203`
- [[fn-backend-app-api-gis-layers-routes-py--read-shapefile-as-geojson|_read_shapefile_as_geojson]] — *Function* `210-248`
- [[fn-backend-app-api-gis-layers-routes-py--get-geojson|get_geojson]] — *Function* `252-276`
- [[fn-backend-app-api-gis-layers-routes-py--validate-shapefile|validate_shapefile]] — *Function* `284-347`
- [[fn-backend-app-api-gis-layers-routes-py--validate-replacement|validate_replacement]] — *Function* `355-381`
- [[fn-backend-app-api-gis-layers-routes-py--upload-shapefiles|upload_shapefiles]] — *Function* `389-430`
- [[fn-backend-app-api-gis-layers-routes-py--replace-shapefiles|replace_shapefiles]] — *Function* `438-488`
- [[fn-backend-app-api-gis-layers-routes-py--delete-shapefile|delete_shapefile]] — *Function* `496-513`
