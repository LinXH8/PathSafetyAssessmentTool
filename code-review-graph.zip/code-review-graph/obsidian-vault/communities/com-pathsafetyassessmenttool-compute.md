---
aliases: ["pathsafetyassessmenttool-compute"]
tags: [community, python]
size: 17
cohesion: 0.2135
---

# Community · pathsafetyassessmenttool-compute

**Size:** 17 &nbsp; **Cohesion:** 0.2135 &nbsp; **Dominant language:** python

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/run_attribute_inference.py

## Members (17)
- [[file-run-attribute-inference-py|run_attribute_inference.py]] — *File* `1-648`
- [[fn-run-attribute-inference-py--parse-args|parse_args]] — *Function* `45-74`
- [[fn-run-attribute-inference-py--load-model|load_model]] — *Function* `81-94`
- [[fn-run-attribute-inference-py--safe-fuse|_safe_fuse]] — *Function* `84-88`
- [[fn-run-attribute-inference-py--build-class-sets|build_class_sets]] — *Function* `101-118`
- [[fn-run-attribute-inference-py--ids|_ids]] — *Function* `105-106`
- [[fn-run-attribute-inference-py--build-masks|build_masks]] — *Function* `129-160`
- [[fn-run-attribute-inference-py--detect-obstacles|detect_obstacles]] — *Function* `171-228`
- [[fn-run-attribute-inference-py--analyze-obstacle|analyze_obstacle]] — *Function* `235-260`
- [[fn-run-attribute-inference-py--compute-width-restriction|compute_width_restriction]] — *Function* `263-270`
- [[fn-run-attribute-inference-py--compute-adjroad|compute_adjroad]] — *Function* `277-305`
- [[fn-run-attribute-inference-py--check-bottom-presence|check_bottom_presence]] — *Function* `312-315`
- [[fn-run-attribute-inference-py--check-bottom-majority|check_bottom_majority]] — *Function* `318-331`
- [[fn-run-attribute-inference-py--assign-attributes|assign_attributes]] — *Function* `338-444`
- [[fn-run-attribute-inference-py--annotate-image|annotate_image]] — *Function* `455-560`
- [[fn-run-attribute-inference-py--process-images|process_images]] — *Function* `567-638`
- [[fn-run-attribute-inference-py--main|main]] — *Function* `641-643`
