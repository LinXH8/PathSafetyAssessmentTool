---
aliases: ["ui-chart"]
tags: [community, tsx]
size: 2
cohesion: 0.0625
---

# Community · ui-chart

**Size:** 2 &nbsp; **Cohesion:** 0.0625 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/ui/ChartTypeToggle.tsx

## Members (2)
- [[file-frontend-src-components-ui-charttypetoggle-tsx|ChartTypeToggle.tsx]] — *File* `1-63`
- [[fn-frontend-src-components-ui-charttypetoggle-tsx--charttypetoggle|ChartTypeToggle]] — *Function* `9-62`
