---
aliases: ["services-check"]
tags: [community, python]
size: 4
cohesion: 0.2778
---

# Community · services-check

**Size:** 4 &nbsp; **Cohesion:** 0.2778 &nbsp; **Dominant language:** python

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/platform_compat.py

## Members (4)
- [[file-backend-app-services-platform-compat-py|platform_compat.py]] — *File* `1-80`
- [[fn-backend-app-services-platform-compat-py--check-windows-feature|check_windows_feature]] — *Function* `31-51`
- [[fn-backend-app-services-platform-compat-py--get-excel-client|get_excel_client]] — *Function* `54-65`
- [[fn-backend-app-services-platform-compat-py--get-pythoncom|get_pythoncom]] — *Function* `68-79`
