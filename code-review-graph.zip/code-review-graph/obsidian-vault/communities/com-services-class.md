---
aliases: ["services-class"]
tags: [community, python]
size: 6
cohesion: 0.3846
---

# Community · services-class

**Size:** 6 &nbsp; **Cohesion:** 0.3846 &nbsp; **Dominant language:** python

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/global_var.py

## Members (6)
- [[file-backend-app-services-global-var-py|global_var.py]] — *File* `1-304`
- [[cls-backend-app-services-global-var-py--map-index|Map_index]] — *Class* `12-15`
- [[fn-backend-app-services-global-var-py--class-name|class_name]] — *Function* `13-13`
- [[cls-backend-app-services-global-var-py--dataframe-attributes|Dataframe_attributes]] — *Class* `42-122`
- [[fn-backend-app-services-global-var-py--class-name-2|class_name]] — *Function* `43-43`
- [[fn-backend-app-services-global-var-py--get-config-path|get_config_path]] — *Function* `303-304`
