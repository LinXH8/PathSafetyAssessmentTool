---
aliases: ["helppage-user"]
tags: [community, tsx]
size: 3
cohesion: 0.0811
---

# Community · helppage-user

**Size:** 3 &nbsp; **Cohesion:** 0.0811 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/HelpPage/UserGuide.tsx

## Members (3)
- [[file-frontend-src-pages-helppage-userguide-tsx|UserGuide.tsx]] — *File* `1-143`
- [[fn-frontend-src-pages-helppage-userguide-tsx--userguide|UserGuide]] — *Function* `15-75`
- [[fn-frontend-src-pages-helppage-userguide-tsx--markdowncontent|MarkdownContent]] — *Function* `77-142`
