---
aliases: ["api-register"]
tags: [community, python]
size: 2
cohesion: 0.2000
---

# Community · api-register

**Size:** 2 &nbsp; **Cohesion:** 0.2000 &nbsp; **Dominant language:** python

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/__init__.py

## Members (2)
- [[file-backend-app-api-init-py|__init__.py]] — *File* `1-19`
- [[fn-backend-app-api-init-py--register-blueprints|register_blueprints]] — *Function* `6-18`
