---
aliases: ["app-config"]
tags: [community, python]
size: 2
cohesion: 0.5000
---

# Community · app-config

**Size:** 2 &nbsp; **Cohesion:** 0.5000 &nbsp; **Dominant language:** python

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/config.py

## Members (2)
- [[file-backend-app-config-py|config.py]] — *File* `1-6`
- [[cls-backend-app-config-py--config|Config]] — *Class* `3-5`
