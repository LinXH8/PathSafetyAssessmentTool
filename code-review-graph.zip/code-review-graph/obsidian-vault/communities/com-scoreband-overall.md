---
aliases: ["scoreband-overall"]
tags: [community, tsx]
size: 2
cohesion: 0.0500
---

# Community · scoreband-overall

**Size:** 2 &nbsp; **Cohesion:** 0.0500 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/scoreband/OverallTreatmentAnalysis.tsx

## Members (2)
- [[file-frontend-src-components-visualization-scoreband-overalltreatmentanalysis-tsx|OverallTreatmentAnalysis.tsx]] — *File* `1-107`
- [[fn-frontend-src-components-visualization-scoreband-overalltreatmentanalysis-tsx--overalltreatmentanalysis|OverallTreatmentAnalysis]] — *Function* `32-106`
