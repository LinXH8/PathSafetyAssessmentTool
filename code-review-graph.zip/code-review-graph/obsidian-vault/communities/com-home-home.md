---
aliases: ["home-home"]
tags: [community, tsx]
size: 6
cohesion: 0.0897
---

# Community · home-home

**Size:** 6 &nbsp; **Cohesion:** 0.0897 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/Home/home.tsx

## Members (6)
- [[file-frontend-src-pages-home-home-tsx|home.tsx]] — *File* `1-222`
- [[fn-frontend-src-pages-home-home-tsx--home|Home]] — *Function* `24-222`
- [[fn-frontend-src-pages-home-home-tsx--onrowclick|onRowClick]] — *Function* `78-78`
- [[fn-frontend-src-pages-home-home-tsx--loadproject|loadProject]] — *Function* `81-85`
- [[fn-frontend-src-pages-home-home-tsx--askdelete|askDelete]] — *Function* `88-92`
- [[fn-frontend-src-pages-home-home-tsx--confirmdelete|confirmDelete]] — *Function* `95-114`
