---
aliases: ["app-app"]
tags: [community, python]
size: 2
cohesion: 0.0909
---

# Community · app-app

**Size:** 2 &nbsp; **Cohesion:** 0.0909 &nbsp; **Dominant language:** python

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/__init__.py

## Members (2)
- [[file-backend-app-init-py|__init__.py]] — *File* `1-20`
- [[fn-backend-app-init-py--create-app|create_app]] — *Function* `6-19`
