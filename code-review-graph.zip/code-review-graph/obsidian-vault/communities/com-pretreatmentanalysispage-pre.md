---
aliases: ["pretreatmentanalysispage-pre"]
tags: [community, tsx]
size: 5
cohesion: 0.1250
---

# Community · pretreatmentanalysispage-pre

**Size:** 5 &nbsp; **Cohesion:** 0.1250 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PreTreatmentAnalysisPage/preTreatmentAnalysisPage.tsx

## Members (5)
- [[file-frontend-src-pages-pretreatmentanalysispage-pretreatmentanalysispage-tsx|preTreatmentAnalysisPage.tsx]] — *File* `1-207`
- [[fn-frontend-src-pages-pretreatmentanalysispage-pretreatmentanalysispage-tsx--pretreatmentanalysispage|PreTreatmentAnalysisPage]] — *Function* `11-206`
- [[fn-frontend-src-pages-pretreatmentanalysispage-pretreatmentanalysispage-tsx--onrowclick|onRowClick]] — *Function* `43-43`
- [[fn-frontend-src-pages-pretreatmentanalysispage-pretreatmentanalysispage-tsx--analyzeproject|analyzeProject]] — *Function* `45-48`
- [[fn-frontend-src-pages-pretreatmentanalysispage-pretreatmentanalysispage-tsx--compareprojects|compareProjects]] — *Function* `50-53`
