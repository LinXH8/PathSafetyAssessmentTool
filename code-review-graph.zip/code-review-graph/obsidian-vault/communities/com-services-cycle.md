---
aliases: ["services-cycle"]
tags: [community, python]
size: 10
cohesion: 0.1068
---

# Community · services-cycle

**Size:** 10 &nbsp; **Cohesion:** 0.1068 &nbsp; **Dominant language:** python

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/cycleRAP_interface.py

## Members (10)
- [[file-backend-app-services-cyclerap-interface-py|cycleRAP_interface.py]] — *File* `1-349`
- [[cls-backend-app-services-cyclerap-interface-py--cyclerap-interface|cycleRAP_interface]] — *Class* `21-349`
- [[fn-backend-app-services-cyclerap-interface-py--init|__init__]] — *Function* `26-27`
- [[fn-backend-app-services-cyclerap-interface-py--initialise|initialise]] — *Function* `30-39`
- [[fn-backend-app-services-cyclerap-interface-py--parse|_parse]] — *Function* `42-47`
- [[fn-backend-app-services-cyclerap-interface-py--get-cyclerap-metadata|get_cycleRAP_metadata]] — *Function* `50-53`
- [[fn-backend-app-services-cyclerap-interface-py--calculate-cyclerap-score|calculate_cycleRAP_score]] — *Function* `57-131`
- [[fn-backend-app-services-cyclerap-interface-py--evaluate-treatment-suggestions|evaluate_treatment_suggestions]] — *Function* `134-229`
- [[fn-backend-app-services-cyclerap-interface-py--get-treatment-pairs|get_treatment_pairs]] — *Function* `232-257`
- [[fn-backend-app-services-cyclerap-interface-py--write-default-config|_write_default_config]] — *Function* `260-349`
