---
aliases: ["components-aggregated"]
tags: [community, tsx]
size: 3
cohesion: 0.0250
---

# Community · components-aggregated

**Size:** 3 &nbsp; **Cohesion:** 0.0250 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/AggregatedScoreBandPanel.tsx

## Members (3)
- [[file-frontend-src-pages-pathanalysispage-components-aggregatedscorebandpanel-tsx|AggregatedScoreBandPanel.tsx]] — *File* `1-380`
- [[fn-frontend-src-pages-pathanalysispage-components-aggregatedscorebandpanel-tsx--aggregatedscorebandpanel|AggregatedScoreBandPanel]] — *Function* `50-377`
- [[fn-frontend-src-pages-pathanalysispage-components-aggregatedscorebandpanel-tsx--handlescoresupdated|handleScoresUpdated]] — *Function* `192-194`
