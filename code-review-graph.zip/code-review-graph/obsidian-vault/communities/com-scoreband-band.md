---
aliases: ["scoreband-band"]
tags: [community, javascript]
size: 2
cohesion: 0.5000
---

# Community · scoreband-band

**Size:** 2 &nbsp; **Cohesion:** 0.5000 &nbsp; **Dominant language:** javascript

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/scoreband/test_thresholds.js

## Members (2)
- [[file-frontend-src-components-visualization-scoreband-test-thresholds-js|test_thresholds.js]] — *File* `1-61`
- [[fn-frontend-src-components-visualization-scoreband-test-thresholds-js--getbandcolor|getBandColor]] — *Function* `9-23`
