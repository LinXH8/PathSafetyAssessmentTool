---
aliases: ["backend-xml"]
tags: [community, python]
size: 2
cohesion: 0.1429
---

# Community · backend-xml

**Size:** 2 &nbsp; **Cohesion:** 0.1429 &nbsp; **Dominant language:** python

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/extract_xml_dates.py

## Members (2)
- [[file-backend-extract-xml-dates-py|extract_xml_dates.py]] — *File* `1-43`
- [[fn-backend-extract-xml-dates-py--get-xml-date|get_xml_date]] — *Function* `7-21`
