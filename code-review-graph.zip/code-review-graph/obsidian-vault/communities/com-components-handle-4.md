---
aliases: ["components-handle"]
tags: [community, tsx]
size: 12
cohesion: 0.1524
---

# Community · components-handle

**Size:** 12 &nbsp; **Cohesion:** 0.1524 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/ShapefileManagement/components/ReplaceShapefileView.tsx

## Members (12)
- [[file-frontend-src-pages-shapefilemanagement-components-replaceshapefileview-tsx|ReplaceShapefileView.tsx]] — *File* `1-330`
- [[fn-frontend-src-pages-shapefilemanagement-components-replaceshapefileview-tsx--replaceshapefileview|ReplaceShapefileView]] — *Function* `19-329`
- [[fn-frontend-src-pages-shapefilemanagement-components-replaceshapefileview-tsx--handledragenter|handleDragEnter]] — *Function* `30-34`
- [[fn-frontend-src-pages-shapefilemanagement-components-replaceshapefileview-tsx--handledragleave|handleDragLeave]] — *Function* `36-40`
- [[fn-frontend-src-pages-shapefilemanagement-components-replaceshapefileview-tsx--handledragover|handleDragOver]] — *Function* `42-45`
- [[fn-frontend-src-pages-shapefilemanagement-components-replaceshapefileview-tsx--handledrop|handleDrop]] — *Function* `47-54`
- [[fn-frontend-src-pages-shapefilemanagement-components-replaceshapefileview-tsx--handlefileselect|handleFileSelect]] — *Function* `56-61`
- [[fn-frontend-src-pages-shapefilemanagement-components-replaceshapefileview-tsx--addfiles|addFiles]] — *Function* `63-81`
- [[fn-frontend-src-pages-shapefilemanagement-components-replaceshapefileview-tsx--removefile|removeFile]] — *Function* `83-85`
- [[fn-frontend-src-pages-shapefilemanagement-components-replaceshapefileview-tsx--updatetargetpath|updateTargetPath]] — *Function* `87-91`
- [[fn-frontend-src-pages-shapefilemanagement-components-replaceshapefileview-tsx--handlereplace|handleReplace]] — *Function* `93-158`
- [[fn-frontend-src-pages-shapefilemanagement-components-replaceshapefileview-tsx--formatbytes|formatBytes]] — *Function* `160-166`
