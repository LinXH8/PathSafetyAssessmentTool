---
aliases: ["gislayerspage-layers"]
tags: [community, tsx]
size: 9
cohesion: 0.1151
---

# Community · gislayerspage-layers

**Size:** 9 &nbsp; **Cohesion:** 0.1151 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/GisLayersPage/GisLayersPage.tsx

## Members (9)
- [[file-frontend-src-pages-gislayerspage-gislayerspage-tsx|GisLayersPage.tsx]] — *File* `1-373`
- [[fn-frontend-src-pages-gislayerspage-gislayerspage-tsx--fitbounds|FitBounds]] — *Function* `12-20`
- [[fn-frontend-src-pages-gislayerspage-gislayerspage-tsx--gislayerspage|GisLayersPage]] — *Function* `26-336`
- [[fn-frontend-src-pages-gislayerspage-gislayerspage-tsx--loadlayers|loadLayers]] — *Function* `40-52`
- [[fn-frontend-src-pages-gislayerspage-gislayerspage-tsx--loadgeojson|loadGeoJson]] — *Function* `64-94`
- [[fn-frontend-src-pages-gislayerspage-gislayerspage-tsx--formatbytes|formatBytes]] — *Function* `170-177`
- [[fn-frontend-src-pages-gislayerspage-gislayerspage-tsx--rendertooltip|renderTooltip]] — *Function* `179-187`
- [[fn-frontend-src-pages-gislayerspage-gislayerspage-tsx--file|file]] — *Function* `225-252`
- [[fn-frontend-src-pages-gislayerspage-gislayerspage-tsx--matchmapstate|matchMapState]] — *Function* `338-372`
