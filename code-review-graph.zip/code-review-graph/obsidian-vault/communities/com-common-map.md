---
aliases: ["common-map"]
tags: [community, tsx]
size: 2
cohesion: 0.0769
---

# Community · common-map

**Size:** 2 &nbsp; **Cohesion:** 0.0769 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/common/MapCursorController.tsx

## Members (2)
- [[file-frontend-src-components-common-mapcursorcontroller-tsx|MapCursorController.tsx]] — *File* `1-46`
- [[fn-frontend-src-components-common-mapcursorcontroller-tsx--mapcursorcontroller|MapCursorController]] — *Function* `12-45`
