---
aliases: ["tmp-full"]
tags: [community, python]
size: 2
cohesion: 0.0323
---

# Community · tmp-full

**Size:** 2 &nbsp; **Cohesion:** 0.0323 &nbsp; **Dominant language:** python

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/tmp/simulate_gis_full.py

## Members (2)
- [[file-tmp-simulate-gis-full-py|simulate_gis_full.py]] — *File* `1-74`
- [[test-tmp-simulate-gis-full-py--test-full-logic|test_full_logic]] — *Test* `23-70`
