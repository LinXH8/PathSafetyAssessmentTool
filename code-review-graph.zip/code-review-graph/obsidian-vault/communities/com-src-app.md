---
aliases: ["src-app"]
tags: [community, tsx]
size: 2
cohesion: 0.0263
---

# Community · src-app

**Size:** 2 &nbsp; **Cohesion:** 0.0263 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/App.tsx

## Members (2)
- [[file-frontend-src-app-tsx|App.tsx]] — *File* `1-38`
- [[fn-frontend-src-app-tsx--app|App]] — *Function* `15-37`
