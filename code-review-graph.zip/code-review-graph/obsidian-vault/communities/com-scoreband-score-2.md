---
aliases: ["scoreband-score"]
tags: [community, tsx]
size: 3
cohesion: 0.0345
---

# Community · scoreband-score

**Size:** 3 &nbsp; **Cohesion:** 0.0345 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/scoreband/ScoreBandPieChart.tsx

## Members (3)
- [[file-frontend-src-components-visualization-scoreband-scorebandpiechart-tsx|ScoreBandPieChart.tsx]] — *File* `1-214`
- [[fn-frontend-src-components-visualization-scoreband-scorebandpiechart-tsx--scorebandpiechart|ScoreBandPieChart]] — *Function* `33-213`
- [[fn-frontend-src-components-visualization-scoreband-scorebandpiechart-tsx--renderlabel|renderLabel]] — *Function* `63-85`
