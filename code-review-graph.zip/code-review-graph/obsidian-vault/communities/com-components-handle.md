---
aliases: ["components-handle"]
tags: [community, tsx]
size: 18
cohesion: 0.1944
---

# Community · components-handle

**Size:** 18 &nbsp; **Cohesion:** 0.1944 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/AttributesDropdown.tsx

## Members (18)
- [[file-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx|AttributesDropdown.tsx]] — *File* `1-1047`
- [[fn-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx--rendergroupedattributes|renderGroupedAttributes]] — *Function* `14-102`
- [[fn-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx--a|a]] — *Function* `453-455`
- [[fn-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx--o|o]] — *Function* `454-454`
- [[fn-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx--v|v]] — *Function* `506-506`
- [[fn-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx--getcategorycolor|getCategoryColor]] — *Function* `575-682`
- [[fn-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx--getlabelforvalue|getLabelForValue]] — *Function* `705-709`
- [[fn-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx--attributesdropdown|AttributesDropdown]] — *Function* `711-1046`
- [[fn-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx--getfilterlabel|getFilterLabel]] — *Function* `722-725`
- [[fn-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx--handleattributechange|handleAttributeChange]] — *Function* `727-747`
- [[fn-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx--handleaddfilter|handleAddFilter]] — *Function* `749-756`
- [[fn-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx--handleremovefilter|handleRemoveFilter]] — *Function* `758-779`
- [[fn-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx--handleresetfilters|handleResetFilters]] — *Function* `782-787`
- [[fn-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx--fuzzymatch|fuzzyMatch]] — *Function* `792-807`
- [[fn-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx--getfilteredattributes|getFilteredAttributes]] — *Function* `809-866`
- [[fn-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx--getattributecollection|getAttributeCollection]] — *Function* `869-876`
- [[fn-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx--item|item]] — *Function* `872-872`
- [[fn-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx--attr|attr]] — *Function* `878-878`
