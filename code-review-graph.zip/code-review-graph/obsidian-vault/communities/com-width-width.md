---
aliases: ["width-width"]
tags: [community, tsx]
size: 2
cohesion: 0.0833
---

# Community · width-width

**Size:** 2 &nbsp; **Cohesion:** 0.0833 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/width/WidthSearchDiagnostics.tsx

## Members (2)
- [[file-frontend-src-components-visualization-width-widthsearchdiagnostics-tsx|WidthSearchDiagnostics.tsx]] — *File* `1-138`
- [[fn-frontend-src-components-visualization-width-widthsearchdiagnostics-tsx--widthsearchdiagnostics|WidthSearchDiagnostics]] — *Function* `10-135`
