---
aliases: ["scoreband-score"]
tags: [community, tsx]
size: 3
cohesion: 0.0556
---

# Community · scoreband-score

**Size:** 3 &nbsp; **Cohesion:** 0.0556 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/scoreband/ScoreBandDistributionPanel.tsx

## Members (3)
- [[file-frontend-src-components-visualization-scoreband-scorebanddistributionpanel-tsx|ScoreBandDistributionPanel.tsx]] — *File* `1-241`
- [[fn-frontend-src-components-visualization-scoreband-scorebanddistributionpanel-tsx--scorebanddistributionpanel|ScoreBandDistributionPanel]] — *Function* `47-238`
- [[fn-frontend-src-components-visualization-scoreband-scorebanddistributionpanel-tsx--handlescoresupdated|handleScoresUpdated]] — *Function* `123-126`
