---
aliases: ["analysispage-analysis"]
tags: [community, tsx]
size: 5
cohesion: 0.1034
---

# Community · analysispage-analysis

**Size:** 5 &nbsp; **Cohesion:** 0.1034 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/AnalysisPage/analysisPage.tsx

## Members (5)
- [[file-frontend-src-pages-analysispage-analysispage-tsx|analysisPage.tsx]] — *File* `1-239`
- [[fn-frontend-src-pages-analysispage-analysispage-tsx--analysispage|AnalysisPage]] — *Function* `22-238`
- [[fn-frontend-src-pages-analysispage-analysispage-tsx--onrowclick|onRowClick]] — *Function* `71-71`
- [[fn-frontend-src-pages-analysispage-analysispage-tsx--analyzeproject|analyzeProject]] — *Function* `73-78`
- [[fn-frontend-src-pages-analysispage-analysispage-tsx--compareprojects|compareProjects]] — *Function* `80-85`
