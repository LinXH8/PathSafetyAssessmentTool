---
aliases: ["components-handle"]
tags: [community, tsx]
size: 4
cohesion: 0.0870
---

# Community · components-handle

**Size:** 4 &nbsp; **Cohesion:** 0.0870 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/TreatmentPage/components/AttributesDropdown.tsx

## Members (4)
- [[file-frontend-src-pages-treatmentpage-components-attributesdropdown-tsx|AttributesDropdown.tsx]] — *File* `1-321`
- [[fn-frontend-src-pages-treatmentpage-components-attributesdropdown-tsx--attributesdropdown|AttributesDropdown]] — *Function* `190-320`
- [[fn-frontend-src-pages-treatmentpage-components-attributesdropdown-tsx--handleattributechange|handleAttributeChange]] — *Function* `197-199`
- [[fn-frontend-src-pages-treatmentpage-components-attributesdropdown-tsx--handleresetfilters|handleResetFilters]] — *Function* `202-206`
