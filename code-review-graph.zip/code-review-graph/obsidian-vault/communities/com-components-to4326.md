---
aliases: ["components-to4326"]
tags: [community, tsx]
size: 5
cohesion: 0.1132
---

# Community · components-to4326

**Size:** 5 &nbsp; **Cohesion:** 0.1132 &nbsp; **Dominant language:** tsx

File-based community: /Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/TreatmentPage/components/TreatmentMapView.tsx

## Members (5)
- [[file-frontend-src-pages-treatmentpage-components-treatmentmapview-tsx|TreatmentMapView.tsx]] — *File* `1-198`
- [[fn-frontend-src-pages-treatmentpage-components-treatmentmapview-tsx--to4326|to4326]] — *Function* `19-22`
- [[fn-frontend-src-pages-treatmentpage-components-treatmentmapview-tsx--fitbounds|FitBounds]] — *Function* `25-33`
- [[fn-frontend-src-pages-treatmentpage-components-treatmentmapview-tsx--treatmentmapview|TreatmentMapView]] — *Function* `35-197`
- [[fn-frontend-src-pages-treatmentpage-components-treatmentmapview-tsx--p|p]] — *Function* `61-61`
