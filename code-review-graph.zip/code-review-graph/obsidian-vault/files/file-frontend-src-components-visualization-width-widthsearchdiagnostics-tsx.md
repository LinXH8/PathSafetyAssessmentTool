---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/width/WidthSearchDiagnostics.tsx", "frontend/src/components/visualization/width/WidthSearchDiagnostics.tsx", "WidthSearchDiagnostics.tsx"]
tags: [file, tsx]
path: "frontend/src/components/visualization/width/WidthSearchDiagnostics.tsx"
---

# WidthSearchDiagnostics.tsx

**Path:** `frontend/src/components/visualization/width/WidthSearchDiagnostics.tsx`
**Community:** [[com-width-width|width-width]]

## Contains (1)
- [[fn-frontend-src-components-visualization-width-widthsearchdiagnostics-tsx--widthsearchdiagnostics|WidthSearchDiagnostics]] — *Function* `10-135`

## Imports (1)
- [[file-frontend-src-api-widthvisualization-ts|widthVisualization.ts]]

## Imported by (2)
- [[file-frontend-src-components-visualization-analysispanel-tsx|AnalysisPanel.tsx]]
- [[file-frontend-src-components-visualization-width-widthvisualizationpanel-tsx|WidthVisualizationPanel.tsx]]
