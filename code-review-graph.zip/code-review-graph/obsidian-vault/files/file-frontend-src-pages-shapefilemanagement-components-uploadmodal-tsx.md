---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/ShapefileManagement/components/UploadModal.tsx", "frontend/src/pages/ShapefileManagement/components/UploadModal.tsx", "UploadModal.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/ShapefileManagement/components/UploadModal.tsx"
---

# UploadModal.tsx

**Path:** `frontend/src/pages/ShapefileManagement/components/UploadModal.tsx`
**Community:** [[com-components-upload|components-upload]]

## Contains (2)
- [[fn-frontend-src-pages-shapefilemanagement-components-uploadmodal-tsx--uploadmodal|UploadModal]] — *Function* `16-110`
- [[fn-frontend-src-pages-shapefilemanagement-components-uploadmodal-tsx--handleback|handleBack]] — *Function* `24-26`

## Imports (3)
- [[file-frontend-src-pages-shapefilemanagement-components-addshapefileview-tsx|AddShapefileView.tsx]]
- [[file-frontend-src-pages-shapefilemanagement-components-replaceshapefileview-tsx|ReplaceShapefileView.tsx]]
- [[file-frontend-src-api-index-ts|index.ts]]

## Imported by (1)
- [[file-frontend-src-pages-shapefilemanagement-shapefilemanagementpage-tsx|ShapefileManagementPage.tsx]]
