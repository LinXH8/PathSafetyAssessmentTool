---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/scoreband/OverallTreatmentAnalysis.tsx", "frontend/src/components/visualization/scoreband/OverallTreatmentAnalysis.tsx", "OverallTreatmentAnalysis.tsx"]
tags: [file, tsx]
path: "frontend/src/components/visualization/scoreband/OverallTreatmentAnalysis.tsx"
---

# OverallTreatmentAnalysis.tsx

**Path:** `frontend/src/components/visualization/scoreband/OverallTreatmentAnalysis.tsx`
**Community:** [[com-scoreband-overall|scoreband-overall]]

## Contains (1)
- [[fn-frontend-src-components-visualization-scoreband-overalltreatmentanalysis-tsx--overalltreatmentanalysis|OverallTreatmentAnalysis]] — *Function* `32-106`

## Imports (1)
- [[file-frontend-src-components-visualization-scoreband-scorebandpiechart-tsx|ScoreBandPieChart.tsx]]

## Imported by (1)
- [[file-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx|treatmentDetailPage.tsx]]
