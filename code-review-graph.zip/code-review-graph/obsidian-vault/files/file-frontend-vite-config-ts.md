---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/vite.config.ts", "frontend/vite.config.ts", "vite.config.ts"]
tags: [file, typescript]
path: "frontend/vite.config.ts"
---

# vite.config.ts

**Path:** `frontend/vite.config.ts`
