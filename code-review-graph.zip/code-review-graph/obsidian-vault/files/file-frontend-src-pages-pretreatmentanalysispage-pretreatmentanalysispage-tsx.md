---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PreTreatmentAnalysisPage/preTreatmentAnalysisPage.tsx", "frontend/src/pages/PreTreatmentAnalysisPage/preTreatmentAnalysisPage.tsx", "preTreatmentAnalysisPage.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/PreTreatmentAnalysisPage/preTreatmentAnalysisPage.tsx"
---

# preTreatmentAnalysisPage.tsx

**Path:** `frontend/src/pages/PreTreatmentAnalysisPage/preTreatmentAnalysisPage.tsx`
**Community:** [[com-pretreatmentanalysispage-pre|pretreatmentanalysispage-pre]]

## Contains (4)
- [[fn-frontend-src-pages-pretreatmentanalysispage-pretreatmentanalysispage-tsx--pretreatmentanalysispage|PreTreatmentAnalysisPage]] — *Function* `11-206`
- [[fn-frontend-src-pages-pretreatmentanalysispage-pretreatmentanalysispage-tsx--onrowclick|onRowClick]] — *Function* `43-43`
- [[fn-frontend-src-pages-pretreatmentanalysispage-pretreatmentanalysispage-tsx--analyzeproject|analyzeProject]] — *Function* `45-48`
- [[fn-frontend-src-pages-pretreatmentanalysispage-pretreatmentanalysispage-tsx--compareprojects|compareProjects]] — *Function* `50-53`

## Imports (1)
- [[file-frontend-src-api-index-ts|index.ts]]
