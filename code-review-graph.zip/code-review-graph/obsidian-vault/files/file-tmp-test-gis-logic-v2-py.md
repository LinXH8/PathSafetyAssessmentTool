---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/tmp/test_gis_logic_v2.py", "tmp/test_gis_logic_v2.py", "test_gis_logic_v2.py"]
tags: [file, python]
path: "tmp/test_gis_logic_v2.py"
---

# test_gis_logic_v2.py

**Path:** `tmp/test_gis_logic_v2.py`
