---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/test_routes2.py", "backend/test_routes2.py", "test_routes2.py"]
tags: [file, python]
path: "backend/test_routes2.py"
---

# test_routes2.py

**Path:** `backend/test_routes2.py`
**Community:** [[com-backend-read|backend-read]]

## Contains (1)
- [[fn-backend-test-routes2-py--read-shapefile-as-geojson|_read_shapefile_as_geojson]] — *Function* `5-43`
