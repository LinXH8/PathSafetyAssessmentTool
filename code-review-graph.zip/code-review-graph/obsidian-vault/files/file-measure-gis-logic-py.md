---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/measure_gis_logic.py", "measure_gis_logic.py", "measure_gis_logic.py"]
tags: [file, python]
path: "measure_gis_logic.py"
---

# measure_gis_logic.py

**Path:** `measure_gis_logic.py`
**Community:** [[com-pathsafetyassessmenttool-routes|pathsafetyassessmenttool-routes]]

## Contains (1)
- [[test-measure-gis-logic-py--test-routes-logic|test_routes_logic]] — *Test* `12-84`
