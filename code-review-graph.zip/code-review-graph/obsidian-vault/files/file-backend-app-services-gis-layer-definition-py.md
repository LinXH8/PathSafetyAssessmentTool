---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/gis_layer_definition.py", "backend/app/services/gis_layer_definition.py", "gis_layer_definition.py"]
tags: [file, python]
path: "backend/app/services/gis_layer_definition.py"
---

# gis_layer_definition.py

**Path:** `backend/app/services/gis_layer_definition.py`
**Community:** [[com-services-layer|services-layer]]

## Description

> GIS Layer Definitions
> Defines structure and requirements for each GIS layer to maximize portability

## Contains (4)
- [[cls-backend-app-services-gis-layer-definition-py--layerdefinition|LayerDefinition]] — *Class* `11-49`
- [[fn-backend-app-services-gis-layer-definition-py--get-column-name|get_column_name]] — *Function* `25-49`
- [[fn-backend-app-services-gis-layer-definition-py--get-layer-definition|get_layer_definition]] — *Function* `203-205`
- [[fn-backend-app-services-gis-layer-definition-py--list-layer-definitions|list_layer_definitions]] — *Function* `208-210`
