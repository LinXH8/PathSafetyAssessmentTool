---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/test_flask_endpoint.py", "backend/test_flask_endpoint.py", "test_flask_endpoint.py"]
tags: [file, python]
path: "backend/test_flask_endpoint.py"
---

# test_flask_endpoint.py

**Path:** `backend/test_flask_endpoint.py`

## Imports (1)
- [[file-backend-app-py|app.py]]
