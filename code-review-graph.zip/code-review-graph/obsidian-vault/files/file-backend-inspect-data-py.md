---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/inspect_data.py", "backend/inspect_data.py", "inspect_data.py"]
tags: [file, python]
path: "backend/inspect_data.py"
---

# inspect_data.py

**Path:** `backend/inspect_data.py`
**Community:** [[com-backend-inspect|backend-inspect]]

## Contains (1)
- [[fn-backend-inspect-data-py--inspect-project|inspect_project]] — *Function* `10-50`

## Imports (1)
- [[file-backend-app-services-project-manager-py|project_manager.py]]
