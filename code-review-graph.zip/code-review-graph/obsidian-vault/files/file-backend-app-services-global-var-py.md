---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/global_var.py", "backend/app/services/global_var.py", "global_var.py"]
tags: [file, python]
path: "backend/app/services/global_var.py"
---

# global_var.py

**Path:** `backend/app/services/global_var.py`
**Community:** [[com-services-class|services-class]]

## Contains (5)
- [[cls-backend-app-services-global-var-py--map-index|Map_index]] — *Class* `12-15`
- [[fn-backend-app-services-global-var-py--class-name|class_name]] — *Function* `13-13`
- [[cls-backend-app-services-global-var-py--dataframe-attributes|Dataframe_attributes]] — *Class* `42-122`
- [[fn-backend-app-services-global-var-py--class-name-2|class_name]] — *Function* `43-43`
- [[fn-backend-app-services-global-var-py--get-config-path|get_config_path]] — *Function* `303-304`

## Imports (1)
- [[file-backend-app-services-cyclerap-va-py|cycleRAP_VA.py]]
