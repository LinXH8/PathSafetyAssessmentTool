---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/api/widthVisualization.ts", "frontend/src/api/widthVisualization.ts", "widthVisualization.ts"]
tags: [file, typescript]
path: "frontend/src/api/widthVisualization.ts"
---

# widthVisualization.ts

**Path:** `frontend/src/api/widthVisualization.ts`
**Community:** [[com-api-fetch-2|api-fetch]]

## Contains (1)
- [[fn-frontend-src-api-widthvisualization-ts--fetchwidthvisualization|fetchWidthVisualization]] — *Function* `63-85`

## Imported by (4)
- [[file-frontend-src-components-visualization-analysispanel-tsx|AnalysisPanel.tsx]]
- [[file-frontend-src-components-visualization-width-widthsearchdiagnostics-tsx|WidthSearchDiagnostics.tsx]]
- [[file-frontend-src-components-visualization-width-widthvisualization-tsx|WidthVisualization.tsx]]
- [[file-frontend-src-components-visualization-width-widthvisualizationpanel-tsx|WidthVisualizationPanel.tsx]]
