---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/curvature/CurvatureDiagnostics.tsx", "frontend/src/components/visualization/curvature/CurvatureDiagnostics.tsx", "CurvatureDiagnostics.tsx"]
tags: [file, tsx]
path: "frontend/src/components/visualization/curvature/CurvatureDiagnostics.tsx"
---

# CurvatureDiagnostics.tsx

**Path:** `frontend/src/components/visualization/curvature/CurvatureDiagnostics.tsx`
**Community:** [[com-curvature-curvature|curvature-curvature]]

## Contains (1)
- [[fn-frontend-src-components-visualization-curvature-curvaturediagnostics-tsx--curvaturediagnostics|CurvatureDiagnostics]] — *Function* `37-173`

## Imported by (2)
- [[file-frontend-src-components-visualization-analysispanel-tsx|AnalysisPanel.tsx]]
- [[file-frontend-src-components-visualization-curvature-curvaturevisualizationpanel-tsx|CurvatureVisualizationPanel.tsx]]
