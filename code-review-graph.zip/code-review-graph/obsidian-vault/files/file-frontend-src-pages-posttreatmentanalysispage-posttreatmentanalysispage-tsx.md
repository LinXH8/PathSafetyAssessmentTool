---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PostTreatmentAnalysisPage/postTreatmentAnalysisPage.tsx", "frontend/src/pages/PostTreatmentAnalysisPage/postTreatmentAnalysisPage.tsx", "postTreatmentAnalysisPage.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/PostTreatmentAnalysisPage/postTreatmentAnalysisPage.tsx"
---

# postTreatmentAnalysisPage.tsx

**Path:** `frontend/src/pages/PostTreatmentAnalysisPage/postTreatmentAnalysisPage.tsx`
**Community:** [[com-posttreatmentanalysispage-tag|posttreatmentanalysispage-tag]]

## Contains (7)
- [[fn-frontend-src-pages-posttreatmentanalysispage-posttreatmentanalysispage-tsx--gettagbordercolor|getTagBorderColor]] — *Function* `11-15`
- [[fn-frontend-src-pages-posttreatmentanalysispage-posttreatmentanalysispage-tsx--gettagcolor|getTagColor]] — *Function* `17-45`
- [[fn-frontend-src-pages-posttreatmentanalysispage-posttreatmentanalysispage-tsx--posttreatmentanalysispage|PostTreatmentAnalysisPage]] — *Function* `47-242`
- [[fn-frontend-src-pages-posttreatmentanalysispage-posttreatmentanalysispage-tsx--onrowclick|onRowClick]] — *Function* `79-79`
- [[fn-frontend-src-pages-posttreatmentanalysispage-posttreatmentanalysispage-tsx--analyzeproject|analyzeProject]] — *Function* `81-84`
- [[fn-frontend-src-pages-posttreatmentanalysispage-posttreatmentanalysispage-tsx--compareprojects|compareProjects]] — *Function* `86-89`
- [[fn-frontend-src-pages-posttreatmentanalysispage-posttreatmentanalysispage-tsx--tag|tag]] — *Function* `160-160`

## Imports (1)
- [[file-frontend-src-api-index-ts|index.ts]]
