---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/main.tsx", "frontend/src/main.tsx", "main.tsx"]
tags: [file, tsx]
path: "frontend/src/main.tsx"
---

# main.tsx

**Path:** `frontend/src/main.tsx`

## Imports (3)
- [[file-frontend-src-components-ui-provider-tsx|provider.tsx]]
- [[file-frontend-src-components-ui-toaster-tsx|toaster.tsx]]
- [[file-frontend-src-app-tsx|App.tsx]]
