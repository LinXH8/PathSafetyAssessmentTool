---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/sidebar/components/ResetConfirmationDialog.tsx", "frontend/src/pages/sidebar/components/ResetConfirmationDialog.tsx", "ResetConfirmationDialog.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/sidebar/components/ResetConfirmationDialog.tsx"
---

# ResetConfirmationDialog.tsx

**Path:** `frontend/src/pages/sidebar/components/ResetConfirmationDialog.tsx`
**Community:** [[com-components-reset|components-reset]]

## Contains (1)
- [[fn-frontend-src-pages-sidebar-components-resetconfirmationdialog-tsx--resetconfirmationdialog|ResetConfirmationDialog]] — *Function* `11-64`

## Imported by (1)
- [[file-frontend-src-pages-sidebar-sidebar-tsx|Sidebar.tsx]]
