---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/sidebar/components/ExitConfirmationDialog.tsx", "frontend/src/pages/sidebar/components/ExitConfirmationDialog.tsx", "ExitConfirmationDialog.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/sidebar/components/ExitConfirmationDialog.tsx"
---

# ExitConfirmationDialog.tsx

**Path:** `frontend/src/pages/sidebar/components/ExitConfirmationDialog.tsx`
**Community:** [[com-components-exit|components-exit]]

## Contains (1)
- [[fn-frontend-src-pages-sidebar-components-exitconfirmationdialog-tsx--exitconfirmationdialog|ExitConfirmationDialog]] — *Function* `12-74`

## Imported by (2)
- [[file-frontend-src-pages-codingpage-codingpage-tsx|codingPage.tsx]]
- [[file-frontend-src-pages-sidebar-sidebar-tsx|Sidebar.tsx]]
