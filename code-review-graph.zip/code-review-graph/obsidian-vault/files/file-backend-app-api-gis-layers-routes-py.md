---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/gis_layers/routes.py", "backend/app/api/gis_layers/routes.py", "routes.py"]
tags: [file, python]
path: "backend/app/api/gis_layers/routes.py"
---

# routes.py

**Path:** `backend/app/api/gis_layers/routes.py`
**Community:** [[com-gis-layers-shapefiles|gis-layers-shapefiles]]

## Description

> GIS Layers Blueprint  (url_prefix: /api/shapefiles)
>
> Serves the shapefiles stored in backend/shapefiles/ to the frontend GIS
> Layers page.  The URL prefix is kept as /api/shapefiles so no frontend
> changes are needed; only the Python module was renamed to gis_layers to
> avoid being swallowed by the backend/.gitignore rule that ignores any
> folder named 'shapefiles'.
>
> Endpoints
> ---------
> GET  /api/shapefiles                      – list all shapefiles with metadata
> GET  /api/shapefiles/categories           – list category subdirectories
> POST /api/shapefiles/geojson              – return GeoJSON for one shapefile
> POST /api/shapefiles/upload               – upload new shapefile(s)
> POST /api/shapefiles/validate             – validate a shapefile ZIP
> POST /api/shapefiles/validate-replacement – check replacement compatibility
> PUT  /api/shapefiles/replace              – move uploaded file over existing
> DELETE /api/shapefiles/<path>             – delete a shapefile + companions

## Contains (15)
- [[fn-backend-app-api-gis-layers-routes-py--shp-root|_shp_root]] — *Function* `49-51`
- [[fn-backend-app-api-gis-layers-routes-py--extract-xml-yearstr|_extract_xml_yearStr]] — *Function* `77-93`
- [[fn-backend-app-api-gis-layers-routes-py--temp-root|_temp_root]] — *Function* `97-101`
- [[fn-backend-app-api-gis-layers-routes-py--safe-relative|_safe_relative]] — *Function* `104-116`
- [[fn-backend-app-api-gis-layers-routes-py--companion-extensions|_companion_extensions]] — *Function* `119-122`
- [[fn-backend-app-api-gis-layers-routes-py--file-info|_file_info]] — *Function* `125-163`
- [[fn-backend-app-api-gis-layers-routes-py--list-shapefiles|list_shapefiles]] — *Function* `171-183`
- [[fn-backend-app-api-gis-layers-routes-py--list-categories|list_categories]] — *Function* `191-203`
- [[fn-backend-app-api-gis-layers-routes-py--read-shapefile-as-geojson|_read_shapefile_as_geojson]] — *Function* `210-248`
- [[fn-backend-app-api-gis-layers-routes-py--get-geojson|get_geojson]] — *Function* `252-276`
- [[fn-backend-app-api-gis-layers-routes-py--validate-shapefile|validate_shapefile]] — *Function* `284-347`
- [[fn-backend-app-api-gis-layers-routes-py--validate-replacement|validate_replacement]] — *Function* `355-381`
- [[fn-backend-app-api-gis-layers-routes-py--upload-shapefiles|upload_shapefiles]] — *Function* `389-430`
- [[fn-backend-app-api-gis-layers-routes-py--replace-shapefiles|replace_shapefiles]] — *Function* `438-488`
- [[fn-backend-app-api-gis-layers-routes-py--delete-shapefile|delete_shapefile]] — *Function* `496-513`

## Imports (1)
- [[file-backend-app-services-shapefile-validator-py|shapefile_validator.py]]
