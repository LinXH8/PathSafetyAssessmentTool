---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/project_manager.py", "backend/app/services/project_manager.py", "project_manager.py"]
tags: [file, python]
path: "backend/app/services/project_manager.py"
---

# project_manager.py

**Path:** `backend/app/services/project_manager.py`
**Community:** [[com-services-project|services-project]]

## Contains (47)
- [[cls-backend-app-services-project-manager-py--projectversion|ProjectVersion]] — *Class* `19-182`
- [[fn-backend-app-services-project-manager-py--init|__init__]] — *Function* `25-39`
- [[fn-backend-app-services-project-manager-py--snapshot-metadata|snapshot_metadata]] — *Function* `57-61`
- [[fn-backend-app-services-project-manager-py--attributes|attributes]] — *Function* `72-77`
- [[fn-backend-app-services-project-manager-py--results|results]] — *Function* `88-93`
- [[fn-backend-app-services-project-manager-py--treatment|treatment]] — *Function* `104-109`
- [[fn-backend-app-services-project-manager-py--load-all|load_all]] — *Function* `112-118`
- [[fn-backend-app-services-project-manager-py--save-all|save_all]] — *Function* `120-128`
- [[fn-backend-app-services-project-manager-py--delete-segment|delete_segment]] — *Function* `132-151`
- [[fn-backend-app-services-project-manager-py--delete-segments|delete_segments]] — *Function* `152-182`
- [[cls-backend-app-services-project-manager-py--project|Project]] — *Class* `185-733`
- [[fn-backend-app-services-project-manager-py--init-2|__init__]] — *Function* `186-197`
- [[fn-backend-app-services-project-manager-py--discover-versions|_discover_versions]] — *Function* `200-207`
- [[fn-backend-app-services-project-manager-py--latest|latest]] — *Function* `209-214`
- [[fn-backend-app-services-project-manager-py--by-date|by_date]] — *Function* `216-220`
- [[fn-backend-app-services-project-manager-py--create-new-version|create_new_version]] — *Function* `222-261`
- [[fn-backend-app-services-project-manager-py--save-all-2|save_all]] — *Function* `263-277`
- [[fn-backend-app-services-project-manager-py--delete|_delete]] — *Function* `279-281`
- [[fn-backend-app-services-project-manager-py--delete-segment-2|delete_segment]] — *Function* `283-319`
- [[fn-backend-app-services-project-manager-py--delete-segments-2|delete_segments]] — *Function* `321-374`
- [[fn-backend-app-services-project-manager-py--check-collisions|check_collisions]] — *Function* `376-421`
- [[fn-backend-app-services-project-manager-py--copy-segments|copy_segments]] — *Function* `423-697`
- [[fn-backend-app-services-project-manager-py--predict-name|predict_name]] — *Function* `465-492`
- [[fn-backend-app-services-project-manager-py--map-labels-to-values|map_labels_to_values]] — *Function* `634-639`
- [[fn-backend-app-services-project-manager-py--metadata|metadata]] — *Function* `714-718`
- [[fn-backend-app-services-project-manager-py--geo-data|geo_data]] — *Function* `729-733`
- [[cls-backend-app-services-project-manager-py--project-manager|project_manager]] — *Class* `736-1016`
- [[fn-backend-app-services-project-manager-py--init-3|__init__]] — *Function* `751-766`
- [[fn-backend-app-services-project-manager-py--initialise|_initialise]] — *Function* `769-778`
- [[fn-backend-app-services-project-manager-py--discover-projects|_discover_projects]] — *Function* `784-791`
- [[fn-backend-app-services-project-manager-py--delete-project|delete_project]] — *Function* `793-800`
- [[fn-backend-app-services-project-manager-py--list-names|list_names]] — *Function* `802-803`
- [[fn-backend-app-services-project-manager-py--project|project]] — *Function* `805-809`
- [[fn-backend-app-services-project-manager-py--create-project|create_project]] — *Function* `811-862`
- [[fn-backend-app-services-project-manager-py--create-temporary-project|create_temporary_project]] — *Function* `865-866`
- [[fn-backend-app-services-project-manager-py--merge-project|merge_project]] — *Function* `868-869`
- [[fn-backend-app-services-project-manager-py--merge-project-list|merge_project_list]] — *Function* `871-897`
- [[fn-backend-app-services-project-manager-py--search|search]] — *Function* `901-976`
- [[fn-backend-app-services-project-manager-py--load-config|load_config]] — *Function* `983-992`
- [[fn-backend-app-services-project-manager-py--save-config|save_config]] — *Function* `994-996`
- [[fn-backend-app-services-project-manager-py--write-config|write_config]] — *Function* `998-1002`
- [[fn-backend-app-services-project-manager-py--save-project|save_project]] — *Function* `1005-1006`
- [[fn-backend-app-services-project-manager-py--read-project|read_project]] — *Function* `1009-1016`
- [[fn-backend-app-services-project-manager-py--load-images-from-folder-cv|load_images_from_folder_cv]] — *Function* `1023-1050`
- [[fn-backend-app-services-project-manager-py--extract-numeric-key|extract_numeric_key]] — *Function* `1030-1048`
- [[fn-backend-app-services-project-manager-py--get-config-path|get_config_path]] — *Function* `1052-1053`
- [[fn-backend-app-services-project-manager-py--rename-files-with-prefix|rename_files_with_prefix]] — *Function* `1055-1072`

## Imports (1)
- [[file-backend-app-services-cyclerap-va-py|cycleRAP_VA.py]]

## Imported by (2)
- [[file-backend-app-api-projects-routes-py|routes.py]]
- [[file-backend-inspect-data-py|inspect_data.py]]
