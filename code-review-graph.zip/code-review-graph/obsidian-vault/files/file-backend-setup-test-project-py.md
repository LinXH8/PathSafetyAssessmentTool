---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/setup_test_project.py", "backend/setup_test_project.py", "setup_test_project.py"]
tags: [file, python]
path: "backend/setup_test_project.py"
---

# setup_test_project.py

**Path:** `backend/setup_test_project.py`

## Description

> Setup script to create a test project structure for PSAT
