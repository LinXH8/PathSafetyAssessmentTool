---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/ui/slider.tsx", "frontend/src/components/ui/slider.tsx", "slider.tsx"]
tags: [file, tsx]
path: "frontend/src/components/ui/slider.tsx"
---

# slider.tsx

**Path:** `frontend/src/components/ui/slider.tsx`

## Imported by (2)
- [[file-frontend-src-pages-codingpage-components-imagepanel-tsx|ImagePanel.tsx]]
- [[file-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx|PathAnalysisMapView.tsx]]
