---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/api/curvatureVisualization.ts", "frontend/src/api/curvatureVisualization.ts", "curvatureVisualization.ts"]
tags: [file, typescript]
path: "frontend/src/api/curvatureVisualization.ts"
---

# curvatureVisualization.ts

**Path:** `frontend/src/api/curvatureVisualization.ts`
**Community:** [[com-api-fetch|api-fetch]]

## Contains (1)
- [[fn-frontend-src-api-curvaturevisualization-ts--fetchcurvaturevisualization|fetchCurvatureVisualization]] — *Function* `103-125`

## Imported by (2)
- [[file-frontend-src-components-visualization-analysispanel-tsx|AnalysisPanel.tsx]]
- [[file-frontend-src-components-visualization-curvature-curvaturevisualizationpanel-tsx|CurvatureVisualizationPanel.tsx]]
