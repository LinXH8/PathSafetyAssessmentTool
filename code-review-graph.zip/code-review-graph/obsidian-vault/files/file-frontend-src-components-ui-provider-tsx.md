---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/ui/provider.tsx", "frontend/src/components/ui/provider.tsx", "provider.tsx"]
tags: [file, tsx]
path: "frontend/src/components/ui/provider.tsx"
---

# provider.tsx

**Path:** `frontend/src/components/ui/provider.tsx`
**Community:** [[com-ui-provider|ui-provider]]

## Contains (1)
- [[fn-frontend-src-components-ui-provider-tsx--provider|Provider]] — *Function* `9-15`

## Imports (1)
- [[file-frontend-src-components-ui-color-mode-tsx|color-mode.tsx]]

## Imported by (1)
- [[file-frontend-src-main-tsx|main.tsx]]
