---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/layouts/AppLayout.tsx", "frontend/src/layouts/AppLayout.tsx", "AppLayout.tsx"]
tags: [file, tsx]
path: "frontend/src/layouts/AppLayout.tsx"
---

# AppLayout.tsx

**Path:** `frontend/src/layouts/AppLayout.tsx`
**Community:** [[com-layouts-app|layouts-app]]

## Contains (1)
- [[fn-frontend-src-layouts-applayout-tsx--applayout|AppLayout]] — *Function* `5-14`

## Imports (1)
- [[file-frontend-src-pages-sidebar-sidebar-tsx|Sidebar.tsx]]

## Imported by (1)
- [[file-frontend-src-app-tsx|App.tsx]]
