---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx", "frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx", "PathAnalysisMapView.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx"
---

# PathAnalysisMapView.tsx

**Path:** `frontend/src/pages/PathAnalysisPage/components/PathAnalysisMapView.tsx`
**Community:** [[com-components-handle-2|components-handle]]

## Contains (44)
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--to4326|to4326]] — *Function* `29-32`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--pantobounds|PanToBounds]] — *Function* `35-42`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--fitbounds|FitBounds]] — *Function* `45-53`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--ispointinpolygon|isPointInPolygon]] — *Function* `56-68`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--draggablemarker|DraggableMarker]] — *Function* `87-115`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--polygondrawingtool|PolygonDrawingTool]] — *Function* `117-217`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--click|click]] — *Function* `133-137`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--createcustomicon|createCustomIcon]] — *Function* `169-184`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--attributeanalysismapview|AttributeAnalysisMapView]] — *Function* `238-2511`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--handlepolygonpoint|handlePolygonPoint]] — *Function* `346-348`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--finishpolygonselection|finishPolygonSelection]] — *Function* `358-391`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--handlebatchdelete|handleBatchDelete]] — *Function* `393-436`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--handledeletesegment|handleDeleteSegment]] — *Function* `438-455`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--selectedattributes|selectedAttributes]] — *Function* `460-460`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--f|f]] — *Function* `466-466`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--mappings|mappings]] — *Function* `485-487`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--getscorecolor|getScoreColor]] — *Function* `492-506`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--getoverallriskscore|getOverallRiskScore]] — *Function* `524-535`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--getattrtext|getAttrText]] — *Function* `552-616`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--getcolumnvalue|getColumnValue]] — *Function* `814-857`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--pd|pd]] — *Function* `866-875`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--opt|opt]] — *Function* `1322-1324`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--handleheaderclick|handleHeaderClick]] — *Function* `1331-1353`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--prevconfig|prevConfig]] — *Function* `1332-1352`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--handleprojectclick|handleProjectClick]] — *Function* `1382-1389`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--escapecsv|escapeCSV]] — *Function* `1392-1397`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--generatecsv|generateCSV]] — *Function* `1400-1414`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--row|row]] — *Function* `1410-1410`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--handledownloadcsv|handleDownloadCSV]] — *Function* `1417-1426`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--handledownloadimages|handleDownloadImages]] — *Function* `1429-1473`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--point|point]] — *Function* `1434-1445`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--attr|attr]] — *Function* `1552-1674`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--projectdata|projectData]] — *Function* `1560-1628`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--cat|cat]] — *Function* `1659-1668`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--finishaddsegmentsselection|finishAddSegmentsSelection]] — *Function* `1707-1738`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--p|p]] — *Function* `1716-1723`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--pt|pt]] — *Function* `1890-1890`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--e|e]] — *Function* `1950-1954`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--c|c]] — *Function* `1992-1992`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--category|category]] — *Function* `2034-2177`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--sub|sub]] — *Function* `2110-2171`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--prev|prev]] — *Function* `2402-2405`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--col|col]] — *Function* `2424-2446`
- [[fn-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx--s|s]] — *Function* `2469-2469`

## Imports (8)
- [[file-frontend-src-components-common-themeawaretilelayer-tsx|ThemeAwareTileLayer.tsx]]
- [[file-frontend-src-components-ui-toaster-tsx|toaster.tsx]]
- [[file-frontend-src-components-ui-slider-tsx|slider.tsx]]
- [[file-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx|AttributesDropdown.tsx]]
- [[file-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx|AddSegmentsDialog.tsx]]
- [[file-frontend-src-components-common-mapcursorcontroller-tsx|MapCursorController.tsx]]
- [[file-frontend-src-api-index-ts|index.ts]]
- [[file-frontend-src-components-visualization-scoreband-colorconstants-ts|colorConstants.ts]]

## Imported by (1)
- [[file-frontend-src-pages-pathanalysispage-pathanalysispage-tsx|pathAnalysisPage.tsx]]
