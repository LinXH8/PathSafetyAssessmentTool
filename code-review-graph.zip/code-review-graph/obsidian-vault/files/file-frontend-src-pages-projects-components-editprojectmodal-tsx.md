---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/Projects/components/EditProjectModal.tsx", "frontend/src/pages/Projects/components/EditProjectModal.tsx", "EditProjectModal.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/Projects/components/EditProjectModal.tsx"
---

# EditProjectModal.tsx

**Path:** `frontend/src/pages/Projects/components/EditProjectModal.tsx`
**Community:** [[com-components-tag-2|components-tag]]

## Contains (6)
- [[fn-frontend-src-pages-projects-components-editprojectmodal-tsx--gettagcolor|getTagColor]] — *Function* `24-41`
- [[fn-frontend-src-pages-projects-components-editprojectmodal-tsx--editprojectmodal|EditProjectModal]] — *Function* `43-228`
- [[fn-frontend-src-pages-projects-components-editprojectmodal-tsx--handleclose|handleClose]] — *Function* `64-69`
- [[fn-frontend-src-pages-projects-components-editprojectmodal-tsx--handletaginputkeydown|handleTagInputKeyDown]] — *Function* `71-83`
- [[fn-frontend-src-pages-projects-components-editprojectmodal-tsx--removetag|removeTag]] — *Function* `85-87`
- [[fn-frontend-src-pages-projects-components-editprojectmodal-tsx--handlesave|handleSave]] — *Function* `89-140`

## Imports (2)
- [[file-frontend-src-components-ui-toaster-tsx|toaster.tsx]]
- [[file-frontend-src-api-index-ts|index.ts]]

## Imported by (2)
- [[file-frontend-src-pages-projects-projects-tsx|projects.tsx]]
- [[file-frontend-src-pages-treatmentpage-treatmentpage-tsx|treatmentPage.tsx]]
