---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/CodingPage/components/ImagePanel.tsx", "frontend/src/pages/CodingPage/components/ImagePanel.tsx", "ImagePanel.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/CodingPage/components/ImagePanel.tsx"
---

# ImagePanel.tsx

**Path:** `frontend/src/pages/CodingPage/components/ImagePanel.tsx`
**Community:** [[com-components-image|components-image]]

## Contains (1)
- [[fn-frontend-src-pages-codingpage-components-imagepanel-tsx--imagepanel|ImagePanel]] — *Function* `11-63`

## Imports (1)
- [[file-frontend-src-components-ui-slider-tsx|slider.tsx]]

## Imported by (2)
- [[file-frontend-src-pages-codingpage-codingpage-tsx|codingPage.tsx]]
- [[file-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx|treatmentDetailPage.tsx]]
