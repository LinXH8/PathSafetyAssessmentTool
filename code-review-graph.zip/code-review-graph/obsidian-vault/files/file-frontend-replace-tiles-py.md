---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/replace_tiles.py", "frontend/replace_tiles.py", "replace_tiles.py"]
tags: [file, python]
path: "frontend/replace_tiles.py"
---

# replace_tiles.py

**Path:** `frontend/replace_tiles.py`
