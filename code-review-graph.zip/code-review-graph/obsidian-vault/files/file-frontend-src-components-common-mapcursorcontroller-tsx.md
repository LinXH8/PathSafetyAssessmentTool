---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/common/MapCursorController.tsx", "frontend/src/components/common/MapCursorController.tsx", "MapCursorController.tsx"]
tags: [file, tsx]
path: "frontend/src/components/common/MapCursorController.tsx"
---

# MapCursorController.tsx

**Path:** `frontend/src/components/common/MapCursorController.tsx`
**Community:** [[com-common-map|common-map]]

## Contains (1)
- [[fn-frontend-src-components-common-mapcursorcontroller-tsx--mapcursorcontroller|MapCursorController]] — *Function* `12-45`

## Imported by (2)
- [[file-frontend-src-pages-codingpage-components-geodatapanel-tsx|GeoDataPanel.tsx]]
- [[file-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx|PathAnalysisMapView.tsx]]
