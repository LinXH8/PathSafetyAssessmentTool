---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/cycleRAP/routes.py", "backend/app/api/cycleRAP/routes.py", "routes.py"]
tags: [file, python]
path: "backend/app/api/cycleRAP/routes.py"
---

# routes.py

**Path:** `backend/app/api/cycleRAP/routes.py`

## Imported by (1)
- [[file-backend-app-api-cyclerap-init-py|__init__.py]]
