---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/utils/__init__.py", "backend/app/utils/__init__.py", "__init__.py"]
tags: [file, python]
path: "backend/app/utils/__init__.py"
---

# __init__.py

**Path:** `backend/app/utils/__init__.py`
