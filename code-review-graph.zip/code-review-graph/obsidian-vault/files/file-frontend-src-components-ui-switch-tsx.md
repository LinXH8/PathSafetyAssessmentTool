---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/ui/switch.tsx", "frontend/src/components/ui/switch.tsx", "switch.tsx"]
tags: [file, tsx]
path: "frontend/src/components/ui/switch.tsx"
---

# switch.tsx

**Path:** `frontend/src/components/ui/switch.tsx`

## Imported by (3)
- [[file-frontend-src-pages-codingpage-components-geodatapanel-tsx|GeoDataPanel.tsx]]
- [[file-frontend-src-pages-pathanalysispage-components-filterpanel-tsx|FilterPanel.tsx]]
- [[file-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx|treatmentDetailPage.tsx]]
