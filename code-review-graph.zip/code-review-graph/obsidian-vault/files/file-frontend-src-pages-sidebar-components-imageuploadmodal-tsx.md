---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/sidebar/components/ImageUploadModal.tsx", "frontend/src/pages/sidebar/components/ImageUploadModal.tsx", "ImageUploadModal.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/sidebar/components/ImageUploadModal.tsx"
---

# ImageUploadModal.tsx

**Path:** `frontend/src/pages/sidebar/components/ImageUploadModal.tsx`
**Community:** [[com-components-handle-6|components-handle]]

## Contains (14)
- [[fn-frontend-src-pages-sidebar-components-imageuploadmodal-tsx--imageuploadmodal|ImageUploadModal]] — *Function* `18-377`
- [[fn-frontend-src-pages-sidebar-components-imageuploadmodal-tsx--resetstate|resetState]] — *Function* `33-39`
- [[fn-frontend-src-pages-sidebar-components-imageuploadmodal-tsx--handleclose|handleClose]] — *Function* `41-47`
- [[fn-frontend-src-pages-sidebar-components-imageuploadmodal-tsx--handledragenter|handleDragEnter]] — *Function* `50-54`
- [[fn-frontend-src-pages-sidebar-components-imageuploadmodal-tsx--handledragleave|handleDragLeave]] — *Function* `56-60`
- [[fn-frontend-src-pages-sidebar-components-imageuploadmodal-tsx--handledragover|handleDragOver]] — *Function* `62-65`
- [[fn-frontend-src-pages-sidebar-components-imageuploadmodal-tsx--handledrop|handleDrop]] — *Function* `67-115`
- [[fn-frontend-src-pages-sidebar-components-imageuploadmodal-tsx--processentries|processEntries]] — *Function* `76-92`
- [[fn-frontend-src-pages-sidebar-components-imageuploadmodal-tsx--handlefileselect|handleFileSelect]] — *Function* `117-122`
- [[fn-frontend-src-pages-sidebar-components-imageuploadmodal-tsx--addfiles|addFiles]] — *Function* `124-142`
- [[fn-frontend-src-pages-sidebar-components-imageuploadmodal-tsx--ext|ext]] — *Function* `130-130`
- [[fn-frontend-src-pages-sidebar-components-imageuploadmodal-tsx--removefile|removeFile]] — *Function* `144-146`
- [[fn-frontend-src-pages-sidebar-components-imageuploadmodal-tsx--handleupload|handleUpload]] — *Function* `148-191`
- [[fn-frontend-src-pages-sidebar-components-imageuploadmodal-tsx--formatbytes|formatBytes]] — *Function* `193-199`

## Imports (2)
- [[file-frontend-src-components-ui-toaster-tsx|toaster.tsx]]
- [[file-frontend-src-api-index-ts|index.ts]]

## Imported by (1)
- [[file-frontend-src-pages-createprojectpage-createprojectpage-tsx|createProjectPage.tsx]]
