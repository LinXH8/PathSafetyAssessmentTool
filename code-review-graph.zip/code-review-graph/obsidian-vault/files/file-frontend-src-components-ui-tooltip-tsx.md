---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/ui/tooltip.tsx", "frontend/src/components/ui/tooltip.tsx", "tooltip.tsx"]
tags: [file, tsx]
path: "frontend/src/components/ui/tooltip.tsx"
---

# tooltip.tsx

**Path:** `frontend/src/components/ui/tooltip.tsx`
