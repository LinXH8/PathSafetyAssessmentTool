---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/gis_layers/__init__.py", "backend/app/api/gis_layers/__init__.py", "__init__.py"]
tags: [file, python]
path: "backend/app/api/gis_layers/__init__.py"
---

# __init__.py

**Path:** `backend/app/api/gis_layers/__init__.py`
