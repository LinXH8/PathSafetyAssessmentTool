---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/test_routes_with_gpd.py", "backend/test_routes_with_gpd.py", "test_routes_with_gpd.py"]
tags: [file, python]
path: "backend/test_routes_with_gpd.py"
---

# test_routes_with_gpd.py

**Path:** `backend/test_routes_with_gpd.py`
**Community:** [[com-backend-read-2|backend-read]]

## Contains (1)
- [[fn-backend-test-routes-with-gpd-py--read-shapefile-as-geojson|_read_shapefile_as_geojson]] — *Function* `6-44`
