---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/cycleRAP_VA.py", "backend/app/services/cycleRAP_VA.py", "cycleRAP_VA.py"]
tags: [file, python]
path: "backend/app/services/cycleRAP_VA.py"
---

# cycleRAP_VA.py

**Path:** `backend/app/services/cycleRAP_VA.py`
**Community:** [[com-services-distance|services-distance]]

## Contains (10)
- [[fn-backend-app-services-cyclerap-va-py--calculate-distance|calculate_distance]] — *Function* `85-86`
- [[fn-backend-app-services-cyclerap-va-py--save-frame|save_frame]] — *Function* `90-101`
- [[fn-backend-app-services-cyclerap-va-py--prepare-directory|prepare_directory]] — *Function* `104-109`
- [[fn-backend-app-services-cyclerap-va-py--get-geo-points-by-distance|get_geo_points_by_distance]] — *Function* `113-153`
- [[fn-backend-app-services-cyclerap-va-py--convert-points-to-linestrings|convert_points_to_linestrings]] — *Function* `155-181`
- [[fn-backend-app-services-cyclerap-va-py--extract-frames-to-path|extract_frames_to_path]] — *Function* `184-207`
- [[fn-backend-app-services-cyclerap-va-py--extract-images-distance|extract_images_distance]] — *Function* `213-301`
- [[fn-backend-app-services-cyclerap-va-py--extract-images-interval|extract_images_interval]] — *Function* `303-328`
- [[fn-backend-app-services-cyclerap-va-py--create-video|create_video]] — *Function* `331-350`
- [[fn-backend-app-services-cyclerap-va-py--get-full-path|get_full_path]] — *Function* `442-444`

## Imports (1)
- [[file-backend-app-services-cycle-rap-processing-gopro-footage-py|cycle_rap_processing_gopro_footage.py]]

## Imported by (2)
- [[file-backend-app-services-global-var-py|global_var.py]]
- [[file-backend-app-services-project-manager-py|project_manager.py]]
