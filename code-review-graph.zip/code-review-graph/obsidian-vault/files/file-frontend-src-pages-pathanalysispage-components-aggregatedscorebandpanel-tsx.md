---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/AggregatedScoreBandPanel.tsx", "frontend/src/pages/PathAnalysisPage/components/AggregatedScoreBandPanel.tsx", "AggregatedScoreBandPanel.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/PathAnalysisPage/components/AggregatedScoreBandPanel.tsx"
---

# AggregatedScoreBandPanel.tsx

**Path:** `frontend/src/pages/PathAnalysisPage/components/AggregatedScoreBandPanel.tsx`
**Community:** [[com-components-aggregated|components-aggregated]]

## Contains (2)
- [[fn-frontend-src-pages-pathanalysispage-components-aggregatedscorebandpanel-tsx--aggregatedscorebandpanel|AggregatedScoreBandPanel]] — *Function* `50-377`
- [[fn-frontend-src-pages-pathanalysispage-components-aggregatedscorebandpanel-tsx--handlescoresupdated|handleScoresUpdated]] — *Function* `192-194`

## Imports (2)
- [[file-frontend-src-components-visualization-scoreband-scorebandpiechart-tsx|ScoreBandPieChart.tsx]]
- [[file-frontend-src-components-visualization-scoreband-colorconstants-ts|colorConstants.ts]]

## Imported by (1)
- [[file-frontend-src-pages-pathanalysispage-pathanalysispage-tsx|pathAnalysisPage.tsx]]
