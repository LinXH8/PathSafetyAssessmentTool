---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/test_list_shapefiles.py", "backend/test_list_shapefiles.py", "test_list_shapefiles.py"]
tags: [file, python]
path: "backend/test_list_shapefiles.py"
---

# test_list_shapefiles.py

**Path:** `backend/test_list_shapefiles.py`

## Imports (1)
- [[file-backend-app-py|app.py]]
