---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/TreatmentPage/components/AttributesDropdown.tsx", "frontend/src/pages/TreatmentPage/components/AttributesDropdown.tsx", "AttributesDropdown.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/TreatmentPage/components/AttributesDropdown.tsx"
---

# AttributesDropdown.tsx

**Path:** `frontend/src/pages/TreatmentPage/components/AttributesDropdown.tsx`
**Community:** [[com-components-handle-5|components-handle]]

## Contains (3)
- [[fn-frontend-src-pages-treatmentpage-components-attributesdropdown-tsx--attributesdropdown|AttributesDropdown]] — *Function* `190-320`
- [[fn-frontend-src-pages-treatmentpage-components-attributesdropdown-tsx--handleattributechange|handleAttributeChange]] — *Function* `197-199`
- [[fn-frontend-src-pages-treatmentpage-components-attributesdropdown-tsx--handleresetfilters|handleResetFilters]] — *Function* `202-206`
