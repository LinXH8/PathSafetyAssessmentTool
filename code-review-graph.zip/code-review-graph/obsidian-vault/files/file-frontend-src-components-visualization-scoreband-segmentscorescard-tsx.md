---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/scoreband/SegmentScoresCard.tsx", "frontend/src/components/visualization/scoreband/SegmentScoresCard.tsx", "SegmentScoresCard.tsx"]
tags: [file, tsx]
path: "frontend/src/components/visualization/scoreband/SegmentScoresCard.tsx"
---

# SegmentScoresCard.tsx

**Path:** `frontend/src/components/visualization/scoreband/SegmentScoresCard.tsx`
**Community:** [[com-scoreband-color|scoreband-color]]

## Contains (5)
- [[fn-frontend-src-components-visualization-scoreband-segmentscorescard-tsx--getbandcolor|getBandColor]] — *Function* `59-73`
- [[fn-frontend-src-components-visualization-scoreband-segmentscorescard-tsx--getlightbgcolor|getLightBgColor]] — *Function* `75-87`
- [[fn-frontend-src-components-visualization-scoreband-segmentscorescard-tsx--getdarkbgcolor|getDarkBgColor]] — *Function* `89-101`
- [[fn-frontend-src-components-visualization-scoreband-segmentscorescard-tsx--getbandlabel|getBandLabel]] — *Function* `103-115`
- [[fn-frontend-src-components-visualization-scoreband-segmentscorescard-tsx--segmentscorescard|SegmentScoresCard]] — *Function* `117-330`

## Imports (1)
- [[file-frontend-src-components-visualization-scoreband-colorconstants-ts|colorConstants.ts]]

## Imported by (2)
- [[file-frontend-src-pages-codingpage-codingpage-tsx|codingPage.tsx]]
- [[file-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx|treatmentDetailPage.tsx]]
