---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/ShapefileManagement/components/AddShapefileView.tsx", "frontend/src/pages/ShapefileManagement/components/AddShapefileView.tsx", "AddShapefileView.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/ShapefileManagement/components/AddShapefileView.tsx"
---

# AddShapefileView.tsx

**Path:** `frontend/src/pages/ShapefileManagement/components/AddShapefileView.tsx`
**Community:** [[com-components-handle-3|components-handle]]

## Contains (10)
- [[fn-frontend-src-pages-shapefilemanagement-components-addshapefileview-tsx--addshapefileview|AddShapefileView]] — *Function* `12-225`
- [[fn-frontend-src-pages-shapefilemanagement-components-addshapefileview-tsx--handledragenter|handleDragEnter]] — *Function* `19-23`
- [[fn-frontend-src-pages-shapefilemanagement-components-addshapefileview-tsx--handledragleave|handleDragLeave]] — *Function* `25-29`
- [[fn-frontend-src-pages-shapefilemanagement-components-addshapefileview-tsx--handledragover|handleDragOver]] — *Function* `31-34`
- [[fn-frontend-src-pages-shapefilemanagement-components-addshapefileview-tsx--handledrop|handleDrop]] — *Function* `36-43`
- [[fn-frontend-src-pages-shapefilemanagement-components-addshapefileview-tsx--handlefileselect|handleFileSelect]] — *Function* `45-50`
- [[fn-frontend-src-pages-shapefilemanagement-components-addshapefileview-tsx--addfiles|addFiles]] — *Function* `52-72`
- [[fn-frontend-src-pages-shapefilemanagement-components-addshapefileview-tsx--removefile|removeFile]] — *Function* `74-76`
- [[fn-frontend-src-pages-shapefilemanagement-components-addshapefileview-tsx--handleupload|handleUpload]] — *Function* `78-112`
- [[fn-frontend-src-pages-shapefilemanagement-components-addshapefileview-tsx--formatbytes|formatBytes]] — *Function* `114-120`

## Imports (2)
- [[file-frontend-src-components-ui-toaster-tsx|toaster.tsx]]
- [[file-frontend-src-api-index-ts|index.ts]]

## Imported by (1)
- [[file-frontend-src-pages-shapefilemanagement-components-uploadmodal-tsx|UploadModal.tsx]]
