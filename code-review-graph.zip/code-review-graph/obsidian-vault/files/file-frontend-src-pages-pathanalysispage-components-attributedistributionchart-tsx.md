---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/AttributeDistributionChart.tsx", "frontend/src/pages/PathAnalysisPage/components/AttributeDistributionChart.tsx", "AttributeDistributionChart.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/PathAnalysisPage/components/AttributeDistributionChart.tsx"
---

# AttributeDistributionChart.tsx

**Path:** `frontend/src/pages/PathAnalysisPage/components/AttributeDistributionChart.tsx`
**Community:** [[com-components-attribute|components-attribute]]

## Contains (3)
- [[fn-frontend-src-pages-pathanalysispage-components-attributedistributionchart-tsx--attributedistributionchart|AttributeDistributionChart]] — *Function* `29-371`
- [[fn-frontend-src-pages-pathanalysispage-components-attributedistributionchart-tsx--rendercustomlabel|renderCustomLabel]] — *Function* `62-90`
- [[fn-frontend-src-pages-pathanalysispage-components-attributedistributionchart-tsx--c|c]] — *Function* `93-93`

## Imports (1)
- [[file-frontend-src-components-ui-charttypetoggle-tsx|ChartTypeToggle.tsx]]

## Imported by (1)
- [[file-frontend-src-pages-pathanalysispage-pathanalysispage-tsx|pathAnalysisPage.tsx]]
