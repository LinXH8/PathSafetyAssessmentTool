---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/ui/ChartTypeToggle.tsx", "frontend/src/components/ui/ChartTypeToggle.tsx", "ChartTypeToggle.tsx"]
tags: [file, tsx]
path: "frontend/src/components/ui/ChartTypeToggle.tsx"
---

# ChartTypeToggle.tsx

**Path:** `frontend/src/components/ui/ChartTypeToggle.tsx`
**Community:** [[com-ui-chart|ui-chart]]

## Contains (1)
- [[fn-frontend-src-components-ui-charttypetoggle-tsx--charttypetoggle|ChartTypeToggle]] — *Function* `9-62`

## Imported by (1)
- [[file-frontend-src-pages-pathanalysispage-components-attributedistributionchart-tsx|AttributeDistributionChart.tsx]]
