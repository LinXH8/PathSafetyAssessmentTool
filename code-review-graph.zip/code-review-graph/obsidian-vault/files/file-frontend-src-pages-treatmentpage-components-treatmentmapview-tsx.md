---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/TreatmentPage/components/TreatmentMapView.tsx", "frontend/src/pages/TreatmentPage/components/TreatmentMapView.tsx", "TreatmentMapView.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/TreatmentPage/components/TreatmentMapView.tsx"
---

# TreatmentMapView.tsx

**Path:** `frontend/src/pages/TreatmentPage/components/TreatmentMapView.tsx`
**Community:** [[com-components-to4326|components-to4326]]

## Contains (4)
- [[fn-frontend-src-pages-treatmentpage-components-treatmentmapview-tsx--to4326|to4326]] — *Function* `19-22`
- [[fn-frontend-src-pages-treatmentpage-components-treatmentmapview-tsx--fitbounds|FitBounds]] — *Function* `25-33`
- [[fn-frontend-src-pages-treatmentpage-components-treatmentmapview-tsx--treatmentmapview|TreatmentMapView]] — *Function* `35-197`
- [[fn-frontend-src-pages-treatmentpage-components-treatmentmapview-tsx--p|p]] — *Function* `61-61`

## Imports (1)
- [[file-frontend-src-components-common-themeawaretilelayer-tsx|ThemeAwareTileLayer.tsx]]
