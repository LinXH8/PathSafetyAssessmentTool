---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/AutocodeValidation.tsx", "frontend/src/pages/PathAnalysisPage/components/AutocodeValidation.tsx", "AutocodeValidation.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/PathAnalysisPage/components/AutocodeValidation.tsx"
---

# AutocodeValidation.tsx

**Path:** `frontend/src/pages/PathAnalysisPage/components/AutocodeValidation.tsx`
**Community:** [[com-components-algrade|components-algrade]]

## Contains (6)
- [[fn-frontend-src-pages-pathanalysispage-components-autocodevalidation-tsx--getalgrade|getALGrade]] — *Function* `5-14`
- [[fn-frontend-src-pages-pathanalysispage-components-autocodevalidation-tsx--autocodevalidation|AutocodeValidation]] — *Function* `157-450`
- [[fn-frontend-src-pages-pathanalysispage-components-autocodevalidation-tsx--normalizeattributevalues|normalizeAttributeValues]] — *Function* `167-182`
- [[fn-frontend-src-pages-pathanalysispage-components-autocodevalidation-tsx--row|row]] — *Function* `168-181`
- [[fn-frontend-src-pages-pathanalysispage-components-autocodevalidation-tsx--handlebaselineupdate|handleBaselineUpdate]] — *Function* `321-324`
- [[fn-frontend-src-pages-pathanalysispage-components-autocodevalidation-tsx--g|g]] — *Function* `334-334`

## Imports (1)
- [[file-frontend-src-api-index-ts|index.ts]]

## Imported by (1)
- [[file-frontend-src-pages-codingpage-codingpage-tsx|codingPage.tsx]]
