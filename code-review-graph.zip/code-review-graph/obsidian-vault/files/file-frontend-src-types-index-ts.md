---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/types/index.ts", "frontend/src/types/index.ts", "index.ts"]
tags: [file, typescript]
path: "frontend/src/types/index.ts"
---

# index.ts

**Path:** `frontend/src/types/index.ts`
