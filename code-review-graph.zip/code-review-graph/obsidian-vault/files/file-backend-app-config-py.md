---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/config.py", "backend/app/config.py", "config.py"]
tags: [file, python]
path: "backend/app/config.py"
---

# config.py

**Path:** `backend/app/config.py`
**Community:** [[com-app-config|app-config]]

## Contains (1)
- [[cls-backend-app-config-py--config|Config]] — *Class* `3-5`
