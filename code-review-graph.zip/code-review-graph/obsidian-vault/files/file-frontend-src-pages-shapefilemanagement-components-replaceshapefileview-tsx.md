---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/ShapefileManagement/components/ReplaceShapefileView.tsx", "frontend/src/pages/ShapefileManagement/components/ReplaceShapefileView.tsx", "ReplaceShapefileView.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/ShapefileManagement/components/ReplaceShapefileView.tsx"
---

# ReplaceShapefileView.tsx

**Path:** `frontend/src/pages/ShapefileManagement/components/ReplaceShapefileView.tsx`
**Community:** [[com-components-handle-4|components-handle]]

## Contains (11)
- [[fn-frontend-src-pages-shapefilemanagement-components-replaceshapefileview-tsx--replaceshapefileview|ReplaceShapefileView]] — *Function* `19-329`
- [[fn-frontend-src-pages-shapefilemanagement-components-replaceshapefileview-tsx--handledragenter|handleDragEnter]] — *Function* `30-34`
- [[fn-frontend-src-pages-shapefilemanagement-components-replaceshapefileview-tsx--handledragleave|handleDragLeave]] — *Function* `36-40`
- [[fn-frontend-src-pages-shapefilemanagement-components-replaceshapefileview-tsx--handledragover|handleDragOver]] — *Function* `42-45`
- [[fn-frontend-src-pages-shapefilemanagement-components-replaceshapefileview-tsx--handledrop|handleDrop]] — *Function* `47-54`
- [[fn-frontend-src-pages-shapefilemanagement-components-replaceshapefileview-tsx--handlefileselect|handleFileSelect]] — *Function* `56-61`
- [[fn-frontend-src-pages-shapefilemanagement-components-replaceshapefileview-tsx--addfiles|addFiles]] — *Function* `63-81`
- [[fn-frontend-src-pages-shapefilemanagement-components-replaceshapefileview-tsx--removefile|removeFile]] — *Function* `83-85`
- [[fn-frontend-src-pages-shapefilemanagement-components-replaceshapefileview-tsx--updatetargetpath|updateTargetPath]] — *Function* `87-91`
- [[fn-frontend-src-pages-shapefilemanagement-components-replaceshapefileview-tsx--handlereplace|handleReplace]] — *Function* `93-158`
- [[fn-frontend-src-pages-shapefilemanagement-components-replaceshapefileview-tsx--formatbytes|formatBytes]] — *Function* `160-166`

## Imports (2)
- [[file-frontend-src-components-ui-toaster-tsx|toaster.tsx]]
- [[file-frontend-src-api-index-ts|index.ts]]

## Imported by (1)
- [[file-frontend-src-pages-shapefilemanagement-components-uploadmodal-tsx|UploadModal.tsx]]
