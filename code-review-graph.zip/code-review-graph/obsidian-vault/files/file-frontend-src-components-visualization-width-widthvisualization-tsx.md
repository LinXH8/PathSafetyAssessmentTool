---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/width/WidthVisualization.tsx", "frontend/src/components/visualization/width/WidthVisualization.tsx", "WidthVisualization.tsx"]
tags: [file, tsx]
path: "frontend/src/components/visualization/width/WidthVisualization.tsx"
---

# WidthVisualization.tsx

**Path:** `frontend/src/components/visualization/width/WidthVisualization.tsx`
**Community:** [[com-width-fit|width-fit]]

## Contains (2)
- [[fn-frontend-src-components-visualization-width-widthvisualization-tsx--fitbounds|FitBounds]] — *Function* `12-20`
- [[fn-frontend-src-components-visualization-width-widthvisualization-tsx--widthvisualization|WidthVisualization]] — *Function* `22-135`

## Imports (2)
- [[file-frontend-src-components-common-themeawaretilelayer-tsx|ThemeAwareTileLayer.tsx]]
- [[file-frontend-src-api-widthvisualization-ts|widthVisualization.ts]]
