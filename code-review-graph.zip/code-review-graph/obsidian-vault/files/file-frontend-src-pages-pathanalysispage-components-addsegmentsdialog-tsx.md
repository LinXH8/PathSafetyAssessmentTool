---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/AddSegmentsDialog.tsx", "frontend/src/pages/PathAnalysisPage/components/AddSegmentsDialog.tsx", "AddSegmentsDialog.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/PathAnalysisPage/components/AddSegmentsDialog.tsx"
---

# AddSegmentsDialog.tsx

**Path:** `frontend/src/pages/PathAnalysisPage/components/AddSegmentsDialog.tsx`
**Community:** [[com-components-tag|components-tag]]

## Contains (12)
- [[fn-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx--gettagcolor|getTagColor]] — *Function* `20-36`
- [[fn-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx--addsegmentsdialog|AddSegmentsDialog]] — *Function* `50-432`
- [[fn-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx--n|n]] — *Function* `86-86`
- [[fn-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx--tag|tag]] — *Function* `98-98`
- [[fn-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx--handletaginputkeydown|handleTagInputKeyDown]] — *Function* `107-118`
- [[fn-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx--removetag|removeTag]] — *Function* `120-122`
- [[fn-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx--performcopy|performCopy]] — *Function* `124-160`
- [[fn-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx--handlesubmit|handleSubmit]] — *Function* `162-209`
- [[fn-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx--handleconfirmreplace|handleConfirmReplace]] — *Function* `211-213`
- [[fn-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx--p|p]] — *Function* `218-218`
- [[fn-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx--s|s]] — *Function* `237-241`
- [[fn-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx--t|t]] — *Function* `363-367`

## Imports (2)
- [[file-frontend-src-api-index-ts|index.ts]]
- [[file-frontend-src-components-ui-toaster-tsx|toaster.tsx]]

## Imported by (2)
- [[file-frontend-src-pages-codingpage-components-geodatapanel-tsx|GeoDataPanel.tsx]]
- [[file-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx|PathAnalysisMapView.tsx]]
