---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/TreatmentPage/components/MapView.tsx", "frontend/src/pages/TreatmentPage/components/MapView.tsx", "MapView.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/TreatmentPage/components/MapView.tsx"
---

# MapView.tsx

**Path:** `frontend/src/pages/TreatmentPage/components/MapView.tsx`
**Community:** [[com-components-view-2|components-view]]

## Contains (2)
- [[fn-frontend-src-pages-treatmentpage-components-mapview-tsx--setviewonload|SetViewOnLoad]] — *Function* `12-20`
- [[fn-frontend-src-pages-treatmentpage-components-mapview-tsx--mapview|MapView]] — *Function* `22-46`

## Imports (1)
- [[file-frontend-src-components-common-themeawaretilelayer-tsx|ThemeAwareTileLayer.tsx]]
