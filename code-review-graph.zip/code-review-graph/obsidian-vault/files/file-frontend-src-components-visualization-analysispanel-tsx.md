---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/AnalysisPanel.tsx", "frontend/src/components/visualization/AnalysisPanel.tsx", "AnalysisPanel.tsx"]
tags: [file, tsx]
path: "frontend/src/components/visualization/AnalysisPanel.tsx"
---

# AnalysisPanel.tsx

**Path:** `frontend/src/components/visualization/AnalysisPanel.tsx`
**Community:** [[com-visualization-width|visualization-width]]

## Contains (8)
- [[fn-frontend-src-components-visualization-analysispanel-tsx--getwidthcategorycolor|getWidthCategoryColor]] — *Function* `19-26`
- [[fn-frontend-src-components-visualization-analysispanel-tsx--getwidthcategoryicon|getWidthCategoryIcon]] — *Function* `28-35`
- [[fn-frontend-src-components-visualization-analysispanel-tsx--getlayercolor|getLayerColor]] — *Function* `37-44`
- [[fn-frontend-src-components-visualization-analysispanel-tsx--layerdot|LayerDot]] — *Function* `46-60`
- [[fn-frontend-src-components-visualization-analysispanel-tsx--datacard|DataCard]] — *Function* `72-86`
- [[fn-frontend-src-components-visualization-analysispanel-tsx--analysispanel|AnalysisPanel]] — *Function* `90-331`
- [[fn-frontend-src-components-visualization-analysispanel-tsx--e|e]] — *Function* `124-124`
- [[fn-frontend-src-components-visualization-analysispanel-tsx--v|v]] — *Function* `297-297`

## Imports (5)
- [[file-frontend-src-components-visualization-curvature-curvaturevisualization-tsx|CurvatureVisualization.tsx]]
- [[file-frontend-src-components-visualization-curvature-curvaturediagnostics-tsx|CurvatureDiagnostics.tsx]]
- [[file-frontend-src-components-visualization-width-widthsearchdiagnostics-tsx|WidthSearchDiagnostics.tsx]]
- [[file-frontend-src-api-widthvisualization-ts|widthVisualization.ts]]
- [[file-frontend-src-api-curvaturevisualization-ts|curvatureVisualization.ts]]

## Imported by (1)
- [[file-frontend-src-pages-codingpage-codingpage-tsx|codingPage.tsx]]
