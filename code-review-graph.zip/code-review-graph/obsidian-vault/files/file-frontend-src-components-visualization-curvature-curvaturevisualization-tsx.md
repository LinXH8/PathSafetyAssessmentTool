---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/curvature/CurvatureVisualization.tsx", "frontend/src/components/visualization/curvature/CurvatureVisualization.tsx", "CurvatureVisualization.tsx"]
tags: [file, tsx]
path: "frontend/src/components/visualization/curvature/CurvatureVisualization.tsx"
---

# CurvatureVisualization.tsx

**Path:** `frontend/src/components/visualization/curvature/CurvatureVisualization.tsx`
**Community:** [[com-curvature-fit|curvature-fit]]

## Contains (2)
- [[fn-frontend-src-components-visualization-curvature-curvaturevisualization-tsx--fitbounds|FitBounds]] — *Function* `54-62`
- [[fn-frontend-src-components-visualization-curvature-curvaturevisualization-tsx--curvaturevisualization|CurvatureVisualization]] — *Function* `64-167`

## Imports (1)
- [[file-frontend-src-components-common-themeawaretilelayer-tsx|ThemeAwareTileLayer.tsx]]

## Imported by (2)
- [[file-frontend-src-components-visualization-analysispanel-tsx|AnalysisPanel.tsx]]
- [[file-frontend-src-components-visualization-curvature-curvaturevisualizationpanel-tsx|CurvatureVisualizationPanel.tsx]]
