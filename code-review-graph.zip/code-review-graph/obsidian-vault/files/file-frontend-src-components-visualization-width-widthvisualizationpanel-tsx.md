---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/width/WidthVisualizationPanel.tsx", "frontend/src/components/visualization/width/WidthVisualizationPanel.tsx", "WidthVisualizationPanel.tsx"]
tags: [file, tsx]
path: "frontend/src/components/visualization/width/WidthVisualizationPanel.tsx"
---

# WidthVisualizationPanel.tsx

**Path:** `frontend/src/components/visualization/width/WidthVisualizationPanel.tsx`
**Community:** [[com-width-visualization|width-visualization]]

## Contains (5)
- [[fn-frontend-src-components-visualization-width-widthvisualizationpanel-tsx--widthvisualizationpanel|WidthVisualizationPanel]] — *Function* `11-167`
- [[fn-frontend-src-components-visualization-width-widthvisualizationpanel-tsx--loadvisualization|loadVisualization]] — *Function* `22-34`
- [[fn-frontend-src-components-visualization-width-widthvisualizationpanel-tsx--getcategorycolor|getCategoryColor]] — *Function* `62-69`
- [[fn-frontend-src-components-visualization-width-widthvisualizationpanel-tsx--getcategoryicon|getCategoryIcon]] — *Function* `71-78`
- [[fn-frontend-src-components-visualization-width-widthvisualizationpanel-tsx--getlayercolor|getLayerColor]] — *Function* `169-176`

## Imports (2)
- [[file-frontend-src-components-visualization-width-widthsearchdiagnostics-tsx|WidthSearchDiagnostics.tsx]]
- [[file-frontend-src-api-widthvisualization-ts|widthVisualization.ts]]
