---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/HelpPage/helpPage.tsx", "frontend/src/pages/HelpPage/helpPage.tsx", "helpPage.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/HelpPage/helpPage.tsx"
---

# helpPage.tsx

**Path:** `frontend/src/pages/HelpPage/helpPage.tsx`
**Community:** [[com-helppage-help|helppage-help]]

## Contains (3)
- [[fn-frontend-src-pages-helppage-helppage-tsx--helppage|HelpPage]] — *Function* `8-97`
- [[fn-frontend-src-pages-helppage-helppage-tsx--adminguide|AdminGuide]] — *Function* `99-155`
- [[fn-frontend-src-pages-helppage-helppage-tsx--code|Code]] — *Function* `157-173`

## Imports (3)
- [[file-frontend-src-components-ui-color-mode-tsx|color-mode.tsx]]
- [[file-frontend-src-pages-helppage-developerguide-tsx|DeveloperGuide.tsx]]
- [[file-frontend-src-pages-helppage-userguide-tsx|UserGuide.tsx]]

## Imported by (1)
- [[file-frontend-src-app-tsx|App.tsx]]
