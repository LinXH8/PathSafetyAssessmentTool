---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/__init__.py", "backend/app/__init__.py", "__init__.py"]
tags: [file, python]
path: "backend/app/__init__.py"
---

# __init__.py

**Path:** `backend/app/__init__.py`
**Community:** [[com-app-app|app-app]]

## Contains (1)
- [[fn-backend-app-init-py--create-app|create_app]] — *Function* `6-19`
