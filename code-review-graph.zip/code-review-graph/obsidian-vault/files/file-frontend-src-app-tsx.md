---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/App.tsx", "frontend/src/App.tsx", "App.tsx"]
tags: [file, tsx]
path: "frontend/src/App.tsx"
---

# App.tsx

**Path:** `frontend/src/App.tsx`
**Community:** [[com-src-app|src-app]]

## Contains (1)
- [[fn-frontend-src-app-tsx--app|App]] — *Function* `15-37`

## Imports (11)
- [[file-frontend-src-pages-landingpage-landingpage-tsx|landingPage.tsx]]
- [[file-frontend-src-pages-projects-projects-tsx|projects.tsx]]
- [[file-frontend-src-pages-codingpage-codingpage-tsx|codingPage.tsx]]
- [[file-frontend-src-pages-createprojectpage-createprojectpage-tsx|createProjectPage.tsx]]
- [[file-frontend-src-pages-treatmentpage-treatmentpage-tsx|treatmentPage.tsx]]
- [[file-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx|treatmentDetailPage.tsx]]
- [[file-frontend-src-pages-pathanalysispage-pathanalysispage-tsx|pathAnalysisPage.tsx]]
- [[file-frontend-src-pages-gislayerspage-gislayerspage-tsx|GisLayersPage.tsx]]
- [[file-frontend-src-layouts-applayout-tsx|AppLayout.tsx]]
- [[file-frontend-src-components-common-helpbutton-tsx|HelpButton.tsx]]
- [[file-frontend-src-pages-helppage-helppage-tsx|helpPage.tsx]]

## Imported by (1)
- [[file-frontend-src-main-tsx|main.tsx]]
