---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/AnalysisPage/analysisPage.tsx", "frontend/src/pages/AnalysisPage/analysisPage.tsx", "analysisPage.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/AnalysisPage/analysisPage.tsx"
---

# analysisPage.tsx

**Path:** `frontend/src/pages/AnalysisPage/analysisPage.tsx`
**Community:** [[com-analysispage-analysis|analysispage-analysis]]

## Contains (4)
- [[fn-frontend-src-pages-analysispage-analysispage-tsx--analysispage|AnalysisPage]] — *Function* `22-238`
- [[fn-frontend-src-pages-analysispage-analysispage-tsx--onrowclick|onRowClick]] — *Function* `71-71`
- [[fn-frontend-src-pages-analysispage-analysispage-tsx--analyzeproject|analyzeProject]] — *Function* `73-78`
- [[fn-frontend-src-pages-analysispage-analysispage-tsx--compareprojects|compareProjects]] — *Function* `80-85`

## Imports (1)
- [[file-frontend-src-api-index-ts|index.ts]]
