---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/sidebar/components/ShapefileModal.tsx", "frontend/src/pages/sidebar/components/ShapefileModal.tsx", "ShapefileModal.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/sidebar/components/ShapefileModal.tsx"
---

# ShapefileModal.tsx

**Path:** `frontend/src/pages/sidebar/components/ShapefileModal.tsx`
**Community:** [[com-components-handle-7|components-handle]]

## Contains (26)
- [[fn-frontend-src-pages-sidebar-components-shapefilemodal-tsx--shapefilemodal|ShapefileModal]] — *Function* `15-809`
- [[fn-frontend-src-pages-sidebar-components-shapefilemodal-tsx--loadcategories|loadCategories]] — *Function* `43-49`
- [[fn-frontend-src-pages-sidebar-components-shapefilemodal-tsx--loadallshapefiles|loadAllShapefiles]] — *Function* `51-57`
- [[fn-frontend-src-pages-sidebar-components-shapefilemodal-tsx--resetstate|resetState]] — *Function* `59-68`
- [[fn-frontend-src-pages-sidebar-components-shapefilemodal-tsx--handleclose|handleClose]] — *Function* `70-73`
- [[fn-frontend-src-pages-sidebar-components-shapefilemodal-tsx--handlechoiceselect|handleChoiceSelect]] — *Function* `75-77`
- [[fn-frontend-src-pages-sidebar-components-shapefilemodal-tsx--handlebacktochoice|handleBackToChoice]] — *Function* `79-86`
- [[fn-frontend-src-pages-sidebar-components-shapefilemodal-tsx--handledragenter|handleDragEnter]] — *Function* `90-94`
- [[fn-frontend-src-pages-sidebar-components-shapefilemodal-tsx--handledragleave|handleDragLeave]] — *Function* `96-100`
- [[fn-frontend-src-pages-sidebar-components-shapefilemodal-tsx--handledragover|handleDragOver]] — *Function* `102-105`
- [[fn-frontend-src-pages-sidebar-components-shapefilemodal-tsx--handledrop|handleDrop]] — *Function* `107-114`
- [[fn-frontend-src-pages-sidebar-components-shapefilemodal-tsx--handlefileselect|handleFileSelect]] — *Function* `116-121`
- [[fn-frontend-src-pages-sidebar-components-shapefilemodal-tsx--addfiles|addFiles]] — *Function* `123-145`
- [[fn-frontend-src-pages-sidebar-components-shapefilemodal-tsx--removefile|removeFile]] — *Function* `147-149`
- [[fn-frontend-src-pages-sidebar-components-shapefilemodal-tsx--handleaddupload|handleAddUpload]] — *Function* `151-199`
- [[fn-frontend-src-pages-sidebar-components-shapefilemodal-tsx--handlereplacedragenter|handleReplaceDragEnter]] — *Function* `203-207`
- [[fn-frontend-src-pages-sidebar-components-shapefilemodal-tsx--handlereplacedragleave|handleReplaceDragLeave]] — *Function* `209-213`
- [[fn-frontend-src-pages-sidebar-components-shapefilemodal-tsx--handlereplacedragover|handleReplaceDragOver]] — *Function* `215-218`
- [[fn-frontend-src-pages-sidebar-components-shapefilemodal-tsx--handlereplacedrop|handleReplaceDrop]] — *Function* `220-229`
- [[fn-frontend-src-pages-sidebar-components-shapefilemodal-tsx--handlereplacefileselect|handleReplaceFileSelect]] — *Function* `231-236`
- [[fn-frontend-src-pages-sidebar-components-shapefilemodal-tsx--validateandsetreplacefiles|validateAndSetReplaceFiles]] — *Function* `238-267`
- [[fn-frontend-src-pages-sidebar-components-shapefilemodal-tsx--handlereplacesubmit|handleReplaceSubmit]] — *Function* `269-392`
- [[fn-frontend-src-pages-sidebar-components-shapefilemodal-tsx--f|f]] — *Function* `295-298`
- [[fn-frontend-src-pages-sidebar-components-shapefilemodal-tsx--formatbytes|formatBytes]] — *Function* `394-400`
- [[fn-frontend-src-pages-sidebar-components-shapefilemodal-tsx--prev|prev]] — *Function* `652-652`
- [[fn-frontend-src-pages-sidebar-components-shapefilemodal-tsx--ext|ext]] — *Function* `721-721`

## Imports (2)
- [[file-frontend-src-components-ui-toaster-tsx|toaster.tsx]]
- [[file-frontend-src-api-index-ts|index.ts]]

## Imported by (1)
- [[file-frontend-src-pages-sidebar-sidebar-tsx|Sidebar.tsx]]
