---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/AnalysisPage/components/AttributesDropdown.tsx", "frontend/src/pages/AnalysisPage/components/AttributesDropdown.tsx", "AttributesDropdown.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/AnalysisPage/components/AttributesDropdown.tsx"
---

# AttributesDropdown.tsx

**Path:** `frontend/src/pages/AnalysisPage/components/AttributesDropdown.tsx`
**Community:** [[com-components-attributes|components-attributes]]

## Contains (2)
- [[fn-frontend-src-pages-analysispage-components-attributesdropdown-tsx--attributesdropdown|AttributesDropdown]] — *Function* `114-194`
- [[fn-frontend-src-pages-analysispage-components-attributesdropdown-tsx--handleattributechange|handleAttributeChange]] — *Function* `120-123`
