---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/sidebar/Sidebar.tsx", "frontend/src/pages/sidebar/Sidebar.tsx", "Sidebar.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/sidebar/Sidebar.tsx"
---

# Sidebar.tsx

**Path:** `frontend/src/pages/sidebar/Sidebar.tsx`
**Community:** [[com-sidebar-shapefile|sidebar-shapefile]]

## Contains (5)
- [[fn-frontend-src-pages-sidebar-sidebar-tsx--sidebar|Sidebar]] — *Function* `20-404`
- [[fn-frontend-src-pages-sidebar-sidebar-tsx--openshapefilemodal|openShapefileModal]] — *Function* `30-32`
- [[fn-frontend-src-pages-sidebar-sidebar-tsx--closeshapefilemodal|closeShapefileModal]] — *Function* `34-36`
- [[fn-frontend-src-pages-sidebar-sidebar-tsx--onsave|onSave]] — *Function* `180-189`
- [[fn-frontend-src-pages-sidebar-sidebar-tsx--s|s]] — *Function* `246-246`

## Imports (7)
- [[file-frontend-src-components-ui-toaster-tsx|toaster.tsx]]
- [[file-frontend-src-api-index-ts|index.ts]]
- [[file-frontend-src-pages-sidebar-components-codingsidebar-tsx|CodingSidebar.tsx]]
- [[file-frontend-src-pages-sidebar-components-treatmentsidebar-tsx|TreatmentSidebar.tsx]]
- [[file-frontend-src-pages-sidebar-components-resetconfirmationdialog-tsx|ResetConfirmationDialog.tsx]]
- [[file-frontend-src-pages-sidebar-components-shapefilemodal-tsx|ShapefileModal.tsx]]
- [[file-frontend-src-pages-sidebar-components-exitconfirmationdialog-tsx|ExitConfirmationDialog.tsx]]

## Imported by (1)
- [[file-frontend-src-layouts-applayout-tsx|AppLayout.tsx]]
