---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/ui/toaster.tsx", "frontend/src/components/ui/toaster.tsx", "toaster.tsx"]
tags: [file, tsx]
path: "frontend/src/components/ui/toaster.tsx"
---

# toaster.tsx

**Path:** `frontend/src/components/ui/toaster.tsx`
**Community:** [[com-ui-toaster|ui-toaster]]

## Contains (1)
- [[fn-frontend-src-components-ui-toaster-tsx--toaster|Toaster]] — *Function* `17-43`

## Imported by (13)
- [[file-frontend-src-main-tsx|main.tsx]]
- [[file-frontend-src-pages-codingpage-codingpage-tsx|codingPage.tsx]]
- [[file-frontend-src-pages-codingpage-components-attributespanel-tsx|AttributesPanel.tsx]]
- [[file-frontend-src-pages-codingpage-components-geodatapanel-tsx|GeoDataPanel.tsx]]
- [[file-frontend-src-pages-pathanalysispage-components-addsegmentsdialog-tsx|AddSegmentsDialog.tsx]]
- [[file-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx|PathAnalysisMapView.tsx]]
- [[file-frontend-src-pages-projects-components-editprojectmodal-tsx|EditProjectModal.tsx]]
- [[file-frontend-src-pages-shapefilemanagement-shapefilemanagementpage-tsx|ShapefileManagementPage.tsx]]
- [[file-frontend-src-pages-shapefilemanagement-components-addshapefileview-tsx|AddShapefileView.tsx]]
- [[file-frontend-src-pages-shapefilemanagement-components-replaceshapefileview-tsx|ReplaceShapefileView.tsx]]
- [[file-frontend-src-pages-sidebar-sidebar-tsx|Sidebar.tsx]]
- [[file-frontend-src-pages-sidebar-components-imageuploadmodal-tsx|ImageUploadModal.tsx]]
- [[file-frontend-src-pages-sidebar-components-shapefilemodal-tsx|ShapefileModal.tsx]]
