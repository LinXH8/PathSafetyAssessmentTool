---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/scoreband/test_thresholds.js", "frontend/src/components/visualization/scoreband/test_thresholds.js", "test_thresholds.js"]
tags: [file, javascript]
path: "frontend/src/components/visualization/scoreband/test_thresholds.js"
---

# test_thresholds.js

**Path:** `frontend/src/components/visualization/scoreband/test_thresholds.js`
**Community:** [[com-scoreband-band|scoreband-band]]

## Contains (1)
- [[fn-frontend-src-components-visualization-scoreband-test-thresholds-js--getbandcolor|getBandColor]] — *Function* `9-23`
