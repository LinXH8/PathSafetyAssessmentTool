---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/sidebar/components/CodingSidebar.tsx", "frontend/src/pages/sidebar/components/CodingSidebar.tsx", "CodingSidebar.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/sidebar/components/CodingSidebar.tsx"
---

# CodingSidebar.tsx

**Path:** `frontend/src/pages/sidebar/components/CodingSidebar.tsx`
**Community:** [[com-components-coding|components-coding]]

## Contains (1)
- [[fn-frontend-src-pages-sidebar-components-codingsidebar-tsx--codingsidebar|CodingSidebar]] — *Function* `14-72`

## Imported by (1)
- [[file-frontend-src-pages-sidebar-sidebar-tsx|Sidebar.tsx]]
