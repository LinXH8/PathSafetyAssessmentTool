---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/CreateProjectPage/createProjectPage.tsx", "frontend/src/pages/CreateProjectPage/createProjectPage.tsx", "createProjectPage.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/CreateProjectPage/createProjectPage.tsx"
---

# createProjectPage.tsx

**Path:** `frontend/src/pages/CreateProjectPage/createProjectPage.tsx`
**Community:** [[com-createprojectpage-tag|createprojectpage-tag]]

## Contains (10)
- [[fn-frontend-src-pages-createprojectpage-createprojectpage-tsx--gettagcolor|getTagColor]] — *Function* `21-38`
- [[fn-frontend-src-pages-createprojectpage-createprojectpage-tsx--createprojectpage|CreateProjectPage]] — *Function* `40-314`
- [[fn-frontend-src-pages-createprojectpage-createprojectpage-tsx--loadfolders|loadFolders]] — *Function* `55-76`
- [[fn-frontend-src-pages-createprojectpage-createprojectpage-tsx--p|p]] — *Function* `67-69`
- [[fn-frontend-src-pages-createprojectpage-createprojectpage-tsx--tag|tag]] — *Function* `68-68`
- [[fn-frontend-src-pages-createprojectpage-createprojectpage-tsx--handletaginputkeydown|handleTagInputKeyDown]] — *Function* `91-103`
- [[fn-frontend-src-pages-createprojectpage-createprojectpage-tsx--removetag|removeTag]] — *Function* `105-107`
- [[fn-frontend-src-pages-createprojectpage-createprojectpage-tsx--oncreate|onCreate]] — *Function* `109-122`
- [[fn-frontend-src-pages-createprojectpage-createprojectpage-tsx--t|t]] — *Function* `215-219`
- [[fn-frontend-src-pages-createprojectpage-createprojectpage-tsx--f|f]] — *Function* `264-268`

## Imports (2)
- [[file-frontend-src-api-index-ts|index.ts]]
- [[file-frontend-src-pages-sidebar-components-imageuploadmodal-tsx|ImageUploadModal.tsx]]

## Imported by (1)
- [[file-frontend-src-app-tsx|App.tsx]]
