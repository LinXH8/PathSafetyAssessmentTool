---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/tmp/simulate_gis_full.py", "tmp/simulate_gis_full.py", "simulate_gis_full.py"]
tags: [file, python]
path: "tmp/simulate_gis_full.py"
---

# simulate_gis_full.py

**Path:** `tmp/simulate_gis_full.py`
**Community:** [[com-tmp-full|tmp-full]]

## Contains (1)
- [[test-tmp-simulate-gis-full-py--test-full-logic|test_full_logic]] — *Test* `23-70`
