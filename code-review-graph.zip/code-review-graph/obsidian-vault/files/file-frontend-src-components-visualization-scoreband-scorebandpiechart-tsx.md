---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/scoreband/ScoreBandPieChart.tsx", "frontend/src/components/visualization/scoreband/ScoreBandPieChart.tsx", "ScoreBandPieChart.tsx"]
tags: [file, tsx]
path: "frontend/src/components/visualization/scoreband/ScoreBandPieChart.tsx"
---

# ScoreBandPieChart.tsx

**Path:** `frontend/src/components/visualization/scoreband/ScoreBandPieChart.tsx`
**Community:** [[com-scoreband-score-2|scoreband-score]]

## Contains (2)
- [[fn-frontend-src-components-visualization-scoreband-scorebandpiechart-tsx--scorebandpiechart|ScoreBandPieChart]] — *Function* `33-213`
- [[fn-frontend-src-components-visualization-scoreband-scorebandpiechart-tsx--renderlabel|renderLabel]] — *Function* `63-85`

## Imports (1)
- [[file-frontend-src-components-visualization-scoreband-colorconstants-ts|colorConstants.ts]]

## Imported by (3)
- [[file-frontend-src-components-visualization-scoreband-overalltreatmentanalysis-tsx|OverallTreatmentAnalysis.tsx]]
- [[file-frontend-src-components-visualization-scoreband-scorebanddistributionpanel-tsx|ScoreBandDistributionPanel.tsx]]
- [[file-frontend-src-pages-pathanalysispage-components-aggregatedscorebandpanel-tsx|AggregatedScoreBandPanel.tsx]]
