---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/common/HelpButton.tsx", "frontend/src/components/common/HelpButton.tsx", "HelpButton.tsx"]
tags: [file, tsx]
path: "frontend/src/components/common/HelpButton.tsx"
---

# HelpButton.tsx

**Path:** `frontend/src/components/common/HelpButton.tsx`
**Community:** [[com-common-help|common-help]]

## Contains (1)
- [[fn-frontend-src-components-common-helpbutton-tsx--helpbutton|HelpButton]] — *Function* `3-43`

## Imported by (1)
- [[file-frontend-src-app-tsx|App.tsx]]
