---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/extract_xml_dates.py", "backend/extract_xml_dates.py", "extract_xml_dates.py"]
tags: [file, python]
path: "backend/extract_xml_dates.py"
---

# extract_xml_dates.py

**Path:** `backend/extract_xml_dates.py`
**Community:** [[com-backend-xml|backend-xml]]

## Contains (1)
- [[fn-backend-extract-xml-dates-py--get-xml-date|get_xml_date]] — *Function* `7-21`
