---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/ShapefileManagement/ShapefileManagementPage.tsx", "frontend/src/pages/ShapefileManagement/ShapefileManagementPage.tsx", "ShapefileManagementPage.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/ShapefileManagement/ShapefileManagementPage.tsx"
---

# ShapefileManagementPage.tsx

**Path:** `frontend/src/pages/ShapefileManagement/ShapefileManagementPage.tsx`
**Community:** [[com-shapefilemanagement-handle|shapefilemanagement-handle]]

## Contains (9)
- [[fn-frontend-src-pages-shapefilemanagement-shapefilemanagementpage-tsx--shapefilemanagementpage|ShapefileManagementPage]] — *Function* `9-230`
- [[fn-frontend-src-pages-shapefilemanagement-shapefilemanagementpage-tsx--loadshapefiles|loadShapefiles]] — *Function* `21-34`
- [[fn-frontend-src-pages-shapefilemanagement-shapefilemanagementpage-tsx--loadcategories|loadCategories]] — *Function* `36-42`
- [[fn-frontend-src-pages-shapefilemanagement-shapefilemanagementpage-tsx--handleopenmodal|handleOpenModal]] — *Function* `44-47`
- [[fn-frontend-src-pages-shapefilemanagement-shapefilemanagementpage-tsx--handleclosemodal|handleCloseModal]] — *Function* `49-52`
- [[fn-frontend-src-pages-shapefilemanagement-shapefilemanagementpage-tsx--handlemodeselect|handleModeSelect]] — *Function* `54-56`
- [[fn-frontend-src-pages-shapefilemanagement-shapefilemanagementpage-tsx--handleuploadcomplete|handleUploadComplete]] — *Function* `58-62`
- [[fn-frontend-src-pages-shapefilemanagement-shapefilemanagementpage-tsx--handledelete|handleDelete]] — *Function* `64-83`
- [[fn-frontend-src-pages-shapefilemanagement-shapefilemanagementpage-tsx--formatbytes|formatBytes]] — *Function* `85-91`

## Imports (3)
- [[file-frontend-src-components-ui-toaster-tsx|toaster.tsx]]
- [[file-frontend-src-api-index-ts|index.ts]]
- [[file-frontend-src-pages-shapefilemanagement-components-uploadmodal-tsx|UploadModal.tsx]]
