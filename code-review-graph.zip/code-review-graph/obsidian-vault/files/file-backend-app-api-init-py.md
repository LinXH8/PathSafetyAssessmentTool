---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/__init__.py", "backend/app/api/__init__.py", "__init__.py"]
tags: [file, python]
path: "backend/app/api/__init__.py"
---

# __init__.py

**Path:** `backend/app/api/__init__.py`
**Community:** [[com-api-register|api-register]]

## Contains (1)
- [[fn-backend-app-api-init-py--register-blueprints|register_blueprints]] — *Function* `6-18`
