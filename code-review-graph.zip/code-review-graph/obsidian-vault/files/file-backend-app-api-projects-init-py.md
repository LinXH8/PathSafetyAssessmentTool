---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/projects/__init__.py", "backend/app/api/projects/__init__.py", "__init__.py"]
tags: [file, python]
path: "backend/app/api/projects/__init__.py"
---

# __init__.py

**Path:** `backend/app/api/projects/__init__.py`

## Imports (1)
- [[file-backend-app-api-projects-routes-py|routes.py]]

## Imported by (1)
- [[file-backend-app-api-projects-width-visualization-py|width_visualization.py]]
