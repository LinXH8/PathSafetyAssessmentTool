---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/Home/home.tsx", "frontend/src/pages/Home/home.tsx", "home.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/Home/home.tsx"
---

# home.tsx

**Path:** `frontend/src/pages/Home/home.tsx`
**Community:** [[com-home-home|home-home]]

## Contains (5)
- [[fn-frontend-src-pages-home-home-tsx--home|Home]] — *Function* `24-222`
- [[fn-frontend-src-pages-home-home-tsx--onrowclick|onRowClick]] — *Function* `78-78`
- [[fn-frontend-src-pages-home-home-tsx--loadproject|loadProject]] — *Function* `81-85`
- [[fn-frontend-src-pages-home-home-tsx--askdelete|askDelete]] — *Function* `88-92`
- [[fn-frontend-src-pages-home-home-tsx--confirmdelete|confirmDelete]] — *Function* `95-114`

## Imports (1)
- [[file-frontend-src-api-index-ts|index.ts]]
