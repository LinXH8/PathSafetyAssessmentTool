---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/LandingPage/landingPage.tsx", "frontend/src/pages/LandingPage/landingPage.tsx", "landingPage.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/LandingPage/landingPage.tsx"
---

# landingPage.tsx

**Path:** `frontend/src/pages/LandingPage/landingPage.tsx`
**Community:** [[com-landingpage-landing|landingpage-landing]]

## Contains (2)
- [[fn-frontend-src-pages-landingpage-landingpage-tsx--landingpage|LandingPage]] — *Function* `8-53`
- [[fn-frontend-src-pages-landingpage-landingpage-tsx--startpsat|startPSAT]] — *Function* `10-10`

## Imports (1)
- [[file-frontend-src-appmeta-ts|appMeta.ts]]

## Imported by (1)
- [[file-frontend-src-app-tsx|App.tsx]]
