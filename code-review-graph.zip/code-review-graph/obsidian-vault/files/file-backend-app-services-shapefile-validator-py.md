---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/shapefile_validator.py", "backend/app/services/shapefile_validator.py", "shapefile_validator.py"]
tags: [file, python]
path: "backend/app/services/shapefile_validator.py"
---

# shapefile_validator.py

**Path:** `backend/app/services/shapefile_validator.py`
**Community:** [[com-services-validate|services-validate]]

## Description

> Shapefile Validator
> Validates GIS shapefiles for compatibility before replacement

## Contains (8)
- [[cls-backend-app-services-shapefile-validator-py--shapefilevalidator|ShapefileValidator]] — *Class* `16-307`
- [[fn-backend-app-services-shapefile-validator-py--validate-replacement|validate_replacement]] — *Function* `20-133`
- [[fn-backend-app-services-shapefile-validator-py--validate-crs|_validate_crs]] — *Function* `136-164`
- [[fn-backend-app-services-shapefile-validator-py--validate-geometry-type|_validate_geometry_type]] — *Function* `167-203`
- [[fn-backend-app-services-shapefile-validator-py--validate-required-columns|_validate_required_columns]] — *Function* `206-234`
- [[fn-backend-app-services-shapefile-validator-py--validate-feature-count|_validate_feature_count]] — *Function* `237-256`
- [[fn-backend-app-services-shapefile-validator-py--validate-empty-geometries|_validate_empty_geometries]] — *Function* `259-274`
- [[fn-backend-app-services-shapefile-validator-py--validate-spatial-bounds|_validate_spatial_bounds]] — *Function* `277-307`

## Imported by (1)
- [[file-backend-app-api-gis-layers-routes-py|routes.py]]
