---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/eslint.config.js", "frontend/eslint.config.js", "eslint.config.js"]
tags: [file, javascript]
path: "frontend/eslint.config.js"
---

# eslint.config.js

**Path:** `frontend/eslint.config.js`
