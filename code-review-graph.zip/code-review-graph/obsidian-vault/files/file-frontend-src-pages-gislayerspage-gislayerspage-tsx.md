---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/GisLayersPage/GisLayersPage.tsx", "frontend/src/pages/GisLayersPage/GisLayersPage.tsx", "GisLayersPage.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/GisLayersPage/GisLayersPage.tsx"
---

# GisLayersPage.tsx

**Path:** `frontend/src/pages/GisLayersPage/GisLayersPage.tsx`
**Community:** [[com-gislayerspage-layers|gislayerspage-layers]]

## Contains (8)
- [[fn-frontend-src-pages-gislayerspage-gislayerspage-tsx--fitbounds|FitBounds]] — *Function* `12-20`
- [[fn-frontend-src-pages-gislayerspage-gislayerspage-tsx--gislayerspage|GisLayersPage]] — *Function* `26-336`
- [[fn-frontend-src-pages-gislayerspage-gislayerspage-tsx--loadlayers|loadLayers]] — *Function* `40-52`
- [[fn-frontend-src-pages-gislayerspage-gislayerspage-tsx--loadgeojson|loadGeoJson]] — *Function* `64-94`
- [[fn-frontend-src-pages-gislayerspage-gislayerspage-tsx--formatbytes|formatBytes]] — *Function* `170-177`
- [[fn-frontend-src-pages-gislayerspage-gislayerspage-tsx--rendertooltip|renderTooltip]] — *Function* `179-187`
- [[fn-frontend-src-pages-gislayerspage-gislayerspage-tsx--file|file]] — *Function* `225-252`
- [[fn-frontend-src-pages-gislayerspage-gislayerspage-tsx--matchmapstate|matchMapState]] — *Function* `338-372`

## Imports (2)
- [[file-frontend-src-components-common-themeawaretilelayer-tsx|ThemeAwareTileLayer.tsx]]
- [[file-frontend-src-api-index-ts|index.ts]]

## Imported by (1)
- [[file-frontend-src-app-tsx|App.tsx]]
