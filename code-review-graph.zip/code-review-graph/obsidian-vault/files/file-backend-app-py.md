---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app.py", "backend/app.py", "app.py"]
tags: [file, python]
path: "backend/app.py"
---

# app.py

**Path:** `backend/app.py`
**Community:** [[com-backend-health|backend-health]]

## Contains (1)
- [[fn-backend-app-py--health|health]] — *Function* `5-6`

## Imports (1)
- [[file-backend-app-py|app.py]]

## Imported by (5)
- [[file-backend-app-py|app.py]]
- [[file-backend-test-flask-endpoint-py|test_flask_endpoint.py]]
- [[file-backend-test-gis-mock-py|test_gis_mock.py]]
- [[file-backend-test-list-shapefiles-py|test_list_shapefiles.py]]
- [[file-backend-test-payload-py|test_payload.py]]
