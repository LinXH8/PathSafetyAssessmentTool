---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/components/FilterPanel.tsx", "frontend/src/pages/PathAnalysisPage/components/FilterPanel.tsx", "FilterPanel.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/PathAnalysisPage/components/FilterPanel.tsx"
---

# FilterPanel.tsx

**Path:** `frontend/src/pages/PathAnalysisPage/components/FilterPanel.tsx`
**Community:** [[com-components-filter|components-filter]]

## Contains (6)
- [[fn-frontend-src-pages-pathanalysispage-components-filterpanel-tsx--filterpanel|FilterPanel]] — *Function* `23-167`
- [[fn-frontend-src-pages-pathanalysispage-components-filterpanel-tsx--toggle|toggle]] — *Function* `26-32`
- [[fn-frontend-src-pages-pathanalysispage-components-filterpanel-tsx--f|f]] — *Function* `28-28`
- [[fn-frontend-src-pages-pathanalysispage-components-filterpanel-tsx--a|a]] — *Function* `100-100`
- [[fn-frontend-src-pages-pathanalysispage-components-filterpanel-tsx--group|group]] — *Function* `115-161`
- [[fn-frontend-src-pages-pathanalysispage-components-filterpanel-tsx--attr|attr]] — *Function* `118-158`

## Imports (2)
- [[file-frontend-src-components-ui-switch-tsx|switch.tsx]]
- [[file-frontend-src-pages-pathanalysispage-components-attributesdropdown-tsx|AttributesDropdown.tsx]]

## Imported by (1)
- [[file-frontend-src-pages-pathanalysispage-pathanalysispage-tsx|pathAnalysisPage.tsx]]
