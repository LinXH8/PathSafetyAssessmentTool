---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/sidebar/components/TreatmentSidebar.tsx", "frontend/src/pages/sidebar/components/TreatmentSidebar.tsx", "TreatmentSidebar.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/sidebar/components/TreatmentSidebar.tsx"
---

# TreatmentSidebar.tsx

**Path:** `frontend/src/pages/sidebar/components/TreatmentSidebar.tsx`
**Community:** [[com-components-treatment|components-treatment]]

## Contains (1)
- [[fn-frontend-src-pages-sidebar-components-treatmentsidebar-tsx--treatmentsidebar|TreatmentSidebar]] — *Function* `10-81`

## Imported by (1)
- [[file-frontend-src-pages-sidebar-sidebar-tsx|Sidebar.tsx]]
