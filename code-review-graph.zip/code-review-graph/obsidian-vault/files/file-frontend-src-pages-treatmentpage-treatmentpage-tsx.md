---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/TreatmentPage/treatmentPage.tsx", "frontend/src/pages/TreatmentPage/treatmentPage.tsx", "treatmentPage.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/TreatmentPage/treatmentPage.tsx"
---

# treatmentPage.tsx

**Path:** `frontend/src/pages/TreatmentPage/treatmentPage.tsx`
**Community:** [[com-treatmentpage-tag|treatmentpage-tag]]

## Contains (12)
- [[fn-frontend-src-pages-treatmentpage-treatmentpage-tsx--gettagbordercolor|getTagBorderColor]] — *Function* `15-19`
- [[fn-frontend-src-pages-treatmentpage-treatmentpage-tsx--gettagcolor|getTagColor]] — *Function* `22-50`
- [[fn-frontend-src-pages-treatmentpage-treatmentpage-tsx--treatmentpage|TreatmentPage]] — *Function* `52-409`
- [[fn-frontend-src-pages-treatmentpage-treatmentpage-tsx--handleverificationupdate|handleVerificationUpdate]] — *Function* `81-94`
- [[fn-frontend-src-pages-treatmentpage-treatmentpage-tsx--onrowclick|onRowClick]] — *Function* `127-138`
- [[fn-frontend-src-pages-treatmentpage-treatmentpage-tsx--toggleselectall|toggleSelectAll]] — *Function* `141-149`
- [[fn-frontend-src-pages-treatmentpage-treatmentpage-tsx--loadproject|loadProject]] — *Function* `151-160`
- [[fn-frontend-src-pages-treatmentpage-treatmentpage-tsx--name|name]] — *Function* `158-158`
- [[fn-frontend-src-pages-treatmentpage-treatmentpage-tsx--handleeditsuccess|handleEditSuccess]] — *Function* `162-181`
- [[fn-frontend-src-pages-treatmentpage-treatmentpage-tsx--prev|prev]] — *Function* `174-179`
- [[fn-frontend-src-pages-treatmentpage-treatmentpage-tsx--p|p]] — *Function* `217-221`
- [[fn-frontend-src-pages-treatmentpage-treatmentpage-tsx--tag|tag]] — *Function* `326-326`

## Imports (2)
- [[file-frontend-src-api-index-ts|index.ts]]
- [[file-frontend-src-pages-projects-components-editprojectmodal-tsx|EditProjectModal.tsx]]

## Imported by (1)
- [[file-frontend-src-app-tsx|App.tsx]]
