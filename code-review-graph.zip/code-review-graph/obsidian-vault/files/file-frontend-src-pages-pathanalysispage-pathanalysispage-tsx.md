---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/PathAnalysisPage/pathAnalysisPage.tsx", "frontend/src/pages/PathAnalysisPage/pathAnalysisPage.tsx", "pathAnalysisPage.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/PathAnalysisPage/pathAnalysisPage.tsx"
---

# pathAnalysisPage.tsx

**Path:** `frontend/src/pages/PathAnalysisPage/pathAnalysisPage.tsx`
**Community:** [[com-pathanalysispage-load|pathanalysispage-load]]

## Contains (2)
- [[fn-frontend-src-pages-pathanalysispage-pathanalysispage-tsx--loadstate|loadState]] — *Function* `14-21`
- [[fn-frontend-src-pages-pathanalysispage-pathanalysispage-tsx--pathanalysispage|PathAnalysisPage]] — *Function* `23-98`

## Imports (4)
- [[file-frontend-src-pages-pathanalysispage-components-filterpanel-tsx|FilterPanel.tsx]]
- [[file-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx|PathAnalysisMapView.tsx]]
- [[file-frontend-src-pages-pathanalysispage-components-attributedistributionchart-tsx|AttributeDistributionChart.tsx]]
- [[file-frontend-src-pages-pathanalysispage-components-aggregatedscorebandpanel-tsx|AggregatedScoreBandPanel.tsx]]

## Imported by (1)
- [[file-frontend-src-app-tsx|App.tsx]]
