---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/temp_script.py", "temp_script.py", "temp_script.py"]
tags: [file, python]
path: "temp_script.py"
---

# temp_script.py

**Path:** `temp_script.py`
