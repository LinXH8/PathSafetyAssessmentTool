---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/ema.py", "backend/app/services/ema.py", "ema.py"]
tags: [file, python]
path: "backend/app/services/ema.py"
---

# ema.py

**Path:** `backend/app/services/ema.py`
**Community:** [[com-services-ema|services-ema]]

## Contains (3)
- [[cls-backend-app-services-ema-py--ema|EMA]] — *Class* `5-32`
- [[fn-backend-app-services-ema-py--init|__init__]] — *Function* `6-16`
- [[fn-backend-app-services-ema-py--forward|forward]] — *Function* `18-32`
