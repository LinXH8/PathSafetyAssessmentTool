---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/tmp/inspect_gis.py", "tmp/inspect_gis.py", "inspect_gis.py"]
tags: [file, python]
path: "tmp/inspect_gis.py"
---

# inspect_gis.py

**Path:** `tmp/inspect_gis.py`
