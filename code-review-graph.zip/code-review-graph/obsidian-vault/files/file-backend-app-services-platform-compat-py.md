---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/platform_compat.py", "backend/app/services/platform_compat.py", "platform_compat.py"]
tags: [file, python]
path: "backend/app/services/platform_compat.py"
---

# platform_compat.py

**Path:** `backend/app/services/platform_compat.py`
**Community:** [[com-services-check|services-check]]

## Description

> Platform compatibility module for handling Windows-specific dependencies.
>
> This module provides conditional imports and stubs for Windows-only modules
> like pythoncom and win32com, allowing the application to run on non-Windows systems.

## Contains (3)
- [[fn-backend-app-services-platform-compat-py--check-windows-feature|check_windows_feature]] — *Function* `31-51`
- [[fn-backend-app-services-platform-compat-py--get-excel-client|get_excel_client]] — *Function* `54-65`
- [[fn-backend-app-services-platform-compat-py--get-pythoncom|get_pythoncom]] — *Function* `68-79`

## Imported by (1)
- [[file-backend-app-services-cyclerap-interface-py|cycleRAP_interface.py]]
