---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/curvature/CurvatureVisualizationPanel.tsx", "frontend/src/components/visualization/curvature/CurvatureVisualizationPanel.tsx", "CurvatureVisualizationPanel.tsx"]
tags: [file, tsx]
path: "frontend/src/components/visualization/curvature/CurvatureVisualizationPanel.tsx"
---

# CurvatureVisualizationPanel.tsx

**Path:** `frontend/src/components/visualization/curvature/CurvatureVisualizationPanel.tsx`
**Community:** [[com-curvature-visualization|curvature-visualization]]

## Contains (3)
- [[fn-frontend-src-components-visualization-curvature-curvaturevisualizationpanel-tsx--curvaturevisualizationpanel|CurvatureVisualizationPanel]] — *Function* `12-176`
- [[fn-frontend-src-components-visualization-curvature-curvaturevisualizationpanel-tsx--loadvisualization|loadVisualization]] — *Function* `23-35`
- [[fn-frontend-src-components-visualization-curvature-curvaturevisualizationpanel-tsx--getlayercolor|getLayerColor]] — *Function* `178-185`

## Imports (3)
- [[file-frontend-src-components-visualization-curvature-curvaturevisualization-tsx|CurvatureVisualization.tsx]]
- [[file-frontend-src-components-visualization-curvature-curvaturediagnostics-tsx|CurvatureDiagnostics.tsx]]
- [[file-frontend-src-api-curvaturevisualization-ts|curvatureVisualization.ts]]
