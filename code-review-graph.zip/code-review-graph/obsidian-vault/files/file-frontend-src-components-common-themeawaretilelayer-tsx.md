---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/common/ThemeAwareTileLayer.tsx", "frontend/src/components/common/ThemeAwareTileLayer.tsx", "ThemeAwareTileLayer.tsx"]
tags: [file, tsx]
path: "frontend/src/components/common/ThemeAwareTileLayer.tsx"
---

# ThemeAwareTileLayer.tsx

**Path:** `frontend/src/components/common/ThemeAwareTileLayer.tsx`
**Community:** [[com-common-theme|common-theme]]

## Contains (1)
- [[fn-frontend-src-components-common-themeawaretilelayer-tsx--themeawaretilelayer|ThemeAwareTileLayer]] — *Function* `4-18`

## Imports (1)
- [[file-frontend-src-components-ui-color-mode-tsx|color-mode.tsx]]

## Imported by (8)
- [[file-frontend-src-components-visualization-curvature-curvaturevisualization-tsx|CurvatureVisualization.tsx]]
- [[file-frontend-src-components-visualization-width-widthvisualization-tsx|WidthVisualization.tsx]]
- [[file-frontend-src-pages-analysispage-components-mapview-tsx|MapView.tsx]]
- [[file-frontend-src-pages-codingpage-components-geodatapanel-tsx|GeoDataPanel.tsx]]
- [[file-frontend-src-pages-gislayerspage-gislayerspage-tsx|GisLayersPage.tsx]]
- [[file-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx|PathAnalysisMapView.tsx]]
- [[file-frontend-src-pages-treatmentpage-components-mapview-tsx|MapView.tsx]]
- [[file-frontend-src-pages-treatmentpage-components-treatmentmapview-tsx|TreatmentMapView.tsx]]
