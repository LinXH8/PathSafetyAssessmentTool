---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/cycleRAP_interface.py", "backend/app/services/cycleRAP_interface.py", "cycleRAP_interface.py"]
tags: [file, python]
path: "backend/app/services/cycleRAP_interface.py"
---

# cycleRAP_interface.py

**Path:** `backend/app/services/cycleRAP_interface.py`
**Community:** [[com-services-cycle|services-cycle]]

## Contains (9)
- [[cls-backend-app-services-cyclerap-interface-py--cyclerap-interface|cycleRAP_interface]] — *Class* `21-349`
- [[fn-backend-app-services-cyclerap-interface-py--init|__init__]] — *Function* `26-27`
- [[fn-backend-app-services-cyclerap-interface-py--initialise|initialise]] — *Function* `30-39`
- [[fn-backend-app-services-cyclerap-interface-py--parse|_parse]] — *Function* `42-47`
- [[fn-backend-app-services-cyclerap-interface-py--get-cyclerap-metadata|get_cycleRAP_metadata]] — *Function* `50-53`
- [[fn-backend-app-services-cyclerap-interface-py--calculate-cyclerap-score|calculate_cycleRAP_score]] — *Function* `57-131`
- [[fn-backend-app-services-cyclerap-interface-py--evaluate-treatment-suggestions|evaluate_treatment_suggestions]] — *Function* `134-229`
- [[fn-backend-app-services-cyclerap-interface-py--get-treatment-pairs|get_treatment_pairs]] — *Function* `232-257`
- [[fn-backend-app-services-cyclerap-interface-py--write-default-config|_write_default_config]] — *Function* `260-349`

## Imports (2)
- [[file-backend-app-services-serializer-py|serializer.py]]
- [[file-backend-app-services-platform-compat-py|platform_compat.py]]
