---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/CodingPage/components/AttributesPanel.tsx", "frontend/src/pages/CodingPage/components/AttributesPanel.tsx", "AttributesPanel.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/CodingPage/components/AttributesPanel.tsx"
---

# AttributesPanel.tsx

**Path:** `frontend/src/pages/CodingPage/components/AttributesPanel.tsx`
**Community:** [[com-components-group|components-group]]

## Contains (5)
- [[fn-frontend-src-pages-codingpage-components-attributespanel-tsx--groupentries|groupEntries]] — *Function* `163-209`
- [[fn-frontend-src-pages-codingpage-components-attributespanel-tsx--todisplaystring|toDisplayString]] — *Function* `211-215`
- [[fn-frontend-src-pages-codingpage-components-attributespanel-tsx--attributespanel|AttributesPanel]] — *Function* `218-538`
- [[fn-frontend-src-pages-codingpage-components-attributespanel-tsx--ismanuallyedited|isManuallyEdited]] — *Function* `249-283`
- [[fn-frontend-src-pages-codingpage-components-attributespanel-tsx--code|code]] — *Function* `473-480`

## Imports (2)
- [[file-frontend-src-api-index-ts|index.ts]]
- [[file-frontend-src-components-ui-toaster-tsx|toaster.tsx]]

## Imported by (2)
- [[file-frontend-src-pages-codingpage-codingpage-tsx|codingPage.tsx]]
- [[file-frontend-src-pages-treatmentpage-treatmentdetailpage-tsx|treatmentDetailPage.tsx]]
