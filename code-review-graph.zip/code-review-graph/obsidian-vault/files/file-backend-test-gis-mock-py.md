---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/test_gis_mock.py", "backend/test_gis_mock.py", "test_gis_mock.py"]
tags: [file, python]
path: "backend/test_gis_mock.py"
---

# test_gis_mock.py

**Path:** `backend/test_gis_mock.py`

## Imports (1)
- [[file-backend-app-py|app.py]]
