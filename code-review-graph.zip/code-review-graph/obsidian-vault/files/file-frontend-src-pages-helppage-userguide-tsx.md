---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/HelpPage/UserGuide.tsx", "frontend/src/pages/HelpPage/UserGuide.tsx", "UserGuide.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/HelpPage/UserGuide.tsx"
---

# UserGuide.tsx

**Path:** `frontend/src/pages/HelpPage/UserGuide.tsx`
**Community:** [[com-helppage-user|helppage-user]]

## Contains (2)
- [[fn-frontend-src-pages-helppage-userguide-tsx--userguide|UserGuide]] — *Function* `15-75`
- [[fn-frontend-src-pages-helppage-userguide-tsx--markdowncontent|MarkdownContent]] — *Function* `77-142`

## Imports (1)
- [[file-frontend-src-components-ui-color-mode-tsx|color-mode.tsx]]

## Imported by (1)
- [[file-frontend-src-pages-helppage-helppage-tsx|helpPage.tsx]]
