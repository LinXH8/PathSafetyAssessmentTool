---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/appMeta.ts", "frontend/src/appMeta.ts", "appMeta.ts"]
tags: [file, typescript]
path: "frontend/src/appMeta.ts"
---

# appMeta.ts

**Path:** `frontend/src/appMeta.ts`

## Imported by (1)
- [[file-frontend-src-pages-landingpage-landingpage-tsx|landingPage.tsx]]
