---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/scoreband/ScoreBandDistributionPanel.tsx", "frontend/src/components/visualization/scoreband/ScoreBandDistributionPanel.tsx", "ScoreBandDistributionPanel.tsx"]
tags: [file, tsx]
path: "frontend/src/components/visualization/scoreband/ScoreBandDistributionPanel.tsx"
---

# ScoreBandDistributionPanel.tsx

**Path:** `frontend/src/components/visualization/scoreband/ScoreBandDistributionPanel.tsx`
**Community:** [[com-scoreband-score|scoreband-score]]

## Contains (2)
- [[fn-frontend-src-components-visualization-scoreband-scorebanddistributionpanel-tsx--scorebanddistributionpanel|ScoreBandDistributionPanel]] — *Function* `47-238`
- [[fn-frontend-src-components-visualization-scoreband-scorebanddistributionpanel-tsx--handlescoresupdated|handleScoresUpdated]] — *Function* `123-126`

## Imports (1)
- [[file-frontend-src-components-visualization-scoreband-scorebandpiechart-tsx|ScoreBandPieChart.tsx]]
