---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/prediction.py", "backend/app/services/prediction.py", "prediction.py"]
tags: [file, python]
path: "backend/app/services/prediction.py"
---

# prediction.py

**Path:** `backend/app/services/prediction.py`
**Community:** [[com-services-compute|services-compute]]

## Contains (17)
- [[cls-backend-app-services-prediction-py--cyclerap-coding-helper|CycleRAP_Coding_Helper]] — *Class* `21-522`
- [[fn-backend-app-services-prediction-py--init|__init__]] — *Function* `26-27`
- [[fn-backend-app-services-prediction-py--initialise|initialise]] — *Function* `33-87`
- [[fn-backend-app-services-prediction-py--safe-fuse|_safe_fuse]] — *Function* `40-44`
- [[fn-backend-app-services-prediction-py--load-one|_load_one]] — *Function* `58-66`
- [[fn-backend-app-services-prediction-py--build-class-sets|_build_class_sets]] — *Function* `93-109`
- [[fn-backend-app-services-prediction-py--ids|_ids]] — *Function* `96-97`
- [[fn-backend-app-services-prediction-py--build-masks|_build_masks]] — *Function* `115-145`
- [[fn-backend-app-services-prediction-py--detect-obstacles|_detect_obstacles]] — *Function* `151-199`
- [[fn-backend-app-services-prediction-py--analyze-obstacle|_analyze_obstacle]] — *Function* `205-224`
- [[fn-backend-app-services-prediction-py--compute-width-restriction|_compute_width_restriction]] — *Function* `227-249`
- [[fn-backend-app-services-prediction-py--compute-adjroad|_compute_adjroad]] — *Function* `255-282`
- [[fn-backend-app-services-prediction-py--check-bottom-presence|_check_bottom_presence]] — *Function* `288-290`
- [[fn-backend-app-services-prediction-py--check-bottom-majority|_check_bottom_majority]] — *Function* `293-305`
- [[fn-backend-app-services-prediction-py--assign-attributes|_assign_attributes]] — *Function* `311-415`
- [[fn-backend-app-services-prediction-py--convert-to-coded|_convert_to_coded]] — *Function* `421-471`
- [[fn-backend-app-services-prediction-py--autocode|autocode]] — *Function* `477-522`

## Imports (1)
- [[file-backend-app-services-serializer-py|serializer.py]]
