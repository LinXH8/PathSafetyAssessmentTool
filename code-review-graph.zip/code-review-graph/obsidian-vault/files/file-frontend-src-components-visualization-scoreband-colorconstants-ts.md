---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/visualization/scoreband/colorConstants.ts", "frontend/src/components/visualization/scoreband/colorConstants.ts", "colorConstants.ts"]
tags: [file, typescript]
path: "frontend/src/components/visualization/scoreband/colorConstants.ts"
---

# colorConstants.ts

**Path:** `frontend/src/components/visualization/scoreband/colorConstants.ts`
**Community:** [[com-scoreband-risk|scoreband-risk]]

## Description

> STANDARDIZED RISK BAND THRESHOLDS
> This is the single source of truth for all safety band categorization in the application.
>
> All pages must use these exact thresholds:
> - Low: <10
> - Medium: 10-25
> - High: 25-60
> - Extreme: >60
>
> Used consistently throughout the application for:
> - Risk Score visualization (Coding Page, Path Analysis)
> - Crash Type Risk bands (VB, BB, SB, BP)
> - Score-based UI elements (Attribute Analysis filters)

## Contains (3)
- [[fn-frontend-src-components-visualization-scoreband-colorconstants-ts--getriskbandcolor|getRiskBandColor]] — *Function* `28-33`
- [[fn-frontend-src-components-visualization-scoreband-colorconstants-ts--getriskbandlabel|getRiskBandLabel]] — *Function* `39-44`
- [[fn-frontend-src-components-visualization-scoreband-colorconstants-ts--getriskbandindex|getRiskBandIndex]] — *Function* `50-55`

## Imported by (5)
- [[file-frontend-src-components-visualization-scoreband-scorebandpiechart-tsx|ScoreBandPieChart.tsx]]
- [[file-frontend-src-components-visualization-scoreband-segmentscorescard-tsx|SegmentScoresCard.tsx]]
- [[file-frontend-src-pages-codingpage-components-geodatapanel-tsx|GeoDataPanel.tsx]]
- [[file-frontend-src-pages-pathanalysispage-components-aggregatedscorebandpanel-tsx|AggregatedScoreBandPanel.tsx]]
- [[file-frontend-src-pages-pathanalysispage-components-pathanalysismapview-tsx|PathAnalysisMapView.tsx]]
