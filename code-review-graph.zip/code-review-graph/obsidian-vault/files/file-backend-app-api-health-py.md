---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/api/health.py", "backend/app/api/health.py", "health.py"]
tags: [file, python]
path: "backend/app/api/health.py"
---

# health.py

**Path:** `backend/app/api/health.py`
**Community:** [[com-api-ping|api-ping]]

## Contains (1)
- [[fn-backend-app-api-health-py--ping|ping]] — *Function* `6-7`
