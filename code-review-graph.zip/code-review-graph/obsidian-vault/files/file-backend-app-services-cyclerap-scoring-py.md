---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/app/services/cyclerap_scoring.py", "backend/app/services/cyclerap_scoring.py", "cyclerap_scoring.py"]
tags: [file, python]
path: "backend/app/services/cyclerap_scoring.py"
---

# cyclerap_scoring.py

**Path:** `backend/app/services/cyclerap_scoring.py`
**Community:** [[com-services-calculate|services-calculate]]

## Description

> Native Python implementation of cycleRAP scoring algorithm (CycleRAP v2.11).
>
> This module provides an accurate implementation of the cycleRAP score calculation
> based on the CycleRAP Model v2.11, ported from cyclerap_accurate_v3.jsx.
>
> No Windows, Excel, or VBA macros required - pure Python implementation.

## Contains (11)
- [[fn-backend-app-services-cyclerap-scoring-py--get-risk|get_risk]] — *Function* `115-117`
- [[fn-backend-app-services-cyclerap-scoring-py--get-cond|get_cond]] — *Function* `120-122`
- [[fn-backend-app-services-cyclerap-scoring-py--get-aadt-risk-factor|get_aadt_risk_factor]] — *Function* `147-155`
- [[fn-backend-app-services-cyclerap-scoring-py--get-road-speed-risk-factor|get_road_speed_risk_factor]] — *Function* `158-164`
- [[fn-backend-app-services-cyclerap-scoring-py--calculate-cm3|calculate_cm3]] — *Function* `168-202`
- [[fn-backend-app-services-cyclerap-scoring-py--calculate-cm16|calculate_cm16]] — *Function* `205-227`
- [[fn-backend-app-services-cyclerap-scoring-py--calculate-cm25|calculate_cm25]] — *Function* `230-249`
- [[fn-backend-app-services-cyclerap-scoring-py--calculate-cm40|calculate_cm40]] — *Function* `252-288`
- [[fn-backend-app-services-cyclerap-scoring-py--calculate-cyclerap-score|calculate_cyclerap_score]] — *Function* `291-424`
- [[fn-backend-app-services-cyclerap-scoring-py--calculate-risk-band-for-type|calculate_risk_band_for_type]] — *Function* `428-463`
- [[fn-backend-app-services-cyclerap-scoring-py--calculate-cyclerap-score-native|calculate_cyclerap_score_native]] — *Function* `466-518`

## Imports (1)
- [[file-backend-app-services-serializer-py|serializer.py]]

## Imported by (2)
- [[file-backend-app-api-projects-routes-py|routes.py]]
- [[file-test-los-scoring-py|test_los_scoring.py]]
