---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/vite-env.d.ts", "frontend/src/vite-env.d.ts", "vite-env.d.ts"]
tags: [file, typescript]
path: "frontend/src/vite-env.d.ts"
---

# vite-env.d.ts

**Path:** `frontend/src/vite-env.d.ts`
