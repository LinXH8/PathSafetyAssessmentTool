---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/components/ui/color-mode.tsx", "frontend/src/components/ui/color-mode.tsx", "color-mode.tsx"]
tags: [file, tsx]
path: "frontend/src/components/ui/color-mode.tsx"
---

# color-mode.tsx

**Path:** `frontend/src/components/ui/color-mode.tsx`
**Community:** [[com-ui-color|ui-color]]

## Contains (5)
- [[fn-frontend-src-components-ui-color-mode-tsx--colormodeprovider|ColorModeProvider]] — *Function* `12-22`
- [[fn-frontend-src-components-ui-color-mode-tsx--usecolormode|useColorMode]] — *Function* `32-43`
- [[fn-frontend-src-components-ui-color-mode-tsx--togglecolormode|toggleColorMode]] — *Function* `35-37`
- [[fn-frontend-src-components-ui-color-mode-tsx--usecolormodevalue|useColorModeValue]] — *Function* `45-48`
- [[fn-frontend-src-components-ui-color-mode-tsx--colormodeicon|ColorModeIcon]] — *Function* `50-53`

## Imported by (5)
- [[file-frontend-src-components-common-themeawaretilelayer-tsx|ThemeAwareTileLayer.tsx]]
- [[file-frontend-src-components-ui-provider-tsx|provider.tsx]]
- [[file-frontend-src-pages-helppage-developerguide-tsx|DeveloperGuide.tsx]]
- [[file-frontend-src-pages-helppage-userguide-tsx|UserGuide.tsx]]
- [[file-frontend-src-pages-helppage-helppage-tsx|helpPage.tsx]]
