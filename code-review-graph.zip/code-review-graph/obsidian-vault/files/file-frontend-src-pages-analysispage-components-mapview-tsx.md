---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/frontend/src/pages/AnalysisPage/components/MapView.tsx", "frontend/src/pages/AnalysisPage/components/MapView.tsx", "MapView.tsx"]
tags: [file, tsx]
path: "frontend/src/pages/AnalysisPage/components/MapView.tsx"
---

# MapView.tsx

**Path:** `frontend/src/pages/AnalysisPage/components/MapView.tsx`
**Community:** [[com-components-view|components-view]]

## Contains (2)
- [[fn-frontend-src-pages-analysispage-components-mapview-tsx--setviewonload|SetViewOnLoad]] — *Function* `12-20`
- [[fn-frontend-src-pages-analysispage-components-mapview-tsx--mapview|MapView]] — *Function* `22-46`

## Imports (1)
- [[file-frontend-src-components-common-themeawaretilelayer-tsx|ThemeAwareTileLayer.tsx]]
