---
aliases: ["/Users/xh/School/Final Year/LTA/PathSafetyAssessmentTool/backend/visualize_facility_width.py", "backend/visualize_facility_width.py", "visualize_facility_width.py"]
tags: [file, python]
path: "backend/visualize_facility_width.py"
---

# visualize_facility_width.py

**Path:** `backend/visualize_facility_width.py`
**Community:** [[com-backend-width|backend-width]]

## Description

> Facility Width per Direction Visualization and Debugging Tool
>
> Similar to the curvature visualization, this tool helps analyze and debug
> the facility width calculation by showing:
> 1. What width values are found at each search radius
> 2. Which layer (cycling/shared/footpath) provides the width
> 3. The actual numeric width values from shapefiles
> 4. Search pattern visualization
> 5. Diagnostic information for troubleshooting
>
> This helps identify issues like:
> - Why all results are "Narrow"
> - Whether shapefiles have correct WIDTH values
> - If search radii are appropriate
> - Which paths are being matched

## Contains (4)
- [[fn-backend-visualize-facility-width-py--analyze-width-at-point-detailed|analyze_width_at_point_detailed]] — *Function* `41-175`
- [[fn-backend-visualize-facility-width-py--visualize-width-analysis|visualize_width_analysis]] — *Function* `178-247`
- [[fn-backend-visualize-facility-width-py--create-width-visualization|create_width_visualization]] — *Function* `250-356`
- [[fn-backend-visualize-facility-width-py--main|main]] — *Function* `359-409`

## Imports (2)
- [[file-backend-app-services-init-py|__init__.py]]
- [[file-backend-app-utils-path-width-curvature-py|path_width_curvature.py]]
